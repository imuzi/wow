
EnemyGridDBChr = {
	["KeyBinds"] = {
		[266] = {
			{
				["actiontext"] = "",
				["key"] = "type1",
				["action"] = "_target",
			}, -- [1]
		},
		[267] = {
			{
				["actiontext"] = "",
				["key"] = "type1",
				["action"] = "_target",
			}, -- [1]
		},
		[265] = {
			{
				["actiontext"] = "",
				["key"] = "type1",
				["action"] = "_target",
			}, -- [1]
		},
	},
	["spellRangeCheck"] = {
		[266] = "暗影箭",
		[267] = "混乱之箭",
		[265] = "痛楚",
	},
	["debuffsBanned"] = {
	},
	["specEnabled"] = {
		[266] = true,
		[267] = true,
		[265] = true,
	},
}
