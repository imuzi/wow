
weizPVPOptions = {
	["profileKeys"] = {
		["Ennyin - 埃加洛尔"] = "Ennyin - 埃加洛尔",
	},
	["profiles"] = {
		["Ennyin - 埃加洛尔"] = {
			["Options"] = {
				["Addon"] = {
					["Version"] = "1.81.1",
					["VersionSplashSeen"] = true,
					["VersionNumber"] = 1802.1,
				},
				["Frames"] = {
					["Point"] = "RIGHT",
					["Width"] = 251.0001220703125,
					["Y"] = -68.95730590820312,
					["X"] = -80.2996826171875,
					["Header"] = {
						["Point"] = "RIGHT",
						["Width"] = 251.0001220703125,
						["Y"] = 58.54269409179688,
						["Height"] = 26.00000762939453,
						["X"] = -80.2996826171875,
					},
				},
			},
		},
	},
}
