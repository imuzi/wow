
RETabBinderSettings = {
	["OpenWorld"] = false,
	["DefaultKey"] = true,
	["SilentMode"] = false,
}
