
C2MSBT_SettingsPC = {
	["ChanList"] = {
	},
	["CustomOutput"] = {
	},
	["CustomOutputFrame"] = {
	},
}
