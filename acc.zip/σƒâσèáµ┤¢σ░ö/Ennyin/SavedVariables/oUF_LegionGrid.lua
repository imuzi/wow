
LegionGridomf2Char = nil
