
DJBags_DB_Char = {
	["categories"] = {
	},
	["newItems"] = {
	},
	["VERSION"] = 0.8,
}
