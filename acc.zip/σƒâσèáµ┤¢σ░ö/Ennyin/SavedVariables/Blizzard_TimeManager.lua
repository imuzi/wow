
BlizzardStopwatchOptions = {
	["position"] = {
		["y"] = 221.9247131347656,
		["x"] = 66.0000228881836,
	},
}
