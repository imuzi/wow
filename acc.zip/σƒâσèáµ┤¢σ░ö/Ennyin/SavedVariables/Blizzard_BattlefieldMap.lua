
BattlefieldMapOptions = {
	["locked"] = false,
	["opacity"] = 0.6714320778846741,
	["showPlayers"] = true,
	["position"] = {
		["y"] = 701.2169799804688,
		["x"] = 300.5956726074219,
	},
}
