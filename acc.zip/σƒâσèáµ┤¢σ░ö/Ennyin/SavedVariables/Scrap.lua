
Scrap_CharSets = {
	["ml"] = {
	},
	["list"] = {
	},
}
