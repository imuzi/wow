
PlaterDBChr = {
	["resources_on_target"] = false,
	["debuffsBanned"] = {
	},
	["spellRangeCheckRangeEnemy"] = {
		[266] = 40,
		[267] = 40,
		[265] = 40,
	},
	["spellRangeCheckRangeFriendly"] = {
		[266] = 40,
		[267] = 40,
		[265] = 40,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-920-03C9F6E5"] = true,
	},
	["spellRangeCheck"] = {
		[266] = "暗影箭",
		[267] = "混乱之箭",
		[265] = "痛楚",
	},
	["minimap"] = {
	},
	["first_run2"] = {
		["Player-743-019FE1FE"] = true,
	},
}
