
NarcissusDB_PC = {
	["UseAlias"] = false,
	["PlayerAlias"] = "",
	["EquipmentSetDB"] = {
	},
}
