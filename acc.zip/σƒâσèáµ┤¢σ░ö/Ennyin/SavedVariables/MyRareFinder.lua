
MyRareFinderNormalRares = true
MyRareFinderDailyRares = true
MyRareFinderOneTimeRares = true
MyRareFinderKilledOTRares = true
