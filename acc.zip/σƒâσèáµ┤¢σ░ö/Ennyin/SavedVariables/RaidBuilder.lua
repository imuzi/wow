
RAIDBUILDER_CHARACTER_DB = {
	["profileKeys"] = {
		["Ennyin - 索瑞森"] = "Ennyin - 索瑞森",
	},
	["profiles"] = {
		["Ennyin - 索瑞森"] = {
		},
	},
}
