
MyslotSettings = {
	["minimap"] = {
		["hide"] = false,
	},
}
