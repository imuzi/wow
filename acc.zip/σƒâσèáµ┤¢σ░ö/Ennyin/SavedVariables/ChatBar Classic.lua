
ChatBar_VerticalDisplay = false
ChatBar_AlternateOrientation = false
ChatBar_HideSpecialChannels = true
ChatBar_TextOnButtonDisplay = true
ChatBar_ButtonFlashing = true
ChatBar_BarBorder = false
ChatBar_ButtonText = false
ChatBar_StoredStickies = {
}
ChatBar_HiddenButtons = {
	["集合石"] = true,
	["交易"] = true,
	["本地防务"] = true,
	["大脚世界频道"] = true,
	["pvp"] = true,
	["寻求组队"] = true,
	["大喊"] = true,
	["组队频道"] = true,
	["表情"] = true,
}
ChatBar_TextChannelNumbers = false
ChatBar_HideAllButtons = false
ChatBar_AltArt = 5
ChatBar_ChannelBindings = {
}
ChatBar_ButtonScale = 1
ChatBar_isLock = false
