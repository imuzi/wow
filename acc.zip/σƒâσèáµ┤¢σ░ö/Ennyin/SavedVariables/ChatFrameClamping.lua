
ChatFrameClampingChar = "default"
FriendsMicroButtonChar = false
GryphonsChar = false
