
PVPScoreSaves = {
	["PVPScoreOption_OutPut_Kills"] = false,
	["PVPScoreOption_OutPut_Duel"] = true,
	["PVPScoreOption_Arena_OutPut_Ratio"] = true,
	["PVPScoreOption_RoleFrame_Duel"] = true,
	["PVPScoreOption_OutPut_ArenaRating"] = false,
	["PVPScoreOption_CacheDate"] = 7,
	["PVPScoreOption_OutPut_Ratio"] = true,
	["PVPScoreOption_Target_Frame_Star_PointX"] = 7,
	["PVPScoreOption_OutPut_Arena"] = true,
	["PVPScoreOption_Target_Frame_Star"] = true,
	["PVPScoreOption_OutPut_RatedBattlegrounds"] = false,
	["PVPScoreOption_RoleFrame_Ratio"] = true,
	["PVPScoreOption_Target_Frame_Star_PointY"] = 33,
	["PVPScoreOption_RoleFrame_Arena"] = true,
}
