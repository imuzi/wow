
TrufiGCDChSave = {
	["TooltipEnable"] = true,
	["TooltipStopMove"] = true,
	["TrGCDQueueFr"] = {
		{
			["point"] = "CENTER",
			["enable"] = false,
			["text"] = "Player",
			["fade"] = "Left",
			["y"] = 0,
			["x"] = 0,
			["speed"] = 15,
			["width"] = 3,
			["size"] = 24,
		}, -- [1]
		{
			["point"] = "CENTER",
			["enable"] = true,
			["text"] = "Party 1",
			["fade"] = "Left",
			["y"] = 76.44451904296875,
			["x"] = 265.778076171875,
			["speed"] = 13.75,
			["width"] = 3,
			["size"] = 22,
		}, -- [2]
		{
			["point"] = "CENTER",
			["enable"] = true,
			["text"] = "Party 2",
			["fade"] = "Left",
			["y"] = 53.33340835571289,
			["x"] = 269.3335266113281,
			["speed"] = 15,
			["width"] = 3,
			["size"] = 24,
		}, -- [3]
		{
			["point"] = "CENTER",
			["enable"] = true,
			["text"] = "Party 3",
			["fade"] = "Left",
			["y"] = 27.55549812316895,
			["x"] = 270.22216796875,
			["speed"] = 15,
			["width"] = 3,
			["size"] = 24,
		}, -- [4]
		{
			["point"] = "CENTER",
			["enable"] = false,
			["text"] = "Party 4",
			["fade"] = "Left",
			["y"] = 0,
			["x"] = 0,
			["speed"] = 15,
			["width"] = 3,
			["size"] = 24,
		}, -- [5]
		{
			["point"] = "CENTER",
			["enable"] = true,
			["text"] = "Arena 1",
			["fade"] = "Left",
			["y"] = -4.444564819335938,
			["x"] = 370.6669006347656,
			["speed"] = 15.625,
			["width"] = 3,
			["size"] = 25,
		}, -- [6]
		{
			["point"] = "CENTER",
			["enable"] = true,
			["text"] = "Arena 2",
			["fade"] = "Left",
			["y"] = -31.99994659423828,
			["x"] = 371.5560607910156,
			["speed"] = 14.375,
			["width"] = 3,
			["size"] = 23,
		}, -- [7]
		{
			["point"] = "CENTER",
			["enable"] = true,
			["text"] = "Arena 3",
			["fade"] = "Left",
			["y"] = -59.5555305480957,
			["x"] = 373.3335876464844,
			["speed"] = 15,
			["width"] = 3,
			["size"] = 24,
		}, -- [8]
		{
			["point"] = "CENTER",
			["enable"] = true,
			["text"] = "Arena 4",
			["fade"] = "Left",
			["y"] = 0,
			["x"] = 0,
			["speed"] = 15,
			["width"] = 3,
			["size"] = 24,
		}, -- [9]
		{
			["point"] = "CENTER",
			["enable"] = true,
			["text"] = "Arena 5",
			["fade"] = "Left",
			["y"] = 0,
			["x"] = 0,
			["speed"] = 14.375,
			["width"] = 3,
			["size"] = 23,
		}, -- [10]
		{
			["point"] = "CENTER",
			["enable"] = true,
			["text"] = "Target",
			["fade"] = "Left",
			["y"] = 0,
			["x"] = 0,
			["speed"] = 14.375,
			["width"] = 3,
			["size"] = 23,
		}, -- [11]
		{
			["point"] = "CENTER",
			["enable"] = true,
			["text"] = "Focus",
			["fade"] = "Left",
			["y"] = 0,
			["x"] = 0,
			["speed"] = 14.375,
			["width"] = 3,
			["size"] = 23,
		}, -- [12]
	},
	["TooltipSpellID"] = false,
	["EnableIn"] = {
		["World"] = true,
		["Arena"] = true,
		["Enable"] = true,
		["Raid"] = false,
		["Bg"] = false,
		["PvE"] = false,
	},
	["TrGCDBL"] = {
		6603, -- [1]
		75, -- [2]
		7384, -- [3]
	},
	["ModScroll"] = true,
}
