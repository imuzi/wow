
ATTCharDB = nil
