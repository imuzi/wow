
RagnarokPerCharDB = {
	["autoload"] = {
		["party"] = "Default",
		["Default"] = "PVP关键技能监视",
		["enable"] = true,
		["arena"] = "Default",
		["raid"] = "Default",
		["pvp"] = "Default",
	},
}
