
AucAdvancedLocal = {
	["Stats"] = {
	},
}
