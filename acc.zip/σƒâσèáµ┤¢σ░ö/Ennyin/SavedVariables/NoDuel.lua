
NoDuelData = {
	["whisper"] = "?>",
	["minimappos"] = 174.300043962057,
}
