
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["time"] = 1587045476,
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame12"] = {
			["maxElements"] = 128,
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[14:32:42]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq68|k:93:290:BN_WHISPER:|Kq68|k:夜小五#51505|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cfffefefe|Kq68|k|r|h|cffd8d8d8]|r: 好久不见宝贝~",
					["r"] = 0,
					["b"] = 0.9647059440612793,
					["g"] = 1,
					["timestamp"] = 556697.712,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						76, -- [3]
						77, -- [4]
						["n"] = 4,
					},
					["serverTime"] = 1613111568,
				}, -- [1]
			},
			["headIndex"] = 1,
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame13"] = {
			["maxElements"] = 128,
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[23:26:08]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2131:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: halo",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3647974.889,
					["serverTime"] = 1610810767,
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:26:16]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2132:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: hi",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3647982.889,
					["serverTime"] = 1610810775,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:26:22]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2133:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 这配置好吓人",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3647988.272,
					["serverTime"] = 1610810781,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:26:34]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2137:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 菜刀队 。娱乐啊",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648000.439,
					["serverTime"] = 1610810793,
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:26:54]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2138:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 你们都多少分了",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648020.639,
					["serverTime"] = 1610810813,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:07]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2139:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 2600多",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648033.306,
					["serverTime"] = 1610810826,
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:29]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2145:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 我昨天被朋友喊去 说他们打大号军训下",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648055.922,
					["serverTime"] = 1610810848,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:39]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2150:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 然后呢",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648065.522,
					["serverTime"] = 1610810858,
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:43]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2151:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 然后进去一看 全是1600  2000的单子",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648070.072,
					["serverTime"] = 1610810862,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:53]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2153:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 进场2400",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648079.44,
					["serverTime"] = 1610810872,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:56]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2154:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 连输三把",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648082.639,
					["serverTime"] = 1610810875,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:02]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2155:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 我差点吐血了",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648088.506,
					["serverTime"] = 1610810881,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:03]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2156:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 都是单子。 不是坑你分吗",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648089.906,
					["serverTime"] = 1610810882,
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:12]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2157:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 关键是",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648098.839,
					["serverTime"] = 1610810891,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:24]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2161:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 都呆呆的",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648110.456,
					["serverTime"] = 1610810903,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:29:51]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2181:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 。。。 先把低保混了",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648197.722,
					["serverTime"] = 1610810990,
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:30:04]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2183:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 现在每周不就是为了低保么",
					["b"] = 1,
					["r"] = 1,
					["g"] = 0.501960813999176,
					["timestamp"] = 3648210.289,
					["serverTime"] = 1610811003,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
				}, -- [17]
			},
			["headIndex"] = 17,
		},
		["ChatFrame11"] = {
			["maxElements"] = 128,
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:31]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:5:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: ..",
					["r"] = 0,
					["b"] = 0.9647059440612793,
					["g"] = 1,
					["timestamp"] = 555847.08,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["serverTime"] = 1613110717,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:35]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:6:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: lm？",
					["r"] = 0,
					["b"] = 0.9647059440612793,
					["g"] = 1,
					["timestamp"] = 555851.182,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["serverTime"] = 1613110721,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:37]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:7:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: 。。。。",
					["r"] = 0,
					["b"] = 0.9647059440612793,
					["g"] = 1,
					["timestamp"] = 555853.4,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						1, -- [3]
						3, -- [4]
						["n"] = 4,
					},
					["serverTime"] = 1613110723,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:45]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:10:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: 来 一起排zc",
					["r"] = 0,
					["b"] = 0.9647059440612793,
					["g"] = 1,
					["timestamp"] = 555861.12,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["serverTime"] = 1613110731,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:45]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:11:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: 小号混分",
					["r"] = 0,
					["b"] = 0.9647059440612793,
					["g"] = 1,
					["timestamp"] = 555861.505,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						1, -- [3]
						3, -- [4]
						["n"] = 4,
					},
					["serverTime"] = 1613110731,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:50]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:12:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: 。。。",
					["r"] = 0,
					["b"] = 0.9647059440612793,
					["g"] = 1,
					["timestamp"] = 555866.022,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						1, -- [3]
						3, -- [4]
						["n"] = 4,
					},
					["serverTime"] = 1613110736,
				}, -- [6]
			},
			["headIndex"] = 6,
		},
		["ChatFrame14"] = {
			["maxElements"] = 128,
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:16]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq76|k:46:2158:BN_WHISPER:|Kq76|k:泰兰风#5409|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cff006fdc|Kq76|k|r|h|cffd8d8d8]|r: 打多少了",
					["b"] = 0.9647059440612793,
					["r"] = 0,
					["g"] = 1,
					["timestamp"] = 3648102.889,
					["serverTime"] = 1610810895,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						334, -- [3]
						335, -- [4]
						["n"] = 4,
					},
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:23]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq76|k:46:2159:BN_WHISPER:|Kq76|k:泰兰风#5409|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cff006fdc|Kq76|k|r|h|cffd8d8d8]|r: 2200没啊",
					["b"] = 0.9647059440612793,
					["r"] = 0,
					["g"] = 1,
					["timestamp"] = 3648109.406,
					["serverTime"] = 1610810902,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						334, -- [3]
						335, -- [4]
						["n"] = 4,
					},
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:23]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq76|k:46:2160:BN_WHISPER:|Kq76|k:泰兰风#5409|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cff006fdc|Kq76|k|r|h|cffd8d8d8]|r: 打的玩",
					["b"] = 0.9647059440612793,
					["r"] = 0,
					["g"] = 1,
					["timestamp"] = 3648109.822,
					["serverTime"] = 1610810902,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						334, -- [3]
						336, -- [4]
						["n"] = 4,
					},
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:26]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq76|k:46:2163:BN_WHISPER:|Kq76|k:泰兰风#5409|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cff006fdc|Kq76|k|r|h|cffd8d8d8]|r: 天天打",
					["b"] = 0.9647059440612793,
					["r"] = 0,
					["g"] = 1,
					["timestamp"] = 3648112.922,
					["serverTime"] = 1610810905,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						334, -- [3]
						335, -- [4]
						["n"] = 4,
					},
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:31]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq76|k:46:2164:BN_WHISPER:|Kq76|k:泰兰风#5409|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cff006fdc|Kq76|k|r|h|cffd8d8d8]|r: 什么组合啊",
					["b"] = 0.9647059440612793,
					["r"] = 0,
					["g"] = 1,
					["timestamp"] = 3648117.139,
					["serverTime"] = 1610810910,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						334, -- [3]
						335, -- [4]
						["n"] = 4,
					},
				}, -- [5]
			},
			["headIndex"] = 5,
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 1,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[16:43:19]|h|r [W From] |cffd8d8d8[|r|Hplayer:两女星球杯-血色十字军:570:WHISPER:两女星球杯-血色十字军|h|cffd8bc3f60|r:|cfffe7b09两女星球杯|r-|cff4db55c血色十|r:1|h|cffd8d8d8]|r: |cff00ff00Ennyin|r, 感谢你对我使用灵魂石. :)",
					["serverTime"] = 1617093798,
					["r"] = 1,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						88, -- [3]
						89, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 271840.9,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [1]
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 35,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:11]|h|r |TInterface\\FriendsFrame\\UI-Toast-ToastIcons.tga:16:16:0:0:128:64:2:29:34:61|t|HBNplayer:|Kq10|k:66:2132:BN_INLINE_TOAST_ALERT:0|h[|Kq10|k]|h已经离线。",
					["serverTime"] = 1617100690,
					["r"] = 0.5098039507865906,
					["extraData"] = {
						54, -- [1]
						false, -- [2]
						51, -- [3]
						96, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278732.594,
					["g"] = 0.7725490927696228,
					["b"] = 1,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:11]|h|r |TInterface\\FriendsFrame\\UI-Toast-ToastIcons.tga:16:16:0:0:128:64:2:29:34:61|t|HBNplayer:|Kq10|k:66:2133:BN_INLINE_TOAST_ALERT:0|h[|Kq10|k] (|TInterface\\ChatFrame\\UI-ChatIcon-Battlenet:14:14:0:0|tPzei)|h已经上线。",
					["serverTime"] = 1617100690,
					["r"] = 0.5098039507865906,
					["extraData"] = {
						54, -- [1]
						false, -- [2]
						51, -- [3]
						96, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278732.594,
					["g"] = 0.7725490927696228,
					["b"] = 1,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:11]|h|r |TInterface\\FriendsFrame\\UI-Toast-ToastIcons.tga:16:16:0:0:128:64:2:29:34:61|t|HBNplayer:|Kq10|k:66:2134:BN_INLINE_TOAST_ALERT:0|h[|Kq10|k] (|TInterface\\ChatFrame\\UI-ChatIcon-Battlenet:14:14:0:0|tPzei)|h已经上线。",
					["serverTime"] = 1617100690,
					["r"] = 0.5098039507865906,
					["extraData"] = {
						54, -- [1]
						false, -- [2]
						51, -- [3]
						96, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278733.295,
					["g"] = 0.7725490927696228,
					["b"] = 1,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:21]|h|r 你已经加入了随机战场的队列。",
					["serverTime"] = 1617100700,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278742.923,
					["g"] = 1,
					["b"] = 0,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:35]|h|r 你获得了物品：|cffffffff|Hitem:183165::::::::60:267::::1:28:742:::|h[渊誓十字弩]|h|r。",
					["serverTime"] = 1617100714,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278757.389,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:38]|h|r 你拾取了75银币, 1铜币",
					["serverTime"] = 1617100717,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						false, -- [2]
						26, -- [3]
						138, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278760.206,
					["g"] = 1,
					["b"] = 0,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:47]|h|r 你获得了战利品：|cff9d9d9d|Hitem:178134::::::::60:267:::::::|h[瞬灭之指]|h|r。",
					["serverTime"] = 1617100726,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278769.272,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:39:07]|h|r 你获得了战利品：|cffffffff|Hitem:173202::::::::60:267:::::::|h[萦亡布]|h|rx2。",
					["serverTime"] = 1617100747,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278789.372,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:39:08]|h|r 你拾取了4金币, 80银币, 81铜币",
					["serverTime"] = 1617100748,
					["r"] = 1,
					["extraData"] = {
						29, -- [1]
						false, -- [2]
						26, -- [3]
						138, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278790.172,
					["g"] = 1,
					["b"] = 0,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:39:08]|h|r 你获得了：|cffffffff|Hcurrency:1767:0|h[冥殇]|h|r x3。",
					["serverTime"] = 1617100748,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278790.272,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:39:25]|h|r 专精拾取已设置为：痛苦",
					["serverTime"] = 1617100765,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 278807.352,
					["g"] = 1,
					["b"] = 0,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:39:26]|h|r zoned between map instances",
					["timestamp"] = 278807.352,
					["serverTime"] = 1617100766,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:39:26]|h|r currentZoneType()none",
					["timestamp"] = 278807.352,
					["serverTime"] = 1617100766,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:39:26]|h|r HOOK: SGA ONLY PLAY 4 UNITS'S SPELL IN BG",
					["timestamp"] = 278807.352,
					["serverTime"] = 1617100766,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:39:26]|h|r HOOK: Plater friendlyplayer SIZE LESS WIDER",
					["timestamp"] = 278807.352,
					["serverTime"] = 1617100766,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:39:27]|h|r 你已经加入了随机战场的队列。",
					["serverTime"] = 1617100767,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278808.71,
					["g"] = 1,
					["b"] = 0,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:40:38]|h|r 专精拾取已设置为：痛苦",
					["serverTime"] = 1617100837,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 278880.04,
					["g"] = 1,
					["b"] = 0,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:40:39]|h|r zoned between map instances",
					["timestamp"] = 278880.04,
					["serverTime"] = 1617100838,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:40:39]|h|r currentZoneType()none",
					["timestamp"] = 278880.04,
					["serverTime"] = 1617100838,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:40:39]|h|r HOOK: SGA ONLY PLAY 4 UNITS'S SPELL IN BG",
					["timestamp"] = 278880.04,
					["serverTime"] = 1617100838,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:40:39]|h|r HOOK: Plater friendlyplayer SIZE LESS WIDER",
					["timestamp"] = 278880.04,
					["serverTime"] = 1617100838,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:40:39]|h|r 你已经加入了随机战场的队列。",
					["serverTime"] = 1617100838,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278881.246,
					["g"] = 1,
					["b"] = 0,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:21]|h|r 你在荒猎团中的声望值提高了2000点。",
					["serverTime"] = 1617100880,
					["r"] = 0.501960813999176,
					["extraData"] = {
						36, -- [1]
						false, -- [2]
						173, -- [3]
						174, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278922.806,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:21]|h|r 你获得了物品：|cffa335ee|Hitem:181476::::::::60:267::74::1:28:2060:::|h[荒猎团的礼物]|h|r。",
					["serverTime"] = 1617100880,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278922.922,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:21]|h|r 突袭噬渊完成。",
					["serverTime"] = 1617100880,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278922.956,
					["g"] = 1,
					["b"] = 0,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:22]|h|r 你获得了：|cffa335ee|Hcurrency:1191:0|h[勇气点数]|h|r x50。",
					["serverTime"] = 1617100881,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278923.823,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:25]|h|r 你获得了物品：|cffa335ee|Hitem:176832::::::::60:267:::::::|h[灵种根粒]|h|rx3。",
					["serverTime"] = 1617100884,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278926.856,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:25]|h|r 你获得了物品：|cff1eff00|Hitem:176921::::::::60:267:::::::|h[时空之叶]|h|rx2。",
					["serverTime"] = 1617100884,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278926.856,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:25]|h|r 你获得了物品：|cff0070dd|Hitem:176922::::::::60:267:::::::|h[荒野魅夜花]|h|rx3。",
					["serverTime"] = 1617100884,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278926.856,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:25]|h|r 你获得了物品：|cff9d9d9d|Hitem:184403::::::::60:267:::::::|h[梦饵蜡烛]|h|rx15。",
					["serverTime"] = 1617100884,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278926.924,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:25]|h|r 你获得了物品：|cffa335ee|Hitem:182750::::::::60:267::74:3:1472:5900:7245:2:28:2060:37:5:::|h[肉食追踪者]|h|r。",
					["serverTime"] = 1617100884,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278926.924,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:25]|h|r 你获得了物品：|cff9d9d9d|Hitem:181490::::::::60:267:::::::|h[荒野神符]|h|rx5。",
					["serverTime"] = 1617100884,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278926.924,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:25]|h|r 你获得了物品：|cff9d9d9d|Hitem:181489::::::::60:267:::::::|h[泊星十四行诗集]|h|rx10。",
					["serverTime"] = 1617100884,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278926.924,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:41:53]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:红颜丿醉-幽暗沼泽:2159:CHANNEL:5|h|cffa9d271红颜丿醉|r-|cff05c922幽暗沼|r|h|cffd8d8d8]|r: 布、皮、锁、板、首饰橙胚，代工免费，廉价成品，卡牌，全职业168装绑，需要的MMMM！",
					["serverTime"] = 1617100912,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						false, -- [2]
						3, -- [3]
						71, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278954.756,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:43:23]|h|r |TInterface\\FriendsFrame\\UI-Toast-ToastIcons.tga:16:16:0:0:128:64:2:29:34:61|t|HBNplayer:|Kq113|k:72:2160:BN_INLINE_TOAST_ALERT:0|h[|Kq113|k] (|TInterface\\ChatFrame\\UI-ChatIcon-Battlenet:14:14:0:0|t低俗的信仰)|h已经上线。",
					["serverTime"] = 1617101002,
					["r"] = 0.5098039507865906,
					["extraData"] = {
						54, -- [1]
						false, -- [2]
						51, -- [3]
						175, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 279044.974,
					["g"] = 0.7725490927696228,
					["b"] = 1,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:33]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x10。",
					["serverTime"] = 1617100412,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278454.835,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:33]|h|r 你获得了10点荣誉。",
					["serverTime"] = 1617100412,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278454.835,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:34]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1617100413,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						24, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278455.822,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:34]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100413,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278456.439,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:34]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100413,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278456.439,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:45]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100424,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278467.205,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:45]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100424,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278467.205,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:48]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100427,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278470.265,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:48]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100427,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278470.283,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:55]|h|r 铁山拷-迅捷微风收集到了艾泽里特！",
					["serverTime"] = 1617100434,
					["r"] = 0,
					["extraData"] = {
						38, -- [1]
						false, -- [2]
						32, -- [3]
						33, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278477.289,
					["g"] = 0.6823529601097107,
					["b"] = 0.9372549653053284,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:55]|h|r 马迪亚斯·肖尔大师说： 又有艾泽里特喷发点！看看地图，把它们拿下！",
					["serverTime"] = 1617100434,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						20, -- [3]
						21, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278477.493,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:56]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x10。",
					["serverTime"] = 1617100435,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278478.305,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:56]|h|r 你获得了10点荣誉。",
					["serverTime"] = 1617100435,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278478.305,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:33:57]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1617100436,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						24, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278479.306,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:00]|h|r 君思予-拉贾克斯收集到了艾泽里特！",
					["serverTime"] = 1617100439,
					["r"] = 0,
					["extraData"] = {
						38, -- [1]
						false, -- [2]
						32, -- [3]
						33, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278481.622,
					["g"] = 0.6823529601097107,
					["b"] = 0.9372549653053284,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:01]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x10。",
					["serverTime"] = 1617100440,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278482.639,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:01]|h|r 你获得了10点荣誉。",
					["serverTime"] = 1617100440,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278482.639,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:02]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1617100441,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						24, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278483.619,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:06]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100445,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278488.189,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:06]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100445,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278488.189,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:20]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100459,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278502.34,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:20]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100459,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278502.34,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:27]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100466,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278509.289,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:27]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100466,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278509.31,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:38]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100477,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278519.795,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:38]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100477,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278519.795,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:46]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100485,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278528.189,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:46]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100485,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278528.189,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:52]|h|r 顶天牛肉干店-贫瘠之地收集到了艾泽里特！",
					["serverTime"] = 1617100491,
					["r"] = 0,
					["extraData"] = {
						38, -- [1]
						false, -- [2]
						32, -- [3]
						33, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278534.195,
					["g"] = 0.6823529601097107,
					["b"] = 0.9372549653053284,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:52]|h|r 掩饰回忆-石锤收集到了艾泽里特！",
					["serverTime"] = 1617100491,
					["r"] = 0,
					["extraData"] = {
						38, -- [1]
						false, -- [2]
						32, -- [3]
						33, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278534.195,
					["g"] = 0.6823529601097107,
					["b"] = 0.9372549653053284,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:52]|h|r 切莫太宰-冰风岗收集到了艾泽里特！",
					["serverTime"] = 1617100491,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278534.288,
					["g"] = 0,
					["b"] = 0,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:53]|h|r 联盟已经收集了超过1200份艾泽里特，离胜利不远了！",
					["serverTime"] = 1617100492,
					["r"] = 0,
					["extraData"] = {
						38, -- [1]
						false, -- [2]
						32, -- [3]
						33, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278534.766,
					["g"] = 0.6823529601097107,
					["b"] = 0.9372549653053284,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:53]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x20。",
					["serverTime"] = 1617100492,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278535.209,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:53]|h|r 你获得了20点荣誉。",
					["serverTime"] = 1617100492,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278535.232,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:54]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1617100493,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						24, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278536.209,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:54]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1617100493,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						24, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278536.209,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:54]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1617100493,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						24, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278536.302,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:56]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100495,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278537.906,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:56]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100495,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278537.906,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:57]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100496,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278539.485,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:57]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100496,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278539.501,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:59]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100498,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278541.558,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:34:59]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100498,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278541.558,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:03]|h|r |Hchannel:INSTANCE_CHAT|h[I] |h|cffd8d8d8[|r|Hplayer:云游者灬-索瑞森:2084:INSTANCE_CHAT|h|cffd8bc3f60|r:|cffc59a6c云游者灬|r-|cff9ae694索瑞森|r:1|h|cffd8d8d8]|r: 新点 1DZ 1AM",
					["serverTime"] = 1617100502,
					["r"] = 1,
					["extraData"] = {
						63, -- [1]
						false, -- [2]
						27, -- [3]
						170, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278544.772,
					["g"] = 0.4980392456054688,
					["b"] = 0,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:18]|h|r 马迪亚斯·肖尔大师说： 补给来了！去拿吧，勇士们！",
					["serverTime"] = 1617100517,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						20, -- [3]
						21, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278560.189,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:26]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x3。",
					["serverTime"] = 1617100525,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278567.962,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:26]|h|r 你获得了3点荣誉。",
					["serverTime"] = 1617100525,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278567.962,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:38]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x3。",
					["serverTime"] = 1617100537,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278580.285,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:38]|h|r 你获得了3点荣誉。",
					["serverTime"] = 1617100537,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278580.285,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:40]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x3。",
					["serverTime"] = 1617100539,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278582.44,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:40]|h|r 你获得了3点荣誉。",
					["serverTime"] = 1617100539,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278582.44,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:46]|h|r 速效丶揪心丸-安苏收集到了艾泽里特！",
					["serverTime"] = 1617100545,
					["r"] = 0,
					["extraData"] = {
						38, -- [1]
						false, -- [2]
						32, -- [3]
						33, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278588.425,
					["g"] = 0.6823529601097107,
					["b"] = 0.9372549653053284,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:46]|h|r Shourenvokup-阿纳克洛斯收集到了艾泽里特！",
					["serverTime"] = 1617100545,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278588.521,
					["g"] = 0,
					["b"] = 0,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:47]|h|r 马迪亚斯·肖尔大师说： 部落没拿到那份艾泽里特。干得漂亮！",
					["serverTime"] = 1617100546,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						20, -- [3]
						21, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278588.624,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:47]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x10。",
					["serverTime"] = 1617100546,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278589.458,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:47]|h|r 你获得了10点荣誉。",
					["serverTime"] = 1617100546,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278589.458,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:48]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1617100548,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						24, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278590.423,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:48]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1617100548,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						24, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278590.51,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:52]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100552,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278594.456,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:35:52]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100552,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278594.486,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:02]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100562,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278603.602,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:02]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100562,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278603.602,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:11]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100571,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278612.808,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:11]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100571,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278612.826,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:13]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1617100573,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278615.116,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:13]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1617100573,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278615.116,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:19]|h|r 顶天牛肉干店-贫瘠之地收集到了艾泽里特！",
					["serverTime"] = 1617100579,
					["r"] = 0,
					["extraData"] = {
						38, -- [1]
						false, -- [2]
						32, -- [3]
						33, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278620.806,
					["g"] = 0.6823529601097107,
					["b"] = 0.9372549653053284,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:20]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x10。",
					["serverTime"] = 1617100580,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278621.827,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:20]|h|r 你获得了10点荣誉。",
					["serverTime"] = 1617100580,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278621.827,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:21]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1617100581,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						24, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278622.838,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:38]|h|r 速效丶揪心丸-安苏收集到了艾泽里特！",
					["serverTime"] = 1617100598,
					["r"] = 0,
					["extraData"] = {
						38, -- [1]
						false, -- [2]
						32, -- [3]
						33, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278639.811,
					["g"] = 0.6823529601097107,
					["b"] = 0.9372549653053284,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:38]|h|r 联盟获得了胜利！",
					["serverTime"] = 1617100598,
					["r"] = 0,
					["extraData"] = {
						38, -- [1]
						false, -- [2]
						32, -- [3]
						33, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278639.843,
					["g"] = 0.6823529601097107,
					["b"] = 0.9372549653053284,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:38]|h|r 马迪亚斯·肖尔大师说： 干得好，勇士！乌瑞恩国王知道了一定会大喜过望。为了联盟！",
					["serverTime"] = 1617100598,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						20, -- [3]
						21, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278639.956,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:38]|h|r 你获得了物品：|cff0070dd|Hitem:137642::::::::60:267:::::::|h[荣耀印记]|h|r。",
					["serverTime"] = 1617100598,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278639.956,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:39]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x180。",
					["serverTime"] = 1617100599,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278640.855,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:39]|h|r 你获得了30点荣誉。",
					["serverTime"] = 1617100599,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278640.855,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:39]|h|r 你获得了：|cffa335ee|Hcurrency:1602:0|h[征服点数]|h|r x8。",
					["serverTime"] = 1617100599,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278640.905,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:40]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1617100600,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						24, -- [3]
						25, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278641.822,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:40]|h|r |cfffe7b09流氓小小兎|r-贫瘠之地已经离开了副本队伍。",
					["serverTime"] = 1617100600,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278642.139,
					["g"] = 1,
					["b"] = 0,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:40]|h|r |cffa5a5a5云游者灬|r-索瑞森已经离开了副本队伍。",
					["serverTime"] = 1617100600,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278642.439,
					["g"] = 1,
					["b"] = 0,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:41]|h|r |cffc59a6c速效丶揪心丸|r-安苏已经离开了副本队伍。",
					["serverTime"] = 1617100601,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278642.643,
					["g"] = 1,
					["b"] = 0,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:41]|h|r |cffa22fc8君思予|r-拉贾克斯已经离开了副本队伍。",
					["serverTime"] = 1617100601,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278642.643,
					["g"] = 1,
					["b"] = 0,
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:41]|h|r |cfff38bb9本人换名字了|r-安威玛尔已经离开了副本队伍。",
					["serverTime"] = 1617100601,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278642.913,
					["g"] = 1,
					["b"] = 0,
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:41]|h|r 你已经被移出队伍",
					["serverTime"] = 1617100601,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278643.339,
					["g"] = 1,
					["b"] = 0,
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:45]|h|r 你的队伍已经解散。",
					["serverTime"] = 1617100605,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278647.422,
					["g"] = 1,
					["b"] = 0,
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:46]|h|r 专精拾取已设置为：痛苦",
					["serverTime"] = 1617100606,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 278647.422,
					["g"] = 1,
					["b"] = 0,
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:46]|h|r zoned between map instances",
					["timestamp"] = 278647.422,
					["serverTime"] = 1617100606,
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:46]|h|r currentZoneType()none",
					["timestamp"] = 278647.422,
					["serverTime"] = 1617100606,
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:46]|h|r HOOK: SGA ONLY PLAY 4 UNITS'S SPELL IN BG",
					["timestamp"] = 278647.422,
					["serverTime"] = 1617100606,
				}, -- [124]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:46]|h|r HOOK: Plater friendlyplayer SIZE LESS WIDER",
					["timestamp"] = 278647.422,
					["serverTime"] = 1617100606,
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:36:48]|h|r |TInterface\\ICONS\\INV_MawEye_Grey.blp:20|t 噬渊中的|cFFFF0000|Hspell:335417|h[搜魂者]|h|r现在会立刻对你发起攻击。",
					["serverTime"] = 1617100608,
					["r"] = 1,
					["extraData"] = {
						17, -- [1]
						false, -- [2]
						68, -- [3]
						164, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278649.605,
					["g"] = 0.501960813999176,
					["b"] = 0.250980406999588,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:09]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x4。",
					["serverTime"] = 1617100688,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						36, -- [3]
						37, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278730.799,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [127]
				{
					["message"] = "|cff979797|Hpratcopy|h[18:38:09]|h|r 你获得了4点荣誉。",
					["serverTime"] = 1617100688,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						38, -- [3]
						39, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 278730.799,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [128]
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}
