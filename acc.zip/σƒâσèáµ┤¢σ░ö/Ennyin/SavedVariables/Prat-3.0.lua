
Prat3CharDB = {
	["history"] = {
		["cmdhistory"] = {
			["ChatFrame10EditBox"] = {
			},
			["ChatFrame7EditBox"] = {
			},
			["ChatFrame5EditBox"] = {
			},
			["ChatFrame8EditBox"] = {
			},
			["ChatFrame4EditBox"] = {
			},
			["ChatFrame6EditBox"] = {
			},
			["ChatFrame9EditBox"] = {
			},
			["ChatFrame2EditBox"] = {
			},
			["ChatFrame3EditBox"] = {
			},
			["ChatFrame1EditBox"] = {
			},
		},
	},
}
Prat3HighCPUPerCharDB = {
	["time"] = 1587045476,
	["scrollback"] = {
		["ChatFrame5"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame4"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame3"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame12"] = {
			["maxElements"] = 128,
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[14:32:42]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq68|k:93:290:BN_WHISPER:|Kq68|k:夜小五#51505|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cfffefefe|Kq68|k|r|h|cffd8d8d8]|r: 好久不见宝贝~",
					["serverTime"] = 1613111568,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						76, -- [3]
						77, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 556697.712,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [1]
			},
			["headIndex"] = 1,
		},
		["ChatFrame7"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame6"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame13"] = {
			["maxElements"] = 128,
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[23:26:08]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2131:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: halo",
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810767,
					["timestamp"] = 3647974.889,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:26:16]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2132:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: hi",
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810775,
					["timestamp"] = 3647982.889,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:26:22]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2133:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 这配置好吓人",
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810781,
					["timestamp"] = 3647988.272,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:26:34]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2137:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 菜刀队 。娱乐啊",
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810793,
					["timestamp"] = 3648000.439,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:26:54]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2138:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 你们都多少分了",
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810813,
					["timestamp"] = 3648020.639,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:07]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2139:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 2600多",
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810826,
					["timestamp"] = 3648033.306,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:29]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2145:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 我昨天被朋友喊去 说他们打大号军训下",
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810848,
					["timestamp"] = 3648055.922,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:39]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2150:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 然后呢",
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810858,
					["timestamp"] = 3648065.522,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:43]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2151:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 然后进去一看 全是1600  2000的单子",
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810862,
					["timestamp"] = 3648070.072,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:53]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2153:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 进场2400",
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810872,
					["timestamp"] = 3648079.44,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:27:56]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2154:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 连输三把",
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810875,
					["timestamp"] = 3648082.639,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:02]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2155:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 我差点吐血了",
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810881,
					["timestamp"] = 3648088.506,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:03]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2156:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 都是单子。 不是坑你分吗",
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810882,
					["timestamp"] = 3648089.906,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:12]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2157:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 关键是",
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810891,
					["timestamp"] = 3648098.839,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:24]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2161:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 都呆呆的",
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810903,
					["timestamp"] = 3648110.456,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:29:51]|h|r [W To] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2181:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 。。。 先把低保混了",
					["extraData"] = {
						10, -- [1]
						false, -- [2]
						328, -- [3]
						329, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610810990,
					["timestamp"] = 3648197.722,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:30:04]|h|r [W From] |cffd8d8d8[|r|Hplayer:酒酿圆籽-死亡之翼:2183:WHISPER:酒酿圆籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe酒酿圆籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: 现在每周不就是为了低保么",
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						328, -- [3]
						330, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1610811003,
					["timestamp"] = 3648210.289,
					["g"] = 0.501960813999176,
					["r"] = 1,
				}, -- [17]
			},
			["headIndex"] = 17,
		},
		["ChatFrame11"] = {
			["maxElements"] = 128,
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:31]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:5:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: ..",
					["serverTime"] = 1613110717,
					["r"] = 0,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 555847.08,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:35]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:6:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: lm？",
					["serverTime"] = 1613110721,
					["r"] = 0,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 555851.182,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:37]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:7:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: 。。。。",
					["serverTime"] = 1613110723,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						1, -- [3]
						3, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 555853.4,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:45]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:10:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: 来 一起排zc",
					["serverTime"] = 1613110731,
					["r"] = 0,
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						1, -- [3]
						2, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 555861.12,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:45]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:11:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: 小号混分",
					["serverTime"] = 1613110731,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						1, -- [3]
						3, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 555861.505,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[14:18:50]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq23|k:105:12:BN_WHISPER:|Kq23|k:imheasalways#5367|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cffc31d39|Kq23|k|r|h|cffd8d8d8]|r: 。。。",
					["serverTime"] = 1613110736,
					["r"] = 0,
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						1, -- [3]
						3, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 555866.022,
					["g"] = 1,
					["b"] = 0.9647059440612793,
				}, -- [6]
			},
			["headIndex"] = 6,
		},
		["ChatFrame14"] = {
			["maxElements"] = 128,
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:16]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq76|k:46:2158:BN_WHISPER:|Kq76|k:泰兰风#5409|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cff006fdc|Kq76|k|r|h|cffd8d8d8]|r: 打多少了",
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						334, -- [3]
						335, -- [4]
						["n"] = 4,
					},
					["b"] = 0.9647059440612793,
					["serverTime"] = 1610810895,
					["timestamp"] = 3648102.889,
					["g"] = 1,
					["r"] = 0,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:23]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq76|k:46:2159:BN_WHISPER:|Kq76|k:泰兰风#5409|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cff006fdc|Kq76|k|r|h|cffd8d8d8]|r: 2200没啊",
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						334, -- [3]
						335, -- [4]
						["n"] = 4,
					},
					["b"] = 0.9647059440612793,
					["serverTime"] = 1610810902,
					["timestamp"] = 3648109.406,
					["g"] = 1,
					["r"] = 0,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:23]|h|r [W From] |cffd8d8d8[|r|HBNplayer:|Kq76|k:46:2160:BN_WHISPER:|Kq76|k:泰兰风#5409|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cff006fdc|Kq76|k|r|h|cffd8d8d8]|r: 打的玩",
					["extraData"] = {
						52, -- [1]
						false, -- [2]
						334, -- [3]
						336, -- [4]
						["n"] = 4,
					},
					["b"] = 0.9647059440612793,
					["serverTime"] = 1610810902,
					["timestamp"] = 3648109.822,
					["g"] = 1,
					["r"] = 0,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:26]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq76|k:46:2163:BN_WHISPER:|Kq76|k:泰兰风#5409|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cff006fdc|Kq76|k|r|h|cffd8d8d8]|r: 天天打",
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						334, -- [3]
						335, -- [4]
						["n"] = 4,
					},
					["b"] = 0.9647059440612793,
					["serverTime"] = 1610810905,
					["timestamp"] = 3648112.922,
					["g"] = 1,
					["r"] = 0,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:28:31]|h|r [W To] |cffd8d8d8[|r|HBNplayer:|Kq76|k:46:2164:BN_WHISPER:|Kq76|k:泰兰风#5409|h|TInterface\\FriendsFrame\\Battlenet-WoWicon:14:0:0:0|t|cff006fdc|Kq76|k|r|h|cffd8d8d8]|r: 什么组合啊",
					["extraData"] = {
						53, -- [1]
						false, -- [2]
						334, -- [3]
						335, -- [4]
						["n"] = 4,
					},
					["b"] = 0.9647059440612793,
					["serverTime"] = 1610810910,
					["timestamp"] = 3648117.139,
					["g"] = 1,
					["r"] = 0,
				}, -- [5]
			},
			["headIndex"] = 5,
		},
		["ChatFrame8"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 18,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[02:34:21]|h|r [S] |cffd8d8d8[|r|Hplayer:希女王安牧-安苏:129:SAY|h|cffd8bc3f60|r:|cfffefefe希女王安牧|r-|cffddc83b安苏|r:3|h|cffd8d8d8]|r: [通用语] 驱散-->|cff71d5ff|Hspell:191587:0|h[恶性瘟疫]|h|r",
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						29, -- [3]
						30, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1616178860,
					["timestamp"] = 1181049.745,
					["g"] = 1,
					["r"] = 1,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[02:34:21]|h|r [S] |cffd8d8d8[|r|Hplayer:希女王安牧-安苏:130:SAY|h|cffd8bc3f60|r:|cfffefefe希女王安牧|r-|cffddc83b安苏|r:3|h|cffd8d8d8]|r: [通用语] 驱散-->|cff71d5ff|Hspell:335467:0|h[噬灵疫病]|h|r",
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						29, -- [3]
						30, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1616178860,
					["timestamp"] = 1181049.745,
					["g"] = 1,
					["r"] = 1,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[02:34:21]|h|r [S] |cffd8d8d8[|r|Hplayer:希女王安牧-安苏:131:SAY|h|cffd8bc3f60|r:|cfffefefe希女王安牧|r-|cffddc83b安苏|r:3|h|cffd8d8d8]|r: [通用语] 驱散-->|cff71d5ff|Hspell:55095:0|h[冰霜疫病]|h|r",
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						29, -- [3]
						30, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1616178860,
					["timestamp"] = 1181049.745,
					["g"] = 1,
					["r"] = 1,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[02:34:21]|h|r [S] |cffd8d8d8[|r|Hplayer:希女王安牧-安苏:132:SAY|h|cffd8bc3f60|r:|cfffefefe希女王安牧|r-|cffddc83b安苏|r:3|h|cffd8d8d8]|r: [通用语] 驱散-->|cff71d5ff|Hspell:55078:0|h[血之疫病]|h|r",
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						29, -- [3]
						30, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1616178860,
					["timestamp"] = 1181049.745,
					["g"] = 1,
					["r"] = 1,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[02:34:21]|h|r [S] |cffd8d8d8[|r|Hplayer:希女王安牧-安苏:133:SAY|h|cffd8bc3f60|r:|cfffefefe希女王安牧|r-|cffddc83b安苏|r:3|h|cffd8d8d8]|r: [通用语] 驱散-->|cff71d5ff|Hspell:853:0|h[制裁之锤]|h|r",
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						29, -- [3]
						30, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1616178860,
					["timestamp"] = 1181049.745,
					["g"] = 1,
					["r"] = 1,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[02:34:21]|h|r [S] |cffd8d8d8[|r|Hplayer:希女王安牧-安苏:134:SAY|h|cffd8bc3f60|r:|cfffefefe希女王安牧|r-|cffddc83b安苏|r:3|h|cffd8d8d8]|r: [通用语] 驱散-->|cff71d5ff|Hspell:34914:0|h[吸血鬼之触]|h|r",
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						29, -- [3]
						30, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1616178860,
					["timestamp"] = 1181049.745,
					["g"] = 1,
					["r"] = 1,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[02:34:21]|h|r [S] |cffd8d8d8[|r|Hplayer:希女王安牧-安苏:135:SAY|h|cffd8bc3f60|r:|cfffefefe希女王安牧|r-|cffddc83b安苏|r:3|h|cffd8d8d8]|r: [通用语] 驱散-->|cff71d5ff|Hspell:589:0|h[暗言术：痛]|h|r",
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						29, -- [3]
						30, -- [4]
						["n"] = 4,
					},
					["b"] = 1,
					["serverTime"] = 1616178860,
					["timestamp"] = 1181049.745,
					["g"] = 1,
					["r"] = 1,
				}, -- [7]
				{
					["message"] = "0天，20小时，55分钟，50秒",
					["timestamp"] = 1181049.745,
				}, -- [8]
				{
					["message"] = "========== 回卷结束 ==========",
					["timestamp"] = 1181049.745,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[23:30:50]|h|r [S] |cffd8d8d8[|r|Hplayer:大熊法-奎尔萨拉斯:10:SAY|h|cff3ec6ea大熊法|r-|cff74dc99奎尔萨|r|h|cffd8d8d8]|r: 没死",
					["serverTime"] = 1616254249,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						6, -- [3]
						7, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1181090.645,
					["g"] = 1,
					["b"] = 1,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:18:55]|h|r [S] |cffd8d8d8[|r|Hplayer:Ennyin-埃加洛尔:498:SAY|h|cffd8bc3f60|r:|cff8687edEnnyin|r|h|cffd8d8d8]|r: fq",
					["serverTime"] = 1616257134,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						6, -- [3]
						92, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1183975.463,
					["g"] = 1,
					["b"] = 1,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:22:38]|h|r [W From] |cffd8d8d8[|r|Hplayer:卡布的羞涩-冰霜之刃:557:WHISPER:卡布的羞涩-冰霜之刃|h|cffd8bc3f60|r:|cfffefefe卡布的羞涩|r-|cffa06cb1冰霜之|r:2|h|cffd8d8d8]|r: 我已经给你灌注",
					["serverTime"] = 1616257358,
					["r"] = 1,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						100, -- [3]
						101, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1184198.261,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:31:33]|h|r [S] |cffd8d8d8[|r|Hplayer:Ennyin-埃加洛尔:658:SAY|h|cffd8bc3f60|r:|cff8687edEnnyin|r|h|cffd8d8d8]|r: animals",
					["serverTime"] = 1616257892,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						6, -- [3]
						92, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1184733.801,
					["g"] = 1,
					["b"] = 1,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:32:32]|h|r [W From] |cffd8d8d8[|r|Hplayer:葵雏籽-死亡之翼:701:WHISPER:葵雏籽-死亡之翼|h|cffd8bc3f60|r:|cfffefefe葵雏籽|r-|cff5fd8c8死亡之|r|h|cffd8d8d8]|r: |cff00ff00Ennyin|r, 感谢你对我使用灵魂石. :)",
					["serverTime"] = 1616257951,
					["r"] = 1,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						112, -- [3]
						113, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1184792.197,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:32:47]|h|r [W From] |cffd8d8d8[|r|Hplayer:部落壶哥-血色十字军:702:WHISPER:部落壶哥-血色十字军|h|cffd8bc3f60|r:|cffa9d271部落壶哥|r-|cff4db55c血色十|r|h|cffd8d8d8]|r: 能不能拉个糖 ？",
					["serverTime"] = 1616257966,
					["r"] = 1,
					["extraData"] = {
						0, -- [1]
						false, -- [2]
						114, -- [3]
						115, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1184807.23,
					["g"] = 0.501960813999176,
					["b"] = 1,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:35:32]|h|r [S] |cffd8d8d8[|r|Hplayer:東邪暮雨-罗宁:725:SAY|h|cffc31d39東邪暮雨|r-|cff5f9f51罗宁|r|h|cffd8d8d8]|r: [通用语] VEL",
					["serverTime"] = 1616258131,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						6, -- [3]
						116, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1184972.702,
					["g"] = 1,
					["b"] = 1,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:39:41]|h|r [S] |cffd8d8d8[|r|Hplayer:東邪暮雨-罗宁:785:SAY|h|cffc31d39東邪暮雨|r-|cff5f9f51罗宁|r|h|cffd8d8d8]|r: [通用语] MAND FIR NEVR",
					["serverTime"] = 1616258380,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						6, -- [3]
						116, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1185221.337,
					["g"] = 1,
					["b"] = 1,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:39:49]|h|r [S] |cffd8d8d8[|r|Hplayer:東邪暮雨-罗宁:788:SAY|h|cffc31d39東邪暮雨|r-|cff5f9f51罗宁|r|h|cffd8d8d8]|r: [通用语] ADOR RO",
					["serverTime"] = 1616258388,
					["r"] = 1,
					["extraData"] = {
						2, -- [1]
						false, -- [2]
						6, -- [3]
						116, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1185229.214,
					["g"] = 1,
					["b"] = 1,
				}, -- [18]
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame10"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame9"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 0,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
		["ChatFrame1"] = {
			["EnumerateIndexedEntries"] = nil --[[ skipped inline function ]],
			["headIndex"] = 51,
			["ReplaceElements"] = nil --[[ skipped inline function ]],
			["CalculateElementIndex"] = nil --[[ skipped inline function ]],
			["CalculateElementIndexFromGlobalIndex"] = nil --[[ skipped inline function ]],
			["PushBack"] = nil --[[ skipped inline function ]],
			["RemoveIf"] = nil --[[ skipped inline function ]],
			["Clear"] = nil --[[ skipped inline function ]],
			["PushFront"] = nil --[[ skipped inline function ]],
			["OnLoad"] = nil --[[ skipped inline function ]],
			["IsEmpty"] = nil --[[ skipped inline function ]],
			["IsFull"] = nil --[[ skipped inline function ]],
			["elements"] = {
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:07]|h|r |Hchannel:INSTANCE_CHAT|h[I] |h|cffd8d8d8[|r|Hplayer:終嫣的黑百合-阿克蒙德:1133:INSTANCE_CHAT|h|cffd8bc3f60|r:|cffc31d39終嫣的黑百合|r-|cffc63987阿克蒙|r|h|cffd8d8d8]|r: 全面碾压···",
					["serverTime"] = 1616259786,
					["r"] = 1,
					["extraData"] = {
						63, -- [1]
						false, -- [2]
						42, -- [3]
						146, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186627.398,
					["g"] = 0.4980392456054688,
					["b"] = 0,
				}, -- [1]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:19]|h|r cmd..... setmacro",
					["timestamp"] = 1186639.667,
					["serverTime"] = 1616259798,
				}, -- [2]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:19]|h|r MY HEALER NAME  三月的五月",
					["timestamp"] = 1186639.667,
					["serverTime"] = 1616259798,
				}, -- [3]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:19]|h|r MyBgFaction: 0",
					["timestamp"] = 1186639.667,
					["serverTime"] = 1616259798,
				}, -- [4]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:19]|h|r ",
					["timestamp"] = 1186639.667,
					["serverTime"] = 1616259798,
				}, -- [5]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:19]|h|r /targetenemyplayer 笑雨清风-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 神說要有愛-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 魔铸-主宰之剑\n/focus\n/targetlasttarget\n/targetenemyplayer 億万少女的梦-凯尔萨斯\n/focus\n/targetlasttarget\n",
					["timestamp"] = 1186639.667,
					["serverTime"] = 1616259798,
				}, -- [6]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:19]|h|r ",
					["timestamp"] = 1186639.667,
					["serverTime"] = 1616259798,
				}, -- [7]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:20]|h|r cmd..... setmacro",
					["timestamp"] = 1186640.614,
					["serverTime"] = 1616259799,
				}, -- [8]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:20]|h|r MY HEALER NAME  三月的五月",
					["timestamp"] = 1186640.614,
					["serverTime"] = 1616259799,
				}, -- [9]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:20]|h|r MyBgFaction: 0",
					["timestamp"] = 1186640.614,
					["serverTime"] = 1616259799,
				}, -- [10]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:20]|h|r ",
					["timestamp"] = 1186640.614,
					["serverTime"] = 1616259799,
				}, -- [11]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:20]|h|r /targetenemyplayer 笑雨清风-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 神說要有愛-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 魔铸-主宰之剑\n/focus\n/targetlasttarget\n/targetenemyplayer 億万少女的梦-凯尔萨斯\n/focus\n/targetlasttarget\n",
					["timestamp"] = 1186640.614,
					["serverTime"] = 1616259799,
				}, -- [12]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:20]|h|r ",
					["timestamp"] = 1186640.614,
					["serverTime"] = 1616259799,
				}, -- [13]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:21]|h|r cmd..... setmacro",
					["timestamp"] = 1186641.881,
					["serverTime"] = 1616259800,
				}, -- [14]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:21]|h|r MY HEALER NAME  三月的五月",
					["timestamp"] = 1186641.881,
					["serverTime"] = 1616259800,
				}, -- [15]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:21]|h|r MyBgFaction: 0",
					["timestamp"] = 1186641.881,
					["serverTime"] = 1616259800,
				}, -- [16]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:21]|h|r ",
					["timestamp"] = 1186641.881,
					["serverTime"] = 1616259800,
				}, -- [17]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:21]|h|r /targetenemyplayer 笑雨清风-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 神說要有愛-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 魔铸-主宰之剑\n/focus\n/targetlasttarget\n/targetenemyplayer 億万少女的梦-凯尔萨斯\n/focus\n/targetlasttarget\n",
					["timestamp"] = 1186641.881,
					["serverTime"] = 1616259800,
				}, -- [18]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:21]|h|r ",
					["timestamp"] = 1186641.881,
					["serverTime"] = 1616259800,
				}, -- [19]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:22]|h|r cmd..... setmacro",
					["timestamp"] = 1186643.031,
					["serverTime"] = 1616259801,
				}, -- [20]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:22]|h|r MY HEALER NAME  三月的五月",
					["timestamp"] = 1186643.031,
					["serverTime"] = 1616259801,
				}, -- [21]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:22]|h|r MyBgFaction: 0",
					["timestamp"] = 1186643.031,
					["serverTime"] = 1616259801,
				}, -- [22]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:22]|h|r ",
					["timestamp"] = 1186643.031,
					["serverTime"] = 1616259801,
				}, -- [23]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:22]|h|r /targetenemyplayer 笑雨清风-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 神說要有愛-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 魔铸-主宰之剑\n/focus\n/targetlasttarget\n/targetenemyplayer 億万少女的梦-凯尔萨斯\n/focus\n/targetlasttarget\n",
					["timestamp"] = 1186643.031,
					["serverTime"] = 1616259801,
				}, -- [24]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:22]|h|r ",
					["timestamp"] = 1186643.031,
					["serverTime"] = 1616259801,
				}, -- [25]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:24]|h|r cmd..... setmacro",
					["timestamp"] = 1186644.214,
					["serverTime"] = 1616259803,
				}, -- [26]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:24]|h|r MY HEALER NAME  三月的五月",
					["timestamp"] = 1186644.214,
					["serverTime"] = 1616259803,
				}, -- [27]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:24]|h|r MyBgFaction: 0",
					["timestamp"] = 1186644.214,
					["serverTime"] = 1616259803,
				}, -- [28]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:24]|h|r ",
					["timestamp"] = 1186644.214,
					["serverTime"] = 1616259803,
				}, -- [29]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:24]|h|r /targetenemyplayer 笑雨清风-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 神說要有愛-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 魔铸-主宰之剑\n/focus\n/targetlasttarget\n/targetenemyplayer 億万少女的梦-凯尔萨斯\n/focus\n/targetlasttarget\n",
					["timestamp"] = 1186644.214,
					["serverTime"] = 1616259803,
				}, -- [30]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:24]|h|r ",
					["timestamp"] = 1186644.214,
					["serverTime"] = 1616259803,
				}, -- [31]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:24]|h|r 鉴茶院院长-凤凰之神收集到了艾泽里特！",
					["serverTime"] = 1616259803,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186644.244,
					["g"] = 0,
					["b"] = 0,
				}, -- [32]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:24]|h|r 部落获得了胜利！",
					["serverTime"] = 1616259803,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186644.264,
					["g"] = 0,
					["b"] = 0,
				}, -- [33]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:24]|h|r 你获得了物品：|cff0070dd|Hitem:137642::::::::60:267:::::::|h[荣耀印记]|h|r。",
					["serverTime"] = 1616259803,
					["r"] = 0,
					["extraData"] = {
						28, -- [1]
						false, -- [2]
						3, -- [3]
						4, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186644.358,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [34]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:25]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x270。",
					["serverTime"] = 1616259804,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186645.281,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [35]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:25]|h|r 你获得了45点荣誉。",
					["serverTime"] = 1616259804,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186645.281,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [36]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:25]|h|r 你获得了：|cffa335ee|Hcurrency:1602:0|h[征服点数]|h|r x8。",
					["serverTime"] = 1616259804,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186645.331,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [37]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:26]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1616259805,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						25, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186646.264,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [38]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:33]|h|r 你的队伍已经解散。",
					["serverTime"] = 1616259812,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						8, -- [3]
						9, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186653.981,
					["g"] = 1,
					["b"] = 0,
				}, -- [39]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:33]|h|r 你已经被移出队伍",
					["serverTime"] = 1616259812,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						8, -- [3]
						9, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186653.981,
					["g"] = 1,
					["b"] = 0,
				}, -- [40]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:34]|h|r 专精拾取已设置为：痛苦",
					["serverTime"] = 1616259813,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						["n"] = 1,
					},
					["timestamp"] = 1186653.981,
					["g"] = 1,
					["b"] = 0,
				}, -- [41]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:34]|h|r zoned between map instances",
					["timestamp"] = 1186653.981,
					["serverTime"] = 1616259813,
				}, -- [42]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:34]|h|r currentZoneType()none",
					["timestamp"] = 1186653.981,
					["serverTime"] = 1616259813,
				}, -- [43]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:34]|h|r HOOK: SGA ONLY PLAY 4 UNITS'S SPELL IN BG",
					["timestamp"] = 1186653.981,
					["serverTime"] = 1616259813,
				}, -- [44]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:34]|h|r HOOK: Plater friendlyplayer SIZE LESS WIDER",
					["timestamp"] = 1186653.981,
					["serverTime"] = 1616259813,
				}, -- [45]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:35]|h|r |cffa5a5a5三月的五月|r-凤凰之神已经离开了副本队伍。",
					["serverTime"] = 1616259814,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						8, -- [3]
						9, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186655.485,
					["g"] = 1,
					["b"] = 0,
				}, -- [46]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:35]|h|r |cffa5a5a5鉴茶院院长|r-凤凰之神已经离开了副本队伍。",
					["serverTime"] = 1616259814,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						8, -- [3]
						9, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186655.485,
					["g"] = 1,
					["b"] = 0,
				}, -- [47]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:35]|h|r |cffa5a5a5奎尔塞拉晨曦|r-血色十字军已经离开了副本队伍。",
					["serverTime"] = 1616259814,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						8, -- [3]
						9, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186655.485,
					["g"] = 1,
					["b"] = 0,
				}, -- [48]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:35]|h|r |cffa5a5a5难忆醉生梦死|r-布兰卡德已经离开了副本队伍。",
					["serverTime"] = 1616259814,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						8, -- [3]
						9, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186655.485,
					["g"] = 1,
					["b"] = 0,
				}, -- [49]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:35]|h|r 你已经加入了乱斗：阿拉希暴风雪的队列。",
					["serverTime"] = 1616259814,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						8, -- [3]
						9, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186655.485,
					["g"] = 1,
					["b"] = 0,
				}, -- [50]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:03:53]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:玄天皓月-幽暗沼泽:1150:CHANNEL:5|h|cff8687ed玄天皓月|r-|cff05c922幽暗沼|r|h|cffd8d8d8]|r: 在哪",
					["serverTime"] = 1616259832,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						false, -- [2]
						14, -- [3]
						121, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186674.081,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [51]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:54]|h|r cmd..... setmacro",
					["timestamp"] = 1186434.781,
					["serverTime"] = 1616259593,
				}, -- [52]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:54]|h|r MY HEALER NAME  三月的五月",
					["timestamp"] = 1186434.781,
					["serverTime"] = 1616259593,
				}, -- [53]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:54]|h|r MyBgFaction: 0",
					["timestamp"] = 1186434.781,
					["serverTime"] = 1616259593,
				}, -- [54]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:54]|h|r ",
					["timestamp"] = 1186434.781,
					["serverTime"] = 1616259593,
				}, -- [55]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:54]|h|r /targetenemyplayer 笑雨清风-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 神說要有愛-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 魔铸-主宰之剑\n/focus\n/targetlasttarget\n",
					["timestamp"] = 1186434.781,
					["serverTime"] = 1616259593,
				}, -- [56]
				{
					["message"] = "|cff979797|Hpratcopy|h[00:59:54]|h|r /targetenemyplayer 白色山猫卡娜-金色平原\n/focus\n/targetlasttarget\n/targetenemyplayer 洛莉丝丶星痕-金色平原\n/focus\n/targetlasttarget\n",
					["timestamp"] = 1186434.781,
					["serverTime"] = 1616259593,
				}, -- [57]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:01]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1616259600,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186442.064,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [58]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:01]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1616259600,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186442.064,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [59]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:12]|h|r 兔兔的积分已经死亡。",
					["serverTime"] = 1616259611,
					["r"] = 1,
					["extraData"] = {
						1, -- [1]
						false, -- [2]
						8, -- [3]
						9, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186452.247,
					["g"] = 1,
					["b"] = 0,
				}, -- [60]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:15]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:繁花入夢-斩魔者:1071:CHANNEL:5|h|cfff38bb9繁花入夢|r-|cff88b1a8斩魔者|r|h|cffd8d8d8]|r: 111",
					["serverTime"] = 1616259614,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						false, -- [2]
						14, -- [3]
						143, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186455.847,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [61]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:21]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:繁花入夢-斩魔者:1072:CHANNEL:5|h|cfff38bb9繁花入夢|r-|cff88b1a8斩魔者|r|h|cffd8d8d8]|r: 111",
					["serverTime"] = 1616259620,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						false, -- [2]
						14, -- [3]
						143, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186461.679,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [62]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:28]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1616259627,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186468.964,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [63]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:28]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1616259627,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186468.964,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [64]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:30]|h|r 笑雨清风-末日行者收集到了艾泽里特！",
					["serverTime"] = 1616259629,
					["r"] = 0,
					["extraData"] = {
						38, -- [1]
						false, -- [2]
						32, -- [3]
						33, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186470.798,
					["g"] = 0.6823529601097107,
					["b"] = 0.9372549653053284,
				}, -- [65]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:32]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1616259631,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						25, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186472.831,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [66]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:34]|h|r |Hchannel:channel:5|h[5] |h|cffd8d8d8[|r|Hplayer:繁花入夢-斩魔者:1077:CHANNEL:5|h|cfff38bb9繁花入夢|r-|cff88b1a8斩魔者|r|h|cffd8d8d8]|r: 123",
					["serverTime"] = 1616259633,
					["r"] = 1,
					["extraData"] = {
						71, -- [1]
						false, -- [2]
						14, -- [3]
						143, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186474.717,
					["g"] = 0.7529412508010864,
					["b"] = 0.7529412508010864,
				}, -- [67]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:42]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x4。",
					["serverTime"] = 1616259641,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186482.322,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [68]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:42]|h|r 你获得了4点荣誉。",
					["serverTime"] = 1616259641,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186482.322,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [69]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:52]|h|r 德鲁鲁伊-塞拉赞恩收集到了艾泽里特！",
					["serverTime"] = 1616259651,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186492.384,
					["g"] = 0,
					["b"] = 0,
				}, -- [70]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:53]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x19。",
					["serverTime"] = 1616259652,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186493.398,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [71]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:53]|h|r 你获得了19点荣誉。",
					["serverTime"] = 1616259652,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186493.398,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [72]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:00:54]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1616259653,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						25, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186494.381,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [73]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:01]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1616259660,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186501.733,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [74]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:01]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1616259660,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186501.733,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [75]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:10]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1616259669,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186510.981,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [76]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:10]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1616259669,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186510.998,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [77]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:12]|h|r 蝶碎丶灵儿-死亡之翼收集到了艾泽里特！",
					["serverTime"] = 1616259671,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186513.047,
					["g"] = 0,
					["b"] = 0,
				}, -- [78]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:13]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x15。",
					["serverTime"] = 1616259672,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186514.064,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [79]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:13]|h|r 你获得了15点荣誉。",
					["serverTime"] = 1616259672,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186514.064,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [80]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:14]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1616259673,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						25, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186515.051,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [81]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:17]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x1。",
					["serverTime"] = 1616259676,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186517.834,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [82]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:17]|h|r 你获得了1点荣誉。",
					["serverTime"] = 1616259676,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186517.834,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [83]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:25]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x1。",
					["serverTime"] = 1616259684,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186525.264,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [84]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:25]|h|r 你获得了1点荣誉。",
					["serverTime"] = 1616259684,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186525.281,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [85]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:36]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x1。",
					["serverTime"] = 1616259695,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186536.464,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [86]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:36]|h|r 你获得了1点荣誉。",
					["serverTime"] = 1616259695,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186536.464,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [87]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:39]|h|r 纳萨诺斯·凋零者说： 补给过来了。别让联盟把这些补给抢了！",
					["serverTime"] = 1616259698,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						30, -- [3]
						31, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186539.433,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [88]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:41]|h|r |TInterface\\FriendsFrame\\UI-Toast-ToastIcons.tga:16:16:0:0:128:64:2:29:34:61|t|HBNplayer:|Kq11|k:39:1099:BN_INLINE_TOAST_ALERT:0|h[|Kq11|k]|h已经离线。",
					["serverTime"] = 1616259700,
					["r"] = 0.5098039507865906,
					["extraData"] = {
						54, -- [1]
						false, -- [2]
						1, -- [3]
						145, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186541.934,
					["g"] = 0.7725490927696228,
					["b"] = 1,
				}, -- [89]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:46]|h|r 鉴茶院院长-凤凰之神收集到了艾泽里特！",
					["serverTime"] = 1616259705,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186546.61,
					["g"] = 0,
					["b"] = 0,
				}, -- [90]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:47]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x15。",
					["serverTime"] = 1616259706,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186547.629,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [91]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:47]|h|r 你获得了15点荣誉。",
					["serverTime"] = 1616259706,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186547.629,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [92]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:47]|h|r 纳萨诺斯·凋零者说： 哈！从联盟手上抢来啦！干得不错！",
					["serverTime"] = 1616259706,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						30, -- [3]
						31, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186547.953,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [93]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:48]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1616259707,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						25, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186548.606,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [94]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:49]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x1。",
					["serverTime"] = 1616259708,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186549.337,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [95]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:49]|h|r 你获得了1点荣誉。",
					["serverTime"] = 1616259708,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186549.337,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [96]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:52]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x1。",
					["serverTime"] = 1616259711,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186552.338,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [97]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:52]|h|r 你获得了1点荣誉。",
					["serverTime"] = 1616259711,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186552.338,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [98]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:58]|h|r 难忆醉生梦死-布兰卡德收集到了艾泽里特！",
					["serverTime"] = 1616259717,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186558.897,
					["g"] = 0,
					["b"] = 0,
				}, -- [99]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:59]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x15。",
					["serverTime"] = 1616259718,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186559.914,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [100]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:01:59]|h|r 你获得了15点荣誉。",
					["serverTime"] = 1616259718,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186559.914,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [101]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:00]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1616259719,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						25, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186560.898,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [102]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:15]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x1。",
					["serverTime"] = 1616259734,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186575.718,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [103]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:15]|h|r 你获得了1点荣誉。",
					["serverTime"] = 1616259734,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186575.718,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [104]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:24]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x2。",
					["serverTime"] = 1616259743,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186584.898,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [105]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:24]|h|r 你获得了2点荣誉。",
					["serverTime"] = 1616259743,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186584.914,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [106]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:26]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x1。",
					["serverTime"] = 1616259745,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186586.514,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [107]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:26]|h|r 你获得了1点荣誉。",
					["serverTime"] = 1616259745,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186586.531,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [108]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:30]|h|r 蝶碎丶灵儿-死亡之翼收集到了艾泽里特！",
					["serverTime"] = 1616259749,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186590.331,
					["g"] = 0,
					["b"] = 0,
				}, -- [109]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:30]|h|r 部落已经收集了超过1200份艾泽里特，离胜利不远了！",
					["serverTime"] = 1616259749,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186590.731,
					["g"] = 0,
					["b"] = 0,
				}, -- [110]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:30]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x17。",
					["serverTime"] = 1616259749,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186590.997,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [111]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:30]|h|r 你获得了17点荣誉。",
					["serverTime"] = 1616259749,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186590.997,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [112]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:32]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1616259751,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						25, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186592.347,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [113]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:38]|h|r 奎尔塞拉晨曦-血色十字军收集到了艾泽里特！",
					["serverTime"] = 1616259757,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186598.381,
					["g"] = 0,
					["b"] = 0,
				}, -- [114]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:39]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x15。",
					["serverTime"] = 1616259758,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186599.399,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [115]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:39]|h|r 你获得了15点荣誉。",
					["serverTime"] = 1616259758,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186599.399,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [116]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:40]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1616259759,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						25, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186600.398,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [117]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:49]|h|r 难忆醉生梦死-布兰卡德收集到了艾泽里特！",
					["serverTime"] = 1616259768,
					["r"] = 1,
					["extraData"] = {
						39, -- [1]
						false, -- [2]
						34, -- [3]
						35, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186609.981,
					["g"] = 0,
					["b"] = 0,
				}, -- [118]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:50]|h|r 你获得了：|cff0070dd|Hcurrency:1792:0|h[荣誉点数]|h|r x15。",
					["serverTime"] = 1616259769,
					["r"] = 0,
					["extraData"] = {
						59, -- [1]
						false, -- [2]
						10, -- [3]
						11, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186610.997,
					["g"] = 0.6666666865348816,
					["b"] = 0,
				}, -- [119]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:50]|h|r 你获得了15点荣誉。",
					["serverTime"] = 1616259769,
					["r"] = 0.8784314393997192,
					["extraData"] = {
						35, -- [1]
						false, -- [2]
						12, -- [3]
						13, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186610.997,
					["g"] = 0.7921569347381592,
					["b"] = 0.03921568766236305,
				}, -- [120]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:51]|h|r 纳萨诺斯·凋零者说： 第一次嘛，还行，但我们需要更多的艾泽里特！",
					["serverTime"] = 1616259770,
					["r"] = 1,
					["extraData"] = {
						13, -- [1]
						false, -- [2]
						30, -- [3]
						31, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186611.247,
					["g"] = 1,
					["b"] = 0.6235294342041016,
				}, -- [121]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:51]|h|r 艾泽里特裂隙开始喷发了！",
					["serverTime"] = 1616259770,
					["r"] = 1,
					["extraData"] = {
						37, -- [1]
						false, -- [2]
						25, -- [3]
						26, -- [4]
						["n"] = 4,
					},
					["timestamp"] = 1186611.981,
					["g"] = 0.4705882668495178,
					["b"] = 0.03921568766236305,
				}, -- [122]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:53]|h|r cmd..... setmacro",
					["timestamp"] = 1186613.281,
					["serverTime"] = 1616259772,
				}, -- [123]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:53]|h|r MY HEALER NAME  三月的五月",
					["timestamp"] = 1186613.281,
					["serverTime"] = 1616259772,
				}, -- [124]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:53]|h|r MyBgFaction: 0",
					["timestamp"] = 1186613.281,
					["serverTime"] = 1616259772,
				}, -- [125]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:53]|h|r ",
					["timestamp"] = 1186613.281,
					["serverTime"] = 1616259772,
				}, -- [126]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:53]|h|r /targetenemyplayer 笑雨清风-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 神說要有愛-末日行者\n/focus\n/targetlasttarget\n/targetenemyplayer 魔铸-主宰之剑\n/focus\n/targetlasttarget\n",
					["timestamp"] = 1186613.281,
					["serverTime"] = 1616259772,
				}, -- [127]
				{
					["message"] = "|cff979797|Hpratcopy|h[01:02:53]|h|r ",
					["timestamp"] = 1186613.281,
					["serverTime"] = 1616259772,
				}, -- [128]
			},
			["maxElements"] = 128,
			["GetEntryAtIndex"] = nil --[[ skipped inline function ]],
			["TransformIf"] = nil --[[ skipped inline function ]],
			["SetMaxNumElements"] = nil --[[ skipped inline function ]],
			["GetNumElements"] = nil --[[ skipped inline function ]],
			["GetMaxNumElements"] = nil --[[ skipped inline function ]],
		},
	},
}
