
LoseControlFixDB = {
	["y"] = 6.103514897404239e-05,
	["x"] = -9.155271254712716e-05,
	["point"] = "CENTER",
	["alert"] = true,
	["actionbars"] = true,
}
