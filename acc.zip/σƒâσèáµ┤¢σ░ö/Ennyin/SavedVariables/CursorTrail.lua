
CursorTrail_PlayerConfig = {
	["FadeOut"] = true,
	["UserOfsY"] = 0,
	["UserShowMouseLook"] = false,
	["ModelID"] = 166381,
	["UserAlpha"] = 1,
	["UserOfsX"] = 0,
	["UserScale"] = 2.4,
	["UserShadowAlpha"] = 0,
	["Strata"] = "FULLSCREEN",
	["UserShowOnlyInCombat"] = false,
}
