
Scorpio_DB_Char = {
}
