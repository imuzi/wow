
DCP_SavedPerCharacter = {
	["ignoredSpells"] = "",
	["invertIgnored"] = false,
}
