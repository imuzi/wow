
SkadaPerCharDB = {
	["total"] = {
		["healingabsorbed"] = 0,
		["dispells"] = 0,
		["ffdamagedone"] = 0,
		["time"] = 0,
		["interrupts"] = 0,
		["damage"] = 0,
		["starttime"] = 1578243926,
		["deaths"] = 0,
		["damagetaken"] = 0,
		["mobtaken"] = 0,
		["healing"] = 0,
		["ccbreaks"] = 0,
		["overhealing"] = 0,
		["players"] = {
		},
		["name"] = "总计",
		["shielding"] = 0,
		["mobs"] = {
		},
		["mobhdone"] = 0,
		["last_action"] = 1578243926,
		["mobdone"] = 0,
	},
	["sets"] = {
	},
}
