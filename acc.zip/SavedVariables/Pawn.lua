
PawnCommon = {
	["ShowUpgradesOnTooltips"] = true,
	["ShowSpace"] = false,
	["AlignNumbersRight"] = false,
	["ShowItemID"] = false,
	["ShowAsterisks"] = 1,
	["ShowValuesForUpgradesOnly"] = true,
	["Debug"] = false,
	["ShowReforgingAdvisor"] = true,
	["ColorTooltipBorder"] = true,
	["ShowTooltipIcons"] = true,
	["ShowSocketingAdvisor"] = true,
	["Scales"] = {
		["\"Wowhead\":ShamanRestoration"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["我过年好-鬼雾峰"] = {
					["Visible"] = true,
					["BestItems"] = {
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "萨满祭司:恢复",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "526fbf",
		},
		["\"Wowhead\":ShamanEnhancement"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["我过年好-鬼雾峰"] = {
					["Visible"] = true,
					["BestItems"] = {
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "萨满祭司:增强",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "526fbf",
		},
		["\"Wowhead\":RogueSubtlety"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["Rainylone-夏维安"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONOFFHAND"] = {
							0.7707774798927614, -- [1]
							50055, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							0.6127920337035618, -- [1]
							28979, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							0.8607309157612529, -- [1]
							25, -- [2]
							0, -- [3]
						},
					},
				},
				["Ylno-夏维安"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONOFFHAND"] = {
							0.7707774798927614, -- [1]
							50055, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							1.072386058981233, -- [1]
							54986, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							0.8923783990808119, -- [1]
							37, -- [2]
							0, -- [3]
						},
					},
				},
				["Elytolpain-夏维安"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_FEET"] = {
							0.798544618919954, -- [1]
							65961, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							3.780586407932252, -- [1]
							6448, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							1.225584067407124, -- [1]
							55012, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							3.207730607194414, -- [1]
							68194, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							0.0003829950210647262, -- [1]
							54994, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							1.054385292991191, -- [1]
							51964, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							0.3063960168517809, -- [1]
							55000, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							0.798544618919954, -- [1]
							65960, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							0.7671390271926465, -- [1]
							5193, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							0.1535810034469552, -- [1]
							52595, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "潜行者:敏锐",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bfb74e",
		},
		["\"Wowhead\":MageFire"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "69ccf0",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["浮雲-恶魔之翼"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							55.35943617854346, -- [1]
							35097, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							8.894805533803185, -- [1]
							35149, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							7.319237796919864, -- [1]
							35016, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							41.52310101801096, -- [1]
							35099, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							64.61707126076742, -- [1]
							35102, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							6.799008091882015, -- [1]
							35129, -- [2]
							0, -- [3]
							6.274079874706342, -- [4]
							37927, -- [5]
							0, -- [6]
						},
						["INVTYPE_SHOULDER"] = {
							30.81754111198121, -- [1]
							35096, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							17.24171234664578, -- [1]
							35179, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							8.894805533803185, -- [1]
							35164, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							17.23831897676847, -- [1]
							37929, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							13.33724876011485, -- [1]
							35100, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							9.93683111459149, -- [1]
							35098, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							7.319759853824066, -- [1]
							44429, -- [2]
							0, -- [3]
						},
					},
				},
				["別雨-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							217.025841816758, -- [1]
							78796, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							122.1117201774993, -- [1]
							58485, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							197.0845732184808, -- [1]
							71289, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							60.43904985643435, -- [1]
							71151, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							108.5802662490211, -- [1]
							72888, -- [2]
							0, -- [3]
							108.5802662490211, -- [4]
							72888, -- [5]
							0, -- [6]
						},
						["INVTYPE_2HWEAPON"] = {
							634.0357608979379, -- [1]
							72863, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							200.5027407987471, -- [1]
							78815, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							146.5189245627773, -- [1]
							72852, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							146.4641085878361, -- [1]
							72851, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							104.1453928478204, -- [1]
							71213, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							143.3604802923519, -- [1]
							72865, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							106.4111198120595, -- [1]
							71265, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							100.2743409031584, -- [1]
							76160, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "法师:火焰",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "4e99b3",
		},
		["\"Wowhead\":DruidFeralTank"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "德鲁伊:熊",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bf5d07",
		},
		["\"Wowhead\":WarriorArms"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["Eofol-沙怒"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_2HWEAPON"] = {
							0.5530394750609091, -- [1]
							49778, -- [2]
							0, -- [3]
						},
					},
				},
				["Esserbella-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							4.277416558300824, -- [1]
							69887, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							13.05866204305736, -- [1]
							24064, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							33.26647676842735, -- [1]
							69893, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							19.79637542056268, -- [1]
							65972, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							2.870249963878052, -- [1]
							69892, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							0.8565236237537928, -- [1]
							10795, -- [2]
							0, -- [3]
							0.8565236237537928, -- [4]
							10795, -- [5]
							0, -- [6]
						},
						["INVTYPE_SHOULDER"] = {
							2.357029331021529, -- [1]
							69890, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							1.177719982661465, -- [1]
							51989, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							1.392862303135385, -- [1]
							51985, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							2.767808120213842, -- [1]
							51995, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							0.002600780234070221, -- [1]
							65928, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							2.511486779367143, -- [1]
							51987, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							3.107065452969224, -- [1]
							69889, -- [2]
							0, -- [3]
						},
					},
				},
				["失重-无尽之海"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_2HWEAPON"] = {
							0.5530394750609091, -- [1]
							12282, -- [2]
							0, -- [3]
						},
					},
				},
				["Lure-达文格尔"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_FEET"] = {
							0.0008669267446900738, -- [1]
							6573, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							0.3207628955353273, -- [1]
							7120, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							0.0007224389539083947, -- [1]
							6340, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							0.3219187978615807, -- [1]
							6414, -- [2]
							0, -- [3]
							0.3219187978615807, -- [4]
							6414, -- [5]
							0, -- [6]
						},
						["INVTYPE_WRIST"] = {
							0.0005779511631267159, -- [1]
							3230, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							0.2141309059384482, -- [1]
							9787, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							0.427972836295333, -- [1]
							4697, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							0.1070654529692241, -- [1]
							6337, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							0.0005779511631267159, -- [1]
							5254, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							0.3207628955353273, -- [1]
							4568, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							0.6419592544429996, -- [1]
							3733, -- [2]
							0, -- [3]
						},
					},
				},
				["失重-冰风岗"] = {
					["Visible"] = true,
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "战士:武器",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "957552",
		},
		["\"Wowhead\":WarriorFury"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["Eofol-沙怒"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_2HWEAPON"] = {
							0.2104993286960511, -- [1]
							49778, -- [2]
							0, -- [3]
						},
					},
				},
				["Esserbella-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							5.316767755820779, -- [1]
							69887, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							17.43670514576404, -- [1]
							24064, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							13.70226681946502, -- [1]
							69893, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							7.795091818766247, -- [1]
							65972, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							3.041479162590491, -- [1]
							69892, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							1.018978673449423, -- [1]
							10795, -- [2]
							0, -- [3]
							1.018978673449423, -- [4]
							10795, -- [5]
							0, -- [6]
						},
						["INVTYPE_SHOULDER"] = {
							2.804343572686363, -- [1]
							69890, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							1.401095675992956, -- [1]
							51989, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							1.657209939346507, -- [1]
							51985, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							2.779495206417531, -- [1]
							51995, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							0.003521815691645471, -- [1]
							65928, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							4.52396791234592, -- [1]
							51987, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							3.696732537663862, -- [1]
							69889, -- [2]
							0, -- [3]
						},
					},
				},
				["失重-无尽之海"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_2HWEAPON"] = {
							0.2104993286960511, -- [1]
							12282, -- [2]
							0, -- [3]
						},
					},
				},
				["Lure-达文格尔"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_FEET"] = {
							0.001173938563881824, -- [1]
							6573, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							0.3815300332615926, -- [1]
							7120, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							0.0009782821365681863, -- [1]
							6340, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							0.3830952846801017, -- [1]
							6414, -- [2]
							0, -- [3]
							0.3830952846801017, -- [4]
							6414, -- [5]
							0, -- [6]
						},
						["INVTYPE_WRIST"] = {
							0.000782625709254549, -- [1]
							3230, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							0.2547446683623557, -- [1]
							9787, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							0.5090980238700841, -- [1]
							4697, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							0.1273723341811778, -- [1]
							6337, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							0.000782625709254549, -- [1]
							5254, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							0.3815300332615926, -- [1]
							4568, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							0.7636470358051262, -- [1]
							3733, -- [2]
							0, -- [3]
						},
					},
				},
				["失重-冰风岗"] = {
					["Visible"] = true,
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "战士:狂怒",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "957552",
		},
		["\"Wowhead\":DruidFeralDps"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "德鲁伊:猎豹",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bf5d07",
		},
		["\"Wowhead\":DeathKnightFrostDps"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["你诺-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_CHEST"] = {
							3.307092854312508, -- [1]
							69889, -- [2]
							0, -- [3]
						},
						["INVTYPE_HEAD"] = {
							4.490556069211465, -- [1]
							69887, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							3.495707304187029, -- [1]
							38670, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							18.47129227924367, -- [1]
							39371, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							18.47129227924367, -- [1]
							39371, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							3.964865935807687, -- [1]
							38669, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							2.43640206049399, -- [1]
							34649, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							32.8421919553715, -- [1]
							38633, -- [2]
							0, -- [3]
						},
						["INVTYPE_RELIC"] = {
							6.606392814687624, -- [1]
							39208, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							2.268920882314093, -- [1]
							38666, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							3.86052040681548, -- [1]
							38668, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							2.753665301809537, -- [1]
							38662, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							2.513406419231278, -- [1]
							69890, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							2.926297714964998, -- [1]
							38672, -- [2]
							0, -- [3]
							2.268920882314093, -- [4]
							38671, -- [5]
							0, -- [6]
						},
						["INVTYPE_CLOAK"] = {
							2.490027737419099, -- [1]
							69892, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "死亡骑士:冰霜",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bf3950",
		},
		["\"Wowhead\":WarlockDestruction"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["幽笠巫-熊猫酒仙"] = {
					["Visible"] = true,
					["BestItems"] = {
					},
				},
				["木诺子其-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONMAINHAND"] = {
							746.5057935866342, -- [1]
							73434, -- [2]
							0, -- [3]
						},
						["INVTYPE_HEAD"] = {
							242.0425761250337, -- [1]
							76342, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							180.2807868499057, -- [1]
							77176, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							112.0962004850445, -- [1]
							73436, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							242.8644570196712, -- [1]
							76340, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							72.02101859337105, -- [1]
							77079, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							226.5561843168957, -- [1]
							76341, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							131.6211263810294, -- [1]
							77108, -- [2]
							0, -- [3]
							124.0167070870385, -- [4]
							78012, -- [5]
							0, -- [6]
						},
						["INVTYPE_HAND"] = {
							172.2398275397467, -- [1]
							76343, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							123.7526273241714, -- [1]
							77249, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							152.2770142818647, -- [1]
							78398, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							124.9867960118566, -- [1]
							77088, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							165.8722716248989, -- [1]
							76339, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							822.3632444085151, -- [1]
							77221, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							133.1139854486661, -- [1]
							77098, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "术士:毁灭",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "8d7bbf",
		},
		["\"Wowhead\":WarlockAffliction"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["幽笠巫-熊猫酒仙"] = {
					["Visible"] = true,
					["BestItems"] = {
					},
				},
				["木诺子其-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONMAINHAND"] = {
							832.8375805096611, -- [1]
							73434, -- [2]
							0, -- [3]
						},
						["INVTYPE_HEAD"] = {
							244.9901988238588, -- [1]
							76342, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							175.5032203864463, -- [1]
							77176, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							110.5849901988239, -- [1]
							73436, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							238.1013721646598, -- [1]
							76340, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							69.12629515541865, -- [1]
							77079, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							231.198543825259, -- [1]
							76341, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							127.8258190982918, -- [1]
							77108, -- [2]
							0, -- [3]
							126.3612433492019, -- [4]
							78012, -- [5]
							0, -- [6]
						},
						["INVTYPE_HAND"] = {
							167.5894707364884, -- [1]
							76343, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							126.2352282273873, -- [1]
							77249, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							154.4413329599552, -- [1]
							78398, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							122.5107812937552, -- [1]
							77088, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							165.7300476057127, -- [1]
							76339, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							892.5735088210585, -- [1]
							77221, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							128.5119014281714, -- [1]
							77098, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "术士:痛苦",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "8d7bbf",
		},
		["\"Wowhead\":PriestShadow"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["绑住了风-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							146.1086116791638, -- [1]
							69622, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							101.813224267212, -- [1]
							58486, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							67.86184957964099, -- [1]
							69796, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							49.78686662122245, -- [1]
							71150, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							101.177005226085, -- [1]
							60275, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							77.57577823221995, -- [1]
							71329, -- [2]
							0, -- [3]
							74.27993637809588, -- [4]
							58189, -- [5]
							0, -- [6]
						},
						["INVTYPE_LEGS"] = {
							137.9213815042036, -- [1]
							60261, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							88.85730515791865, -- [1]
							71266, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							101.177005226085, -- [1]
							62386, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							72.82799363780958, -- [1]
							62416, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							94.98068620768007, -- [1]
							69612, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							475.3878663940013, -- [1]
							59525, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							130.2713019768235, -- [1]
							69578, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "牧师:暗影",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bfbfbf",
		},
		["\"Wowhead\":PaladinTank"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "圣骑士:防护",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "b7698b",
		},
		["\"Wowhead\":WarlockDemonology"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["幽笠巫-熊猫酒仙"] = {
					["Visible"] = true,
					["BestItems"] = {
					},
				},
				["木诺子其-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONMAINHAND"] = {
							717.6924829157175, -- [1]
							73434, -- [2]
							0, -- [3]
						},
						["INVTYPE_HEAD"] = {
							232.9688686408504, -- [1]
							76342, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							176.4975955454315, -- [1]
							77176, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							106.1070615034168, -- [1]
							73436, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							237.6689445709947, -- [1]
							76340, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							71.07314603897747, -- [1]
							77079, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							224.8215641609719, -- [1]
							76341, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							128.8296633763604, -- [1]
							77108, -- [2]
							0, -- [3]
							123.185522652493, -- [4]
							78012, -- [5]
							0, -- [6]
						},
						["INVTYPE_HAND"] = {
							169.7094406479372, -- [1]
							76343, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							122.9273601619843, -- [1]
							77249, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							147.7954948114401, -- [1]
							78398, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							122.9324221716021, -- [1]
							77088, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							160.2814477347507, -- [1]
							76339, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							796.0086054163503, -- [1]
							77221, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							130.7380410022779, -- [1]
							77098, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "术士:恶魔学识",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "8d7bbf",
		},
		["\"Wowhead\":ShamanElemental"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["我过年好-鬼雾峰"] = {
					["Visible"] = true,
					["BestItems"] = {
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "萨满祭司:元素",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "526fbf",
		},
		["\"Wowhead\":DruidRestoration"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "德鲁伊:恢复",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bf5d07",
		},
		["\"Wowhead\":HunterBeastMastery"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["嘿嘿牛-达尔坎"] = {
					["Visible"] = true,
					["BestItems"] = {
					},
				},
				["海雅-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							5.736801392380584, -- [1]
							61935, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							3.320054148133823, -- [1]
							51982, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							3.089151034616128, -- [1]
							62039, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							16.9102411802083, -- [1]
							42946, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							3.322181396248308, -- [1]
							65979, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							2.343260491200928, -- [1]
							51992, -- [2]
							0, -- [3]
							1.674337652291626, -- [4]
							66035, -- [5]
							0, -- [6]
						},
						["INVTYPE_LEGS"] = {
							4.686520982401857, -- [1]
							14638, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							2.128601817830207, -- [1]
							56841, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							1.383291432991684, -- [1]
							51964, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							2.452136917424096, -- [1]
							66009, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							4.018178302069233, -- [1]
							42950, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							1.935022239412106, -- [1]
							19508, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							5.357764455617868, -- [1]
							48677, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "猎人:野兽控制",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "809f56",
		},
		["\"Wowhead\":HunterMarksman"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["嘿嘿牛-达尔坎"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONMAINHAND"] = {
							0.7071681131468981, -- [1]
							4923, -- [2]
							0, -- [3]
						},
					},
				},
				["海雅-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							3.656380585020894, -- [1]
							61935, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							2.162648666023786, -- [1]
							51982, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							1.836708453873353, -- [1]
							62039, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							14.65582954493273, -- [1]
							42946, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							3.226936676309868, -- [1]
							65979, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							1.329797492767599, -- [1]
							51992, -- [2]
							0, -- [3]
							0.9508196721311475, -- [4]
							66035, -- [5]
							0, -- [6]
						},
						["INVTYPE_LEGS"] = {
							2.659594985535197, -- [1]
							14638, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							1.416586306653809, -- [1]
							56841, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							0.9009964641594342, -- [1]
							51964, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							1.555769848923176, -- [1]
							66009, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							2.281581485053037, -- [1]
							42950, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							1.287688846030215, -- [1]
							19508, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							3.042430086788814, -- [1]
							48677, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "猎人:射击",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "809f56",
		},
		["\"Wowhead\":RogueCombat"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["Rainylone-夏维安"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONOFFHAND"] = {
							0.5579680872550999, -- [1]
							50055, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							0.3231670369622298, -- [1]
							28979, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							0.5814880566392754, -- [1]
							25, -- [2]
							0, -- [3]
						},
					},
				},
				["Ylno-夏维安"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONOFFHAND"] = {
							0.5579680872550999, -- [1]
							50055, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							0.5655423146839023, -- [1]
							54986, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							0.5917996364370834, -- [1]
							37, -- [2]
							0, -- [3]
						},
					},
				},
				["Elytolpain-夏维安"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_FEET"] = {
							0.7281357301555241, -- [1]
							65961, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							4.522767566597095, -- [1]
							6448, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							0.7008685114118359, -- [1]
							55012, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							3.747028572316392, -- [1]
							68194, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							0.0002019793981013937, -- [1]
							54994, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							1.060997778226621, -- [1]
							51964, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							0.2706523934558675, -- [1]
							55000, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							0.7281357301555241, -- [1]
							65960, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							0.6772369218339729, -- [1]
							5193, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							0.1355281761260351, -- [1]
							52595, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "潜行者:战斗",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bfb74e",
		},
		["\"Wowhead\":PaladinHoly"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "圣骑士:神圣",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "b7698b",
		},
		["\"Wowhead\":PaladinRetribution"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "圣骑士:惩戒",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "b7698b",
		},
		["\"Wowhead\":MageArcane"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "69ccf0",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["浮雲-恶魔之翼"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							72.11220673240395, -- [1]
							35097, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							11.58653519211153, -- [1]
							35149, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							9.534172050323019, -- [1]
							35016, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							54.08874532471948, -- [1]
							35099, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							60.60795647738863, -- [1]
							35102, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							8.856511390683441, -- [1]
							35129, -- [2]
							0, -- [3]
							8.172730363821829, -- [4]
							37927, -- [5]
							0, -- [6]
						},
						["INVTYPE_SHOULDER"] = {
							40.14348860931656, -- [1]
							35096, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							22.45936756205372, -- [1]
							35179, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							11.58653519211153, -- [1]
							35164, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							22.45494729683781, -- [1]
							37929, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							17.37334240054403, -- [1]
							35100, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							12.94389663379803, -- [1]
							35098, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							9.534852091125467, -- [1]
							44429, -- [2]
							0, -- [3]
						},
					},
				},
				["別雨-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							250.5035702142129, -- [1]
							73575, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							139.534172050323, -- [1]
							58485, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							223.3699421965318, -- [1]
							71289, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							68.04556273376402, -- [1]
							71151, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							123.2849370962258, -- [1]
							72888, -- [2]
							0, -- [3]
							109.6365181910915, -- [4]
							72329, -- [5]
							0, -- [6]
						},
						["INVTYPE_2HWEAPON"] = {
							628.0044202652158, -- [1]
							72863, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							230.8962937776266, -- [1]
							78815, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							170.6780006800408, -- [1]
							72852, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							169.9809588575315, -- [1]
							72851, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							117.7358041482489, -- [1]
							71213, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							169.6439986399184, -- [1]
							73572, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							122.6388983339, -- [1]
							71265, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							110.6939816388983, -- [1]
							76160, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "法师:奥术",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "4e99b3",
		},
		["\"Wowhead\":DeathKnightUnholyDps"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["你诺-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_CHEST"] = {
							4.5515360843483, -- [1]
							69889, -- [2]
							0, -- [3]
						},
						["INVTYPE_HEAD"] = {
							5.424104708234866, -- [1]
							69887, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							4.702054171968733, -- [1]
							38670, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							12.85220868932921, -- [1]
							39371, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							12.85220868932921, -- [1]
							39371, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							5.456826031630612, -- [1]
							38669, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							3.295037265951645, -- [1]
							34649, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							25.4904455874333, -- [1]
							38633, -- [2]
							0, -- [3]
						},
						["INVTYPE_RELIC"] = {
							9.041447009634611, -- [1]
							39208, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							3.035448100345392, -- [1]
							38666, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							5.525904381021633, -- [1]
							38668, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							3.955280858025814, -- [1]
							38662, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							3.459189238320306, -- [1]
							69890, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							4.169241956007999, -- [1]
							38672, -- [2]
							0, -- [3]
							3.035448100345392, -- [4]
							38671, -- [5]
							0, -- [6]
						},
						["INVTYPE_CLOAK"] = {
							3.592437738592983, -- [1]
							69892, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "死亡骑士:邪恶 ",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bf3950",
		},
		["\"Wowhead\":WarriorTank"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["Eofol-沙怒"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_LEGS"] = {
							0.3160919540229885, -- [1]
							39, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							0.3735632183908046, -- [1]
							58231, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							0.2586206896551724, -- [1]
							40, -- [2]
							0, -- [3]
						},
					},
				},
				["Esserbella-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							35.50574712643678, -- [1]
							69887, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							45.07471264367816, -- [1]
							24064, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							45.11494252873563, -- [1]
							13375, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							6.431034482758621, -- [1]
							69893, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							1.663793103448276, -- [1]
							65972, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							11.84195402298851, -- [1]
							69892, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							4.885057471264368, -- [1]
							10795, -- [2]
							0, -- [3]
							4.885057471264368, -- [4]
							10795, -- [5]
							0, -- [6]
						},
						["INVTYPE_SHOULDER"] = {
							32.27873563218391, -- [1]
							69890, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							9.301724137931034, -- [1]
							51989, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							16.5948275862069, -- [1]
							51985, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							2.772988505747127, -- [1]
							51995, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							21.25287356321839, -- [1]
							65928, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							14.59770114942529, -- [1]
							51987, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							42.64655172413793, -- [1]
							69889, -- [2]
							0, -- [3]
						},
					},
				},
				["失重-无尽之海"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_LEGS"] = {
							0.3160919540229885, -- [1]
							139, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							0.2586206896551724, -- [1]
							140, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							0.3735632183908046, -- [1]
							58245, -- [2]
							0, -- [3]
						},
					},
				},
				["Lure-达文格尔"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_FEET"] = {
							3.833333333333334, -- [1]
							6573, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							17.10919540229885, -- [1]
							7120, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							1.681034482758621, -- [1]
							6340, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							1.137931034482759, -- [1]
							6414, -- [2]
							0, -- [3]
							0.4482758620689655, -- [4]
							3235, -- [5]
							0, -- [6]
						},
						["INVTYPE_WRIST"] = {
							1.71264367816092, -- [1]
							3230, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							2.85632183908046, -- [1]
							9787, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							2.844827586206896, -- [1]
							4697, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							2.635057471264368, -- [1]
							6337, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							2.603448275862069, -- [1]
							5254, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							0.2413793103448276, -- [1]
							4568, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							5.416666666666667, -- [1]
							3733, -- [2]
							0, -- [3]
						},
					},
				},
				["失重-冰风岗"] = {
					["Visible"] = true,
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "战士:防御",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "957552",
		},
		["\"Wowhead\":PriestDiscipline"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["绑住了风-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							167.7570970130832, -- [1]
							69622, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							120.7059985188842, -- [1]
							58486, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							78.6645272772155, -- [1]
							69796, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							60.92125401135522, -- [1]
							71150, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							124.4087879535917, -- [1]
							60275, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							92.00222167366083, -- [1]
							71329, -- [2]
							0, -- [3]
							90.86299679091582, -- [4]
							58189, -- [5]
							0, -- [6]
						},
						["INVTYPE_LEGS"] = {
							170.0103678104172, -- [1]
							60261, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							105.9839545791163, -- [1]
							71266, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							124.4087879535917, -- [1]
							62386, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							83.25993581831645, -- [1]
							62416, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							110.1851394717354, -- [1]
							69612, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							525.0461614416194, -- [1]
							59525, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							160.0799802517897, -- [1]
							69578, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "牧师:戒律",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bfbfbf",
		},
		["\"Wowhead\":DruidBalance"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "德鲁伊:平衡",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bf5d07",
		},
		["\"Wowhead\":DeathKnightBloodTank"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["你诺-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							29.03931203931204, -- [1]
							69887, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							17.1965601965602, -- [1]
							38670, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							33.46191646191646, -- [1]
							69889, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							11.94348894348894, -- [1]
							38666, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							21.82063882063882, -- [1]
							38669, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							3.302211302211302, -- [1]
							38672, -- [2]
							0, -- [3]
							3.095823095823096, -- [4]
							38671, -- [5]
							0, -- [6]
						},
						["INVTYPE_RELIC"] = {
							11.16953316953317, -- [1]
							39208, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							16.53808353808354, -- [1]
							38667, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							15.49140049140049, -- [1]
							38668, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							3.624078624078624, -- [1]
							38662, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							25.22850122850123, -- [1]
							69890, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							5.277641277641278, -- [1]
							38633, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							9.921375921375921, -- [1]
							69892, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "死亡骑士:鲜血",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bf3950",
		},
		["\"Wowhead\":HunterSurvival"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["嘿嘿牛-达尔坎"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONMAINHAND"] = {
							0.6937874487543362, -- [1]
							4923, -- [2]
							0, -- [3]
						},
					},
				},
				["海雅-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							4.44812362030905, -- [1]
							61935, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							2.765058341217281, -- [1]
							51982, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							2.047934405550299, -- [1]
							62039, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							12.77514979501735, -- [1]
							42946, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							3.809208451592558, -- [1]
							65979, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							1.260485651214128, -- [1]
							51992, -- [2]
							0, -- [3]
							0.901292967518133, -- [4]
							66035, -- [5]
							0, -- [6]
						},
						["INVTYPE_LEGS"] = {
							2.520971302428256, -- [1]
							14638, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							1.528539892778303, -- [1]
							56841, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							1.15200252286345, -- [1]
							51964, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							1.747082939135919, -- [1]
							66009, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							2.162724692526017, -- [1]
							42950, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							1.389467045096184, -- [1]
							19508, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							2.883948281299274, -- [1]
							48677, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "猎人:生存",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "809f56",
		},
		["\"Wowhead\":MageFrost"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "69ccf0",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["浮雲-恶魔之翼"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							52.61275117836765, -- [1]
							35097, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							8.45348548747209, -- [1]
							35149, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							6.956090300173654, -- [1]
							35016, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							39.46291242867775, -- [1]
							35099, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							67.14165219548498, -- [1]
							35102, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							6.461672041677002, -- [1]
							35129, -- [2]
							0, -- [3]
							5.962788389977672, -- [4]
							37927, -- [5]
							0, -- [6]
						},
						["INVTYPE_SHOULDER"] = {
							29.28851401637311, -- [1]
							35096, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							16.38625651203175, -- [1]
							35179, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							8.45348548747209, -- [1]
							35164, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							16.38303150582982, -- [1]
							37929, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							12.67551476060531, -- [1]
							35100, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							9.443810468866285, -- [1]
							35098, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							6.956586454973951, -- [1]
							44429, -- [2]
							0, -- [3]
						},
					},
				},
				["別雨-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							208.0292731332176, -- [1]
							78796, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							120.5060778963036, -- [1]
							58485, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							194.8526420243116, -- [1]
							71289, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							59.93847680476308, -- [1]
							71151, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							108.8764574547259, -- [1]
							72888, -- [2]
							0, -- [3]
							89.35772761101462, -- [4]
							72329, -- [5]
							0, -- [6]
						},
						["INVTYPE_2HWEAPON"] = {
							647.1225502356735, -- [1]
							72863, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							194.0079384768048, -- [1]
							78815, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							148.093277102456, -- [1]
							72852, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							148.5869511287522, -- [1]
							72851, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							102.3024063507814, -- [1]
							71213, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							143.5906722897544, -- [1]
							72865, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							107.028280823617, -- [1]
							71265, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							96.10543289506326, -- [1]
							76160, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "法师:冰霜",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "4e99b3",
		},
		["\"Wowhead\":PriestHoly"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["绑住了风-索瑞森"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HEAD"] = {
							160.8940235503221, -- [1]
							69622, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							116.2697178404799, -- [1]
							58486, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							74.44345700955344, -- [1]
							69796, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							57.04110197733837, -- [1]
							71150, -- [2]
							0, -- [3]
						},
						["INVTYPE_HAND"] = {
							115.9364585647634, -- [1]
							60275, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							86.36991779604531, -- [1]
							71329, -- [2]
							0, -- [3]
							85.15574316818484, -- [4]
							58189, -- [5]
							0, -- [6]
						},
						["INVTYPE_LEGS"] = {
							158.0231059764497, -- [1]
							60261, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							101.9197956009776, -- [1]
							71266, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							115.9364585647634, -- [1]
							62386, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							79.46811819595645, -- [1]
							62416, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							104.0902021772939, -- [1]
							69612, -- [2]
							0, -- [3]
						},
						["INVTYPE_2HWEAPON"] = {
							478.6296378582537, -- [1]
							59525, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							148.9522328371473, -- [1]
							69578, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "牧师:神圣",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bfbfbf",
		},
		["\"Wowhead\":RogueAssassination"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["Rainylone-夏维安"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONOFFHAND"] = {
							0.810860058309038, -- [1]
							50055, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							0.810860058309038, -- [1]
							28979, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							0.9129967776584318, -- [1]
							25, -- [2]
							0, -- [3]
						},
					},
				},
				["Ylno-夏维安"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_WEAPONOFFHAND"] = {
							0.810860058309038, -- [1]
							50055, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							1.578955197239246, -- [1]
							54986, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							0.9485630987088713, -- [1]
							37, -- [2]
							0, -- [3]
						},
					},
				},
				["Elytolpain-夏维安"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_FEET"] = {
							0.6518117451062058, -- [1]
							65961, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONOFFHAND"] = {
							3.498079503910408, -- [1]
							6448, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							2.82798833819242, -- [1]
							55012, -- [2]
							0, -- [3]
						},
						["INVTYPE_WEAPONMAINHAND"] = {
							3.104475699227886, -- [1]
							68194, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							0.0004164931278633903, -- [1]
							54994, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							0.8758850478967097, -- [1]
							51964, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							0.2415660141607663, -- [1]
							55000, -- [2]
							0, -- [3]
						},
						["INVTYPE_SHOULDER"] = {
							0.6518117451062058, -- [1]
							65960, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							0.6051645147855062, -- [1]
							5193, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							0.1211995002082466, -- [1]
							52595, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["GemQualityLevel"] = 86,
			["LocalizedName"] = "潜行者:刺杀",
			["UpgradesFollowSpecialization"] = true,
			["SmartGemSocketing"] = true,
			["UnenchantedColor"] = "bfb74e",
		},
	},
	["ShownGettingStarted"] = true,
	["ButtonPosition"] = 2,
	["LastVersion"] = 1.513,
	["ShowQuestUpgradeAdvisor"] = true,
	["Digits"] = 1,
	["ShowLootUpgradeAdvisor"] = true,
}
