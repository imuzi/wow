
ChatFrameClamping = {
}
Gryphons = nil
