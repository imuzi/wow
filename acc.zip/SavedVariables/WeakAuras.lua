
WeakAurasSaved = {
	["dynamicIconCache"] = {
	},
	["editor_tab_spaces"] = 4,
	["login_squelch_time"] = 10,
	["personalRessourceDisplayFrame"] = {
		["xOffset"] = -1224.084815540641,
		["yOffset"] = -425.1940387309477,
	},
	["lastArchiveClear"] = 1580801177,
	["minimap"] = {
		["hide"] = false,
	},
	["lastUpgrade"] = 1605763155,
	["dbVersion"] = 40,
	["clearOldHistory"] = 30,
	["registered"] = {
	},
	["displays"] = {
		["Infernal Timer #1"] = {
			["iconSource"] = 0,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["preferToUpdate"] = false,
			["customText"] = "",
			["yOffset"] = -4.000003814697266,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Afenar_Warlock/88",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["ownOnly"] = true,
						["genericShowOn"] = "showOnActive",
						["use_specific_unit"] = false,
						["use_totemType"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Totem",
						["totemType"] = 1,
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["spellIds"] = {
							113860, -- [1]
						},
						["names"] = {
							"Черная душа: страдание", -- [1]
						},
						["use_unit"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["useTooltip"] = false,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["stickyDuration"] = false,
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						0.4352941176470588, -- [1]
						1, -- [2]
						0.3686274509803922, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_shadowYOffset"] = 5,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "THICKOUTLINE",
					["text_anchorPoint"] = "INNER_TOP",
					["text_fontSize"] = 64,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [1]
			},
			["height"] = 79.66663360595703,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["role"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["size"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_vehicle"] = false,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[2] = true,
						[3] = true,
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["use_petbattle"] = false,
				["faction"] = {
					["multi"] = {
					},
				},
				["use_vehicleUi"] = false,
				["race"] = {
					["multi"] = {
					},
				},
				["spellknown"] = 1122,
				["pvptalent"] = {
					["multi"] = {
					},
				},
			},
			["authorMode"] = true,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 2.6666259765625,
			["actions"] = {
				["start"] = {
					["do_glow"] = false,
				},
				["init"] = {
				},
				["finish"] = {
					["do_glow"] = false,
					["sound"] = "Interface\\Addons\\MikScrollingBattleText\\Sounds\\Cooldown.ogg",
					["do_sound"] = false,
				},
			},
			["cooldownEdge"] = false,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["regionType"] = "icon",
			["conditions"] = {
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "shrink",
					["easeStrength"] = 3,
				},
			},
			["config"] = {
			},
			["frameStrata"] = 4,
			["desaturate"] = false,
			["zoom"] = 0.3,
			["semver"] = "2.2.2",
			["tocversion"] = 80205,
			["id"] = "Infernal Timer #1",
			["auto"] = false,
			["alpha"] = 1,
			["width"] = 82.333251953125,
			["cooldownTextDisabled"] = false,
			["uid"] = "m4QVb6l2n6J",
			["inverse"] = false,
			["authorOptions"] = {
			},
			["displayIcon"] = 136219,
			["cooldown"] = true,
			["parent"] = "Infernal Timer ",
		},
		["嘻嘻"] = {
			["sparkWidth"] = 10,
			["sparkOffsetX"] = 0,
			["authorOptions"] = {
			},
			["yOffset"] = 31.88861083984375,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["icon"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["rem"] = "1",
						["auranames"] = {
							"灵魂腐化", -- [1]
						},
						["matchesShowOn"] = "showOnMissing",
						["genericShowOn"] = "showOnCooldown",
						["names"] = {
						},
						["remaining_operator"] = "<",
						["remaining"] = "58",
						["use_genericShowOn"] = true,
						["unit"] = "nameplate",
						["ownOnly"] = true,
						["use_remaining"] = true,
						["type"] = "status",
						["spellName"] = 325640,
						["unevent"] = "auto",
						["useName"] = true,
						["use_debuffClass"] = false,
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["event"] = "Cooldown Progress (Spell)",
						["duration"] = "1",
						["realSpellName"] = "灵魂腐化",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["debuffType"] = "HARMFUL",
						["remOperator"] = ">",
						["subeventPrefix"] = "SPELL",
						["use_track"] = true,
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["rem"] = "5",
						["useStacks"] = true,
						["auranames"] = {
							"大难临头", -- [1]
						},
						["totalOperator"] = ">",
						["ownOnly"] = true,
						["subeventPrefix"] = "SPELL",
						["stacks"] = "39",
						["debuffType"] = "HELPFUL",
						["total"] = "10",
						["stacksOperator"] = ">=",
						["subeventSuffix"] = "_CAST_START",
						["useTotal"] = false,
						["event"] = "Health",
						["unit"] = "player",
						["names"] = {
						},
						["spellIds"] = {
						},
						["type"] = "aura2",
						["remOperator"] = "<=",
						["useName"] = true,
						["matchesShowOn"] = "showOnActive",
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["rem"] = "1",
						["auranames"] = {
							"灵魂腐化", -- [1]
						},
						["remaining_operator"] = ">=",
						["genericShowOn"] = "showOnCooldown",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["remaining"] = "52",
						["ownOnly"] = true,
						["names"] = {
						},
						["matchesShowOn"] = "showOnMissing",
						["debuffType"] = "HARMFUL",
						["useName"] = true,
						["spellName"] = 325640,
						["subeventSuffix"] = "_CAST_START",
						["use_remaining"] = true,
						["use_debuffClass"] = false,
						["unevent"] = "auto",
						["use_absorbMode"] = true,
						["duration"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["use_unit"] = true,
						["realSpellName"] = "灵魂腐化",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["type"] = "status",
						["remOperator"] = ">",
						["unit"] = "nameplate",
						["use_track"] = true,
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["rem"] = "5",
						["useStacks"] = true,
						["auranames"] = {
							"大难临头", -- [1]
						},
						["totalOperator"] = ">",
						["matchesShowOn"] = "showOnActive",
						["subeventPrefix"] = "SPELL",
						["stacks"] = "50",
						["debuffType"] = "HELPFUL",
						["total"] = "10",
						["stacksOperator"] = ">=",
						["subeventSuffix"] = "_CAST_START",
						["useTotal"] = false,
						["event"] = "Health",
						["ownOnly"] = true,
						["unit"] = "player",
						["spellIds"] = {
						},
						["useName"] = true,
						["remOperator"] = "<=",
						["type"] = "aura2",
						["names"] = {
						},
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [4]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n    return (t[1] and  t[2]   and t[3]) or t[4]\nend",
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["use_rotate"] = false,
					["duration_type"] = "seconds",
					["use_scale"] = true,
					["alphaType"] = "hide",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "function()\n    return 0\nend\n",
					["scalex"] = 3.3,
					["easeStrength"] = 3,
					["use_translate"] = true,
					["use_alpha"] = false,
					["rotate"] = 333,
					["type"] = "custom",
					["scaley"] = 3.3,
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["preset"] = "slideright",
					["alpha"] = 0,
					["colorA"] = 1,
					["y"] = -80,
					["x"] = -88,
					["scaleType"] = "straightScale",
					["colorR"] = 1,
					["translateType"] = "straightTranslate",
					["rotateFunc"] = "function(progress, start, delta)\n    local angle = progress * 2 * math.pi\n    return start + math.sin(angle) * delta\nend\n",
					["duration"] = ".66",
					["rotateType"] = "wobble",
				},
				["main"] = {
					["translateType"] = "straightTranslate",
					["use_rotate"] = false,
					["use_scale"] = true,
					["scalex"] = 1.6,
					["duration_type"] = "seconds",
					["colorB"] = 1,
					["colorG"] = 1,
					["easeStrength"] = 3,
					["rotateType"] = "backandforth",
					["colorA"] = 1,
					["use_translate"] = false,
					["scaley"] = 1.6,
					["x"] = 60,
					["type"] = "preset",
					["preset"] = "alphaPulse",
					["easeType"] = "none",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["use_color"] = false,
					["alpha"] = 0,
					["scaleType"] = "pulse",
					["y"] = -55,
					["colorType"] = "straightHSV",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\nend\n",
					["duration"] = "0.66",
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    return WeakAuras.GetHSVTransition(progress, r1, g1, b1, a1, r2, g2, b2, a2)\nend\n",
					["rotate"] = 0,
					["rotateFunc"] = "function(progress, start, delta)\n    local prog\n    if(progress < 0.25) then\n        prog = progress * 4\n    elseif(progress < .75) then\n        prog = 2 - (progress * 4)\n    else\n        prog = (progress - 1) * 4\n    end\n    return start + (prog * delta)\nend\n",
					["colorR"] = 1,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["sparkHidden"] = "NEVER",
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 87,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["sparkOffsetY"] = 0,
			["subRegions"] = {
			},
			["height"] = 259.6665954589844,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						[3] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["textureWrapMode"] = "CLAMP",
			["color"] = {
				0.9333333333333333, -- [1]
				0.9294117647058824, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["iconSource"] = -1,
			["xOffset"] = 191.111328125,
			["discrete_rotation"] = 0,
			["mirror"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "texture",
			["selfPoint"] = "CENTER",
			["blendMode"] = "ADD",
			["icon_side"] = "RIGHT",
			["uid"] = "novzDjHlbSM",
			["sparkHeight"] = 30,
			["texture"] = "186214",
			["anchorFrameType"] = "SCREEN",
			["zoom"] = 0,
			["spark"] = false,
			["frameStrata"] = 9,
			["id"] = "嘻嘻",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["alpha"] = 1,
			["width"] = 39.22321701049805,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["config"] = {
			},
			["inverse"] = false,
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 3,
						["op"] = "<=",
						["variable"] = "expirationTime",
						["value"] = "55",
					},
					["changes"] = {
						{
							["value"] = 84,
							["property"] = "width",
						}, -- [1]
						{
							["value"] = 914,
							["property"] = "height",
						}, -- [2]
					},
				}, -- [1]
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["parent"] = "痛苦ss",
		},
		["对我读控心术"] = {
			["color"] = {
				1, -- [1]
				0.02352941176470588, -- [2]
				0, -- [3]
				0.75, -- [4]
			},
			["yOffset"] = 176.0003356933594,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_unit"] = true,
						["spell"] = "控心术",
						["event"] = "Cast",
						["unevent"] = "auto",
						["names"] = {
						},
						["use_absorbMode"] = true,
						["use_spell"] = true,
						["subeventPrefix"] = "SPELL",
						["destUnit"] = "player",
						["type"] = "status",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["use_destUnit"] = true,
						["unit"] = "nameplate",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["unit"] = "nameplate",
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 200,
			["rotate"] = true,
			["load"] = {
				["size"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura58",
			["parent"] = "SS通用",
			["frameStrata"] = 1,
			["width"] = 200,
			["id"] = "对我读控心术",
			["authorOptions"] = {
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 257.77783203125,
			["uid"] = "gwWXjBfKe)Y",
			["discrete_rotation"] = 0,
			["config"] = {
			},
			["conditions"] = {
			},
			["information"] = {
			},
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["use_scale"] = true,
					["colorB"] = 1,
					["colorG"] = 1,
					["type"] = "custom",
					["easeType"] = "easeIn",
					["duration"] = "。33",
					["scaley"] = 2.3,
					["alpha"] = 0,
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["y"] = 0,
					["x"] = 0,
					["easeStrength"] = 3,
					["colorA"] = 1,
					["duration_type"] = "seconds",
					["rotate"] = 0,
					["scaleType"] = "straightScale",
					["scalex"] = 2.3,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "alphaPulse",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["糖"] = {
			["iconSource"] = -1,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["yOffset"] = 184.8888854980469,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["itemName"] = 5512,
						["use_count"] = true,
						["auranames"] = {
							"爆燃冲刺", -- [1]
						},
						["duration"] = "1",
						["names"] = {
						},
						["use_includeCharges"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["unevent"] = "auto",
						["unit"] = "player",
						["event"] = "Item Count",
						["use_unit"] = true,
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["count"] = "1",
						["useName"] = true,
						["use_itemName"] = true,
						["count_operator"] = "<",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["useGlowColor"] = false,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["glowXOffset"] = 0,
					["glow"] = false,
					["glowThickness"] = 1,
					["glowScale"] = 1,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 58.6668701171875,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["icon"] = true,
			["cooldownTextDisabled"] = false,
			["information"] = {
			},
			["authorOptions"] = {
			},
			["zoom"] = 0,
			["xOffset"] = 1.77801513671875,
			["frameStrata"] = 1,
			["id"] = "糖",
			["uid"] = "juQauragEmi",
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["width"] = 58.66664123535156,
			["config"] = {
			},
			["inverse"] = false,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["conditions"] = {
			},
			["cooldown"] = false,
			["parent"] = "SS通用",
		},
		["补鬼影"] = {
			["authorOptions"] = {
			},
			["yOffset"] = 260,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["do_custom"] = false,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["rem"] = "2",
						["auranames"] = {
							"暗影之拥", -- [1]
						},
						["matchesShowOn"] = "showOnMissing",
						["unit"] = "target",
						["ownOnly"] = true,
						["debuffType"] = "HARMFUL",
						["spellName"] = 48181,
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["unevent"] = "auto",
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["event"] = "Action Usable",
						["duration"] = "1",
						["realSpellName"] = "鬼影缠身",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["names"] = {
						},
						["remOperator"] = "<=",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "function (t)\n    return (t[1] or  t[2])  and t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["duration"] = ".33",
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = true,
					["duration_type"] = "seconds",
					["scalex"] = 2.7,
					["type"] = "custom",
					["easeStrength"] = 3,
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["preset"] = "slidetop",
					["alpha"] = 0,
					["use_scale"] = true,
					["y"] = -95,
					["x"] = -75,
					["scaley"] = 2.7,
					["colorA"] = 1,
					["translateType"] = "straightTranslate",
					["rotate"] = 0,
					["scaleType"] = "straightScale",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 94,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						[3] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = true,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\PVPFrame\\PVP-Banner-Emblem-5",
			["uid"] = "2y44)RcybBW",
			["selfPoint"] = "CENTER",
			["anchorFrameType"] = "SCREEN",
			["id"] = "补鬼影",
			["color"] = {
				0.7254901960784313, -- [1]
				0.08235294117647059, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["alpha"] = 0.71,
			["width"] = 59,
			["parent"] = "痛苦ss",
			["config"] = {
			},
			["xOffset"] = 140,
			["frameStrata"] = 9,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["discrete_rotation"] = 0,
		},
		["浩劫提醒"] = {
			["authorOptions"] = {
			},
			["yOffset"] = 188.8893737792969,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["spellName"] = 200546,
						["type"] = "status",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["names"] = {
						},
						["duration"] = "1",
						["event"] = "Action Usable",
						["unit"] = "player",
						["realSpellName"] = "浩劫灾祸",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["names"] = {
						},
						["duration"] = "1",
						["event"] = "Action Usable",
						["unit"] = "player",
						["realSpellName"] = "浩劫",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_track"] = true,
						["spellName"] = 80240,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "aura2",
						["use_debuffClass"] = false,
						["subeventSuffix"] = "_CAST_START",
						["group_countOperator"] = ">=",
						["useGroup_count"] = true,
						["event"] = "Health",
						["unit"] = "nameplate",
						["namePattern_operator"] = "match('%s')",
						["group_count"] = "2",
						["spellIds"] = {
						},
						["names"] = {
						},
						["namePattern_name"] = ".",
						["useNamePattern"] = true,
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "status",
						["spellName"] = 6789,
						["unevent"] = "auto",
						["use_spellName"] = true,
						["remaining_operator"] = "<=",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "死亡缠绕",
						["remaining"] = "3",
						["duration"] = "1",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["use_remaining"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [4]
				{
					["trigger"] = {
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["powertype"] = 7,
						["use_powertype"] = true,
						["spellName"] = 0,
						["type"] = "status",
						["unevent"] = "auto",
						["power_operator"] = ">=",
						["event"] = "Power",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["use_power"] = true,
						["use_unit"] = true,
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["power"] = "3",
					},
					["untrigger"] = {
					},
				}, -- [5]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    return ( t[1] or t[2]) and t[3] and t[4] and t[5]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 81.77699279785156,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\PVPFrame\\Icons\\PVP-Banner-Emblem-55",
			["parent"] = "毁灭ss",
			["frameStrata"] = 1,
			["width"] = 80.88914489746094,
			["id"] = "浩劫提醒",
			["xOffset"] = -133.3329467773438,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				1, -- [1]
				0.03137254901960784, -- [2]
				0.6039215686274509, -- [3]
				0.75, -- [4]
			},
			["uid"] = "y(6p)GSfzbv",
			["discrete_rotation"] = 0,
			["config"] = {
			},
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 5,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0.9372549019607843, -- [2]
								0.9921568627450981, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [1]
			},
			["information"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "pulse",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["SPELL LOCK"] = {
			["outline"] = "OUTLINE",
			["iconSource"] = 0,
			["xOffset"] = 178.77783203125,
			["preferToUpdate"] = false,
			["yOffset"] = 289.3338317871094,
			["displayText_format_p_time_dynamic"] = false,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["spellId"] = "Création d’un puits des âmes",
						["use_genericShowOn"] = true,
						["use_spell"] = true,
						["group_count"] = "0",
						["use_petspec"] = false,
						["group_countOperator"] = ">=",
						["use_health"] = false,
						["subeventSuffix"] = "_CAST_SUCCESS",
						["percenthealth"] = "33",
						["event"] = "Action Usable",
						["use_behavior"] = false,
						["use_spellId"] = false,
						["use_track"] = true,
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnCooldown",
						["subeventPrefix"] = "SPELL",
						["namerealm"] = "Création d’un puits des âmes",
						["use_HasPet"] = false,
						["use_mounted"] = false,
						["names"] = {
							"Puits des âmes", -- [1]
						},
						["type"] = "status",
						["use_alive"] = true,
						["unevent"] = "auto",
						["use_vehicle"] = false,
						["spell"] = "Création d’un puits des âmes",
						["debuffType"] = "HELPFUL",
						["use_unit"] = true,
						["realSpellName"] = "法术封锁",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["duration"] = "20",
						["unit"] = "pet",
						["use_percenthealth"] = true,
						["percenthealth_operator"] = "<=",
						["spellName"] = 132409,
					},
					["untrigger"] = {
						["unit"] = "pet",
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_power"] = true,
						["use_spell"] = false,
						["remaining"] = "0.5",
						["spellName"] = 0,
						["nameplateType"] = "hostile",
						["power_operator"] = ">",
						["event"] = "Cast",
						["use_nameplateType"] = true,
						["use_destUnit"] = false,
						["use_track"] = true,
						["use_specId"] = false,
						["use_unitisunit"] = false,
						["use_hostility"] = false,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "nameplate",
						["use_class"] = false,
						["powertype"] = 0,
						["remaining_operator"] = ">",
						["use_powertype"] = false,
						["debuffType"] = "HELPFUL",
						["use_interruptible"] = true,
						["use_remaining"] = true,
						["use_level"] = false,
						["unevent"] = "auto",
						["classification"] = {
						},
						["power"] = "0",
						["use_requirePowerType"] = false,
						["duration"] = "1",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["use_character"] = false,
						["use_unit"] = true,
						["specId"] = {
						},
						["type"] = "status",
						["class"] = "DRUID",
						["use_genericShowOn"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate",
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t) \n    return  (t[1] or  t[2])  and   t[3] \nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["semver"] = "1.0.0",
			["desaturate"] = false,
			["justify"] = "LEFT",
			["font"] = "默认",
			["version"] = 1,
			["subRegions"] = {
			},
			["height"] = 55,
			["cooldown"] = true,
			["load"] = {
				["ingroup"] = {
					["single"] = "raid",
					["multi"] = {
						["raid"] = true,
					},
				},
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
						["WARLOCK"] = true,
					},
				},
				["affixes"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["talent3"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						true, -- [1]
					},
				},
				["size"] = {
					["single"] = "pvp",
					["multi"] = {
					},
				},
			},
			["fixedWidth"] = 200,
			["color"] = {
				1, -- [1]
				0.1333333333333333, -- [2]
				0.807843137254902, -- [3]
				1, -- [4]
			},
			["fontSize"] = 37,
			["icon"] = true,
			["parent"] = "SS通用",
			["shadowXOffset"] = 1,
			["uid"] = "ubMYCFAhsNz",
			["authorOptions"] = {
			},
			["anchorFrameType"] = "SCREEN",
			["regionType"] = "text",
			["alpha"] = 1,
			["conditions"] = {
			},
			["displayText"] = "SPELL LOCK！\n",
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["preset"] = "fade",
				},
				["main"] = {
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["use_scale"] = false,
					["alphaType"] = "straight",
					["colorA"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["use_alpha"] = false,
					["type"] = "preset",
					["scaleType"] = "pulse",
					["easeType"] = "none",
					["colorR"] = 1,
					["scaley"] = 1,
					["alpha"] = 0,
					["easeStrength"] = 3,
					["y"] = 0,
					["x"] = 0,
					["duration_type"] = "seconds",
					["preset"] = "alphaPulse",
					["duration"] = "5",
					["rotate"] = 0,
					["colorB"] = 1,
					["scalex"] = 1,
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["preset"] = "fade",
				},
			},
			["displayText_format_p_time_precision"] = 1,
			["zoom"] = 0,
			["url"] = "https://wago.io/UVsQmiaHX/1",
			["cooldownTextDisabled"] = true,
			["auto"] = false,
			["wordWrap"] = "WordWrap",
			["id"] = "SPELL LOCK",
			["shadowYOffset"] = -1,
			["frameStrata"] = 1,
			["width"] = 55,
			["stickyDuration"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["anchorPoint"] = "CENTER",
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayIcon"] = 132163,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["cooldownEdge"] = false,
		},
		["Infernal Timer #5"] = {
			["iconSource"] = 0,
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["customText"] = "",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Afenar_Warlock/88",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["totemType"] = 5,
						["duration"] = "1",
						["event"] = "Totem",
						["use_unit"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["use_totemType"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["stickyDuration"] = false,
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						0.4352941176470588, -- [1]
						1, -- [2]
						0.3686274509803922, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_shadowYOffset"] = 5,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "THICKOUTLINE",
					["text_anchorPoint"] = "INNER_TOP",
					["text_fontSize"] = 64,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [1]
			},
			["height"] = 77,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["role"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["size"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_vehicle"] = false,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[2] = true,
						[3] = true,
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["use_petbattle"] = false,
				["faction"] = {
					["multi"] = {
					},
				},
				["use_vehicleUi"] = false,
				["race"] = {
					["multi"] = {
					},
				},
				["spellknown"] = 1122,
				["pvptalent"] = {
					["multi"] = {
					},
				},
			},
			["authorMode"] = true,
			["anchorFrameType"] = "SCREEN",
			["useTooltip"] = false,
			["cooldownEdge"] = false,
			["desaturate"] = false,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["regionType"] = "icon",
			["conditions"] = {
			},
			["authorOptions"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
			},
			["config"] = {
			},
			["frameStrata"] = 4,
			["actions"] = {
				["start"] = {
					["do_glow"] = false,
				},
				["init"] = {
				},
				["finish"] = {
					["do_glow"] = false,
					["sound"] = "Interface\\Addons\\MikScrollingBattleText\\Sounds\\Cooldown.ogg",
					["do_sound"] = false,
				},
			},
			["zoom"] = 0.3,
			["auto"] = false,
			["tocversion"] = 80205,
			["id"] = "Infernal Timer #5",
			["semver"] = "2.2.2",
			["alpha"] = 1,
			["width"] = 77,
			["cooldownTextDisabled"] = false,
			["uid"] = "v0IfEQpa)nw",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayIcon"] = 136219,
			["cooldown"] = true,
			["parent"] = "Infernal Timer ",
		},
		["Pet HEAL"] = {
			["outline"] = "OUTLINE",
			["iconSource"] = 0,
			["color"] = {
				1, -- [1]
				0.5254901960784314, -- [2]
				0.7843137254901961, -- [3]
				1, -- [4]
			},
			["preferToUpdate"] = false,
			["yOffset"] = 163.1114196777344,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["spellId"] = "Création d’un puits des âmes",
						["use_absorbMode"] = true,
						["names"] = {
							"Puits des âmes", -- [1]
						},
						["duration"] = "20",
						["genericShowOn"] = "showOnActive",
						["unit"] = "pet",
						["use_alive"] = true,
						["use_spell"] = true,
						["use_unit"] = true,
						["type"] = "status",
						["group_count"] = "0",
						["use_spellId"] = false,
						["use_HasPet"] = false,
						["group_countOperator"] = ">=",
						["namerealm"] = "Création d’un puits des âmes",
						["spell"] = "Création d’un puits des âmes",
						["use_health"] = false,
						["unevent"] = "auto",
						["use_vehicle"] = false,
						["percenthealth"] = "33",
						["event"] = "Health",
						["spellName"] = "Création d’un puits des âmes",
						["subeventSuffix"] = "_CAST_SUCCESS",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_mounted"] = false,
						["debuffType"] = "HELPFUL",
						["use_percenthealth"] = true,
						["percenthealth_operator"] = "<=",
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
						["unit"] = "pet",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["use_vehicle"] = false,
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnActive",
						["subeventPrefix"] = "SPELL",
						["duration"] = "1",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Conditions",
						["use_unit"] = true,
						["use_alive"] = true,
						["unit"] = "player",
						["use_mounted"] = false,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["spellId"] = "Création d’un puits des âmes",
						["use_unit"] = true,
						["subeventPrefix"] = "SPELL",
						["duration"] = "20",
						["use_spell"] = true,
						["unit"] = "pet",
						["use_percenthealth"] = true,
						["debuffType"] = "HELPFUL",
						["use_mounted"] = false,
						["spell"] = "Création d’un puits des âmes",
						["group_count"] = "0",
						["use_spellName"] = true,
						["use_HasPet"] = false,
						["group_countOperator"] = ">=",
						["subeventSuffix"] = "_CAST_SUCCESS",
						["type"] = "status",
						["namerealm"] = "Création d’un puits des âmes",
						["unevent"] = "auto",
						["use_vehicle"] = false,
						["percenthealth"] = "0",
						["event"] = "Health",
						["spellName"] = "Création d’un puits des âmes",
						["use_health"] = false,
						["use_spellId"] = false,
						["spellIds"] = {
						},
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnActive",
						["use_alive"] = true,
						["percenthealth_operator"] = ">",
						["names"] = {
							"Puits des âmes", -- [1]
						},
					},
					["untrigger"] = {
						["unit"] = "pet",
					},
				}, -- [3]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function (t)\n    if t[4] then return false end \n    return  (t[1] and  t[2])  or  t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["preset"] = "fade",
				},
				["main"] = {
					["colorR"] = 1,
					["scalex"] = 1,
					["alphaType"] = "straight",
					["colorA"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["use_alpha"] = false,
					["type"] = "preset",
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["easeType"] = "none",
					["scaleType"] = "pulse",
					["scaley"] = 1,
					["alpha"] = 0,
					["easeStrength"] = 3,
					["y"] = 0,
					["x"] = 0,
					["duration_type"] = "seconds",
					["preset"] = "alphaPulse",
					["duration"] = "5",
					["rotate"] = 0,
					["use_scale"] = false,
					["colorB"] = 1,
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["preset"] = "fade",
				},
			},
			["justify"] = "LEFT",
			["desaturate"] = false,
			["parent"] = "SS通用",
			["font"] = "默认",
			["version"] = 1,
			["subRegions"] = {
			},
			["height"] = 55,
			["cooldown"] = true,
			["load"] = {
				["ingroup"] = {
					["single"] = "raid",
					["multi"] = {
						["raid"] = true,
					},
				},
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
						["WARLOCK"] = true,
					},
				},
				["affixes"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["talent3"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						true, -- [1]
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["conditions"] = {
			},
			["automaticWidth"] = "Auto",
			["fontSize"] = 37,
			["xOffset"] = -120.7777709960938,
			["wordWrap"] = "WordWrap",
			["shadowXOffset"] = 1,
			["uid"] = "k5BJyYFzwDo",
			["fixedWidth"] = 200,
			["anchorFrameType"] = "SCREEN",
			["regionType"] = "text",
			["alpha"] = 1,
			["icon"] = true,
			["displayText_format_p_time_dynamic"] = false,
			["displayText"] = "HEAL PET！",
			["displayText_format_p_time_precision"] = 1,
			["cooldownTextDisabled"] = true,
			["shadowYOffset"] = -1,
			["zoom"] = 0,
			["auto"] = false,
			["semver"] = "1.0.0",
			["id"] = "Pet HEAL",
			["url"] = "https://wago.io/UVsQmiaHX/1",
			["frameStrata"] = 1,
			["width"] = 55,
			["stickyDuration"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["authorOptions"] = {
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayIcon"] = 132163,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["selfPoint"] = "CENTER",
		},
		["死缠"] = {
			["parent"] = "SS通用",
			["yOffset"] = 136.4445495605469,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["useGroup_count"] = true,
						["duration"] = "1",
						["useHostility"] = true,
						["hostility"] = "hostile",
						["group_count"] = "2",
						["subeventPrefix"] = "",
						["group_countOperator"] = ">=",
						["debuffType"] = "HELPFUL",
						["subeventSuffix"] = "",
						["type"] = "custom",
						["namePattern_name"] = ".",
						["custom_type"] = "status",
						["unit"] = "nameplate",
						["spellIds"] = {
						},
						["event"] = "Combat Events",
						["unevent"] = "timed",
						["use_eventtype"] = true,
						["use_spellName"] = true,
						["custom"] = "function()\n    local count = 0\n    for i = 1, 40 do\n        local unit = \"nameplate\"..i\n        local plateFrame = C_NamePlate.GetNamePlateForUnit (unit, issecure())\n        if UnitCanAttack(\"player\", unit)\n        and WeakAuras.CheckRange(unit, 19, \"<=\")\n        then\n            if Plater.GetUnitType (plateFrame) == \"normal\"  then\n                count = count + 1\n            end \n            \n        end\n    end\n    \n    return count >=1;\n    \nend",
						["names"] = {
						},
						["check"] = "update",
						["useNamePattern"] = true,
						["spellName"] = 0,
						["namePattern_operator"] = "match('%s')",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "死亡缠绕",
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["use_track"] = true,
						["spellName"] = 6789,
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "aura2",
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function (t)\n    return ((t[1] and  t[2] ) or t[3] or t[4]) and t[5] and  t[6] and (t[8] and not t[7])\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["preset"] = "grow",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = true,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 108.0001068115234,
			["rotate"] = true,
			["load"] = {
				["difficulty"] = {
				},
				["ingroup"] = {
					["single"] = "group",
					["multi"] = {
						["group"] = true,
					},
				},
				["use_zone"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						true, -- [1]
						[3] = true,
					},
				},
				["size"] = {
					["single"] = "arena",
					["multi"] = {
						["arena"] = true,
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = true,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura15",
			["config"] = {
			},
			["selfPoint"] = "CENTER",
			["frameStrata"] = 9,
			["id"] = "死缠",
			["authorOptions"] = {
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				0.3294117647058824, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["uid"] = "Dsi8jKrErxU",
			["xOffset"] = -154.8890991210938,
			["width"] = 143.5556945800781,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["discrete_rotation"] = 0,
		},
		["SS通用"] = {
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["controlledChildren"] = {
				"对我读控心术", -- [1]
				"控心术", -- [2]
				"被控制提醒减伤", -- [3]
				"被控制提醒狗技能", -- [4]
				"被控制提醒徽章", -- [5]
				"爆燃", -- [6]
				"糖", -- [7]
				"魔甲术", -- [8]
				"血量低", -- [9]
				"战斗状态", -- [10]
				"战斗状态焦点", -- [11]
				"战斗状态目标", -- [12]
				"可以排zc了", -- [13]
				"hp", -- [14]
				"Demonic Circle: Teleport 2", -- [15]
				" 法阵不可用！", -- [16]
				"暗影系被反", -- [17]
				"Pet Dead Alert", -- [18]
				"Pet HEAL", -- [19]
				"Change Focus", -- [20]
				"SPELL LOCK", -- [21]
				"FAST SPELL LOCK", -- [22]
				"狗反", -- [23]
				"群恐", -- [24]
				"黑魂", -- [25]
				"魅惑", -- [26]
				"狗吃魔法", -- [27]
				"虚空防护", -- [28]
				"补诅咒", -- [29]
				"心能", -- [30]
				"吸血", -- [31]
				"群控", -- [32]
				"暗怒气", -- [33]
				"死缠", -- [34]
				"门快好了", -- [35]
				"额", -- [36]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["authorOptions"] = {
			},
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "group",
			["borderSize"] = 2,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["xOffset"] = 0,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["event"] = "Health",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["information"] = {
			},
			["internalVersion"] = 40,
			["yOffset"] = 0,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["id"] = "SS通用",
			["selfPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["borderOffset"] = 4,
			["uid"] = "C0oGFbQktht",
			["borderInset"] = 1,
			["config"] = {
			},
			["conditions"] = {
			},
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["scale"] = 1,
		},
		["急速触发快速"] = {
			["outline"] = "OUTLINE",
			["color"] = {
				1, -- [1]
				0.08627450980392157, -- [2]
				0.9882352941176471, -- [3]
				1, -- [4]
			},
			["displayText"] = "%c s",
			["customText"] = "function()\n    local name, rank, icon, castTime, minRange, maxRange = GetSpellInfo(\"116858\")\n    return string.format(\"%.2f\", castTime/1000)\nend",
			["yOffset"] = 120,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["debuffType"] = "HELPFUL",
						["unevent"] = "auto",
						["custom_type"] = "status",
						["names"] = {
						},
						["genericShowOn"] = "showOnActive",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["spellIds"] = {
						},
						["custom"] = "function()\n    local name, rank, icon, castTime, minRange, maxRange = GetSpellInfo(\"116858\")\n    return castTime <1450\nend\n\n\n\n\n\n\n\n",
						["check"] = "update",
						["use_unit"] = true,
						["event"] = "Health",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["power_operator"] = ">=",
						["use_power"] = true,
						["event"] = "Power",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["powertype"] = 7,
						["power"] = "2",
						["use_unit"] = true,
						["unit"] = "player",
						["unevent"] = "auto",
						["use_powertype"] = true,
						["duration"] = "1",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "aura2",
						["stacksOperator"] = "<=",
						["auranames"] = {
							"爆燃", -- [1]
						},
						["duration"] = "1",
						["matchesShowOn"] = "showOnMissing",
						["event"] = "Health",
						["use_unit"] = true,
						["useName"] = true,
						["stacks"] = "1",
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["subeventPrefix"] = "SPELL",
						["unevent"] = "auto",
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "pulse",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["height"] = 317,
			["rotate"] = true,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["role"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["size"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["talent3"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["faction"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 19,
			["wordWrap"] = "WordWrap",
			["mirror"] = false,
			["fixedWidth"] = 200,
			["regionType"] = "texture",
			["textureWrapMode"] = "CLAMP",
			["blendMode"] = "BLEND",
			["selfPoint"] = "BOTTOM",
			["preferToUpdate"] = false,
			["texture"] = "1029138",
			["parent"] = "毁灭ss",
			["config"] = {
			},
			["justify"] = "LEFT",
			["tocversion"] = 80300,
			["id"] = "急速触发快速",
			["authorOptions"] = {
			},
			["alpha"] = 0.97,
			["width"] = 302,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "esUwy30Y4K(",
			["frameStrata"] = 1,
			["xOffset"] = 130,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["1TotemNameplateTracker"] = {
			["iconSource"] = -1,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["preferToUpdate"] = false,
			["customText"] = "function()\n    if aura_env.state and aura_env.state.unit then\n        local region = aura_env.region\n        local plate = C_NamePlate.GetNamePlateForUnit(aura_env.state.unit)\n        \n        if plate then \n            region:ClearAllPoints()\n            region:SetPoint(\"BOTTOM\", plate, \"TOP\", 0, -23)\n            region:SetScale(aura_env.state.scale)\n            region:SetAlpha(aura_env.state.alpha)\n            region:Show()\n        else\n            region:Hide()\n        end\n    end\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["cooldownEdge"] = true,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["unevent"] = "timed",
						["names"] = {
						},
						["duration"] = "1",
						["event"] = "Chat Message",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["custom"] = "function(allstates, event, unit)\n    if event == \"NAME_PLATE_UNIT_ADDED\" then\n        if UnitExists(unit) and string.match(unit, \"nameplate\") then\n            for _, state in pairs(allstates) do\n                if UnitIsUnit(state.unit, unit) then\n                    state.changed = true\n                    state.show = false\n                end\n            end\n            \n            for i = 0, 6 do\n                if string.match(UnitName(unit), aura_env.totems[i]) and UnitCanAttack(unit, \"player\") then\n                    local icon, duration, expirationTime, scale = 0 \n                    \n                    icon = aura_env.totemicons[i]\n                    duration = aura_env.totemtimers[i]\n                    expirationTime = GetTime() + duration\n                    scale = aura_env.totemscale[i]\n                    \n                    local ic = GetSpellTexture(aura_env.totems[i])\n                    \n                    print(ic)\n                    if ic then\n                        icon = ic \n                    end\n                    \n                    allstates[unit] = {\n                        changed = false,\n                        show = true,\n                        icon = icon,\n                        progressType = \"timed\",\n                        duration = duration,\n                        expirationTime = expirationTime,\n                        unit = unit,\n                        autoHide = true,\n                        scale = scale[1],\n                        alpha = scale[2],\n                    }\n                end\n            end\n        end\n    end\n    \n    if event == \"NAME_PLATE_UNIT_REMOVED\" then\n        for _, state in pairs(allstates) do\n            if state.unit == unit then\n                state.show = false\n                state.changed = true\n            end\n        end\n    end\n    \n    return true\nend",
						["spellIds"] = {
						},
						["events"] = "NAME_PLATE_UNIT_ADDED, NAME_PLATE_UNIT_REMOVED",
						["check"] = "event",
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
						["customVariables"] = "{\n    expirationTime = true,\n}",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 13,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%c",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "CENTER",
					["text_fontSize"] = 18,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [1]
			},
			["height"] = 66,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorOptions"] = {
			},
			["actions"] = {
				["start"] = {
					["do_message"] = false,
					["do_sound"] = false,
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "aura_env.totems = {\n    [0] = \"根基图腾\",\n    [1] = \"战栗图腾\",\n    [2] = \"电能图腾\",\n    [3] = \"灵魂链接图腾\",\n    [4] = \"反击图腾\",\n    [5] = \"地缚图腾\",\n    [6] = \"天怒图腾\",\n    [7] = \"陷地图腾\",\n    [8] = \"战旗\", --war banner\n}\n\n\naura_env.totemicons= {\n    [0] = 136039, --grounding\n    [1] = 136108, --tremor\n    [2] = 136013, --capacitor \n    [3] = 237586, --spiritlink\n    [4] = 511726, --counterstrike\n    [5] = 136102, --earthbind\n    [6] = 135829, --skyfury\n    [7] = 136100, --earthgrab \n    [8] = 603532, --war banner\n}\n\naura_env.totemtimers= {\n    [0] = 3, --grounding\n    [1] = 10, --tremor\n    [2] = 2, --capacitor \n    [3] = 6, --spiritlink\n    [4] = 15, --counterstrike\n    [5] = 20, --earthbind\n    [6] = 15, --skyfury\n    [7] = 20, --earthgrab \n    [8] = 0, --earthgrab \n}\n\naura_env.totemscale= {  --{scale, alpha}\n    [0] = {1, 1}, --grounding\n    [1] = {1, 1}, --tremor\n    [2] = {1, 1}, --capacitor \n    [3] = {1, 1}, --spiritlink\n    [4] = {1, 1}, --counterstrike\n    [5] = {1, 1}, --earthbind \n    [6] = {1, 1}, --skyfury \n    [7] = {1, 1}, --earthgrab \n    [8] = {1, 1}, --earthgrab \n}",
					["do_custom"] = true,
				},
			},
			["regionType"] = "icon",
			["url"] = "https://wago.io/RKZ96nCmL/13",
			["xOffset"] = -300,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["conditions"] = {
			},
			["uid"] = "BJUjE3Ra)RD",
			["auto"] = true,
			["zoom"] = 0,
			["semver"] = "1.0.12",
			["anchorFrameType"] = "SCREEN",
			["id"] = "1TotemNameplateTracker",
			["frameStrata"] = 2,
			["alpha"] = 1,
			["width"] = 66,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["use_scale"] = true,
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = false,
					["scalex"] = 3,
					["type"] = "custom",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["scaley"] = 3,
					["alpha"] = 0,
					["rotate"] = 0,
					["y"] = 0,
					["x"] = 0,
					["duration_type"] = "seconds",
					["colorA"] = 1,
					["scaleType"] = "straightScale",
					["easeStrength"] = 3,
					["translateType"] = "straightTranslate",
					["duration"] = ".66",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["displayIcon"] = "",
			["cooldown"] = true,
			["stickyDuration"] = false,
		},
		["大灾变献祭"] = {
			["parent"] = "毁灭ss",
			["yOffset"] = 1.879608154296875,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["rem"] = "2",
						["useRem"] = true,
						["subeventSuffix"] = "_CAST_START",
						["names"] = {
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "target",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["matchesShowOn"] = "showOnMissing",
						["remOperator"] = "<=",
						["auranames"] = {
							"献祭", -- [1]
						},
						["useName"] = true,
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"献祭", -- [1]
						},
						["event"] = "Health",
						["unit"] = "target",
						["useRem"] = true,
						["rem"] = "2",
						["subeventPrefix"] = "SPELL",
						["remOperator"] = "<=",
						["useName"] = true,
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "大灾变",
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["use_track"] = true,
						["spellName"] = 152108,
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [3]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n    return (t[1] or  t[2])  and t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 284.6665344238281,
			["rotate"] = true,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "458741",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["alpha"] = 1,
			["id"] = "大灾变献祭",
			["authorOptions"] = {
			},
			["frameStrata"] = 9,
			["width"] = 172.6660919189453,
			["xOffset"] = 142.9588241577148,
			["uid"] = "sKJbMt1xpgd",
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				0.9607843137254902, -- [1]
				1, -- [2]
				0.9803921568627451, -- [3]
				0.75, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 177,
		},
		["狗反"] = {
			["iconSource"] = -1,
			["authorOptions"] = {
			},
			["yOffset"] = 99.55624389648438,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_castType"] = false,
						["use_destFlags2"] = false,
						["remaining_operator"] = "<=",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["remaining"] = "5",
						["debuffType"] = "HELPFUL",
						["use_sourceFlags3"] = false,
						["use_track"] = true,
						["spellName"] = 119910,
						["subeventPrefix"] = "SPELL",
						["type"] = "status",
						["duration"] = "1",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_FAILED",
						["use_remaining"] = true,
						["event"] = "Cooldown Progress (Spell)",
						["use_sourceFlags2"] = false,
						["realSpellName"] = "法术封锁",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_sourceUnit"] = true,
						["use_genericShowOn"] = true,
						["use_unit"] = true,
						["sourceUnit"] = "player",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["preset"] = "grow",
				},
			},
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 26,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
			},
			["height"] = 25,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["parent"] = "SS通用",
			["icon"] = true,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["cooldownTextDisabled"] = false,
			["zoom"] = 0,
			["auto"] = true,
			["alpha"] = 1,
			["id"] = "狗反",
			["config"] = {
			},
			["frameStrata"] = 9,
			["width"] = 25,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "cJYJEisAVIT",
			["inverse"] = false,
			["xOffset"] = -98.66644287109375,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["selfPoint"] = "CENTER",
		},
		["1发快速"] = {
			["parent"] = "毁灭ss",
			["yOffset"] = 270,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["powertype"] = 7,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["power_operator"] = ">=",
						["event"] = "Power",
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["power"] = "2",
						["unit"] = "player",
						["use_power"] = true,
						["unevent"] = "auto",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["useStacks"] = true,
						["auranames"] = {
							"爆燃", -- [1]
						},
						["use_absorbMode"] = true,
						["unit"] = "player",
						["stacks"] = "1",
						["debuffType"] = "HELPFUL",
						["type"] = "aura2",
						["stacksOperator"] = ">=",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["duration"] = "1",
						["spellIds"] = {
						},
						["use_unit"] = true,
						["names"] = {
						},
						["useName"] = true,
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["power_operator"] = "<",
						["use_power"] = true,
						["event"] = "Power",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["powertype"] = 7,
						["power"] = "3.8",
						["unit"] = "player",
						["use_unit"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_powertype"] = true,
						["duration"] = "1",
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 317,
			["rotate"] = true,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "1029138",
			["authorOptions"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "fade",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["alpha"] = 0.96,
			["id"] = "1发快速",
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 5,
			["width"] = 302,
			["xOffset"] = 130,
			["config"] = {
			},
			["uid"] = "fdFv2xwlVTm",
			["color"] = {
				0.7019607843137254, -- [1]
				1, -- [2]
				0.8274509803921568, -- [3]
				0.75, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["Demonic Circle: Teleport 2"] = {
			["iconSource"] = -1,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["preferToUpdate"] = false,
			["yOffset"] = 180,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["auranames"] = {
							"恶魔法阵", -- [1]
						},
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["spellName"] = 48020,
						["type"] = "aura2",
						["subeventSuffix"] = "_CAST_START",
						["matchesShowOn"] = "showOnMissing",
						["useName"] = true,
						["event"] = "Cooldown Progress (Spell)",
						["debuffType"] = "HELPFUL",
						["realSpellName"] = "恶魔法阵：传送",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["duration"] = "1",
						["unevent"] = "auto",
						["unit"] = "player",
						["use_track"] = true,
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["use_vehicle"] = false,
						["duration"] = "1",
						["event"] = "Conditions",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["genericShowOn"] = "showOnCooldown",
						["use_genericShowOn"] = true,
						["use_resting"] = false,
						["use_track"] = true,
						["spellName"] = 0,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function(t) \n    return t[1] and t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["stickyDuration"] = false,
			["version"] = 1,
			["subRegions"] = {
				{
					["text_text_format_p_time_precision"] = 1,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowXOffset"] = 0,
					["text_text_format_p_format"] = "timed",
					["text_fontSize"] = 18,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [1]
			},
			["height"] = 52.44413757324219,
			["load"] = {
				["use_class"] = true,
				["use_never"] = false,
				["talent"] = {
					["single"] = 15,
					["multi"] = {
						[15] = true,
					},
				},
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[2] = true,
					},
				},
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorMode"] = true,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["url"] = "https://wago.io/bfMwlftxG/1",
			["regionType"] = "icon",
			["desaturate"] = false,
			["xOffset"] = 90,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["selfPoint"] = "CENTER",
			["config"] = {
			},
			["zoom"] = 0,
			["cooldownTextDisabled"] = false,
			["semver"] = "1.0.0",
			["width"] = 55.11105346679688,
			["id"] = "Demonic Circle: Teleport 2",
			["alpha"] = 1,
			["frameStrata"] = 5,
			["anchorFrameType"] = "SCREEN",
			["auto"] = true,
			["uid"] = "b(mxUEE8g1u",
			["inverse"] = true,
			["authorOptions"] = {
			},
			["conditions"] = {
			},
			["cooldown"] = true,
			["parent"] = "SS通用",
		},
		["1Focus target casting2"] = {
			["sparkWidth"] = 10,
			["borderBackdrop"] = "Blizzard Tooltip",
			["xOffset"] = -129.7748413085938,
			["preferToUpdate"] = false,
			["yOffset"] = 250.0169601440429,
			["anchorPoint"] = "CENTER",
			["zoom"] = 0.3,
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["url"] = "https://wago.io/3_BRvBTai/1",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_castType"] = true,
						["use_absorbMode"] = true,
						["use_spell"] = false,
						["use_unit"] = true,
						["remaining"] = "0.93",
						["debuffType"] = "HELPFUL",
						["use_interruptible"] = true,
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["remaining_operator"] = "<",
						["event"] = "Cast",
						["use_remaining"] = false,
						["castType"] = "cast",
						["unit"] = "focus",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["duration"] = "1",
						["unevent"] = "auto",
						["spell"] = "旋风",
					},
					["untrigger"] = {
						["unit"] = "focus",
					},
				}, -- [1]
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "custom",
						["spellName"] = 0,
						["custom_type"] = "status",
						["use_genericShowOn"] = true,
						["duration"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["custom"] = "function() \n    \n    -- local ic = GetSpellTexture(\"狂暴之怒\")\n    \n    -- print(\"ic\",ic)\n    \n    if not UnitExists(\"pet\") then\n        return WeakAuras.CheckRange(\"focus\", 40, \"<=\") \n    else\n      --  print( IsSpellInRange(19647,\"spell\", \"focus\") )\n      --  print( IsSpellInRange(\"地狱猎犬\", \"focus\") )\n        return true\n        --IsSpellInRange(\"恶魔掌控\", \"focus\") ==1\n    end\n    -- local x = true;\n    \n    return true\nend\n\n\n\n\n",
						["unevent"] = "auto",
						["check"] = "update",
						["genericShowOn"] = "showOnCooldown",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["auranames"] = {
							"虚空守卫", -- [1]
						},
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["type"] = "aura2",
						["matchesShowOn"] = "showOnMissing",
						["subeventSuffix"] = "_CAST_START",
						["useName"] = true,
						["spellName"] = 19647,
						["event"] = "Cooldown Progress (Spell)",
						["use_exact_spellName"] = true,
						["realSpellName"] = 19647,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["unit"] = "focus",
						["duration"] = "1",
						["use_track"] = true,
						["names"] = {
						},
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [3]
				{
					["trigger"] = {
						["track"] = "auto",
						["itemName"] = 0,
						["auranames"] = {
							"根基图腾", -- [1]
						},
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["use_unit"] = true,
						["remaining"] = "0",
						["matchesShowOn"] = "showOnMissing",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["type"] = "aura2",
						["spellName"] = 132409,
						["use_remaining"] = false,
						["useName"] = true,
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["use_itemName"] = true,
						["event"] = "Cooldown Progress (Item)",
						["use_exact_spellName"] = true,
						["realSpellName"] = 132409,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["duration"] = "1",
						["debuffType"] = "HELPFUL",
						["remaining_operator"] = "<",
						["use_track"] = true,
						["names"] = {
						},
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [4]
				{
					["trigger"] = {
						["track"] = "auto",
						["remaining_operator"] = "<",
						["genericShowOn"] = "showOnReady",
						["names"] = {
						},
						["remaining"] = "0",
						["spellName"] = 119910,
						["debuffType"] = "HELPFUL",
						["use_unit"] = true,
						["type"] = "aura2",
						["use_genericShowOn"] = true,
						["subeventSuffix"] = "_CAST_START",
						["unevent"] = "auto",
						["use_remaining"] = false,
						["event"] = "Cooldown Progress (Spell)",
						["use_exact_spellName"] = true,
						["realSpellName"] = 119910,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_absorbMode"] = true,
						["duration"] = "1",
						["unit"] = "player",
						["use_track"] = true,
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "",
						["duration"] = "1",
						["event"] = "Combat Log",
						["unit"] = "player",
						["custom"] = "function()\n    local s,e = WeakAuras.GetSpellCooldown(\"法术封锁\")\n    --print(\"s,e\",s,e)\n    return (s==0) and (e ==0)\nend",
						["custom_type"] = "status",
						["check"] = "update",
						["unevent"] = "timed",
						["subeventPrefix"] = "",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n    return  t[6]  and  t[1]  and  t[2] and  t[3]  and  t[4] \nend",
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["backdropInFront"] = false,
			["stickyDuration"] = false,
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0.76470588235294, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["authorOptions"] = {
			},
			["customTextUpdate"] = "update",
			["sparkOffsetY"] = 0,
			["subRegions"] = {
				{
					["type"] = "aurabar_bar",
				}, -- [1]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_text_format_p_time_precision"] = 1,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_visible"] = true,
					["text_text_format_p_format"] = "timed",
					["text_fontSize"] = 15,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_text_format_n_format"] = "none",
					["text_anchorYOffset"] = 1,
					["text_fontSize"] = 14,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [3]
				{
					["text_shadowXOffset"] = 1,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "ICON_CENTER",
					["text_fontSize"] = 17,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [4]
				{
					["type"] = "subborder",
					["border_anchor"] = "bar",
					["border_offset"] = 3,
					["border_color"] = {
						0.023529411764706, -- [1]
						0.023529411764706, -- [2]
						0.023529411764706, -- [3]
						1, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "1 Pixel",
					["border_size"] = 3,
				}, -- [5]
			},
			["height"] = 59.33366012573242,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["duration"] = ".33",
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = true,
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["type"] = "custom",
					["scaleType"] = "straightScale",
					["rotate"] = 0,
					["easeType"] = "easeIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["preset"] = "shrink",
					["alpha"] = 0,
					["translateType"] = "straightTranslate",
					["y"] = -85,
					["x"] = -160,
					["colorA"] = 1,
					["scaley"] = 1.3,
					["use_scale"] = true,
					["easeStrength"] = 3,
					["scalex"] = 1.3,
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "pulse",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
			},
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["none"] = true,
						["arena"] = true,
						["party"] = true,
						["pvp"] = true,
					},
				},
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["version"] = 1,
			["config"] = {
			},
			["uid"] = "lzSX6KUf59V",
			["actions"] = {
				["start"] = {
					["do_loop"] = false,
					["sound"] = "Interface\\Addons\\Details\\sounds\\sound_whip1.ogg",
					["do_sound"] = false,
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 0,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["borderInFront"] = true,
			["auto"] = true,
			["icon_side"] = "LEFT",
			["id"] = "1Focus target casting2",
			["sparkHeight"] = 30,
			["texture"] = "Blizzard",
			["semver"] = "1.0.0",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 80300,
			["sparkHidden"] = "NEVER",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["frameStrata"] = 9,
			["width"] = 237.7778015136719,
			["iconSource"] = -1,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["inverse"] = false,
			["icon"] = true,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 6,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = 1,
							["property"] = "alpha",
						}, -- [1]
					},
				}, -- [1]
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["sparkOffsetX"] = 0,
		},
		["2发快速"] = {
			["color"] = {
				0, -- [1]
				1, -- [2]
				0.05098039215686274, -- [3]
				0.75, -- [4]
			},
			["yOffset"] = 270,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["powertype"] = 7,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["power_operator"] = ">=",
						["event"] = "Power",
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["power"] = "3.8",
						["unit"] = "player",
						["use_power"] = true,
						["unevent"] = "auto",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["useName"] = true,
						["stacksOperator"] = ">=",
						["auranames"] = {
							"爆燃", -- [1]
						},
						["buffShowOn"] = "showOnActive",
						["event"] = "Health",
						["names"] = {
						},
						["useStacks"] = true,
						["stacks"] = "2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["type"] = "aura2",
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 317,
			["rotate"] = true,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorMode"] = true,
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "1029139",
			["anchorFrameType"] = "SCREEN",
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "fade",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["authorOptions"] = {
			},
			["id"] = "2发快速",
			["alpha"] = 0.9500000000000001,
			["frameStrata"] = 2,
			["width"] = 302,
			["xOffset"] = 130,
			["uid"] = "mmXGZtktPhi",
			["config"] = {
			},
			["parent"] = "毁灭ss",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["血量低"] = {
			["authorOptions"] = {
			},
			["yOffset"] = 2.22210693359375,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_showAbsorb"] = false,
						["use_absorbMode"] = true,
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["use_health"] = false,
						["unevent"] = "auto",
						["use_unit"] = true,
						["percenthealth"] = "70",
						["event"] = "Health",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["health"] = "43",
						["duration"] = "1",
						["spellIds"] = {
						},
						["use_percenthealth"] = true,
						["percenthealth_operator"] = "<=",
						["health_operator"] = "<=",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["use_scale"] = true,
					["alphaType"] = "straight",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
					["use_translate"] = false,
					["use_alpha"] = false,
					["scalex"] = 2.8,
					["type"] = "custom",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["easeType"] = "easeIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["scaley"] = 2.8,
					["alpha"] = 0,
					["rotate"] = 0,
					["y"] = 0,
					["x"] = 0,
					["duration_type"] = "seconds",
					["colorA"] = 1,
					["scaleType"] = "straightScale",
					["easeStrength"] = 3,
					["translateType"] = "straightTranslate",
					["duration"] = ".33",
				},
				["main"] = {
					["colorR"] = 1,
					["use_scale"] = true,
					["colorB"] = 1,
					["colorG"] = 1,
					["scalex"] = 2.5,
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\nend\n",
					["type"] = "preset",
					["rotate"] = 0,
					["easeType"] = "none",
					["scaley"] = 2.5,
					["preset"] = "wobble",
					["alpha"] = 0,
					["colorA"] = 1,
					["y"] = 0,
					["colorType"] = "straightColor",
					["scaleType"] = "pulse",
					["x"] = 0,
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    return r1 + (progress * (r2 - r1)), g1 + (progress * (g2 - g1)), b1 + (progress * (b2 - b1)), a1 + (progress * (a2 - a1))\nend\n",
					["easeStrength"] = 3,
					["use_color"] = false,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 200.8892211914063,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura55",
			["selfPoint"] = "CENTER",
			["discrete_rotation"] = 0,
			["width"] = 196.4443206787109,
			["id"] = "血量低",
			["xOffset"] = -70.2225341796875,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				1, -- [1]
				0, -- [2]
				0.1647058823529412, -- [3]
				0.75, -- [4]
			},
			["uid"] = "hoXHTg9C)XM",
			["config"] = {
			},
			["alpha"] = 1,
			["conditions"] = {
			},
			["information"] = {
			},
			["parent"] = "SS通用",
		},
		["0FEAR CC Nameplate "] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"FREAR CC", -- [1]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["groupIcon"] = 132349,
			["gridType"] = "DR",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["space"] = 2,
			["url"] = "https://wago.io/OmniBudsNameplateRetail/6",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["debuffType"] = "HELPFUL",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 5,
			["radius"] = 200,
			["useLimit"] = false,
			["align"] = "CENTER",
			["gridWidth"] = 5,
			["stagger"] = 0,
			["sort"] = "none",
			["version"] = 6,
			["subRegions"] = {
			},
			["selfPoint"] = "LEFT",
			["fullCircle"] = true,
			["load"] = {
				["use_class"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["internalVersion"] = 40,
			["animate"] = false,
			["anchorPoint"] = "RIGHT",
			["scale"] = 1,
			["grow"] = "RIGHT",
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["uid"] = "BWDNc9fVzHu",
			["borderInset"] = 1,
			["constantFactor"] = "RADIUS",
			["xOffset"] = -16,
			["borderOffset"] = 4,
			["semver"] = "1.0.5",
			["tocversion"] = 80300,
			["id"] = "0FEAR CC Nameplate ",
			["useAnchorPerUnit"] = true,
			["frameStrata"] = 5,
			["anchorFrameType"] = "SCREEN",
			["anchorPerUnit"] = "NAMEPLATE",
			["config"] = {
			},
			["rowSpace"] = 15,
			["yOffset"] = -23,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["被控制提醒减伤"] = {
			["iconSource"] = 3,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["yOffset"] = -80,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["auranames"] = {
							"变形术", -- [1]
							"恐惧", -- [2]
							"冰冻陷阱", -- [3]
							"闷棍", -- [4]
							"致盲", -- [5]
							"肾击", -- [6]
							"破胆怒吼", -- [7]
							"惊骇", -- [8]
							"", -- [9]
						},
						["totalOperator"] = ">",
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HARMFUL",
						["useName"] = true,
						["subeventSuffix"] = "_CAST_START",
						["useTotal"] = true,
						["use_controlled"] = true,
						["event"] = "Crowd Controlled",
						["names"] = {
						},
						["unit"] = "party",
						["unevent"] = "auto",
						["spellIds"] = {
						},
						["type"] = "status",
						["total"] = "2",
						["use_unit"] = true,
						["use_absorbMode"] = true,
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["auranames"] = {
							"变形术", -- [1]
							"恐惧", -- [2]
							"冰冻陷阱", -- [3]
							"闷棍", -- [4]
							"致盲", -- [5]
							"肾击", -- [6]
							"破胆怒吼", -- [7]
							"惊骇", -- [8]
							"", -- [9]
						},
						["totalOperator"] = ">",
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["subeventPrefix"] = "SPELL",
						["use_controlled"] = true,
						["debuffType"] = "HARMFUL",
						["total"] = "2",
						["duration"] = "1",
						["subeventSuffix"] = "_CAST_START",
						["useTotal"] = true,
						["percenthealth"] = "60",
						["event"] = "Health",
						["type"] = "status",
						["useName"] = true,
						["unevent"] = "auto",
						["spellIds"] = {
						},
						["unit"] = "player",
						["names"] = {
						},
						["use_percenthealth"] = true,
						["percenthealth_operator"] = "<=",
						["useRem"] = false,
					},
					["untrigger"] = {
						["unit"] = "player",
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "不灭决心",
						["use_spellName"] = true,
						["spellName"] = 104773,
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [3]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    \n    return ( t[1] or t[2]) and  t[3] \n    \nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["useGlowColor"] = false,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["glowXOffset"] = 0,
					["glow"] = true,
					["glowThickness"] = 1,
					["glowScale"] = 1,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 64,
			["load"] = {
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_vehicle"] = false,
				["use_combat"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["use_scale"] = true,
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = true,
					["scalex"] = 3.8,
					["type"] = "custom",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["scaley"] = 3.8,
					["alpha"] = 0,
					["rotate"] = 0,
					["y"] = 75,
					["x"] = 65,
					["duration_type"] = "seconds",
					["colorA"] = 1,
					["scaleType"] = "straightScale",
					["easeStrength"] = 3,
					["translateType"] = "straightTranslate",
					["duration"] = ".66",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["authorOptions"] = {
			},
			["information"] = {
			},
			["xOffset"] = -73.77740478515625,
			["zoom"] = 0,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["anchorFrameType"] = "SCREEN",
			["id"] = "被控制提醒减伤",
			["uid"] = "JdNueWwOdJf",
			["frameStrata"] = 1,
			["width"] = 64,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["alpha"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["parent"] = "SS通用",
		},
		["3KILL THE POD"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Alert!", -- [1]
				"pod hp", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["xOffset"] = 220.333251953125,
			["preferToUpdate"] = false,
			["yOffset"] = 270.7778625488281,
			["anchorPoint"] = "CENTER",
			["fullCircle"] = true,
			["space"] = 2,
			["url"] = "https://wago.io/Wi5b8_TmZ/5",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["useLimit"] = false,
			["align"] = "CENTER",
			["stagger"] = 0,
			["version"] = 5,
			["subRegions"] = {
			},
			["rowSpace"] = 1,
			["borderInset"] = 1,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorOptions"] = {
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["rotation"] = 0,
			["animate"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["scale"] = 1,
			["selfPoint"] = "TOP",
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["grow"] = "DOWN",
			["gridType"] = "RD",
			["constantFactor"] = "RADIUS",
			["sort"] = "none",
			["borderOffset"] = 4,
			["semver"] = "2.0.3",
			["tocversion"] = 90002,
			["id"] = "3KILL THE POD",
			["frameStrata"] = 1,
			["gridWidth"] = 5,
			["anchorFrameType"] = "SCREEN",
			["useAnchorPerUnit"] = false,
			["config"] = {
			},
			["uid"] = "P(J4GH5G)6u",
			["internalVersion"] = 40,
			["conditions"] = {
			},
			["information"] = {
			},
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
		},
		["Hide nameplates which aren't casting when holding a modifier - enhanced"] = {
			["outline"] = "OUTLINE",
			["authorOptions"] = {
				{
					["type"] = "select",
					["key"] = "modifier",
					["default"] = 1,
					["values"] = {
						"LALT", -- [1]
						"LCTRL", -- [2]
						"LSHIFT", -- [3]
						"RALT", -- [4]
						"RCTRL", -- [5]
						"RSHIFT", -- [6]
					},
					["name"] = "Modifier",
					["width"] = 1,
				}, -- [1]
				{
					["type"] = "toggle",
					["name"] = "Show uninterruptable spells as well",
					["default"] = false,
					["key"] = "show_uninterruptable",
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["key"] = "forceHide",
					["width"] = 1,
					["name"] = "Force Hide (every frame)",
					["useDesc"] = true,
					["default"] = false,
					["desc"] = "Enable this if nameplates become visible again while holding down the modifier key. (experimental)",
				}, -- [3]
			},
			["displayText"] = "",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
					["stop_sound"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.namePlates = {}\naura_env.showAll = true;\naura_env.modifiers = {\"LALT\", \"LCTRL\", \"LSHIFT\", \"RALT\", \"RCTRL\", \"RSHIFT\"}\n\n\n\n-- check if ElvUI is used and the nameplates module is enabled\naura_env.useElvUINameplates = ElvUI and ElvUI[1].NamePlates and ElvUI[1].NamePlates.Initialized\n-- check if KuiNameplates are used\naura_env.useKuiNameplates = KuiNameplates ~= nil\n-- check if Tidy Plates are used\naura_env.useTidyPlates = TidyPlates ~= nil\n-- check if Tidy Plates Threat Plates are used\naura_env.useTidyPlatesThreat = TidyPlatesThreat ~= nil\n-- check if Plater Nameplates are used\naura_env.usePlater = Plater ~= nil\n-- check if NeatPlates are used\naura_env.useNeatPlates = NeatPlates ~= nil\n\n\nlocal function getUnitFrame(nameplate)\n    \n    if aura_env.useElvUINameplates then\n        return nameplate.unitFrame\n    elseif aura_env.useTidyPlates then\n        return nameplate.extended --nameplate.extended.bars.healthbar\n    elseif aura_env.useTidyPlatesThreat then\n        return nameplate.TPFrame\n    elseif aura_env.useKuiNameplates then\n        return nameplate.kui.HealthBar\n    elseif aura_env.usePlater then\n        return nameplate.unitFrame\n    elseif aura_env.useNeatPlates then\n        return nameplate.extended\n    else\n        return nameplate.UnitFrame\n    end    \nend\n\n\nlocal function showOnlyCastingNamePlates()\n    aura_env.showAll = false;\n    \n    for _, unitId in pairs(aura_env.namePlates) do\n        aura_env.recalculateVisibilityState(unitId);\n    end\n    \n    \nend\n\n\nlocal function showAllNamePlates()\n    aura_env.showAll = true;\n    \n    \n    \n    for _, unitId in pairs(aura_env.namePlates) do\n        aura_env.recalculateVisibilityState(unitId);     \n    end\n    \nend\n\n\nlocal function forceUpdateNamePlates()\n    \n    if aura_env.config.forceHide then\n        \n        for _, unitId in pairs(aura_env.namePlates) do\n            aura_env.recalculateVisibilityState(unitId);\n        end\n        \n    end\n    \nend\n\n\nlocal function recalculateVisibilityState(unitId)\n    local unitPlate = C_NamePlate.GetNamePlateForUnit(unitId)\n    if unitPlate == nil then\n        return;\n    end\n    \n    local unitFrame = getUnitFrame(unitPlate)\n    \n    if aura_env.showAll then        \n        unitFrame:Show();\n        return;\n        \n    end\n    \n    local _, _, _, _, _, _, _, notInterruptible, spellId =  UnitCastingInfo(unitId);\n    \n    if not spellId then\n        _, _, _, _, _, _, notInterruptible, spellId =  UnitChannelInfo(unitId);\n    end\n    \n    \n    if spellId then\n        if aura_env.config.show_uninterruptable or not notInterruptible then\n            unitFrame:Show();\n            return;\n        end    \n    end\n    \n    unitFrame:Hide();\nend\n\n\naura_env.showOnlyCastingNamePlates = showOnlyCastingNamePlates;  \naura_env.showAllNamePlates = showAllNamePlates;\naura_env.recalculateVisibilityState = recalculateVisibilityState;\naura_env.forceUpdateNamePlates = forceUpdateNamePlates\n\n",
					["do_custom"] = true,
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
						["type"] = "custom",
						["unevent"] = "timed",
						["duration"] = "1",
						["custom_hide"] = "timed",
						["event"] = "Chat Message",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["custom_type"] = "stateupdate",
						["events"] = "MODIFIER_STATE_CHANGED",
						["custom"] = "function(_, event, key, state)\n    if key == aura_env.modifiers[aura_env.config.modifier] then\n        if state == 1 then\n            aura_env.showOnlyCastingNamePlates();    \n        else\n            aura_env.showAllNamePlates();\n        end\n    end\nend\n\n--function(_ ,unitid)\n\n-- unitplate = C_NamePlate.GetNamePlateForUnit(unitid)\n\n--for key,value in pairs(aura_env.region:GetChildren()) do\n--  print(key);    \n-- end\n\n\n-- print(aura_env.frame);\n--end\n\n--[[\n    if unitplate ~= nil then\n        table.insert(aura_env.visibleMobsCasting, unitid)\n        \n        \n        \n        \n        \n        print(aura_env.visibleMobsCasting)\n        \n        for _, castingMobUnitId in pairs(aura_env.visibleMobsCasting) do\n            \n            mobUnitPlate =  C_NamePlate.GetNamePlateForUnit(castingMobUnitId)\n            if mobUnitPlate ~= nil then\n                \n                mobUnitPlate.UnitFrame.name:SetText(\"nevim vole\");    \n                mobUnitPlate.UnitFrame:SetScale(1);   \n            end\n            \n        end\n        \n        \n        for _, visibleUnitId in pairs(aura_env.namePlates) do\n            \n            isCasting = false;\n            for _, castingMobUnitId in pairs(aura_env.visibleMobsCasting) do\n                if castingMobUnitId == visibleUnitId then\n                    \n                    isCasting = true\n                    break\n                end\n                \n            end\n            if not isCasting then\n                mobUnitPlate.UnitFrame.name:SetText(\"\");    \n                mobUnitPlate.UnitFrame:SetScale(0.3);\n            end\n            \n        end\n        \n        \n    else \n        table.insert(aura_env.invisibleMobsCasting, unitid)\n    end\nend\n\n\n\n\n--aura_env.namePlates = {}\n--aura_env.visibleMobsCasting = {}\n--aura_env.invisibleMobsCasting = {}\n\n\n\n]]\n\n\n\n\n\n\n\n\n\n\n\n",
						["spellIds"] = {
						},
						["use_unit"] = true,
						["names"] = {
						},
						["buffShowOn"] = "showOnActive",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Chat Message",
						["subeventPrefix"] = "SPELL",
						["events"] = "NAME_PLATE_UNIT_ADDED",
						["unevent"] = "timed",
						["custom_type"] = "event",
						["custom"] = "function(_, unitId) \n    aura_env.recalculateVisibilityState(unitId);\n    \n    for _, otherUnitId in pairs(aura_env.namePlates) do\n        if unitId == otherUnitId then return end    \n    end\n    table.insert(aura_env.namePlates, unitId);\n    \nend",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["subeventPrefix"] = "SPELL",
						["type"] = "custom",
						["custom"] = "function(_, unitId) \n    \n    for index, otherUnitId in pairs(aura_env.namePlates) do\n        if unitId == otherUnitId then    \n            table.remove(aura_env.namePlates,index) \n            return\n        end\n        \n    end\nend",
						["custom_type"] = "event",
						["events"] = "NAME_PLATE_UNIT_REMOVED",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["subeventPrefix"] = "SPELL",
						["type"] = "custom",
						["custom"] = "function(_, unitId, _)\n    aura_env.recalculateVisibilityState(unitId);\nend",
						["custom_type"] = "event",
						["events"] = "UNIT_SPELLCAST_START UNIT_SPELLCAST_STOP",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "status",
						["duration"] = "1",
						["event"] = "Health",
						["use_unit"] = true,
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["custom"] = "function()\n    \n    aura_env.forceUpdateNamePlates()\n    \n    return true\nend",
						["unevent"] = "auto",
						["check"] = "update",
						["use_absorbMode"] = true,
						["unit"] = "player",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [5]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["font"] = "Friz Quadrata TT",
			["version"] = 6,
			["load"] = {
				["use_never"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 6,
			["shadowXOffset"] = 1,
			["regionType"] = "text",
			["preferToUpdate"] = false,
			["url"] = "https://wago.io/KEXsS2Snx/6",
			["fixedWidth"] = 200,
			["selfPoint"] = "BOTTOM",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["tocversion"] = 80300,
			["id"] = "Hide nameplates which aren't casting when holding a modifier - enhanced",
			["xOffset"] = 70,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["config"] = {
				["show_uninterruptable"] = true,
				["forceHide"] = false,
				["modifier"] = 3,
			},
			["uid"] = "cj0kumkFfDt",
			["shadowYOffset"] = -1,
			["semver"] = "1.0.5",
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["wordWrap"] = "WordWrap",
		},
		["灵魂碎片5"] = {
			["parent"] = "灵魂碎片1 Group",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_showAbsorb"] = false,
						["use_incombat"] = true,
						["duration"] = "1",
						["use_track"] = true,
						["use_power"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["use_genericShowOn"] = true,
						["powertype"] = 7,
						["use_absorbMode"] = true,
						["spellName"] = 0,
						["spellIds"] = {
						},
						["power"] = "5",
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["health_operator"] = "<=",
						["type"] = "status",
						["use_health"] = false,
						["unevent"] = "auto",
						["power_operator"] = ">=",
						["percenthealth"] = "43",
						["event"] = "Power",
						["use_unit"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["health"] = "43",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_percenthealth"] = true,
						["percenthealth_operator"] = "<=",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "slideright",
					["easeStrength"] = 3,
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 43,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_AlphaGradient_Out.tga",
			["config"] = {
			},
			["selfPoint"] = "CENTER",
			["discrete_rotation"] = 0,
			["id"] = "灵魂碎片5",
			["xOffset"] = 0,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["authorOptions"] = {
			},
			["uid"] = "jqJe)MvDIxs",
			["frameStrata"] = 1,
			["width"] = 43,
			["conditions"] = {
			},
			["information"] = {
			},
			["color"] = {
				0.7058823529411764, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
			},
		},
		["心能"] = {
			["sparkWidth"] = 10,
			["sparkOffsetX"] = 0,
			["authorOptions"] = {
			},
			["yOffset"] = -191.3333435058594,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["useStacks"] = true,
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["stacksOperator"] = ">",
						["stacks"] = "5",
						["spellIds"] = {
						},
						["auranames"] = {
							"心能转移", -- [1]
						},
						["useName"] = true,
						["names"] = {
						},
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["frameStrata"] = 1,
			["sparkOffsetY"] = 0,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 16,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						0.6627450980392157, -- [1]
						1, -- [2]
						0.5490196078431373, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOM",
					["text_anchorYOffset"] = 6,
					["text_fontSize"] = 33,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["useGlowColor"] = false,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["glowScale"] = 1,
					["glowXOffset"] = 0,
					["glow"] = false,
					["glow_anchor"] = "bar",
					["glowThickness"] = 1,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 50,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["useTooltip"] = true,
			["cooldown"] = true,
			["icon"] = true,
			["xOffset"] = -213.3335571289063,
			["selfPoint"] = "CENTER",
			["config"] = {
			},
			["useAdjustededMin"] = false,
			["regionType"] = "icon",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["parent"] = "SS通用",
			["icon_side"] = "RIGHT",
			["width"] = 50,
			["sparkHeight"] = 30,
			["texture"] = "Blizzard",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["cooldownTextDisabled"] = true,
			["spark"] = false,
			["sparkHidden"] = "NEVER",
			["id"] = "心能",
			["zoom"] = 0,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["uid"] = "2fxgpuMIbSa",
			["inverse"] = true,
			["iconSource"] = -1,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["information"] = {
			},
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
		},
		["Infernal Timer "] = {
			["grow"] = "RIGHT",
			["controlledChildren"] = {
				"Infernal Timer #1", -- [1]
				"Infernal Timer #2", -- [2]
				"Infernal Timer #3", -- [3]
				"Infernal Timer #4", -- [4]
				"Infernal Timer #5", -- [5]
			},
			["borderBackdrop"] = "None",
			["xOffset"] = 110.0371901710142,
			["preferToUpdate"] = false,
			["groupIcon"] = 136219,
			["gridType"] = "RD",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["rowSpace"] = 1,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["subeventPrefix"] = "SPELL",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["names"] = {
						},
						["event"] = "Health",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["useLimit"] = false,
			["align"] = "CENTER",
			["stagger"] = 0,
			["subRegions"] = {
			},
			["uid"] = "UzYVPJTqUnH",
			["load"] = {
				["use_class"] = "true",
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["arcLength"] = 360,
			["backdropColor"] = {
				1, -- [1]
				0.9647058823529412, -- [2]
				0.3764705882352941, -- [3]
				1, -- [4]
			},
			["sort"] = "none",
			["animate"] = true,
			["space"] = 5,
			["scale"] = 0.6500000000000001,
			["fullCircle"] = true,
			["border"] = true,
			["borderEdge"] = "Details BarBorder 1",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 3,
			["limit"] = 5,
			["internalVersion"] = 40,
			["yOffset"] = -9.999765765196376,
			["constantFactor"] = "RADIUS",
			["rotation"] = 0,
			["borderOffset"] = 4,
			["config"] = {
			},
			["tocversion"] = 80205,
			["id"] = "Infernal Timer ",
			["gridWidth"] = 5,
			["frameStrata"] = 8,
			["anchorFrameType"] = "SCREEN",
			["selfPoint"] = "LEFT",
			["borderInset"] = 1,
			["authorOptions"] = {
			},
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["anchorPoint"] = "CENTER",
		},
		["灵魂碎片3"] = {
			["parent"] = "灵魂碎片1 Group",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_showAbsorb"] = false,
						["use_incombat"] = true,
						["duration"] = "1",
						["use_track"] = true,
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["use_genericShowOn"] = true,
						["powertype"] = 7,
						["use_power"] = true,
						["debuffType"] = "HELPFUL",
						["spellIds"] = {
						},
						["health_operator"] = "<=",
						["use_powertype"] = true,
						["spellName"] = 0,
						["subeventSuffix"] = "_CAST_START",
						["type"] = "status",
						["use_health"] = false,
						["unevent"] = "auto",
						["power_operator"] = ">=",
						["percenthealth"] = "43",
						["event"] = "Power",
						["use_unit"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["health"] = "43",
						["power"] = "3",
						["names"] = {
						},
						["use_percenthealth"] = true,
						["percenthealth_operator"] = "<=",
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "slideright",
					["easeStrength"] = 3,
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 43,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_AlphaGradient_Out.tga",
			["config"] = {
			},
			["selfPoint"] = "CENTER",
			["frameStrata"] = 1,
			["id"] = "灵魂碎片3",
			["authorOptions"] = {
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				0.7058823529411764, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["uid"] = "txGecLwSRET",
			["width"] = 43,
			["rotation"] = 0,
			["conditions"] = {
			},
			["information"] = {
			},
			["xOffset"] = 0,
		},
		["Malefic Rapture Efficiency"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["authorOptions"] = {
				{
					["type"] = "number",
					["useDesc"] = true,
					["max"] = 6,
					["step"] = 1,
					["width"] = 1,
					["min"] = 2,
					["key"] = "baseline_num_dots",
					["default"] = 4,
					["name"] = "Baseline number of dots",
					["desc"] = "This is the number of active dots you need to achieve a '1.0' rapture efficiency (without any temporary buffs).",
				}, -- [1]
				{
					["softMin"] = 2,
					["type"] = "range",
					["bigStep"] = 0.05,
					["max"] = 20,
					["step"] = 0.05,
					["width"] = 1,
					["min"] = 2,
					["key"] = "bar_max_efficiency",
					["default"] = 4,
					["softMax"] = 20,
					["name"] = "Efficiency for full progress bar",
					["useDesc"] = true,
					["desc"] = "The efficiency point at which the progress bar is displayed as full.",
				}, -- [2]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 5,
					["useHeight"] = true,
					["width"] = 2,
				}, -- [3]
				{
					["width"] = 1,
					["type"] = "select",
					["default"] = 1,
					["name"] = "Expect Haunt?",
					["useDesc"] = true,
					["key"] = "expect_haunt",
					["values"] = {
						"Always", -- [1]
						"When talented", -- [2]
						"Never", -- [3]
					},
					["desc"] = "If true, the x1.00 baseline will be achieved with haunt active.",
				}, -- [4]
				{
					["width"] = 1,
					["type"] = "select",
					["default"] = 1,
					["name"] = "Expect Shadow Embrace?",
					["useDesc"] = true,
					["key"] = "expect_se",
					["values"] = {
						"Yes", -- [1]
						"No", -- [2]
					},
					["desc"] = "If true, the x1.00 baseline will be achieved with 3 stacks of SE.",
				}, -- [5]
				{
					["width"] = 1,
					["type"] = "select",
					["default"] = 1,
					["name"] = "Expect Focused Malignancy?",
					["useDesc"] = true,
					["key"] = "expect_fm",
					["values"] = {
						"Always", -- [1]
						"When talented", -- [2]
						"Never", -- [3]
					},
					["desc"] = "If true, the x1.00 baseline will be achieved with Focused Maligancy active.",
				}, -- [6]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 5,
					["useHeight"] = true,
					["width"] = 2,
				}, -- [7]
				{
					["softMin"] = 5,
					["type"] = "range",
					["bigStep"] = 1,
					["max"] = 60,
					["step"] = 1,
					["width"] = 1,
					["min"] = 5,
					["key"] = "baseline_after",
					["default"] = 25,
					["softMax"] = 60,
					["name"] = "Capture baseline X seconds after combat",
					["useDesc"] = true,
					["desc"] = "This aura needs a \"baseline multiplier\" to compare your current stats against during combat. When out of combat for X seconds, the \"baseline\" stats get captured regularly.",
				}, -- [8]
				{
					["softMin"] = 1,
					["type"] = "range",
					["bigStep"] = 1,
					["max"] = 20,
					["step"] = 1,
					["width"] = 1,
					["min"] = 1,
					["key"] = "baseline_every",
					["default"] = 3,
					["softMax"] = 20,
					["name"] = "Capture baseline every X seconds",
					["useDesc"] = true,
					["desc"] = "How often the baseline is captured when out of combat. Note that this is also a safety margin: baselines captured less than X seconds before combat starts are discarded.",
				}, -- [9]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 5,
					["useHeight"] = true,
					["width"] = 2,
				}, -- [10]
				{
					["type"] = "toggle",
					["key"] = "report_after_combat",
					["width"] = 1,
					["name"] = "Report efficiency after combat",
					["useDesc"] = true,
					["default"] = true,
					["desc"] = "A one-line report of the average rapture efficiency will be printed in the chat after each combat.",
				}, -- [11]
				{
					["type"] = "toggle",
					["key"] = "debug_mode",
					["width"] = 1,
					["name"] = "Debug mode",
					["useDesc"] = true,
					["default"] = false,
					["desc"] = "For debugging purposes only. Will print additional stuff you probably don't want to see.",
				}, -- [12]
			},
			["displayText"] = "%c",
			["yOffset"] = -88.88870239257812,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/1G1ca3vem/21",
			["actions"] = {
				["start"] = {
					["do_custom"] = false,
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "local e = aura_env\ne.myGUID = UnitGUID(\"player\")\nif e.config.debug_mode then print(\"INIT START\") end\n\n-- For debugging\n\ne.dump = function(t)\n    local s = '{\\n'\n    for k,v in pairs(t) do\n        s = s..tostring(k)..': '..tostring(v)..',\\n'\n    end\n    print(s..'}')\nend\n\n-- Dots tracking\ne.active_dots_by_unit = {} -- Map<UnitID, Map<SpellID, Boolean>>\nlocal uaID = 316099\ne.tracked_dots = {\n    [980]    = true, -- Agony\n    [63106]  = true, -- Siphon Life\n    [146739] = true, -- Corruption\n    [uaID]   = true, -- UA\n    [278350] = true, -- Vile Taint\n    [205179] = true, -- Phantom Singularity\n    [325640] = true, -- Soul Rot\n    [312321] = true, -- Scouring Tithe\n    [321792] = true, -- Impending Catastrophe\n}\n\nlocal function getNumDotsOnUnit(active_dots)\n    local count = 0\n    for _, active in pairs(active_dots) do\n        if active then\n            count = count + 1\n        end\n    end\n    return count\nend\n\ne.getTotalNumDots = function()\n    local total = 0\n    for _, active_dots in pairs(e.active_dots_by_unit) do\n        total = total + getNumDotsOnUnit(active_dots)\n    end\n    return total\nend\n\n-- Haunt tracking\ne.hauntID = 48181\ne.haunt_active = {}\nlocal _, t6_talent = GetTalentTierInfo(6, GetActiveSpecGroup())\nlocal haunt_talented = (t6_talent == 2)\n\n-- Shadow Embrace tracking\ne.seID = 32390\nlocal ceConduitID = 203\nlocal ce_rank = C_Soulbinds.GetConduitRankFromCollection(ceConduitID)\nlocal ce_bonus = (30 + 3 * ce_rank) / 100\nlocal function isCeSocketed()\n    return C_Soulbinds.IsConduitInstalledInSoulbind(C_Soulbinds.GetActiveSoulbindID(), ceConduitID)\nend\nlocal function getSeBonusPerStack() \n    return 0.03 * (1.0 + (isCeSocketed() and ce_bonus or 0.0))\nend\ne.se_stacks = {}\n\n-- Focused Malignancy\nlocal fmConduitID = 202\nlocal fm_rank = C_Soulbinds.GetConduitRankFromCollection(fmConduitID)\nlocal fm_bonus = ceil(13.5 + 1.5 * fm_rank) / 100\nlocal function isFmSocketed()\n    return C_Soulbinds.IsConduitInstalledInSoulbind(C_Soulbinds.GetActiveSoulbindID(), fmConduitID)\nend\n\n-- Demonic Synergy Legenday\nlocal synergyID = 337060\nlocal function getSynergyMultiplier()\n    return WA_GetUnitBuff(\"player\", synergyID) and 1.1 or 1.0\nend\n\n-- Tracking MR overall efficiency.\ne.rapture = 324536\ne.num_mr_casts = 0\ne.sum_mr_relative_power = 0\n\n---------- Power calculations.\n\n-- Single unit multiplier (via debuffs).\nlocal function getUnitMultiplier(unit)\n    local haunt = e.haunt_active[unit] and 1.1 or 1.0\n    local se = 1 + getSeBonusPerStack() * (e.se_stacks[unit] or 0)\n    local fm = 1.0 + ((isFmSocketed() and e.active_dots_by_unit[unit] and e.active_dots_by_unit[unit][uaID] == true) and fm_bonus or 0.0)\n    \n    return haunt * se * fm\nend\n\nlocal current_power = nil -- Proportional to the (total) amount of damage MR would deal if cast now.\ne.current_player_multiplier = nil -- Proportional to the (max) amount of damage MR would deal to any single target (ignoring the number of dots).\ne.updatePower = function()\n    if e.config.debug_mode then\n        print(\"Updating power...\")\n    end\n    \n    local intellect = UnitStat(\"player\", 4)\n    local versa = 1 + GetCombatRatingBonus(CR_VERSATILITY_DAMAGE_DONE) / 100\n    local mastery = 1 + GetMasteryEffect() / 100\n    local crit_chance = GetCritChance() / 100\n    local crit_damage = 1.0\n    local crit = 1 + crit_chance * crit_damage\n    local synergy = getSynergyMultiplier()\n    \n    local player_multiplier = intellect * versa * mastery * crit * synergy\n    \n    local total_power = 0\n    for unit, active_dots in pairs(e.active_dots_by_unit) do\n        local multiplier = player_multiplier * getUnitMultiplier(unit)\n        local num_dots = getNumDotsOnUnit(active_dots)\n        local power = num_dots * multiplier\n        total_power = total_power + power\n    end\n    \n    current_power = total_power\n    e.current_player_multiplier = player_multiplier\n    \n    if e.config.debug_mode then\n        print(string.format(\"Updated power: %.1f | %.1f\", current_power, e.current_player_multiplier))\n    end\n    return\nend\ne.updatePower()\n\n\n---------- Baseline.\n\nlocal baseline_multiplier = nil -- Baseline multiplier (not including target debuffs).\ne.baselineChangedEvent = \"MR_EFFICIENCY_BASELINE_CHANGED\"\ne.updateBaselineMultiplier = function(new_value)\n    baseline_multiplier = new_value\n    WeakAuras.ScanEvents(e.baselineChangedEvent)\n    if e.config.debug_mode then\n        print(string.format(\"Updated baseline: %.1f\", baseline_multiplier))\n    end\nend\ne.updateBaselineMultiplier(e.current_player_multiplier)\n\nlocal function expectHaunt() \n    local expect = e.config.expect_haunt\n    if expect == 1 then return true -- Always.\n    elseif expect == 2 then return haunt_talented -- When talented.\n    else return false -- Never.\n    end\nend\n\nlocal function expectSe() \n    return e.config.expect_se == 1\nend\n\nlocal function expectFm() \n    local expect = e.config.expect_fm\n    if expect == 1 then return true -- Always.\n    elseif expect == 2 then return isFmSocketed() -- When talented.\n    else return false -- Never.\n    end\nend\n\nlocal function getExpectedDebuffsMultiplier() \n    local haunt = 1.0 + (expectHaunt() and 0.1 or 0.0)\n    local se = 1.0 + (expectSe() and 3 * getSeBonusPerStack() or 0.0)\n    local fm = 1.0 + (expectFm() and fm_bonus or 0.0)\n    return haunt * se * fm\nend\n\ne.getRelativeMultiplier = function()\n    return e.current_player_multiplier / baseline_multiplier\nend\n\ne.getRelativePower = function()\n    local baseline_power = e.config.baseline_num_dots * baseline_multiplier * getExpectedDebuffsMultiplier()\n    return current_power / baseline_power\nend\n\n\n---------- Combat transition Loop.\n\n-- Private vars of the loop.\nlocal initially_in_combat = InCombatLockdown()\nlocal combat_transition_loop_state = {\n    ran_at = nil,\n    in_combat = initially_in_combat,\n    in_combat_at = initially_in_combat and GetTime() or nil,\n    out_of_combat_at = not initially_in_combat and GetTime() or nil\n}\n\n-- In/Out-of-combat throttled loop.\n-- Returns: should_run, in_combat, entering_combat, exiting_combat, in_combat_for, out_of_combat_for.\ne.combatTransitionLoop = function()\n    local now = GetTime()\n    local s = combat_transition_loop_state\n    \n    if s.ran_at and now < s.ran_at + 1.0 then\n        return false    \n    end\n    s.ran_at = now\n    \n    local in_combat = InCombatLockdown()\n    local entering_combat = in_combat and not s.in_combat\n    local exiting_combat = not in_combat and s.in_combat\n    \n    s.in_combat = in_combat\n    if entering_combat then\n        s.in_combat_at = now\n        s.out_of_combat_at = nil\n    end\n    if exiting_combat then\n        s.in_combat_at = nil\n        s.out_of_combat_at = now\n    end\n    \n    local in_combat_for = s.in_combat_at and now - s.in_combat_at or nil\n    local out_of_combat_for = s.out_of_combat_at and now - s.out_of_combat_at or nil\n    \n    return true, in_combat, entering_combat, exiting_combat, in_combat_for, out_of_combat_for\nend\n\n-- Baselining loop.\ne.baseline_candidate = nil -- Will become the new baseline...\ne.baseline_candidate_at = nil -- ...if you remain out of combat for X more seconds after this point.\n\n---------- END.\n\nif e.config.debug_mode then print(\"INIT END\") end",
					["do_custom"] = true,
				},
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["keepAspectRatio"] = false,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desc"] = "",
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = true,
				["talent"] = {
					["single"] = 12,
					["multi"] = {
						[12] = true,
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["race"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["texture"] = "Blizzard",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["auto"] = true,
			["tocversion"] = 90002,
			["alpha"] = 1,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["sparkOffsetX"] = 0,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["customText"] = "function() \n    local relative_multiplier = aura_env.current_multiplier / aura_env.baseline_multiplier\n    return string.format(\"x%.2f\", relative_multiplier)\nend",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["genericShowOn"] = "showOnActive",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
						["type"] = "custom",
						["custom_type"] = "status",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["customStacks"] = "function()\n    return aura_env.getTotalNumDots()\nend",
						["customDuration"] = "function()\n    local relative_power = aura_env.getRelativePower()\n    return relative_power, aura_env.config.bar_max_efficiency, true\nend",
						["customName"] = "function()\n    local relative_multiplier = aura_env.getRelativeMultiplier(InCombatLockdown())\n    return string.format(\"x%.2f\", relative_multiplier)\nend",
						["custom"] = "function(event, ...)\n    local e = aura_env\n    \n    if event ~= \"COMBAT_LOG_EVENT_UNFILTERED\" then\n        e.updatePower()\n        return true\n    end\n    \n    local subevent = select(2, ...)\n    local source = select(4, ...)\n    local target = select(8, ...)\n    local spellID = select(12, ...)\n    local stacks = select(16, ...)\n    \n    ---------- Dots tracking.\n    \n    local function getActiveDots(unit)\n        local active_dots = e.active_dots_by_unit[target]\n        if active_dots then \n            return active_dots\n        else\n            e.active_dots_by_unit[target] = {}\n            return e.active_dots_by_unit[target]\n        end\n    end\n    \n    \n    if (subevent == \"SPELL_AURA_APPLIED\" or subevent == \"SPELL_AURA_REFRESH\" or subevent == \"SPELL_AURA_APPLIED_DOSE\") and source == e.myGUID and e.tracked_dots[spellID] then\n        getActiveDots(target)[spellID] = true\n        e.updatePower()\n    end\n    \n    if subevent == \"SPELL_AURA_REMOVED\" and source == e.myGUID and e.tracked_dots[spellID] then\n        getActiveDots(target)[spellID] = nil\n        e.updatePower()\n    end\n    \n    ----------  tracking.\n    \n    if subevent == \"SPELL_AURA_APPLIED\" and source == e.myGUID and spellID == e.hauntID then\n        e.haunt_active[target] = true\n        e.updatePower()\n    end\n    \n    if subevent == \"SPELL_AURA_REMOVED\" and source == e.myGUID and spellID == e.hauntID then\n        e.haunt_active[target] = nil\n        e.updatePower()\n    end\n    \n    ---------- SE tracking.\n    \n    if subevent == \"SPELL_AURA_APPLIED\" and source == e.myGUID and spellID == e.seID then\n        e.se_stacks[target] = 1\n        e.updatePower()\n    end\n    \n    if subevent == \"SPELL_AURA_APPLIED_DOSE\" and source == e.myGUID and spellID == e.seID then\n        e.se_stacks[target] = stacks\n        e.updatePower()\n    end\n    \n    if subevent == \"SPELL_AURA_REMOVED\" and source == e.myGUID and spellID == e.seID then\n        e.se_stacks[target] = nil\n        e.updatePower()\n    end\n    \n    ---------- Rapture average efficiency tracking.\n    \n    if subevent == \"SPELL_CAST_SUCCESS\" and source == e.myGUID and spellID == e.rapture then\n        e.num_mr_casts = e.num_mr_casts + 1\n        e.sum_mr_relative_power = e.sum_mr_relative_power + e.getRelativePower()\n    end\n    \n    return true\nend\n\n\n\n",
						["spellIds"] = {
						},
						["check"] = "event",
						["unit"] = "player",
						["events"] = "CLEU,UNIT_AURA:player,PLAYER_EQUIPMENT_CHANGED,MR_EFFICIENCY_BASELINE_CHANGED",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["debuffType"] = "HELPFUL",
						["type"] = "custom",
						["events"] = "UNIT_AURA",
						["custom_type"] = "status",
						["check"] = "update",
						["custom"] = "function()\n    local e = aura_env\n    \n    local should_run, in_combat, _, exiting_combat, _, out_of_combat_for = e.combatTransitionLoop()\n    \n    -- This loop only runs once every second to save CPU.\n    if not should_run then \n        return false\n    end\n    \n    -- In combat: do nothing.\n    if in_combat then\n        return false\n    end\n    \n    ----- Out of combat.\n    \n    -- Exiting combat: reset everything.\n    if exiting_combat then\n        e.baseline_candidate = nil\n        e.baseline_candidate_at = nil\n        e.active_dots_by_unit = {}\n        e.haunt_active = {}\n        e.bote_active = {}\n    end\n    \n    -- Exiting combat: report average efficiency.\n    if exiting_combat and e.config.report_after_combat and e.num_mr_casts > 0 then\n        local average_efficiency = e.sum_mr_relative_power / e.num_mr_casts\n        print(string.format(\"Average rapture efficiency: %.2f\", average_efficiency))\n        e.num_mr_casts = 0\n        e.sum_mr_relative_power = 0\n    end\n    \n    -- If out of combat for long enough, record baseline candidate on a regulat interval.\n    if out_of_combat_for > e.config.baseline_after - e.config.baseline_every then\n        local now = GetTime()\n        if not e.baseline_candidate_at or now > e.baseline_candidate_at + e.config.baseline_every then\n            if e.baseline_candidate then\n                e.updateBaselineMultiplier(e.baseline_candidate)\n            end\n            e.updatePower()\n            e.baseline_candidate_at = now\n            e.baseline_candidate = e.current_player_multiplier\n        end\n    end\n    \n    return false\nend",
						["custom_hide"] = "timed",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "function(t)\n    return t[1]\nend",
				["activeTriggerMode"] = 1,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["colorR"] = 1,
					["scalex"] = 1,
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = false,
					["type"] = "none",
					["easeType"] = "none",
					["translateFunc"] = "\n\n",
					["scaley"] = 1,
					["alpha"] = 0,
					["y"] = 0,
					["x"] = 0,
					["translateType"] = "custom",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["rotate"] = 0,
					["colorA"] = 1,
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["stickyDuration"] = false,
			["preferToUpdate"] = false,
			["version"] = 21,
			["subRegions"] = {
				{
					["type"] = "aurabar_bar",
				}, -- [1]
				{
					["text_text_format_p_time_precision"] = 2,
					["text_text"] = "%p",
					["text_text_format_p_format"] = "Number",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_decimal_precision"] = 2,
					["type"] = "subtext",
					["text_anchorXOffset"] = -15,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowXOffset"] = 1,
					["text_shadowYOffset"] = -1,
					["text_fontType"] = "None",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_n_format"] = "none",
					["text_fontSize"] = 30,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_anchorXOffset"] = 39,
					["text_color"] = {
						1, -- [1]
						0.1019607843137255, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_CENTER",
					["text_shadowXOffset"] = 1,
					["text_fontSize"] = 50,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [3]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_BOTTOMLEFT",
					["text_shadowXOffset"] = 1,
					["text_visible"] = true,
					["text_fontSize"] = 9,
					["anchorXOffset"] = 0,
					["text_anchorYOffset"] = -5,
				}, -- [4]
			},
			["height"] = 27,
			["cooldown"] = false,
			["spark"] = false,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 20,
			["orientation"] = "HORIZONTAL",
			["displayIcon"] = 1380869,
			["uid"] = "dSjlsMl3sFe",
			["config"] = {
				["report_after_combat"] = true,
				["expect_haunt"] = 1,
				["expect_se"] = 1,
				["expect_fm"] = 1,
				["baseline_num_dots"] = 4,
				["debug_mode"] = false,
				["baseline_every"] = 3,
				["baseline_after"] = 25,
				["bar_max_efficiency"] = 4,
			},
			["xOffset"] = -0.00018310546875,
			["anchorFrameFrame"] = "WeakAuras:Darkglare, Infernal, Tyrant",
			["anchorFrameType"] = "SCREEN",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["sparkRotationMode"] = "AUTO",
			["icon_side"] = "RIGHT",
			["id"] = "Malefic Rapture Efficiency",
			["displayText_format_p_time_precision"] = 1,
			["anchorFrameParent"] = true,
			["semver"] = "1.0.20",
			["cooldownEdge"] = false,
			["icon"] = false,
			["justify"] = "LEFT",
			["sparkHeight"] = 30,
			["sparkHidden"] = "NEVER",
			["desaturate"] = false,
			["frameStrata"] = 1,
			["width"] = 100,
			["displayText_format_p_time_dynamic"] = false,
			["zoom"] = 0,
			["inverse"] = false,
			["wordWrap"] = "WordWrap",
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<",
						["value"] = "1",
						["variable"] = "value",
					},
					["changes"] = {
						{
							["value"] = {
								0.21176470588235, -- [1]
								0.21176470588235, -- [2]
								0.21176470588235, -- [3]
								1, -- [4]
							},
							["property"] = "barColor",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<",
						["value"] = "1.3",
						["variable"] = "value",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								0.6156862745098, -- [1]
								0.6156862745098, -- [2]
								0.6156862745098, -- [3]
								1, -- [4]
							},
							["property"] = "barColor",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<",
						["value"] = "1.6",
						["variable"] = "value",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								0.83921568627451, -- [1]
								1, -- [2]
								0.69019607843137, -- [3]
								1, -- [4]
							},
							["property"] = "barColor",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<",
						["value"] = "2.0",
						["variable"] = "value",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								0.27843137254902, -- [1]
								1, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "barColor",
						}, -- [1]
					},
				}, -- [4]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<",
						["value"] = "3.0",
						["variable"] = "value",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0.42352941176471, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "barColor",
						}, -- [1]
					},
				}, -- [5]
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["cooldownTextDisabled"] = false,
		},
		["补无常"] = {
			["xOffset"] = 50,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
						["subeventSuffix"] = "_CAST_START",
						["ownOnly"] = true,
						["matchesShowOn"] = "showOnMissing",
						["event"] = "Health",
						["names"] = {
						},
						["rem"] = "2",
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["spellIds"] = {
						},
						["useName"] = true,
						["remOperator"] = "<=",
						["subeventPrefix"] = "SPELL",
						["unit"] = "target",
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["useName"] = true,
						["useRem"] = true,
						["subeventSuffix"] = "_CAST_START",
						["ownOnly"] = true,
						["matchesShowOn"] = "showOnActive",
						["event"] = "Health",
						["unit"] = "target",
						["rem"] = "5",
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["spellIds"] = {
						},
						["type"] = "aura2",
						["remOperator"] = "<=",
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["rem"] = "5",
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["matchesShowOn"] = "showOnActive",
						["unit"] = "nameplate",
						["match_count"] = "3",
						["debuffType"] = "HARMFUL",
						["useName"] = true,
						["subeventPrefix"] = "SPELL",
						["match_countOperator"] = "<=",
						["type"] = "aura2",
						["group_count"] = "3",
						["event"] = "Health",
						["subeventSuffix"] = "_CAST_START",
						["ownOnly"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["useMatch_count"] = false,
						["remOperator"] = "<=",
						["useGroup_count"] = true,
						["group_countOperator"] = "<",
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["useMatch_count"] = false,
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["rem"] = "5",
						["useGroup_count"] = true,
						["matchesShowOn"] = "showOnActive",
						["match_count"] = "3",
						["group_count"] = "3",
						["unit"] = "nameplate",
						["use_talent"] = true,
						["group_countOperator"] = "<",
						["duration"] = "1",
						["useName"] = true,
						["unevent"] = "auto",
						["match_countOperator"] = "<=",
						["talent"] = {
							["single"] = 1,
						},
						["type"] = "status",
						["event"] = "PvP Talent Selected",
						["debuffType"] = "HARMFUL",
						["subeventSuffix"] = "_CAST_START",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["names"] = {
						},
						["remOperator"] = "<=",
						["ownOnly"] = true,
						["subeventPrefix"] = "SPELL",
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["rem"] = "5",
						["useGroup_count"] = true,
						["matchesShowOn"] = "showOnActive",
						["unit"] = "nameplate",
						["group_count"] = "0",
						["group_countOperator"] = ">",
						["type"] = "aura2",
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HARMFUL",
						["useName"] = true,
						["event"] = "Health",
						["match_count"] = "3",
						["match_countOperator"] = "<=",
						["useMatch_count"] = false,
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["remOperator"] = "<=",
						["names"] = {
						},
						["ownOnly"] = true,
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["rem"] = "5",
						["useGroup_count"] = true,
						["useMatch_count"] = false,
						["matchesShowOn"] = "showOnActive",
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["unit"] = "nameplate",
						["ownOnly"] = true,
						["use_talent"] = true,
						["subeventPrefix"] = "SPELL",
						["use_instance_size"] = false,
						["match_count"] = "3",
						["duration"] = "1",
						["group_count"] = "3",
						["group_countOperator"] = "<",
						["instance_size"] = {
							["single"] = "party",
							["multi"] = {
								["arena"] = true,
								["none"] = true,
								["pvp"] = true,
							},
						},
						["useName"] = true,
						["unevent"] = "auto",
						["talent"] = {
							["single"] = 1,
						},
						["match_countOperator"] = "<=",
						["debuffType"] = "HARMFUL",
						["event"] = "Conditions",
						["subeventSuffix"] = "_CAST_START",
						["type"] = "status",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_absorbMode"] = true,
						["remOperator"] = "<=",
						["names"] = {
						},
						["use_unit"] = true,
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["rem"] = "5",
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["matchesShowOn"] = "showOnActive",
						["names"] = {
						},
						["group_count"] = "1",
						["group_countOperator"] = "<",
						["type"] = "aura2",
						["match_count"] = "3",
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "nameplate",
						["subeventPrefix"] = "SPELL",
						["event"] = "Health",
						["useGroup_count"] = true,
						["useMatch_count"] = false,
						["ownOnly"] = true,
						["spellIds"] = {
						},
						["match_countOperator"] = "<=",
						["remOperator"] = "<=",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [7]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n    return ((t[1] or  t[2])  and( t[3] and t[4] and t[6]))  or ((t[5] or t[7] ) and not t[4]) or  ((t[5] or t[7])and not t[6])\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 50,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						[3] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura45",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["use_rotate"] = false,
					["duration_type"] = "seconds",
					["duration"] = ".66",
					["alphaType"] = "hide",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "function()\n    return 0\nend\n",
					["rotateType"] = "wobble",
					["rotateFunc"] = "function(progress, start, delta)\n    local angle = progress * 2 * math.pi\n    return start + math.sin(angle) * delta\nend\n",
					["use_translate"] = true,
					["use_alpha"] = false,
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["type"] = "custom",
					["translateType"] = "straightTranslate",
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["preset"] = "grow",
					["alpha"] = 0,
					["scaleType"] = "straightScale",
					["y"] = -200,
					["x"] = -200,
					["colorA"] = 1,
					["scaley"] = 5,
					["rotate"] = 333,
					["easeStrength"] = 3,
					["scalex"] = 5,
					["use_scale"] = true,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["width"] = 50,
			["id"] = "补无常",
			["color"] = {
				1, -- [1]
				0.5529411764705883, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["alpha"] = 0.93,
			["anchorFrameType"] = "SCREEN",
			["parent"] = "DOTS",
			["uid"] = "MGcVzflvGBP",
			["frameStrata"] = 7,
			["authorOptions"] = {
			},
			["conditions"] = {
				{
					["check"] = {
					},
					["changes"] = {
						{
						}, -- [1]
					},
				}, -- [1]
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["discrete_rotation"] = 0,
		},
		["吸血"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["xOffset"] = -213.3333740234375,
			["yOffset"] = -239.6663360595703,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["stacksOperator"] = ">",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["useStacks"] = true,
						["stacks"] = "23",
						["spellIds"] = {
						},
						["unit"] = "player",
						["names"] = {
						},
						["useName"] = true,
						["auranames"] = {
							"大难临头", -- [1]
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["alpha"] = 1,
			["sparkOffsetY"] = 0,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 16,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						0, -- [1]
						1, -- [2]
						0.01568627450980392, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOM",
					["text_anchorYOffset"] = 6,
					["text_fontSize"] = 33,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["useGlowColor"] = false,
					["glowScale"] = 1,
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["glowType"] = "buttonOverlay",
					["glowXOffset"] = 0,
					["glowThickness"] = 1,
					["glow_anchor"] = "bar",
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 50,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["internalVersion"] = 40,
			["information"] = {
			},
			["parent"] = "SS通用",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useAdjustededMin"] = false,
			["regionType"] = "icon",
			["config"] = {
			},
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["icon_side"] = "RIGHT",
			["anchorFrameType"] = "SCREEN",
			["sparkHeight"] = 30,
			["texture"] = "Blizzard",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["zoom"] = 0,
			["spark"] = false,
			["sparkHidden"] = "NEVER",
			["id"] = "吸血",
			["cooldownTextDisabled"] = true,
			["frameStrata"] = 1,
			["width"] = 50,
			["authorOptions"] = {
			},
			["uid"] = "oRfj62cct26",
			["inverse"] = true,
			["sparkOffsetX"] = 0,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["cooldown"] = true,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["补魅影"] = {
			["authorOptions"] = {
			},
			["yOffset"] = -26,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["rem"] = "3",
						["useStacks"] = false,
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["names"] = {
						},
						["duration"] = "1",
						["useHostility"] = true,
						["unit"] = "nameplate",
						["use_absorbMode"] = true,
						["stacks"] = "1",
						["debuffClass"] = {
							["curse"] = true,
							["magic"] = true,
							["disease"] = true,
						},
						["match_count"] = "3",
						["group_count"] = "0",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["group_countOperator"] = ">",
						["unevent"] = "auto",
						["type"] = "aura2",
						["stacksOperator"] = ">=",
						["match_countOperator"] = ">=",
						["use_debuffClass"] = false,
						["ownOnly"] = true,
						["event"] = "Health",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["debuffType"] = "HARMFUL",
						["remOperator"] = ">=",
						["useMatch_count"] = false,
						["use_unit"] = true,
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["debuffClass"] = {
							["curse"] = true,
							["magic"] = true,
							["disease"] = true,
						},
						["useStacks"] = false,
						["auranames"] = {
							"痛楚", -- [1]
						},
						["names"] = {
						},
						["use_absorbMode"] = true,
						["useHostility"] = true,
						["use_unit"] = true,
						["useMatch_count"] = false,
						["stacks"] = "1",
						["rem"] = "3",
						["group_count"] = "0",
						["match_count"] = "3",
						["debuffType"] = "HARMFUL",
						["type"] = "aura2",
						["group_countOperator"] = ">",
						["subeventSuffix"] = "_CAST_START",
						["useName"] = true,
						["stacksOperator"] = ">=",
						["unevent"] = "auto",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["event"] = "Health",
						["ownOnly"] = true,
						["use_debuffClass"] = false,
						["match_countOperator"] = ">=",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["remOperator"] = ">=",
						["unit"] = "target",
						["duration"] = "1",
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["debuffClass"] = {
							["curse"] = true,
							["magic"] = true,
							["disease"] = true,
						},
						["useStacks"] = false,
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["names"] = {
						},
						["use_absorbMode"] = true,
						["useHostility"] = true,
						["use_unit"] = true,
						["useMatch_count"] = true,
						["stacks"] = "1",
						["rem"] = "3",
						["group_count"] = "0",
						["match_count"] = "3",
						["debuffType"] = "HARMFUL",
						["type"] = "aura2",
						["group_countOperator"] = ">",
						["subeventSuffix"] = "_CAST_START",
						["useName"] = true,
						["stacksOperator"] = ">=",
						["unevent"] = "auto",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["event"] = "Health",
						["ownOnly"] = true,
						["use_debuffClass"] = false,
						["match_countOperator"] = ">=",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["remOperator"] = ">=",
						["unit"] = "target",
						["duration"] = "1",
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["use_power"] = true,
						["genericShowOn"] = "showOnReady",
						["names"] = {
						},
						["powertype"] = 7,
						["use_genericShowOn"] = true,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["duration"] = "1",
						["type"] = "status",
						["use_unit"] = true,
						["subeventSuffix"] = "_CAST_START",
						["power_operator"] = ">=",
						["unit"] = "player",
						["event"] = "Cooldown Progress (Spell)",
						["spellName"] = 205179,
						["realSpellName"] = "诡异魅影",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_absorbMode"] = true,
						["power"] = "1",
						["unevent"] = "auto",
						["use_track"] = true,
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [4]
				{
					["trigger"] = {
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_unit"] = true,
						["spellName"] = 0,
						["type"] = "status",
						["use_health"] = false,
						["unevent"] = "auto",
						["debuffType"] = "HELPFUL",
						["percenthealth"] = "83",
						["event"] = "Health",
						["use_track"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["health_operator"] = "<=",
						["duration"] = "1",
						["use_absorbMode"] = true,
						["use_percenthealth"] = true,
						["percenthealth_operator"] = "<=",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "aura2",
						["use_debuffClass"] = false,
						["useGroup_count"] = true,
						["useIgnoreExactSpellId"] = false,
						["unit"] = "nameplate",
						["namePattern_operator"] = "match('%s')",
						["useIgnoreName"] = false,
						["debuffClass"] = {
							["disease"] = true,
							["curse"] = true,
							["poison"] = true,
							["magic"] = true,
							["none"] = true,
						},
						["namePattern_name"] = ".",
						["group_count"] = "3",
						["useNamePattern"] = true,
						["group_countOperator"] = ">",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["powertype"] = 7,
						["use_powertype"] = true,
						["spellName"] = 0,
						["type"] = "status",
						["unevent"] = "auto",
						["power_operator"] = ">=",
						["event"] = "Power",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["power"] = "2",
						["use_power"] = true,
						["use_genericShowOn"] = true,
						["use_unit"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [7]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n    return ( (t[1] and  t[2]  and t[3] and  t[7] ) or t[5] or t[6])  and t[4] \nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["duration"] = ".66",
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = true,
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["scaleType"] = "straightScale",
					["type"] = "custom",
					["rotate"] = 0,
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["preset"] = "fade",
					["alpha"] = 0,
					["translateType"] = "straightTranslate",
					["y"] = -200,
					["x"] = -200,
					["colorA"] = 1,
					["scaley"] = 5,
					["use_scale"] = true,
					["easeStrength"] = 3,
					["scalex"] = 5,
					["duration_type"] = "seconds",
				},
				["main"] = {
					["colorR"] = 1,
					["use_scale"] = true,
					["colorB"] = 1,
					["colorG"] = 1,
					["type"] = "custom",
					["duration"] = ".83",
					["easeType"] = "none",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\nend\n",
					["scaley"] = 1.5,
					["alpha"] = 0,
					["rotate"] = 0,
					["y"] = 0,
					["x"] = 0,
					["colorA"] = 1,
					["scaleType"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["preset"] = "pulse",
					["scalex"] = 1.5,
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 50,
			["rotate"] = true,
			["load"] = {
				["use_spec"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura45",
			["uid"] = "YW4JYWYPFsg",
			["frameStrata"] = 7,
			["anchorFrameType"] = "SCREEN",
			["id"] = "补魅影",
			["parent"] = "DOTS",
			["alpha"] = 0.93,
			["width"] = 50,
			["color"] = {
				0.4588235294117647, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["config"] = {
			},
			["xOffset"] = 77,
			["selfPoint"] = "CENTER",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["痛苦ss"] = {
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["controlledChildren"] = {
				"死亡之剑", -- [1]
				"开黑魂 2", -- [2]
				"开黑魂 3", -- [3]
				"快速传染", -- [4]
				"黑眼", -- [5]
				"嘻嘻", -- [6]
				"3人3dots 有盟约有sp", -- [7]
				"补暗影之拥", -- [8]
				"补鬼影", -- [9]
				"PVP无常提醒非jjc", -- [10]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["authorOptions"] = {
			},
			["border"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["borderSize"] = 2,
			["scale"] = 1,
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["unit"] = "player",
						["spellIds"] = {
						},
						["debuffType"] = "HELPFUL",
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["buffShowOn"] = "showOnActive",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = 1,
			},
			["load"] = {
				["talent2"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["talent3"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["ingroup"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["borderOffset"] = 4,
			["regionType"] = "group",
			["selfPoint"] = "BOTTOMLEFT",
			["id"] = "痛苦ss",
			["internalVersion"] = 40,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "75Z8zJCs)Jj",
			["borderInset"] = 1,
			["config"] = {
			},
			["borderEdge"] = "Square Full White",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
				["groupOffset"] = true,
			},
			["xOffset"] = 0,
		},
		["开黑魂 2"] = {
			["user_y"] = 0,
			["user_x"] = 0,
			["authorOptions"] = {
			},
			["yOffset"] = 260,
			["anchorPoint"] = "CENTER",
			["desaturateBackground"] = false,
			["sameTexture"] = true,
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["auranames"] = {
							"", -- [1]
						},
						["matchesShowOn"] = "showOnMissing",
						["subeventPrefix"] = "SPELL",
						["use_totemType"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "aura2",
						["ownOnly"] = true,
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["use_absorbMode"] = true,
						["event"] = "Stance/Form/Aura",
						["totemType"] = 1,
						["names"] = {
						},
						["unevent"] = "auto",
						["spellIds"] = {
						},
						["use_unit"] = true,
						["namePattern_name"] = "黑暗灵魂",
						["useNamePattern"] = true,
						["duration"] = "1",
						["namePattern_operator"] = "find('%s')",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_totemNamePattern"] = true,
						["duration"] = "1",
						["totemNamePattern"] = "地狱火",
						["use_unit"] = true,
						["remaining"] = "3",
						["spellName"] = 113860,
						["debuffType"] = "HELPFUL",
						["use_remaining"] = true,
						["subeventSuffix"] = "_CAST_START",
						["unevent"] = "auto",
						["genericShowOn"] = "showOnReady",
						["use_genericShowOn"] = true,
						["event"] = "Cooldown Progress (Spell)",
						["use_exact_spellName"] = false,
						["realSpellName"] = "黑暗灵魂：哀难",
						["use_spellName"] = true,
						["remaining_operator"] = ">=",
						["type"] = "status",
						["use_absorbMode"] = true,
						["unit"] = "player",
						["use_track"] = true,
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [2]
				{
					["trigger"] = {
						["use_totemNamePattern"] = true,
						["use_inverse"] = false,
						["totemNamePattern"] = "黑眼",
						["unit"] = "player",
						["remaining"] = "20",
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["unevent"] = "auto",
						["event"] = "Totem",
						["use_unit"] = true,
						["remaining_operator"] = "<=",
						["use_remaining"] = true,
						["subeventPrefix"] = "SPELL",
						["duration"] = "1",
						["use_absorbMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_totemName"] = false,
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["group_countOperator"] = ">=",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "nameplate",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["group_count"] = "2",
						["rem"] = "5",
						["remOperator"] = ">=",
						["useRem"] = true,
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["debuffType"] = "HARMFUL",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "nameplate",
						["type"] = "aura2",
						["useRem"] = true,
						["remOperator"] = ">=",
						["rem"] = "5",
						["group_count"] = "3",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["group_countOperator"] = ">=",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["group_countOperator"] = ">=",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "target",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["group_count"] = "2",
						["rem"] = "5",
						["remOperator"] = ">=",
						["useRem"] = true,
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"痛楚", -- [1]
						},
						["debuffType"] = "HARMFUL",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "target",
						["type"] = "aura2",
						["useRem"] = true,
						["remOperator"] = ">=",
						["rem"] = "5",
						["group_count"] = "2",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["group_countOperator"] = ">=",
					},
					["untrigger"] = {
					},
				}, -- [7]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["group_countOperator"] = ">=",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "target",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["group_count"] = "2",
						["rem"] = "5",
						["remOperator"] = ">=",
						["useRem"] = true,
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [8]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"诡异魅影", -- [1]
						},
						["debuffType"] = "HARMFUL",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "target",
						["type"] = "aura2",
						["useRem"] = true,
						["remOperator"] = ">=",
						["rem"] = "5",
						["group_count"] = "2",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["group_countOperator"] = ">=",
					},
					["untrigger"] = {
					},
				}, -- [9]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n    return  (t[1] and  t[2] ) and (t[3] or (t[4] and t[5]) or  (t[6] and t[7]  and t[8] and t[9]) )\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["startAngle"] = 0,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						0.05882352941176471, -- [2]
						0.06666666666666667, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_text_format_p_time_precision"] = 1,
					["text_shadowYOffset"] = 0,
					["text_visible"] = false,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "MONOCHROME|THICKOUTLINE",
					["text_anchorPoint"] = "CENTER",
					["text_text_format_p_format"] = "timed",
					["text_text_format_n_format"] = "none",
					["text_fontSize"] = 40,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [1]
			},
			["height"] = 56,
			["load"] = {
				["use_spec"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["color"] = {
			},
			["useAdjustededMax"] = false,
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura52",
			["conditions"] = {
			},
			["crop_y"] = 0.41,
			["mirror"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "progresstexture",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["blendMode"] = "BLEND",
			["xOffset"] = 110,
			["uid"] = "X04iyCUehaE",
			["slantMode"] = "INSIDE",
			["width"] = 56,
			["alpha"] = 1,
			["textureWrapMode"] = "CLAMP",
			["backgroundColor"] = {
				0.3058823529411765, -- [1]
				0.3176470588235294, -- [2]
				0.3019607843137255, -- [3]
				0.4000000357627869, -- [4]
			},
			["compress"] = false,
			["id"] = "开黑魂 2",
			["foregroundColor"] = {
				1, -- [1]
				0.3411764705882353, -- [2]
				0.5098039215686274, -- [3]
				0.7171716690063477, -- [4]
			},
			["frameStrata"] = 5,
			["anchorFrameType"] = "SCREEN",
			["parent"] = "痛苦ss",
			["config"] = {
			},
			["inverse"] = false,
			["fontSize"] = 12,
			["orientation"] = "VERTICAL",
			["crop_x"] = 0.44,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["backgroundOffset"] = 0,
		},
		["被控制提醒徽章"] = {
			["iconSource"] = 2,
			["xOffset"] = -0.888671875,
			["yOffset"] = -80,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["auranames"] = {
							"变形术", -- [1]
							"恐惧", -- [2]
							"冰冻陷阱", -- [3]
							"闷棍", -- [4]
							"致盲", -- [5]
							"肾击", -- [6]
							"破胆怒吼", -- [7]
							"惊骇", -- [8]
							"", -- [9]
						},
						["totalOperator"] = ">",
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["debuffType"] = "HARMFUL",
						["total"] = "2",
						["subeventSuffix"] = "_CAST_START",
						["useTotal"] = true,
						["use_controlled"] = true,
						["event"] = "Crowd Controlled",
						["subeventPrefix"] = "SPELL",
						["duration"] = "1",
						["type"] = "status",
						["spellIds"] = {
						},
						["useName"] = true,
						["unevent"] = "auto",
						["unit"] = "party",
						["names"] = {
						},
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["spellName"] = 104773,
						["unevent"] = "auto",
						["itemSlot"] = 13,
						["use_genericShowOn"] = true,
						["event"] = "Cooldown Progress (Equipment Slot)",
						["unit"] = "player",
						["use_itemSlot"] = true,
						["use_spellName"] = true,
						["duration"] = "1",
						["use_testForCooldown"] = true,
						["realSpellName"] = "不灭决心",
						["genericShowOn"] = "showOnReady",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
						["itemSlot"] = 13,
					},
				}, -- [2]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function(t)\n    \n    return t[1]\n    \nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowXOffset"] = 0,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glow"] = true,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 64,
			["load"] = {
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_vehicle"] = false,
				["use_combat"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["authorOptions"] = {
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["cooldown"] = false,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["use_scale"] = true,
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = true,
					["scalex"] = 3.8,
					["type"] = "custom",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["scaley"] = 3.8,
					["alpha"] = 0,
					["rotate"] = 0,
					["y"] = 75,
					["x"] = 65,
					["duration_type"] = "seconds",
					["colorA"] = 1,
					["scaleType"] = "straightScale",
					["easeStrength"] = 3,
					["translateType"] = "straightTranslate",
					["duration"] = ".66",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["zoom"] = 0,
			["cooldownTextDisabled"] = false,
			["frameStrata"] = 1,
			["id"] = "被控制提醒徽章",
			["config"] = {
			},
			["alpha"] = 1,
			["width"] = 64,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "P44rAmGBP)j",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
			},
			["parent"] = "SS通用",
		},
		["暗灼2发"] = {
			["color"] = {
				0.9450980392156862, -- [1]
				0.6039215686274509, -- [2]
				1, -- [3]
				0.75, -- [4]
			},
			["yOffset"] = 265.5554962158203,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["remaining_operator"] = "==",
						["genericShowOn"] = "showOnReady",
						["unit"] = "player",
						["remaining"] = "0",
						["use_charges"] = true,
						["charges"] = "2",
						["debuffType"] = "HELPFUL",
						["charges_operator"] = "==",
						["useName"] = false,
						["names"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Action Usable",
						["spellName"] = 17877,
						["realSpellName"] = "暗影灼烧",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["type"] = "status",
						["duration"] = "1",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["use_remaining"] = true,
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_unit"] = true,
						["spellName"] = 0,
						["type"] = "status",
						["use_health"] = false,
						["unevent"] = "auto",
						["percenthealth"] = "53",
						["event"] = "Health",
						["debuffType"] = "HELPFUL",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["percenthealth_operator"] = "<=",
						["use_absorbMode"] = true,
						["duration"] = "1",
						["use_percenthealth"] = true,
						["use_track"] = true,
						["unit"] = "target",
					},
					["untrigger"] = {
						["unit"] = "target",
					},
				}, -- [2]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "fade",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 183.6668853759766,
			["rotate"] = true,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorMode"] = true,
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "1028137",
			["anchorFrameType"] = "SCREEN",
			["selfPoint"] = "CENTER",
			["authorOptions"] = {
			},
			["id"] = "暗灼2发",
			["frameStrata"] = 6,
			["alpha"] = 1,
			["width"] = 216.6671295166016,
			["config"] = {
			},
			["uid"] = "SyvXPkLFCxO",
			["xOffset"] = 1.555725097656236,
			["parent"] = "毁灭ss",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["可以排zc了"] = {
			["iconSource"] = -1,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["yOffset"] = 170.2226257324219,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_castType"] = false,
						["rem"] = "3",
						["auranames"] = {
							"逃亡者", -- [1]
						},
						["duration"] = "1",
						["remaining"] = "4",
						["spellName"] = 30283,
						["use_debuffClass"] = false,
						["subeventSuffix"] = "_CAST_FAILED",
						["event"] = "Conditions",
						["use_sourceFlags2"] = false,
						["use_sourceUnit"] = true,
						["use_track"] = true,
						["use_destFlags2"] = false,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["use_sourceFlags3"] = false,
						["debuffType"] = "HARMFUL",
						["use_unit"] = true,
						["use_remaining"] = true,
						["use_genericShowOn"] = true,
						["unevent"] = "auto",
						["useName"] = true,
						["remaining_operator"] = "<=",
						["subeventPrefix"] = "SPELL",
						["ownOnly"] = true,
						["realSpellName"] = "暗影之怒",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["names"] = {
						},
						["remOperator"] = "<=",
						["type"] = "aura2",
						["sourceUnit"] = "player",
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "preset",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "grow",
					["easeStrength"] = 3,
				},
			},
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 26,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
			},
			["height"] = 25,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["xOffset"] = -48.88873291015625,
			["selfPoint"] = "CENTER",
			["icon"] = true,
			["authorOptions"] = {
			},
			["zoom"] = 0,
			["auto"] = true,
			["frameStrata"] = 9,
			["id"] = "可以排zc了",
			["config"] = {
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["width"] = 25,
			["uid"] = "oL87sEjOw4b",
			["inverse"] = false,
			["cooldownTextDisabled"] = false,
			["conditions"] = {
			},
			["cooldown"] = true,
			["parent"] = "SS通用",
		},
		["Spells nameplate"] = {
			["iconSource"] = -1,
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["customText"] = "function()\n    if aura_env.state.class then\n        return RAID_CLASS_COLORS[aura_env.state.class]:WrapTextInColorCode(aura_env.state.name)\n    else\n        return aura_env.state.name\n    end\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["url"] = "https://wago.io/OmniBudsNameplateRetail/6",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "2",
						["use_unit"] = true,
						["destUnit"] = "target",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
						["subeventSuffix"] = "_CAST_SUCCESS",
						["type"] = "custom",
						["use_destNpcId"] = false,
						["unevent"] = "timed",
						["subeventPrefix"] = "SPELL",
						["spellName"] = "Battle Stance",
						["event"] = "Combat Log",
						["custom"] = "function(states, e, ...)\n    if e == \"NAME_PLATE_UNIT_ADDED\" then\n        local unit = ...\n        if unit then\n            local guid = UnitGUID(unit)\n            aura_env.nameplates[unit] = guid\n            aura_env.guids[guid] = unit\n            local now = GetTime()\n            for k, state in pairs(aura_env.temp) do\n                if state.guid == guid\n                and state.expirationTime > now\n                then\n                    state.unit = unit\n                    state.show = true\n                    state.changed = true\n                    states[k] = state                    \n                end\n                if state.expirationTime < now then\n                    aura_env.temp[k] = nil \n                end\n            end\n        end\n    elseif e == \"NAME_PLATE_UNIT_REMOVED\" then\n        local unit = ...\n        if unit then\n            local guid = UnitGUID(unit)\n            if guid then\n                aura_env.nameplates[unit] = nil\n                aura_env.guids[guid] = nil\n                for k, state in pairs(states) do\n                    if state.guid == guid then\n                        aura_env.temp[k] = state\n                        state.show = false\n                        state.changed = true\n                    end\n                end\n            end\n        end\n    elseif e == \"COMBAT_LOG_EVENT_UNFILTERED\" then\n        local _, _, _, guid, name, flags, _, _, _, _, _, spellId = ...\n        local spell\n        if flags\n        and guid\n        and bit.band(flags, COMBATLOG_OBJECT_CONTROL_PLAYER) > 0\n        and bit.band(flags, COMBATLOG_OBJECT_REACTION_HOSTILE) > 0\n        then\n            spell = spellId and aura_env.spells[spellId]\n            if spell and spell.parent  then\n                spell = aura_env.spells[spell.parent]\n            end\n        end\n        \n        if spell and spell.interrupt then\n            if spell.duration and type(spell.duration) == \"number\" and spell.duration > 0 then\n                local key = guid..spellId\n                --if not states[key] then\n                local data = {\n                    show = true,\n                    changed = true,\n                    duration = spell.duration,\n                    expirationTime = GetTime() + spell.duration,\n                    icon = spell.icon,\n                    progressType = \"timed\",\n                    autoHide = true,\n                    guid = guid,\n                    unit = aura_env.guids[guid],\n                    interrupt = spell.interrupt\n                }\n                if aura_env.guids[guid] then\n                    states[key] = data\n                else\n                    aura_env.temp[key] = data\n                end\n                --end\n            end\n        end\n    end\n    return true\nend",
						["events"] = "CLEU:SPELL_CAST_SUCCESS NAME_PLATE_UNIT_ADDED NAME_PLATE_UNIT_REMOVED",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unit"] = "player",
						["check"] = "event",
						["use_destUnit"] = true,
						["custom_type"] = "stateupdate",
						["customVariables"] = "{ interrupt = \"bool\" }",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 6,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						0.8980392156862745, -- [1]
						0.9921568627450981, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_text_format_p_time_precision"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["text_visible"] = false,
					["text_text_format_p_format"] = "timed",
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["useGlowColor"] = true,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						0.596078431372549, -- [2]
						0.09803921568627451, -- [3]
						1, -- [4]
					},
					["glowXOffset"] = 0,
					["glowType"] = "Pixel",
					["glow"] = false,
					["glowLength"] = 10,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 30,
			["load"] = {
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_encounter"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["zoom"] = 0,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["parent"] = "0Plater Interrupt and Reflect",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.spells = {}\naura_env.nameplates = {}\naura_env.guids = {}\naura_env.temp = {}\n\naura_env.spells = {\n    \n    -- Death Knight\n    \n    [47528] = { default = true, duration = 15, class = \"DEATHKNIGHT\", interrupt = true }, -- Mind Freeze\n    [48265] = { duration = 45, class = \"DEATHKNIGHT\" }, -- Death's Advance\n    [48707] = { duration = 60, class = \"DEATHKNIGHT\" }, -- Anti-Magic Shell\n    [49576] = { duration = 25, class = \"DEATHKNIGHT\", charges = 2 }, -- Death Grip\n    [51052] = { duration = 120, class = \"DEATHKNIGHT\" }, -- Anti-Magic Zone\n    [61999] = { duration = 600, class = \"DEATHKNIGHT\" }, -- Raise Ally\n    [77606] = { duration = 25, class = \"DEATHKNIGHT\" }, -- Dark Simulacrum\n    [212552] = { duration = 60, class = \"DEATHKNIGHT\" }, -- Wraith Walk\n    \n    -- Blood\n    \n    [43265] = { duration = 30, class = \"DEATHKNIGHT\", specID = { 250, 252 } }, -- Death and Decay\n    [47476] = { duration = 60, class = \"DEATHKNIGHT\", specID = { 250 } }, -- Strangulate\n    [49028] = { duration = 120, class = \"DEATHKNIGHT\", specID = { 250 } }, -- Dancing Rune Weapon\n    [55233] = { duration = 90, class = \"DEATHKNIGHT\", specID = { 250 } }, -- Vampiric Blood\n    [108199] = { duration = 120, class = \"DEATHKNIGHT\", specID = { 250 } }, -- Gorefiend's Grasp\n    [194679] = { duration = 25, class = \"DEATHKNIGHT\", specID = { 250 }, charges = 2 }, -- Rune Tap\n    [194844] = { duration = 60, class = \"DEATHKNIGHT\", specID = { 250 } }, -- Bonestorm\n    [203173] = { duration = 15, class = \"DEATHKNIGHT\", specID = { 250 } }, -- Death Chain\n    [205223] = { duration = 45, class = \"DEATHKNIGHT\", specID = { 250 } }, -- Consumption\n    [206931] = { duration = 30, class = \"DEATHKNIGHT\", specID = { 250 } }, -- Blooddrinker\n    [206977] = { duration = 120, class = \"DEATHKNIGHT\", specID = { 250 } }, -- Blood Mirror\n    [219809] = { duration = 60, class = \"DEATHKNIGHT\", specID = { 250 } }, -- Tombstone\n    [221562] = { duration = 45, class = \"DEATHKNIGHT\", specID = { 250, 252 } }, -- Asphyxiate (Blood)\n    [108194] = { parent = 221562 }, -- Asphyxiate (Unholy)\n    [221699] = { duration = 60, class = \"DEATHKNIGHT\", specID = { 250 }, charges = 2 }, -- Blood Tap\n    \n    -- Frost\n    \n    [47568] = { duration = 120, class = \"DEATHKNIGHT\", specID = { 251 }, charges = 2 }, -- Empower Rune Weapon\n    [207127] = { parent = 47568 }, -- Hungering Rune Weapon\n    [48792] = { duration = 180, class = \"DEATHKNIGHT\", specID = { 251, 252 } }, -- Icebound Fortitude\n    [51271] = { duration = 45, class = \"DEATHKNIGHT\", specID = { 251 } }, -- Pillar of Frost\n    [152279] = { duration = 120, class = \"DEATHKNIGHT\", specID = { 251} }, -- Breath of Sindragosa\n    [196770] = { duration = 20, class = \"DEATHKNIGHT\", specID = { 251 } }, -- Remorseless Winter\n    [204143] = { duration = 45, class = \"DEATHKNIGHT\", specID = { 251 } }, -- Killing Machine\n    [204160] = { duration = 45, class = \"DEATHKNIGHT\", specID = { 251 } }, -- Chill Streak\n    [207167] = { duration = 60, class = \"DEATHKNIGHT\", specID = { 251} }, -- Blinding Sleet\n    [207256] = { duration = 90, class = \"DEATHKNIGHT\", specID = { 251} }, -- Obliteration\n    [279302] = { duration = 180, class = \"DEATHKNIGHT\", specID = { 251} }, -- Frostwyrm's Fury\n    \n    -- Unholy\n    \n    [42650] = { duration = 480, class = \"DEATHKNIGHT\", specID = { 252 } }, -- Army of the Dead\n    [63560] = { duration = 60, class = \"DEATHKNIGHT\", specID = { 252 } }, -- Dark Transformation\n    [43265] = { duration = 30, class = \"DEATHKNIGHT\", specID = { 252 } }, -- Death and Decay\n    [152280] = { parent = 43265 }, -- Defile\n    [47481] = { duration = 90, class = \"DEATHKNIGHT\", specID = { 252 } }, -- Gnaw (Ghoul)\n    [47482] = { duration = 30, class = \"DEATHKNIGHT\", specID = { 252 } }, -- Leap (Ghoul)\n    [49206] = { duration = 180, class = \"DEATHKNIGHT\", specID = { 252 } }, -- Summon Gargoyle\n    [207349] = { parent = 49206 }, -- Dark Arbiter\n    [91802] = { duration = 30, class = \"DEATHKNIGHT\", specID = { 252 } }, -- Shambling Rush (Ghoul)\n    [130736] = { duration = 45, class = \"DEATHKNIGHT\", specID = { 252 } }, -- Soul Reaper\n    [207289] = { duration = 120, class = \"DEATHKNIGHT\", specID = { 252 } }, -- Unholy Frenzy\n    [207319] = { duration = 60, class = \"DEATHKNIGHT\", specID = { 252 } }, -- Corpse Shield\n    [220143] = { duration = 90, class = \"DEATHKNIGHT\", specID = { 252 } }, -- Apocalypse\n    \n    -- Demon Hunter\n    \n    [179057] = { duration = 60, class = \"DEMONHUNTER\" }, -- Chaos Nova\n    [183752] = { default = true, duration = 15, class = \"DEMONHUNTER\", interrupt = true }, -- Disrupt\n    [188499] = { duration = 9, class = \"DEMONHUNTER\" }, -- Blade Dance\n    [188501] = { duration = 30, class = \"DEMONHUNTER\" }, -- Spectral Sight\n    [191427] = { duration = 105, class = \"DEMONHUNTER\" }, -- Metamorphosis\n    [187827] = { parent = 191427, duration = 180 }, -- Metamorphosis (Vengeance)\n    [162264] = { parent = 191427 }, -- Metamorphosis\n    [196718] = { duration = 180, class = \"DEMONHUNTER\" }, -- Darkness\n    [198013] = { duration = 30, class = \"DEMONHUNTER\" }, -- Eye Beam\n    [198793] = { duration = 25, class = \"DEMONHUNTER\" }, -- Vengeful Retreat\n    [203704] = { duration = 60, class = \"DEMONHUNTER\" }, -- Mana Break\n    [205604] = { duration = 60, class = \"DEMONHUNTER\" }, -- Reverse Magic\n    [206649] = { duration = 45, class = \"DEMONHUNTER\" }, -- Eye of Leotheras\n    [206803] = { duration = 60, class = \"DEMONHUNTER\" }, -- Rain from Above\n    [212800] = { duration = 60, class = \"DEMONHUNTER\" }, -- Blur\n    [196555] = { parent = 212800, duration = 90 }, -- Netherwalk\n    [214743] = { duration = 60, class = \"DEMONHUNTER\" }, -- Soul Carver\n    [207407] = { parent = 214743 }, -- Soul Carver (Vengeance)\n    [221527] = { duration = 45, class = \"DEMONHUNTER\" }, -- Imprison\n    \n    -- Havoc\n    \n    [201467] = { duration = 60, class = \"DEMONHUNTER\", specID = { 577 } }, -- Fury of the Illidari\n    [206491] = { duration = 120, class = \"DEMONHUNTER\", specID = { 577 } }, -- Nemesis\n    --[211048] = { duration = 120, class = \"DEMONHUNTER\", specID = { 577 } }, -- Chaos Blades\n    [211881] = { duration = 30, class = \"DEMONHUNTER\", specID = { 577, 581 } }, -- Fel Eruption\n    \n    -- Vengeance\n    \n    [202137] = { duration = 60, class = \"DEMONHUNTER\", specID = { 581 } }, -- Sigil of Silence\n    [202138] = { duration = 120, class = \"DEMONHUNTER\", specID = { 581 } }, -- Sigil of Chains\n    [204021] = { duration = 60, class = \"DEMONHUNTER\", specID = { 581 } }, -- Fiery Brand\n    [204596] = { duration = 30, class = \"DEMONHUNTER\", specID = { 581 } }, -- Sigil of Flame\n    [205629] = { duration = 30,  class = \"DEMONHUNTER\", specID = { 581 } }, -- Demonic Trample\n    [205630] = { duration = 90, class = \"DEMONHUNTER\", specID = { 581 } }, -- Illidan's Grasp\n    [207684] = { duration = 90, class = \"DEMONHUNTER\", specID = { 581 } }, -- Sigil of Misery\n    [207810] = { duration = 120, class = \"DEMONHUNTER\", specID = { 581 } }, -- Nether Bond\n    --[218256] = { duration = 20, class = \"DEMONHUNTER\", specID = { 581 } }, -- Empower Wards\n    [263648] = { duration = 20, class = \"DEMONHUNTER\", specID = { 581 } }, -- Soul Barrier\n    \n    -- Priest\n    \n    [586] = { duration = 30, class = \"PRIEST\" }, -- Fade\n    [213602] = { parent = 586 }, -- Greater Fade\n    [32375] = { duration = 45, class = \"PRIEST\" }, -- Mass Dispel\n    \n    -- Discipline\n    \n    [8122] = { duration = 30, class = \"PRIEST\", specID = { 256, 257, 258 } }, -- Psychic Scream\n    [10060] = { duration = 120, class = \"PRIEST\", specID = { 256, 258 } }, -- Power Infusion\n    [33206] = { duration = 180, class = \"PRIEST\", specID = { 256 } }, -- Pain Suppression\n    [34433] = { duration = 180, class = \"PRIEST\", specID = { 256, 258 } }, -- Shadowfiend\n    [123040] = { parent = 34433, duration = 60 }, -- Mindbender (Discipline)\n    [200174] = { parent = 34433, duration = 60 }, -- Mindbender (Shadow)\n    [47536] = { duration = 90, class = \"PRIEST\", specID = { 256 } }, -- Rapture\n    [62618] = { duration = 180, class = \"PRIEST\", specID = { 256 } }, -- Power Word: Barrier\n    [73325] = { duration = 90, class = \"PRIEST\", specID = { 256, 257, 258 } }, -- Leap of Faith\n    [197862] = { duration = 60, class = \"PRIEST\", specID = { 256 } }, -- Archangel\n    [197871] = { duration = 60, class = \"PRIEST\", specID = { 256 } }, -- Dark Archangel\n    [204263] = { duration = 45, class = \"PRIEST\", specID = { 256, 257 } }, -- Shining Force\n    [209780] = { duration = 12, class = \"PRIEST\", specID = { 256} }, -- Premonition\n    [209885] = { parent = 209780 },\n    \n    -- Holy\n    \n    [19236] = { duration = 90, class = \"PRIEST\", specID = { 256, 257 } }, -- Desperate Prayer\n    [47788] = { duration = 180, class = \"PRIEST\", specID = { 257 } }, -- Guardian Spirit\n    [64843] = { duration = 180, class = \"PRIEST\", specID = { 257 } }, -- Divine Hymn\n    [64901] = { duration = 300, class = \"PRIEST\", specID = { 257 } }, -- Symbol of Hope\n    [196762] = { duration = 30, class = \"PRIEST\", specID = { 257 } }, -- Inner Focus\n    [197268] = { duration = 60, class = \"PRIEST\", specID = { 257 } }, -- Ray of Hope\n    [200183] = { duration = 120, class = \"PRIEST\", specID = { 257 } }, -- Apotheosis\n    [213610] = { duration = 30, class = \"PRIEST\", specID = { 257 } }, -- Holy Ward\n    [215769] = { duration = 300, class = \"PRIEST\", specID = { 257 } }, -- Spirit of Redemption\n    \n    -- Shadow\n    \n    [15286] = { duration = 120, class = \"PRIEST\", specID = { 258 } }, -- Vampiric Embrace\n    [15487] = { duration = 45, class = \"PRIEST\", specID = { 258 }, interrupt = true }, -- Silence\n    [32379] = { duration = 9, class = \"PRIEST\", specID = { 258 }, charges = 2 }, -- Shadow Word: Death\n    [47585] = { duration = 120, class = \"PRIEST\", specID = { 258 } }, -- Dispersion\n    [64044] = { duration = 45, class = \"PRIEST\", specID = { 258 } }, -- Psychic Horror\n    [108968] = { duration = 300, class = \"PRIEST\", specID = { 258 } }, -- Void Shift\n    [193223] = { duration = 240, class = \"PRIEST\", specID = { 258 } }, -- Surrender to Madness\n    [205065] = { duration = 45, class = \"PRIEST\", specID = { 258 } }, -- Void Torrent\n    [205369] = { duration = 30, class = \"PRIEST\", specID = { 258 } }, -- Mind Bomb\n    [211522] = { duration = 45, class = \"PRIEST\", specID = { 258 } }, -- Psyfiend\n    \n    -- Paladin\n    \n    [633] = { duration = 600, class = \"PALADIN\" }, -- Lay on Hands\n    [642] = { duration = 300, class = \"PALADIN\" }, -- Divine Shield\n    [853] = { duration = 60, class = \"PALADIN\" }, -- Hammer of Justice\n    [1022] = { duration = 300, class = \"PALADIN\", charges = 2 }, -- Blessing of Protection\n    [204018] = { parent = 1022, duration = 180 }, -- Blessing of Spellwarding\n    [1044] = { duration = 25, class = \"PALADIN\", charges = 2 }, -- Blessing of Freedom\n    [20066] = { duration = 15, class = \"PALADIN\" }, -- Repentance\n    [31884] = { duration = 120, class = \"PALADIN\" }, -- Avenging Wrath\n    [31842] = { parent = 31884 }, -- Avenging Wrath (Holy)\n    [216331] = { parent = 31884 }, -- Avenging Crusader\n    [224668] = { parent = 31884 }, -- Crusade\n    [231895] = { parent = 31884 }, -- Crusade\n    [115750] = { duration = 90, class = \"PALADIN\" }, -- Blinding Light\n    \n    -- Holy\n    \n    [498] = { duration = 60, class = \"PALADIN\", specID = { 65, 66 } }, -- Divine Protection\n    [6940] = { duration = 120, class = \"PALADIN\", specID = { 65, 66 }, charges = 2 }, -- Blessing of Sacrifice\n    [31821] = { duration = 180, class = \"PALADIN\", specID = { 65 } }, -- Aura Mastery\n    [105809] = { duration = 90, class = \"PALADIN\", specID = { 65 } }, -- Holy Avenger\n    [114158] = { duration = 60, class = \"PALADIN\", specID = { 65 } }, -- Light's Hammer\n    [183415] = { duration = 180, class = \"PALADIN\", specID = { 65 } }, -- Aura of Mercy\n    [200652] = { duration = 90, class = \"PALADIN\", specID = { 65 } }, -- Tyr's Deliverance\n    [210294] = { duration = 25, class = \"PALADIN\", specID = { 65 } }, -- Divine Favor\n    [214202] = { duration = 30, class = \"PALADIN\", specID = { 65 }, charges = 2 }, -- Rule of Law\n    \n    -- Protection\n    \n    [31850] = { duration = 120, class = \"PALADIN\", specID = { 66 } }, -- Ardent Defender\n    [31935] = { default = true, duration = 15, class = \"PALADIN\", specID = { 66 }, interrupt =false }, -- Avenger's Shield\n    [86659] = { duration = 300, class = \"PALADIN\", specID = { 66 } }, -- Guardian of Ancient Kings\n    [228049] = { parent = 86659 }, -- Guardian of the Forgotten Queen\n    [96231] = { default = true, duration = 15, class = \"PALADIN\", specID = { 66, 70 }, interrupt = true }, -- Rebuke\n    [152262] = { duration = 30, class = \"PALADIN\", specID = { 66 } }, -- Seraphim\n    [190784] = { duration = 45, class = \"PALADIN\", specID = { 66 } }, -- Divine Steed\n    [204035] = { duration = 180, class = \"PALADIN\", specID = { 66 } }, -- Bastion of Light\n    [204150] = { duration = 300, class = \"PALADIN\", specID = { 66 } }, -- Aegis of Light\n    [209202] = { duration = 60, class = \"PALADIN\", specID = { 66 } }, -- Eye of Tyr\n    [215652] = { duration = 25, class = \"PALADIN\", specID = { 66 } }, -- Shield of Virtue\n    \n    -- Retribution\n    \n    [184662] = { duration = 120, class = \"PALADIN\", specID = { 70 } }, -- Shield of Vengeance\n    [204939] = { duration = 60, class = \"PALADIN\", specID = { 70 } }, -- Hammer of Reckoning\n    [205191] = { duration = 60, class = \"PALADIN\", specID = { 70 } }, -- Eye for an Eye\n    [205273] = { duration = 45, class = \"PALADIN\", specID = { 70 } }, -- Wake of Ashes\n    [210191] = { duration = 60, class = \"PALADIN\", specID = { 70 }, charges = 2 }, -- Word of Glory\n    [210220] = { duration = 180, class = \"PALADIN\", specID = { 70 } }, -- Holy Wrath\n    [210256] = { duration = 45, class = \"PALADIN\", specID = { 70 } }, -- Blessing of Sanctuary\n    \n    -- Druid\n    \n    [1850] = { duration = 120, class = \"DRUID\" }, -- Dash\n    [252216] = { parent = 1850, duration = 45 }, -- Tiger Dash\n    [5211] = { duration = 50, class = \"DRUID\" }, -- Mighty Bash\n    [20484] = { duration = 600, class = \"DRUID\" }, -- Rebirth\n    [102280] = { duration = 30, class = \"DRUID\" }, -- Displacer Beast\n    [102359] = { duration = 30, class = \"DRUID\" }, -- Mass Entanglement\n    [102401] = { duration = 15, class = \"DRUID\" }, -- Wild Charge\n    [132469] = { duration = 30, class = \"DRUID\" }, -- Typhoon\n    \n    -- Balance\n    \n    [22812] = { duration = { default = 60, [104] = 35 }, class = \"DRUID\", specID = { 102, 104, 105 } }, -- Barkskin\n    [29166] = { duration = 180, class = \"DRUID\", specID = { 102, 105 } }, -- Innervate\n    [78675] = { default = true, duration = 60, class = \"DRUID\", specID = { 102 }, interrupt = true }, -- Solar Beam\n    [102560] = { duration = 180, class = \"DRUID\", specID = { 102 } }, -- Incarnation: Chosen of Elune\n    [108238] = { duration = 120, class = \"DRUID\", specID = { 102, 103, 105 } }, -- Renewal\n    [194223] = { duration = 180, class = \"DRUID\", specID = { 102 } }, -- Celestial Alignment\n    [202425] = { duration = 45, class = \"DRUID\", specID = { 102 } }, -- Warrior of Elune\n    [202770] = { duration = 60, class = \"DRUID\", specID = { 102 } }, -- Fury of Elune\n    [205636] = { duration = 60, class = \"DRUID\", specID = { 102 } }, -- Force of Nature\n    [209749] = { duration = 30, class = \"DRUID\", specID = { 102 } }, -- Faerie Swarm\n    \n    -- Feral\n    \n    [5217] = { duration = 30, class = \"DRUID\", specID = { 103 } }, -- Tiger's Fury\n    [22570] = { duration = 20, class = \"DRUID\", specID = { 103 } }, -- Maim\n    [61336] = { duration = { default = 180, [104] = 120 }, class = \"DRUID\", specID = { 103, 104 }, charges = 2 }, -- Survival Instincts\n    [102543] = { duration = 180, class = \"DRUID\", specID = { 103 } }, -- Incarnation: King of the Jungle\n    [106839] = { default = true, duration = 15, class = \"DRUID\", specID = { 103, 104 }, interrupt = true }, -- Skull Bash\n    [106898] = { duration = 120, class = \"DRUID\", specID = { 103, 104 } }, -- Stampeding Roar\n    [106951] = { duration = 180, class = \"DRUID\", specID = { 103 } }, -- Berserk\n    [202060] = { duration = 45, class = \"DRUID\", specID = { 103 } }, -- Elune's Guidance\n    [203242] = { duration = 60, class = \"DRUID\", specID = { 103 } }, -- Rip and Tear\n    [210722] = { duration = 75, class = \"DRUID\", specID = { 103 } }, -- Ashamane's Frenzy\n    \n    -- Guardian\n    \n    [99] = { duration = 30, class = \"DRUID\", specID = { 104 } }, -- Incapacitating Roar\n    [22842] = { duration = 36, class = \"DRUID\", specID = { 104 } }, -- Frenzied Regeneration\n    [102558] = { duration = 180, class = \"DRUID\", specID = { 104 } }, -- Incarnation: Guardian of Ursoc\n    [200851] = { duration = 90, class = \"DRUID\", specID = { 104 } }, -- Rage of the Sleeper\n    [202246] = { duration = 15, class = \"DRUID\", specID = { 104 } }, -- Overrun\n    [204066] = { duration = 90, class = \"DRUID\", specID = { 104 } }, -- Lunar Beam\n    \n    -- Restoration\n    \n    [740] = { duration = 180, class = \"DRUID\", specID = { 105} }, -- Tranquility\n    [18562] = { duration = 25, class = \"DRUID\", specID = { 105}, charges = 2 }, -- Swiftmend\n    [33891] = { duration = 180, class = \"DRUID\", specID = { 105} }, -- Incarnation: Tree of Life\n    [102342] = { duration = 60, class = \"DRUID\", specID = { 105} }, -- Ironbark\n    [102351] = { duration = 30, class = \"DRUID\", specID = { 105} }, -- Cenarion Ward\n    [102793] = { duration = 60, class = \"DRUID\", specID = { 105} }, -- Ursol's Vortex\n    [197721] = { duration = 90, class = \"DRUID\", specID = { 105} }, -- Flourish\n    [201664] = { duration = 60, class = \"DRUID\", specID = { 105} }, -- Demoralizing Roar\n    [203651] = { duration = 45, class = \"DRUID\", specID = { 105} }, -- Overgrowth\n    [236696] = { duration = 45, class = \"DRUID\", specID = { 102, 103, 105} }, -- Thorns\n    [208253] = { duration = 90, class = \"DRUID\", specID = { 105} }, -- Essence of G'Hanir\n    \n    -- Warrior\n    \n    [100] = { duration = 20, class = \"WARRIOR\" }, -- Charge\n    [198758] = { parent = 100, charges = 2 }, -- Intercept\n    [1719] = { duration = 90, class = \"WARRIOR\" }, -- Recklessness\n    [6544] = { duration = 30, class = \"WARRIOR\", charges = 2 }, -- Heroic Leap\n    [6552] = { default = true, duration = 15, class = \"WARRIOR\", interrupt = true }, -- Pummel\n    [18499] = { duration = 60, class = \"WARRIOR\",interrupt = true }, -- Berserker Rage\n    [23920] = { duration = 25, class = \"WARRIOR\",interrupt = true  }, -- Spell Reflection\n    [213915] = { parent = 23920, duration = 30,interrupt = true  }, -- Mass Spell Reflection\n    [216890] = { parent = 23920 }, -- Spell Reflection (Arms, Fury)\n    [46968] = { duration = 40, class = \"WARRIOR\" }, -- Shockwave\n    [107570] = { duration = 30, class = \"WARRIOR\" }, -- Storm Bolt\n    [107574] = { duration = 90, class = \"WARRIOR\" }, -- Avatar\n    [236077] = { duration = 45, class = \"WARRIOR\" }, -- Disarm\n    [236236] = { parent = 236077 }, -- Disarm (Protection)\n    \n    -- Arms\n    \n    [5246] = { duration = 90, class = \"WARRIOR\", specID = { 71, 72 } }, -- Intimidating Shout\n    [97462] = { duration = 180, class = \"WARRIOR\", specID = { 71, 72, 73 } }, -- Rallying Cry\n    [118038] = { duration = 180, class = \"WARRIOR\", specID = { 71 } }, -- Die by the Sword\n    [167105] = { duration = 45, class = \"WARRIOR\", specID = { 71 } }, -- Colossus Smash\n    [262161] = { parent = 167105 }, -- Warbreaker\n    [197690] = { duration = 10, class = \"WARRIOR\", specID = { 71 } }, -- Defensive Stance\n    [198817] = { duration = 45, class = \"WARRIOR\", specID = { 71 } }, -- Sharpen Blade\n    [227847] = { duration = 60, class = \"WARRIOR\", specID = { 71, 72 } }, -- Bladestorm (Arms)\n    [46924] = { parent = 227847 }, -- Bladestorm (Fury)\n    [152277] = { parent = 227847 }, -- Ravager\n    [236273] = { duration = 60 , class = \"WARRIOR\", specID = { 71 } }, -- Duel\n    \n    -- Fury\n    \n    [184364] = { duration = 120, class = \"WARRIOR\", specID = { 72 } }, -- Enraged Regeneration\n    [205545] = { duration = 45, class = \"WARRIOR\", specID = { 72 } }, -- Odyn's Fury\n    \n    -- Protection\n    \n    [871] = { duration = 240, class = \"WARRIOR\", specID = { 73 } }, -- Shield Wall\n    [1160] = { duration = 45, class = \"WARRIOR\", specID = { 73 } }, -- Demoralizing Shout\n    [12975] = { duration = 180, class = \"WARRIOR\", specID = { 73 } }, -- Last Stand\n    [118000] = { duration = 35, class = \"WARRIOR\", specID = { 73 } }, -- Dragon Roar\n    [198304] = { duration = 20, class = \"WARRIOR\", specID = { 73 }, charges = 2 }, -- Intercept\n    [206572] = { duration = 20, class = \"WARRIOR\", specID = { 73 } }, -- Dragon Charge\n    [213871] = { duration = 15, class = \"WARRIOR\", specID = { 73 } }, -- Bodyguard\n    [228920] = { duration = 60, class = \"WARRIOR\", specID = { 73 } }, -- Ravager\n    \n    -- Warlock\n    \n    [1122] = { duration = 180, class = \"WARLOCK\" }, -- Summon Infernal\n    [6358] = { duration = 30, class = \"WARLOCK\" }, -- Seduction\n    [115268] = { parent = 6358 }, -- Mesmerize\n    [6360] = { duration = 25, class = \"WARLOCK\" }, -- Whiplash\n    [115770] = { parent = 6360 }, -- Fellash\n    [6789] = { duration = 45, class = \"WARLOCK\" }, -- Mortal Coil\n    --[18540] = { duration = 180, class = \"WARLOCK\" }, -- Summon Doomguard\n    [20707] = { duration = 600, class = \"WARLOCK\" }, -- Soulstone\n    [30283] = { duration = 60, class = \"WARLOCK\" }, -- Shadowfury\n    [104773] = { duration = 180, class = \"WARLOCK\" }, -- Unending Resolve\n    [108416] = { duration = 60, class = \"WARLOCK\" }, -- Dark Pact\n    [108501] = { duration = 90, class = \"WARLOCK\" }, -- Grimoire of Service\n    [111896] = { duration = 90, class = \"WARLOCK\" }, -- Grimoire: Succubus\n    [119910] = { default = true, duration = 24, class = \"WARLOCK\", interrupt = true }, -- Spell Lock (Command Demon)\n    [19647] = { parent = 119910 }, -- Spell Lock (Felhunter)\n    [119911] = { parent = 119910 }, -- Optical Blast (Command Demon)\n    [115781] = { parent = 119910 }, -- Optical Blast (Observer)\n    [132409] = { parent = 119910 }, -- Spell Lock (Grimoire of Sacrifice)\n    [171138] = { parent = 119910 }, -- Shadow Lock (Doomguard)\n    [171139] = { parent = 119910 }, -- Shadow Lock (Grimoire of Sacrifice)\n    [171140] = { parent = 119910 }, -- Shadow Lock (Command Demon)\n    [171152] = { duration = 60, class = \"WARLOCK\" }, -- Meteor Strike\n    [196098] = { duration = 120, class = \"WARLOCK\" }, -- Soul Harvest\n    [199890] = { duration = 15, class = \"WARLOCK\" }, -- Curse of Tongues\n    [199892] = { duration = 20, class = \"WARLOCK\" }, -- Curse of Weakness\n    [199954] = { duration = 45, class = \"WARLOCK\" }, -- Curse of Fragility\n    [212295] = { duration = 45, class = \"WARLOCK\" , interrupt = true}, -- Nether Ward\n    [221703] = { duration = 30, class = \"WARLOCK\" }, -- Casting Circle\n    \n    -- Affliction\n    \n    [5484] = { duration = 40, class = \"WARLOCK\", specID = { 265 } }, -- Howl of Terror\n    [48181] = { duration = 15, class = \"WARLOCK\", specID = { 265 } }, -- Haunt\n    [86121] = { duration = 20, class = \"WARLOCK\", specID = { 265 } }, -- Soul Swap\n    [113860] = { duration = 120, class = \"WARLOCK\", specID = { 265 } }, -- Dark Soul: Misery\n    [205179] = { duration = 45, class = \"WARLOCK\", specID = { 265 } }, -- Phantom Singularity\n    \n    -- Demonology\n    \n    [89751] = { duration = 45, class = \"WARLOCK\", specID = { 266 } }, -- Felstorm\n    [115831] = { parent = 89751 }, -- Wrathstorm\n    [89766] = { duration = 30, class = \"WARLOCK\", specID = { 266 } }, -- Axe Toss\n    [201996] = { duration = 90, class = \"WARLOCK\", specID = { 266 } }, -- Call Observer\n    [205180] = { duration = 24, class = \"WARLOCK\", specID = { 266 } }, -- Summon Darkglare\n    [205181] = { duration = 14, class = \"WARLOCK\", specID = { 266 }, charges = 2 }, -- Shadowflame\n    [211714] = { duration = 45, class = \"WARLOCK\", specID = { 266 } }, -- Thal'kiel's Consumption\n    [212459] = { duration = 90, class = \"WARLOCK\", specID = { 266 } }, -- Call Fel Lord\n    [212619] = { duration = 24, class = \"WARLOCK\", specID = { 266 } }, -- Call Felhunter\n    [212623] = { duration = 15, class = \"WARLOCK\", specID = { 266 } }, -- Singe Magic\n    \n    --  Destruction\n    \n    [17962] = { duration = 12, class = \"WARLOCK\", specID = { 267 }, charges = 2 }, -- Conflagrate\n    [80240] = { duration = 30, class = \"WARLOCK\", specID = { 267 } }, -- Havoc\n    [113858] = { duration = 120, class = \"WARLOCK\", specID = { 267 } }, -- Dark Soul: Instability\n    [152108] = { duration = 45, class = \"WARLOCK\", specID = { 267 } }, -- Cataclysm\n    [196447] = { duration = 15, class = \"WARLOCK\", specID = { 267 } }, -- Channel Demonfire\n    [196586] = { duration = 45, class = \"WARLOCK\", specID = { 267 }, charges = 3 }, -- Dimensional Rift\n    [212284] = { duration = 45, class = \"WARLOCK\", specID = { 267 } }, -- Firestone\n    \n    -- Shaman\n    \n    [2825] = { duration = 60, class = \"SHAMAN\" }, -- Bloodlust\n    [32182] = { parent = 2825 }, -- Heroism\n    [20608] = { duration = 1800, class = \"SHAMAN\" }, -- Reincarnation\n    [51485] = { duration = 30, class = \"SHAMAN\" }, -- Earthgrab Totem\n    [51514] = { duration = { default = 30, [264] = 10 }, class = \"SHAMAN\" }, -- Hex\n    [196932] = { parent = 51514 }, -- Voodoo Totem\n    [210873] = { parent = 51514 }, -- Hex (Compy)\n    [211004] = { parent = 51514 }, -- Hex (Spider)\n    [211010] = { parent = 51514 }, -- Hex (Snake)\n    [211015] = { parent = 51514 }, -- Hex (Cockroach)\n    [57994] = { default = true, duration = 12, class = \"SHAMAN\", interrupt = true }, -- Wind Shear\n    [108271] = { duration = 90, class = \"SHAMAN\" }, -- Astral Shift\n    [210918] = { parent = 108271, duration = 45 }, -- Ethereal Form\n    [114049] = { duration = 180, class = \"SHAMAN\" }, -- Ascendance\n    [114050] = { parent = 114050 }, -- Ascendance (Elemental)\n    [114051] = { parent = 114050 }, -- Ascendance (Enhancement)\n    [114052] = { parent = 114050 }, -- Ascendance (Restoration)\n    [192058] = { duration = 60, class = \"SHAMAN\" }, -- Capacitor\n    [192077] = { duration = 120, class = \"SHAMAN\" }, -- Wind Rush Totem\n    [204330] = { duration = 45, class = \"SHAMAN\" }, -- Skyfury Totem\n    [204331] = { duration = 45, class = \"SHAMAN\" }, -- Counterstrike Totem\n    [204332] = { duration = 30, class = \"SHAMAN\" }, -- Windfury Totem\n    \n    -- Elemental\n    \n    [16166] = { duration = 120, class = \"SHAMAN\", specID = { 262 } }, -- Elemental Mastery\n    [51490] = { duration = 45, class = \"SHAMAN\", specID = { 262 } }, -- Thunderstorm\n    [108281] = { duration = 120, class = \"SHAMAN\", specID = { 262, 264 } }, -- Ancestral Guidance\n    [192063] = { duration = 15, class = \"SHAMAN\", specID = { 262, 264 } }, -- Gust of Wind\n    [192222] = { duration = 60, class = \"SHAMAN\", specID = { 262 } }, -- Liquid Magma Totem\n    [198067] = { duration = 150, class = \"SHAMAN\", specID = { 262 } }, -- Fire Elemental\n    [192249] = { parent = 198067 }, -- Storm Elemental\n    [198103] = { duration = 120, class = \"SHAMAN\", specID = { 262 } }, -- Earth Elemental\n    [204437] = { duration = 30, class = \"SHAMAN\", specID = { 262 } }, -- Lightning Lasso\n    [191634] = { duration = 60, class = \"SHAMAN\", specID = { 262 } }, -- Stormkeeper\n    \n    -- Enhancement\n    \n    [58875] = { duration = 60, class = \"SHAMAN\", specID = { 263 } }, -- Spirit Walk\n    [196884] = { duration = 30, class = \"SHAMAN\", specID = { 263 } }, -- Feral Lunge\n    [197214] = { duration = 40, class = \"SHAMAN\", specID = { 263 } }, -- Sundering\n    [201898] = { duration = 45, class = \"SHAMAN\", specID = { 263 } }, -- Windsong\n    [204366] = { duration = 45, class = \"SHAMAN\", specID = { 263 } }, -- Thundercharge\n    [204945] = { duration = 60, class = \"SHAMAN\", specID = { 263 } }, -- Doom Winds\n    \n    -- Restoration\n    \n    [5394] = { duration = 30, class = \"SHAMAN\", specID = { 264 }, charges = 30 }, -- Healing Stream Totem\n    [79206] = { duration = 60, class = \"SHAMAN\", specID = { 264 } }, -- Spiritwalker's Grace\n    [98008] = { duration = 180, class = \"SHAMAN\", specID = { 264 } }, -- Spirit Link Totem\n    [204293] = { parent = 98008, duration = 60 }, -- Spirit Link\n    [108280] = { duration = 180, class = \"SHAMAN\", specID = { 264 } }, -- Healing Tide Totem\n    [157153] = { duration = 30, class = \"SHAMAN\", specID = { 264 } }, -- Cloudburst Totem\n    [198838] = { duration = 60, class = \"SHAMAN\", specID = { 264 } }, -- Earthen Wall Totem\n    [204336] = { duration = 30, class = \"SHAMAN\", specID = { 264 } }, -- Grounding Totem\n    [207399] = { duration = 300, class = \"SHAMAN\", specID = { 264 } }, -- Ancestral Protection Totem\n    [207778] = { duration = 45, class = \"SHAMAN\", specID = { 264 } }, -- Gift of the Queen\n    \n    -- Hunter\n    \n    [136] = { duration = 10, class = \"HUNTER\" }, -- Mend Pet\n    [1543] = { duration = 20, class = \"HUNTER\" }, -- Flare\n    [5384] = { duration = 30, class = \"HUNTER\" }, -- Feign Death\n    [53480] = { duration = 60, class = \"HUNTER\" }, -- Roar of Sacrifice\n    [109304] = { duration = 120, class = \"HUNTER\" }, -- Exhilaration (Beast Mastery, Survival)\n    [131894] = { duration = 60, class = \"HUNTER\" }, -- A Murder of Crows (Beast Mastery, Marksmanship)\n    [206505] = { parent = 131894 }, -- A Murder of Crows (Survival)\n    [186257] = { duration = { default = 180, [253] = 120, [255] = 144 }, class = \"HUNTER\" }, -- Aspect of the Cheetah\n    [186265] = { duration = { default = 180, [255] = 144 }, class = \"HUNTER\" }, -- Aspect of the Turtle\n    [187650] = { duration = { default = 30, [255] = 20 }, class = \"HUNTER\" }, -- Freezing Trap\n    [202914] = { duration = 60, class = \"HUNTER\" }, -- Spider Sting\n    [209997] = { duration = 30, class = \"HUNTER\" }, -- Play Dead\n    \n    -- Beast Mastery\n    \n    [781] = { duration = 20, class = \"HUNTER\", specID = { 253, 254 } }, -- Disengage\n    [19386] = { duration = 45, class = \"HUNTER\", specID = { 253, 254 } }, -- Wyvern Sting\n    [19574] = { duration = 75, class = \"HUNTER\", specID = { 253 } }, -- Bestial Wrath\n    [19577] = { duration = 60, class = \"HUNTER\", specID = { 253 } }, -- Intimidation\n    [109248] = { duration = 45, class = \"HUNTER\", specID = { 253, 254 } }, -- Binding Shot\n    [147362] = { default = true, duration = 24, class = \"HUNTER\", specID = { 253, 254 }, interrupt = true }, -- Counter Shot\n    [193530] = { duration = 120, class = \"HUNTER\", specID = { 253 } }, -- Aspect of the Wild\n    [194386] = { duration = 90, class = \"HUNTER\", specID = { 253, 254 } }, -- Volley\n    [201430] = { duration = 180, class = \"HUNTER\", specID = { 253 } }, -- Stampede\n    [207068] = { duration = 60, class = \"HUNTER\", specID = { 253 } }, -- Titan's Thunder\n    [208652] = { duration = 30, class = \"HUNTER\", specID = { 253 } }, -- Dire Beast: Hawk\n    \n    -- Marksmanship\n    \n    [34477] = { duration = 30, class = \"HUNTER\", specID = { 254 } }, -- Misdirection\n    [186387] = { duration = 20, class = \"HUNTER\", specID = { 254 } }, -- Bursting Shot\n    [193526] = { duration = 140, class = \"HUNTER\", specID = { 254 } }, -- Trueshot\n    [199483] = { duration = 60, class = \"HUNTER\", specID = { 254, 255 } }, -- Camouflage\n    [204147] = { duration = 20, class = \"HUNTER\", specID = { 254 } }, -- Windburst\n    [206817] = { duration = 30, class = \"HUNTER\", specID = { 254 } }, -- Sentinel\n    [209789] = { duration = 30, class = \"HUNTER\", specID = { 254 } }, -- Freezing Arrow\n    [213691] = { duration = 20, class = \"HUNTER\", specID = { 254 } }, -- Scatter Shot\n    \n    -- Survival\n    \n    [53271] = { duration = 45, class = \"HUNTER\", specID = { 255 } }, -- Master's Call\n    [186289] = { duration = 96, class = \"HUNTER\", specID = { 255 } }, -- Aspect of the Eagle\n    [187698] = { duration = 20, class = \"HUNTER\", specID = { 255 } }, -- Tar Trap\n    [187707] = { default = true, duration = 15, class = \"HUNTER\", specID = { 255 }, interrupt = true }, -- Muzzle\n    [190925] = { duration = 20, class = \"HUNTER\", specID = { 255 } }, -- Harpoon\n    [191241] = { duration = 30, class = \"HUNTER\", specID = { 255 } }, -- Sticky Bomb\n    [191433] = { duration = 20, class = \"HUNTER\", specID = { 255 } }, -- Explosive Trap\n    [194407] = { duration = 90, class = \"HUNTER\", specID = { 255 } }, -- Spitting Cobra\n    [201078] = { duration = 90, class = \"HUNTER\", specID = { 255 } }, -- Snake Hunter\n    [203415] = { duration = 45, class = \"HUNTER\", specID = { 255 } }, -- Fury of the Eagle\n    [205691] = { duration = 120, class = \"HUNTER\", specID = { 255 } }, -- Dire Beast: Basilisk\n    [212640] = { duration = 25, class = \"HUNTER\", specID = { 255 } }, -- Mending Bandage\n    [266779] = { duration = 20, class = \"HUNTER\", specID = { 255 } }, -- Coordinated Assault\n    \n    -- Mage\n    \n    [66] = { duration = 300, class = \"MAGE\" }, -- Invisibility\n    [110959] = { parent = 66, duration = 75 }, -- Greater Invisibility\n    [1953] = { duration = 15, class = \"MAGE\"}, -- Blink\n    [212653] = { parent = 1953, duration = 20, charges = 2 }, -- Shimmer\n    [2139] = { default = true, duration = 24, class = \"MAGE\", interrupt = true }, -- Counterspell\n    [11426] = { duration = 25, class = \"MAGE\" }, -- Ice Barrier\n    [45438] = { duration = 300, class = \"MAGE\", charges = 2 }, -- Ice Block\n    [55342] = { duration = 120, class = \"MAGE\" }, -- Mirror Image\n    [80353] = { duration = 300, class = \"MAGE\" }, -- Time Warp\n    [108839] = { duration = 20, class = \"MAGE\", charges = 3 }, -- Ice Floes\n    [113724] = { duration = 45, class = \"MAGE\" }, -- Ring of Frost\n    [116011] = { duration = 40, class = \"MAGE\", charges = 2 }, -- Rune of Power\n    [198111] = { duration = 45, class = \"MAGE\" }, -- Temporal Shield\n    \n    -- Arcane\n    \n    [12042] = { duration = 90, class = \"MAGE\", specID = { 62 } }, -- Arcane Power\n    [12051] = { duration = 90, class = \"MAGE\", specID = { 62 } }, -- Evocation\n    [153626] = { duration = 20, class = \"MAGE\", specID = { 62 } }, -- Arcane Orb\n    [157980] = { duration = 25, class = \"MAGE\", specID = { 62 } }, -- Supernova\n    [195676] = { duration = 24, class = \"MAGE\", specID = { 62 } }, -- Displacement\n    [198158] = { duration = 60, class = \"MAGE\", specID = { 62 } }, -- Mass Invisibility\n    [205025] = { duration = 60, class = \"MAGE\", specID = { 62 } }, -- Presence of Mind\n    [224968] = { duration = 60, class = \"MAGE\", specID = { 62 } }, -- Mark of Aluneth\n    \n    -- Fire\n    \n    [31661] = { duration = 20, class = \"MAGE\", specID = { 63 } }, -- Dragon's Breath\n    [108853] = { duration = 12, class = \"MAGE\", specID = { 63 }, charges = 2 }, -- Fire Blast\n    [153561] = { duration = 45, class = \"MAGE\", specID = { 63 } }, -- Meteor\n    [157981] = { duration = 25, class = \"MAGE\", specID = { 63 } }, -- Blast Wave\n    [190319] = { duration = 115, class = \"MAGE\", specID = { 63 } }, -- Combustion\n    [194466] = { duration = 45, class = \"MAGE\", specID = { 63 }, charges = 3 }, -- Phoenix's Flames\n    [205029] = { duration = 45, class = \"MAGE\", specID = { 63 } }, -- Flame On\n    \n    -- Frost\n    \n    [122] = { duration = 30, class = \"MAGE\", specID = { 64 }, charges = 2 }, -- Frost Nova\n    [12472] = { duration = 180, class = \"MAGE\", specID = { 64 } }, -- Icy Veins\n    [198144] = { parent = 12472, duration = 45 }, -- Ice Form\n    [31687] = { duration = 60, class = \"MAGE\", specID = { 64 } }, -- Summon Water Elemental\n    [84714] = { duration = 60, class = \"MAGE\", specID = { 64 } }, -- Frozen Orb\n    [153595] = { duration = 30, class = \"MAGE\", specID = { 64 } }, -- Comet Storm\n    [157997] = { duration = 25, class = \"MAGE\", specID = { 64 } }, -- Ice Nova\n    [205021] = { duration = 75, class = \"MAGE\", specID = { 64 } }, -- Ray of Frost\n    [214634] = { duration = 45, class = \"MAGE\", specID = { 64 } }, -- Ebonbolt\n    \n    -- Rogue\n    \n    [1725] = { duration = 30, class = \"ROGUE\" }, -- Distract\n    [1766] = { default = true, duration = 15, class = \"ROGUE\", interrupt = true }, -- Kick\n    [1856] = { duration = { default = 120, [261] = 30 }, class = \"ROGUE\" }, -- Vanish\n    [2983] = { duration = { default = 60, [259] = 51 }, class = \"ROGUE\" }, -- Sprint\n    [31224] = { duration = { default = 90, [259] = 81 }, class = \"ROGUE\" }, -- Cloak of Shadows\n    [57934] = { duration = 30, class = \"ROGUE\" }, -- Tricks of the Trade\n    [137619] = { duration = 40, class = \"ROGUE\" }, -- Marked for Death\n    [152150] = { duration = 20, class = \"ROGUE\" }, -- Death from Above\n    \n    -- Assassination\n    \n    [408] = { duration = 20, class = \"ROGUE\", specID = { 259, 261 } }, -- Kidney Shot\n    [703] = { duration = 6, class = \"ROGUE\", specID = { 259 } }, -- Garrote\n    [5277] = { duration = 120, class = \"ROGUE\", specID = { 259, 261 } }, -- Evasion\n    [36554] = { duration = 30, class = \"ROGUE\", specID = { 259, 261 } }, -- Shadowstep\n    [79140] = { duration = 120, class = \"ROGUE\", specID = { 259 } }, -- Vendetta\n    [192759] = { duration = 45, class = \"ROGUE\", specID = { 259 } }, -- Kingsbane\n    [200806] = { duration = 45, class = \"ROGUE\", specID = { 259 } }, -- Exsanguinate\n    [206328] = { duration = 25, class = \"ROGUE\", specID = { 259 } }, -- Shiv\n    \n    -- Outlaw\n    \n    [1776] = { duration = 15, class = \"ROGUE\", specID = { 260 } }, -- Gouge\n    [2094] = { duration = 120, class = \"ROGUE\", specID = { 260, 261 } }, -- Blind\n    [199743] = { parent = 2094, duration = 20 }, -- Parley\n    [13750] = { duration = 150, class = \"ROGUE\", specID = { 260 } }, -- Adrenaline Rush\n    [51690] = { duration = 120, class = \"ROGUE\", specID = { 260 } }, -- Killing Spree\n    --[185767] = { duration = 60, class = \"ROGUE\", specID = { 260 } }, -- Cannonball Barrage\n    [195457] = { duration = 30, class = \"ROGUE\", specID = { 260 } }, -- Grappling Hook\n    [198529] = { duration = 120, class = \"ROGUE\", specID = { 260 } }, -- Plunder Armor\n    [199754] = { duration = 120, class = \"ROGUE\", specID = { 260 } }, -- Riposte\n    [199804] = { duration = 30, class = \"ROGUE\", specID = { 260 } }, -- Between the Eyes\n    [202665] = { duration = 90, class = \"ROGUE\", specID = { 260 } }, -- Curse of the Dreadblades\n    [207777] = { duration = 45, class = \"ROGUE\", specID = { 260 } }, -- Dismantle\n    \n    -- Subtlety\n    \n    [121471] = { duration = 180, class = \"ROGUE\", specID = { 261 } }, -- Shadow Blades\n    [185313] = { duration = 60, class = \"ROGUE\", specID = { 261 }, charges = 3 }, -- Shadow Dance\n    [207736] = { duration = 120, class = \"ROGUE\", specID = { 261 } }, -- Shadowy Duel\n    [209782] = { duration = 60, class = \"ROGUE\", specID = { 261 } }, -- Goremaw's Bite\n    [212182] = { duration = 180, class = \"ROGUE\", specID = { 261 } }, -- Smoke Bomb\n    [213981] = { duration = 45, class = \"ROGUE\", specID = { 261 } }, -- Cold Blood\n    \n    -- Monk\n    \n    [109132] = { duration = 15, class = \"MONK\", charges = 3 }, -- Roll\n    [115008] = { parent = 109132 }, -- Chi Torpedo\n    [115078] = { duration = 45, class = \"MONK\" }, -- Paralysis\n    [116841] = { duration = 30, class = \"MONK\" }, -- Tiger's Lust\n    [116844] = { duration = 45, class = \"MONK\" }, -- Ring of Peace\n    [119381] = { duration = 60, class = \"MONK\" }, -- Leg Sweep\n    [119996] = { duration = 45, class = \"MONK\" }, -- Transcendence: Transfer\n    [122278] = { duration = 120, class = \"MONK\" }, -- Dampen Harm\n    [122783] = { duration = 120, class = \"MONK\" }, -- Diffuse Magic\n    [123986] = { duration = 30, class = \"MONK\" }, -- Chi Burst\n    --[137648] = { duration = 120, class = \"MONK\" }, -- Nimble Brew\n    \n    -- Brewmaster\n    \n    [115203] = { duration = 105, class = \"MONK\", specID = { 268 } }, -- Fortifying Brew\n    [115399] = { duration = 90, class = \"MONK\", specID = { 268 } }, -- Black Ox Brew\n    [116705] = { default = true, duration = 15, class = \"MONK\", specID = { 268, 269 }, interrupt = true }, -- Spear Hand Strike\n    [132578] = { duration = 180, class = \"MONK\", specID = { 268 } }, -- Invoke Niuzao, the Black Ox\n    [202162] = { duration = 45, class = \"MONK\", specID = { 268 } }, -- Guard\n    [202272] = { duration = 45, class = \"MONK\", specID = { 268 } }, -- Incendiary Brew\n    [202370] = { duration = 60, class = \"MONK\", specID = { 268 } }, -- Mighty Ox Kick\n    \n    -- Windwalker\n    \n    [101545] = { duration = 25, class = \"MONK\", specID = { 269 }, charges = 2 }, -- Flying Serpent Kick\n    [113656] = { duration = 24, class = \"MONK\", specID = { 269 } }, -- Fists of Fury\n    [115080] = { duration = 120, class = \"MONK\", specID = { 269 } }, -- Touch of Death\n    [152173] = { parent = 137639 }, -- Serenity\n    [115176] = { duration = 150, class = \"MONK\", specID = { 269 } }, -- Zen Meditation\n    [201325] = { parent = 115176, 180 }, -- Zen Meditation (Windwalker)\n    [115288] = { duration = 60, class = \"MONK\", specID = { 269 } }, -- Energizing Elixir\n    [122470] = { duration = 90, class = \"MONK\", specID = { 269 } }, -- Touch of Karma\n    [123904] = { duration = 120, class = \"MONK\", specID = { 269 } }, -- Invoke Xuen, the White Tiger\n    [137639] = { duration = 90, class = \"MONK\", specID = { 269 }, charges = 2 }, -- Storm, Earth, and Fire\n    [152175] = { duration = 24, class = \"MONK\", specID = { 269 } }, -- Whirling Dragon Punch\n    [201318] = { duration = 90, class = \"MONK\", specID = { 269 } }, -- Fortifying Elixir\n    \n    -- Mistweaver\n    \n    [115310] = { duration = 180, class = \"MONK\", specID = { 270 } }, -- Revival\n    [116680] = { duration = 30, class = \"MONK\", specID = { 270 } }, -- Thunder Focus Tea\n    [116849] = { duration = 120, class = \"MONK\", specID = { 270 } }, -- Life Cocoon\n    [197908] = { duration = 90, class = \"MONK\", specID = { 270 } }, -- Mana Tea\n    --[197945] = { duration = 20, class = \"MONK\", specID = { 270 }, charges = 2 }, -- Mistwalk\n    [198664] = { duration = 180, class = \"MONK\", specID = { 270 } }, -- Invoke Chi-Ji, the Red Crane\n    [198898] = { duration = 30, class = \"MONK\", specID = { 270 } }, -- Song of Chi-Ji\n    [216113] = { duration = 45, class = \"MONK\", specID = { 270 } }, -- Way of the Crane\n    \n}\n\nfor k, d in pairs(aura_env.spells) do\n    local _, _, icon = GetSpellInfo(k)\n    if icon then\n        d.icon = icon\n    end\nend\n\n\n",
					["do_custom"] = true,
				},
				["finish"] = {
					["do_glow"] = false,
					["glow_action"] = "show",
				},
			},
			["cooldown"] = true,
			["xOffset"] = 0,
			["uid"] = "6cVOOS8Fh8n",
			["frameStrata"] = 1,
			["cooldownTextDisabled"] = false,
			["auto"] = true,
			["tocversion"] = 80300,
			["id"] = "Spells nameplate",
			["width"] = 30,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["semver"] = "1.0.5",
			["config"] = {
			},
			["inverse"] = true,
			["cooldownEdge"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "interrupt",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.2.glow",
						}, -- [1]
						{
							["value"] = 21,
							["property"] = "sub.1.text_anchorYOffset",
						}, -- [2]
					},
				}, -- [1]
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["colorR"] = 1,
					["use_scale"] = true,
					["colorB"] = 1,
					["colorG"] = 1,
					["scalex"] = 5,
					["translateType"] = "shake",
					["use_translate"] = true,
					["rotate"] = 0,
					["colorA"] = 1,
					["type"] = "custom",
					["scaley"] = 5,
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    local prog\n    if(progress < 0.25) then\n        prog = progress * 4\n    elseif(progress < .75) then\n        prog = 2 - (progress * 4)\n    else\n        prog = (progress - 1) * 4\n    end\n    return startX + (prog * deltaX), startY + (prog * deltaY)\nend\n",
					["use_color"] = true,
					["alpha"] = 0,
					["scaleType"] = "straightScale",
					["y"] = 33,
					["colorType"] = "pulseColor",
					["x"] = 33,
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    local newProgress = ((math.sin(angle) + 1)/2);\n    return r1 + (newProgress * (r2 - r1)),\n         g1 + (newProgress * (g2 - g1)),\n         b1 + (newProgress * (b2 - b1)),\n         a1 + (newProgress * (a2 - a1))\nend\n",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["duration"] = "1",
				},
			},
		},
		["开地狱火"] = {
			["user_y"] = 0,
			["user_x"] = 0,
			["color"] = {
				1, -- [1]
				0.9058823529411765, -- [2]
				0.3372549019607843, -- [3]
				0.75, -- [4]
			},
			["yOffset"] = 311.1108703613281,
			["anchorPoint"] = "CENTER",
			["desaturateBackground"] = false,
			["sameTexture"] = true,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["track"] = "auto",
						["use_totemNamePattern"] = true,
						["duration"] = "1",
						["totemNamePattern"] = "地狱火",
						["use_unit"] = true,
						["remaining"] = "3",
						["names"] = {
						},
						["remaining_operator"] = ">=",
						["spellName"] = 1122,
						["debuffType"] = "HELPFUL",
						["use_remaining"] = true,
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["genericShowOn"] = "showOnReady",
						["use_genericShowOn"] = true,
						["event"] = "Action Usable",
						["use_exact_spellName"] = false,
						["realSpellName"] = "召唤地狱火",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["type"] = "status",
						["use_absorbMode"] = true,
						["unit"] = "player",
						["use_track"] = true,
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_totemNamePattern"] = true,
						["remaining_operator"] = ">",
						["totemNamePattern"] = "地狱火",
						["use_unit"] = true,
						["remaining"] = "8",
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["use_remaining"] = true,
						["unevent"] = "auto",
						["power"] = "1",
						["power_operator"] = ">=",
						["use_power"] = true,
						["event"] = "Power",
						["powertype"] = 7,
						["use_totemName"] = false,
						["subeventSuffix"] = "_CAST_START",
						["type"] = "status",
						["use_absorbMode"] = true,
						["duration"] = "1",
						["use_inverse"] = false,
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 40,
			["alpha"] = 1,
			["selfPoint"] = "CENTER",
			["rotation"] = 48,
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						0.05882352941176471, -- [2]
						0.06666666666666667, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_text_format_p_time_precision"] = 1,
					["text_shadowYOffset"] = 0,
					["text_visible"] = false,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "MONOCHROME|THICKOUTLINE",
					["text_anchorPoint"] = "CENTER",
					["text_text_format_p_format"] = "timed",
					["text_text_format_n_format"] = "none",
					["text_fontSize"] = 40,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [1]
			},
			["height"] = 97.210693359375,
			["rotate"] = true,
			["crop_y"] = 0.41,
			["conditions"] = {
			},
			["useAdjustededMax"] = false,
			["textureWrapMode"] = "CLAMP",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["preset"] = "pulse",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["startAngle"] = 0,
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["authorOptions"] = {
			},
			["mirror"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "texture",
			["uid"] = "7I6)o60x6)4",
			["blendMode"] = "BLEND",
			["fontSize"] = 12,
			["width"] = 72.2783203125,
			["slantMode"] = "INSIDE",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura88",
			["backgroundColor"] = {
				0.3058823529411765, -- [1]
				0.3176470588235294, -- [2]
				0.3019607843137255, -- [3]
				0.4000000357627869, -- [4]
			},
			["desaturateForeground"] = false,
			["foregroundColor"] = {
				1, -- [1]
				0.9921568627450981, -- [2]
				0.1372549019607843, -- [3]
				1, -- [4]
			},
			["compress"] = false,
			["id"] = "开地狱火",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura88",
			["frameStrata"] = 8,
			["anchorFrameType"] = "SCREEN",
			["parent"] = "毁灭ss",
			["config"] = {
			},
			["inverse"] = false,
			["xOffset"] = 10.85223388671875,
			["orientation"] = "VERTICAL",
			["crop_x"] = 0.44,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["backgroundOffset"] = 0,
		},
		["额"] = {
			["iconSource"] = -1,
			["xOffset"] = -77.77752685546875,
			["yOffset"] = 174.2227478027344,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_castType"] = false,
						["use_destFlags2"] = false,
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_unit"] = true,
						["remaining"] = "4",
						["remaining_operator"] = "<=",
						["use_sourceFlags3"] = false,
						["sourceUnit"] = "player",
						["spellName"] = 30283,
						["unit"] = "player",
						["type"] = "status",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_FAILED",
						["unevent"] = "auto",
						["use_remaining"] = true,
						["event"] = "Cooldown Progress (Spell)",
						["use_sourceFlags2"] = false,
						["realSpellName"] = "暗影之怒",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_sourceUnit"] = true,
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 26,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
			},
			["height"] = 25,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["parent"] = "SS通用",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "grow",
					["easeStrength"] = 3,
				},
			},
			["zoom"] = 0,
			["cooldownTextDisabled"] = false,
			["auto"] = true,
			["frameStrata"] = 9,
			["id"] = "额",
			["config"] = {
			},
			["alpha"] = 1,
			["width"] = 25,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "8bAlz)EZ2Nz",
			["inverse"] = false,
			["authorOptions"] = {
			},
			["conditions"] = {
			},
			["cooldown"] = true,
			["icon"] = true,
		},
		["开黑魂"] = {
			["user_y"] = 0,
			["user_x"] = 0,
			["authorOptions"] = {
			},
			["yOffset"] = 300.8884353637695,
			["anchorPoint"] = "CENTER",
			["desaturateBackground"] = false,
			["sameTexture"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["auranames"] = {
							"", -- [1]
						},
						["use_absorbMode"] = true,
						["subeventPrefix"] = "SPELL",
						["use_totemType"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "aura2",
						["matchesShowOn"] = "showOnMissing",
						["subeventSuffix"] = "_CAST_START",
						["ownOnly"] = true,
						["use_unit"] = true,
						["event"] = "Stance/Form/Aura",
						["totemType"] = 1,
						["duration"] = "1",
						["names"] = {
						},
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["namePattern_name"] = "黑暗灵魂",
						["useNamePattern"] = true,
						["unit"] = "player",
						["namePattern_operator"] = "find('%s')",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_totemNamePattern"] = true,
						["use_absorbMode"] = true,
						["totemNamePattern"] = "地狱火",
						["unit"] = "player",
						["remaining"] = "20",
						["debuffType"] = "HELPFUL",
						["use_remaining"] = true,
						["unevent"] = "auto",
						["event"] = "Totem",
						["use_inverse"] = false,
						["type"] = "status",
						["use_totemName"] = false,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["remaining_operator"] = "<=",
						["use_unit"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_totemNamePattern"] = true,
						["use_absorbMode"] = true,
						["totemNamePattern"] = "地狱火",
						["unit"] = "player",
						["remaining"] = "3",
						["spellName"] = 113858,
						["use_unit"] = true,
						["use_remaining"] = true,
						["subeventPrefix"] = "SPELL",
						["unevent"] = "auto",
						["duration"] = "1",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["use_exact_spellName"] = false,
						["realSpellName"] = "黑暗灵魂：动荡",
						["use_spellName"] = true,
						["type"] = "status",
						["remaining_operator"] = ">=",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [3]
				{
					["trigger"] = {
						["use_totemNamePattern"] = true,
						["use_inverse"] = false,
						["totemNamePattern"] = "地狱火",
						["unit"] = "player",
						["remaining"] = "8",
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["unevent"] = "auto",
						["event"] = "Totem",
						["use_unit"] = true,
						["remaining_operator"] = ">",
						["use_remaining"] = true,
						["subeventPrefix"] = "SPELL",
						["duration"] = "1",
						["use_absorbMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_totemName"] = false,
					},
					["untrigger"] = {
					},
				}, -- [4]
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["subRegions"] = {
				{
					["text_text_format_p_time_precision"] = 1,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						0.05882352941176471, -- [2]
						0.06666666666666667, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_shadowXOffset"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "MONOCHROME|THICKOUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = false,
					["text_anchorPoint"] = "CENTER",
					["text_text_format_p_format"] = "timed",
					["text_text_format_n_format"] = "none",
					["text_fontSize"] = 40,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [1]
			},
			["height"] = 62.54412078857422,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["parent"] = "毁灭ss",
			["useAdjustededMax"] = false,
			["textureWrapMode"] = "CLAMP",
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura52",
			["crop_x"] = 0.44,
			["color"] = {
			},
			["mirror"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "progresstexture",
			["xOffset"] = 41.9621467590332,
			["blendMode"] = "BLEND",
			["fontSize"] = 12,
			["config"] = {
			},
			["slantMode"] = "INSIDE",
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 8,
			["desaturateForeground"] = false,
			["foregroundColor"] = {
				1, -- [1]
				0.1843137254901961, -- [2]
				0.392156862745098, -- [3]
				1, -- [4]
			},
			["compress"] = false,
			["id"] = "开黑魂",
			["backgroundColor"] = {
				0.3058823529411765, -- [1]
				0.3176470588235294, -- [2]
				0.3019607843137255, -- [3]
				0.4000000357627869, -- [4]
			},
			["alpha"] = 1,
			["width"] = 50.94400787353516,
			["startAngle"] = 0,
			["uid"] = "yWJpKGV6mfS",
			["inverse"] = false,
			["crop_y"] = 0.41,
			["orientation"] = "VERTICAL",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["backgroundOffset"] = 0,
		},
		["Pet Dead Alert"] = {
			["outline"] = "OUTLINE",
			["iconSource"] = 0,
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 240,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["spellId"] = "Création d’un puits des âmes",
						["unit"] = "pet",
						["names"] = {
							"Puits des âmes", -- [1]
						},
						["duration"] = "20",
						["genericShowOn"] = "showOnActive",
						["subeventPrefix"] = "SPELL",
						["use_percenthealth"] = true,
						["group_countOperator"] = ">=",
						["debuffType"] = "HELPFUL",
						["spell"] = "Création d’un puits des âmes",
						["group_count"] = "0",
						["use_spellName"] = true,
						["use_HasPet"] = false,
						["use_mounted"] = false,
						["unevent"] = "auto",
						["type"] = "status",
						["use_health"] = false,
						["subeventSuffix"] = "_CAST_SUCCESS",
						["use_vehicle"] = false,
						["percenthealth"] = "1",
						["event"] = "Health",
						["spellName"] = "Création d’un puits des âmes",
						["namerealm"] = "Création d’un puits des âmes",
						["use_spellId"] = false,
						["spellIds"] = {
						},
						["use_unit"] = true,
						["use_spell"] = true,
						["use_alive"] = true,
						["percenthealth_operator"] = "<=",
						["use_absorbMode"] = true,
					},
					["untrigger"] = {
						["unit"] = "pet",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["use_vehicle"] = false,
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnActive",
						["subeventPrefix"] = "SPELL",
						["duration"] = "1",
						["unit"] = "player",
						["event"] = "Conditions",
						["use_unit"] = true,
						["use_alive"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_mounted"] = false,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_unit"] = true,
						["use_HasPet"] = false,
						["use_mounted"] = false,
						["unit"] = "pet",
						["classification"] = {
						},
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["use_vehicle"] = false,
						["use_genericShowOn"] = true,
						["event"] = "Conditions",
						["unevent"] = "auto",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 0,
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["use_alive"] = true,
						["use_track"] = true,
						["use_character"] = false,
					},
					["untrigger"] = {
						["unit"] = "pet",
					},
				}, -- [3]
				{
					["trigger"] = {
						["auranames"] = {
							"牺牲魔典", -- [1]
						},
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["subeventPrefix"] = "",
						["debuffType"] = "HELPFUL",
						["useName"] = true,
						["unevent"] = "auto",
						["unit"] = "player",
						["event"] = "Spell Known",
						["matchesShowOn"] = "showOnMissing",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["duration"] = "1",
						["spellName"] = 108503,
						["subeventSuffix"] = "",
						["type"] = "aura2",
						["use_track"] = true,
						["ownOnly"] = true,
					},
					["untrigger"] = {
					},
				}, -- [4]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n \n    return ( (t[1] and  t[2])  or  t[3])  and t[4]\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["justify"] = "LEFT",
			["desaturate"] = false,
			["displayText_format_p_time_dynamic"] = false,
			["font"] = "Friz Quadrata TT",
			["version"] = 1,
			["subRegions"] = {
			},
			["height"] = 55,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["load"] = {
				["ingroup"] = {
					["single"] = "raid",
					["multi"] = {
						["raid"] = true,
					},
				},
				["affixes"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
						["WARLOCK"] = true,
					},
				},
				["use_never"] = false,
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["talent3"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						true, -- [1]
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fixedWidth"] = 200,
			["displayText"] = "PET GONE！",
			["fontSize"] = 72,
			["shadowYOffset"] = -1,
			["automaticWidth"] = "Auto",
			["shadowXOffset"] = 1,
			["config"] = {
			},
			["parent"] = "SS通用",
			["width"] = 74,
			["regionType"] = "text",
			["frameStrata"] = 1,
			["wordWrap"] = "WordWrap",
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
				["main"] = {
					["colorR"] = 1,
					["scalex"] = 1.7,
					["alphaType"] = "alphaPulse",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "function(progress, start, delta)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return start + (((math.sin(angle) + 1)/2) * delta)\nend\n",
					["use_alpha"] = true,
					["type"] = "preset",
					["use_scale"] = true,
					["easeType"] = "none",
					["colorA"] = 1,
					["scaley"] = 1.5,
					["alpha"] = 0,
					["rotate"] = 0,
					["y"] = 0,
					["x"] = 0,
					["duration"] = "1",
					["preset"] = "alphaPulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["scaleType"] = "pulse",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\nend\n",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
			},
			["stickyDuration"] = false,
			["displayText_format_p_time_precision"] = 1,
			["cooldownTextDisabled"] = true,
			["url"] = "https://wago.io/UVsQmiaHX/1",
			["zoom"] = 0,
			["auto"] = false,
			["icon"] = true,
			["id"] = "Pet Dead Alert",
			["displayIcon"] = 930453,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["semver"] = "1.0.0",
			["uid"] = "n7rBcOvb5a4",
			["inverse"] = false,
			["xOffset"] = 1,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["cooldown"] = true,
			["color"] = {
				1, -- [1]
				0, -- [2]
				0.1686274509803922, -- [3]
				1, -- [4]
			},
		},
		["暗影系被反"] = {
			["iconSource"] = -1,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["yOffset"] = 96.88919067382812,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_castType"] = false,
						["use_destFlags2"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["subeventPrefix"] = "SPELL",
						["use_sourceFlags3"] = false,
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
						["use_track"] = true,
						["use_remaining"] = false,
						["use_genericShowOn"] = true,
						["subeventSuffix"] = "_CAST_FAILED",
						["type"] = "status",
						["spellName"] = 5782,
						["event"] = "Cooldown Progress (Spell)",
						["use_sourceFlags2"] = false,
						["realSpellName"] = "恐惧",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_sourceUnit"] = true,
						["unevent"] = "auto",
						["names"] = {
						},
						["sourceUnit"] = "player",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 26,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
			},
			["height"] = 25,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["parent"] = "SS通用",
			["icon"] = true,
			["xOffset"] = -15.11102294921875,
			["zoom"] = 0,
			["cooldownTextDisabled"] = false,
			["auto"] = true,
			["alpha"] = 1,
			["id"] = "暗影系被反",
			["uid"] = "JX(vtJPREYG",
			["frameStrata"] = 9,
			["width"] = 25,
			["anchorFrameType"] = "SCREEN",
			["config"] = {
			},
			["inverse"] = false,
			["authorOptions"] = {
			},
			["conditions"] = {
			},
			["cooldown"] = true,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "grow",
					["easeStrength"] = 3,
				},
			},
		},
		["战斗状态焦点"] = {
			["xOffset"] = -297.3336181640625,
			["yOffset"] = 316.4443054199219,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_showAbsorb"] = false,
						["use_incombat"] = true,
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_unit"] = true,
						["use_inCombat"] = true,
						["subeventPrefix"] = "SPELL",
						["percenthealth_operator"] = "<=",
						["names"] = {
						},
						["use_genericShowOn"] = true,
						["spellName"] = 0,
						["subeventSuffix"] = "_CAST_START",
						["type"] = "status",
						["use_health"] = false,
						["unevent"] = "auto",
						["health"] = "43",
						["percenthealth"] = "43",
						["event"] = "Unit Characteristics",
						["health_operator"] = "<=",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["duration"] = "1",
						["debuffType"] = "HELPFUL",
						["use_percenthealth"] = true,
						["use_track"] = true,
						["unit"] = "focus",
					},
					["untrigger"] = {
						["unit"] = "focus",
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 48.88936996459961,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "166984",
			["config"] = {
			},
			["frameStrata"] = 1,
			["width"] = 51.55559158325195,
			["id"] = "战斗状态焦点",
			["parent"] = "SS通用",
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["authorOptions"] = {
			},
			["uid"] = "vd9JA0mc4Tx",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["color"] = {
				1, -- [1]
				0, -- [2]
				0.0196078431372549, -- [3]
				0.75, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
			},
			["discrete_rotation"] = 0,
		},
		["群恐"] = {
			["iconSource"] = -1,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["yOffset"] = 129.7785339355469,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_castType"] = false,
						["use_destFlags2"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["subeventPrefix"] = "SPELL",
						["remaining"] = "5",
						["names"] = {
						},
						["use_sourceFlags3"] = false,
						["sourceUnit"] = "player",
						["debuffType"] = "HELPFUL",
						["use_unit"] = true,
						["type"] = "status",
						["use_genericShowOn"] = true,
						["subeventSuffix"] = "_CAST_FAILED",
						["unevent"] = "auto",
						["use_remaining"] = true,
						["event"] = "Cooldown Progress (Spell)",
						["use_sourceFlags2"] = false,
						["realSpellName"] = "恐惧嚎叫",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_sourceUnit"] = true,
						["remaining_operator"] = "<=",
						["unit"] = "player",
						["use_track"] = true,
						["spellName"] = 5484,
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "grow",
					["easeStrength"] = 3,
				},
			},
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 26,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
			},
			["height"] = 25,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["parent"] = "SS通用",
			["selfPoint"] = "CENTER",
			["xOffset"] = -92.44415283203125,
			["cooldownTextDisabled"] = false,
			["zoom"] = 0,
			["auto"] = true,
			["width"] = 25,
			["id"] = "群恐",
			["uid"] = "6qKyAagoxJ3",
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["authorOptions"] = {
			},
			["config"] = {
			},
			["inverse"] = false,
			["frameStrata"] = 9,
			["conditions"] = {
			},
			["cooldown"] = true,
			["icon"] = true,
		},
		["0Plater Interrupt and Reflect"] = {
			["grow"] = "LEFT",
			["controlledChildren"] = {
				"Spells nameplate", -- [1]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["groupIcon"] = 132349,
			["gridType"] = "DR",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["space"] = 2,
			["url"] = "https://wago.io/OmniBudsNameplateRetail/6",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["debuffType"] = "HELPFUL",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 5,
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["align"] = "CENTER",
			["gridWidth"] = 5,
			["stagger"] = 0,
			["uid"] = "CdndF0E442n",
			["version"] = 6,
			["subRegions"] = {
			},
			["radius"] = 200,
			["arcLength"] = 360,
			["load"] = {
				["use_class"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["selfPoint"] = "RIGHT",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["fullCircle"] = true,
			["animate"] = false,
			["yOffset"] = 0,
			["scale"] = 1,
			["anchorPoint"] = "LEFT",
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["anchorPerUnit"] = "NAMEPLATE",
			["borderInset"] = 1,
			["limit"] = 5,
			["constantFactor"] = "RADIUS",
			["xOffset"] = -3,
			["borderOffset"] = 4,
			["semver"] = "1.0.5",
			["tocversion"] = 80300,
			["id"] = "0Plater Interrupt and Reflect",
			["useAnchorPerUnit"] = true,
			["frameStrata"] = 5,
			["anchorFrameType"] = "SCREEN",
			["sort"] = "none",
			["config"] = {
			},
			["rowSpace"] = 15,
			["rotation"] = 0,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["useLimit"] = false,
		},
		["SpellsCast WARING"] = {
			["iconSource"] = -1,
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["customText"] = "function()\n    if aura_env.state.class then\n        return RAID_CLASS_COLORS[aura_env.state.class]:WrapTextInColorCode(aura_env.state.name)\n    else\n        return aura_env.state.name\n    end\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["url"] = "https://wago.io/OmniBudsNameplateRetail/6",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "2",
						["names"] = {
						},
						["destUnit"] = "target",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["unevent"] = "timed",
						["type"] = "custom",
						["use_destNpcId"] = false,
						["subeventSuffix"] = "_CAST_SUCCESS",
						["use_unit"] = true,
						["unit"] = "player",
						["event"] = "Combat Log",
						["events"] = "CLEU:SPELL_CAST_SUCCESS CLEU:SPELL_CAST_START NAME_PLATE_UNIT_ADDED NAME_PLATE_UNIT_REMOVED",
						["spellIds"] = {
						},
						["use_spellName"] = true,
						["custom"] = "\n\n\nfunction(states, e, ...)\n    if e == \"NAME_PLATE_UNIT_ADDED\" then\n        local unit = ...\n        if unit then\n            local guid = UnitGUID(unit)\n            aura_env.nameplates[unit] = guid\n            aura_env.guids[guid] = unit\n            local now = GetTime()\n            for k, state in pairs(aura_env.temp) do\n                if state.guid == guid\n                and state.expirationTime > now\n                then\n                    state.unit = unit\n                    state.show = true\n                    state.changed = true\n                    states[k] = state                    \n                end\n                if state.expirationTime < now then\n                    aura_env.temp[k] = nil \n                end\n            end\n        end\n    elseif e == \"NAME_PLATE_UNIT_REMOVED\" then\n        local unit = ...\n        if unit then\n            local guid = UnitGUID(unit)\n            if guid then\n                aura_env.nameplates[unit] = nil\n                aura_env.guids[guid] = nil\n                for k, state in pairs(states) do\n                    if state.guid == guid then\n                        aura_env.temp[k] = state\n                        state.show = false\n                        state.changed = true\n                    end\n                end\n            end\n        end\n    elseif e == \"COMBAT_LOG_EVENT_UNFILTERED\" then\n        local _, subevent, _, guid, name, flags, _, _, _, _, _, spellId = ...\n        local spell\n        \n        if (subevent == \"SPELL_CAST_START\") and (guid == UnitGUID(\"player\")) then\n            --print(\"im casting\"..name)\n            local now = GetTime()\n            --print(\"im casting\"..now)\n            \n            local count = 0\n            \n            local platerCount = 0\n            --_G.dangerLockSpells = {}\n            \n            \n            \n            for i = 1, 40 do\n                local unit = \"nameplate\"..i \n                if UnitExists(unit) then \n                    \n                    local _guid = UnitGUID(unit)\n                    local plateFrame = C_NamePlate.GetNamePlateForUnit (unit, issecure())\n                    \n                    \n                    local utar = unit.. \"target\"\n                    local ufoucs = unit..\"focus\"\n                    \n                    \n                    \n                    \n                    states[_guid..\"lock\"]  = nil\n                    \n                    local isTarMe = UnitGUID(unit) == UnitGUID(\"player\")\n                    \n                    \n                    if UnitPlayerControlled(unit)\n                    and  (Plater.GetUnitType (plateFrame) == \"normal\" )\n                    --  and UnitCanAttack(\"player\", unit) \n                    and aura_env.hasLockSpell(_guid)\n                    and WeakAuras.CheckRange(unit, 40, \"<=\")\n                    then\n                        local playerClass, englishClass = UnitClass(unit) \n                        \n                        local rPerc, gPerc, bPerc, argbHex = GetClassColor(englishClass)\n                        \n                        local danger = false\n                        for sid,spell_ in pairs(aura_env.spells) do \n                            \n                            local key_ =  _guid..sid\n                            local statesCell = states[key_]  \n                            \n                            \n                            \n                            \n                            if statesCell  then\n                                local leftTime = statesCell.expirationTime - now\n                                \n                                \n                                if leftTime < 1.3 then\n                                    danger = true\n                                end\n                            else \n                                \n                                if (englishClass == spell_.class) then  \n                                    danger = true\n                                end \n                            end\n                            \n                            if danger then \n                                \n                                if WeakAuras.CheckRange(unit, spell_.range, \"<=\") then\n                                    danger = true \n                                    break\n                                else\n                                    danger = false\n                                end \n                            end  \n                            \n                        end\n                        if danger then \n                            count = count + 1\n                            \n                            --table.insert(_G.dangerLockSpells,englishClass)\n                            --print(englishClass..\" can LOCK ME\")\n                            \n                            \n                            states[_guid..\"lock\"]  = {\n                                show = true,\n                                changed = true,\n                                duration = 1,\n                                expirationTime = GetTime() + 1,\n                                icon = aura_env.classIcons[englishClass],\n                                progressType = \"static\",\n                                autoHide = true,\n                                --guid = _guid,\n                                --unit = aura_env.guids[guid],\n                                --range = spell.range,\n                                --interrupt = spell.interrupt\n                            }   \n                            \n                            if  isTarMe  then\n                                states[_guid..\"lock\"].progressType = nil\n                            end\n                            \n                            \n                            \n                            --MikSBT.DisplayMessage(\"X\",  \"KethoCombatLog\", true, rPerc*255, gPerc*255, bPerc*255, 73,nil,nil,aura_env.classIcons[englishClass])\n                        end\n                        \n                        platerCount = platerCount +1 \n                        \n                    end\n                end\n            end\n            \n            \n            --print(count..\" Man can LOCK ME\")\n            \n            if count == 0 then \n                if platerCount > 0 then  \n                    -- MikSBT.DisplayMessage(\"FREE CASTING！\",  \"KethoCombatLog\", false, 68, 230, 155, 33,nil,nil)\n                end\n            else\n                --  MikSBT.DisplayMessage(count..\"Man CAN LOCK ME\",  MikSBT.DISPLAYTYPE_NOTIFICATION, true, 233, 49, 49, 33)\n            end\n            \n            \n        end\n        \n        \n        \n        \n        if flags\n        and guid\n        and bit.band(flags, COMBATLOG_OBJECT_CONTROL_PLAYER) > 0\n        and bit.band(flags, COMBATLOG_OBJECT_REACTION_HOSTILE) > 0\n        then\n            spell = spellId and aura_env.spells[spellId]\n            if spell and spell.parent  then\n                spell = aura_env.spells[spell.parent]\n            end\n        end\n        \n        if spell and not  spell.interrupt then\n            if spell.duration and type(spell.duration) == \"number\" and spell.duration > 0 then\n                local key = guid..spellId\n                --if not states[key] then\n                local data = {\n                    show = true,\n                    changed = true,\n                    duration = spell.duration,\n                    expirationTime = GetTime() + spell.duration,\n                    icon = spell.icon,\n                    progressType = \"timed\",\n                    autoHide = true,\n                    guid = guid,\n                    unit = aura_env.guids[guid],\n                    range = spell.range,\n                    interrupt = spell.interrupt\n                }\n                if aura_env.guids[guid] then\n                    states[key] = data\n                else\n                    aura_env.temp[key] = data\n                end\n                --end\n            end\n        end\n    end\n    return true\nend",
						["custom_type"] = "stateupdate",
						["check"] = "event",
						["use_destUnit"] = true,
						["spellName"] = "Battle Stance",
						["customVariables"] = "{ interrupt = \"bool\" }",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_castType"] = false,
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Cast",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["genericShowOn"] = "showOnCooldown",
						["use_genericShowOn"] = true,
						["use_unit"] = true,
						["use_track"] = true,
						["spellName"] = 0,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 6,
			["subRegions"] = {
				{
					["text_text_format_p_time_precision"] = 0,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						0.8980392156862745, -- [1]
						0.9921568627450981, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_shadowXOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["text_visible"] = false,
					["text_text_format_p_format"] = "timed",
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						0.596078431372549, -- [2]
						0.09803921568627451, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = true,
					["glowType"] = "Pixel",
					["glowLength"] = 10,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 33,
			["load"] = {
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_encounter"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorMode"] = true,
			["cooldownTextDisabled"] = false,
			["cooldownEdge"] = true,
			["regionType"] = "icon",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
					["do_glow"] = false,
					["glow_action"] = "show",
				},
				["init"] = {
					["custom"] = "local e = aura_env\ne.myGUID = UnitGUID(\"player\")\nif e.config.debug_mode then print(\"INIT START\") end\n\n-- For debugging\n\ne.dump = function(t)\n    local s = '{\\n'\n    for k,v in pairs(t) do\n        s = s..tostring(k)..': '..tostring(v)..',\\n'\n    end\n    print(s..'}')\nend\n\naura_env.spells = {}\naura_env.nameplates = {}\naura_env.guids = {}\naura_env.temp = {}\n\naura_env.healerSpecNoLock = {\n    [105] = true, -->  druid resto\n    [270] = true, --> monk mw\n    [65] = true, --> paladin holy\n    [256] = true,  --> priest disc\n    [257] = true,  --> priest holy\n    --[264] = true, --> shaman resto\n}\n\nlocal uaID = 316099\naura_env.tracked_dots = {\n    [980]    = true, -- Agony\n    [63106]  = true, -- Siphon Life\n    [146739] = true, -- Corruption\n    [uaID]   = true, -- UA\n    [342938]   = true, -- UA\n    [278350] = true, -- Vile Taint\n    [205179] = true, -- Phantom Singularity\n    [325640] = true, -- Soul Rot\n    [312321] = true, -- Scouring Tithe\n    [321792] = true, -- Impending Catastrophe\n}\n\n\ne.myUnitDebuffCount = function (uId)\n    local dotsCount = 0\n    --print(\"uid\",uId)\n    for i = 1, 10 do\n        local spellName, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, nameplateShowPersonal, spellId, canApplyAura, isBossDebuff, nameplateShowAll, timeMod, value1, value2, value3 = UnitDebuff(uId, i)\n        \n        \n        \n        if spellName and  e.tracked_dots[spellId] and (UnitGUID(unitCaster)==e.myGUID or unitCaster==e.myGUID) then  \n            \n            dotsCount = dotsCount + 1 \n            \n            --print(\"dotsCount\",dotsCount)\n        end \n        --if spellName then print(\"spellName, unitCaster,spellId\",spellName, unitCaster,spellId) end \n        \n    end\n    \n    return dotsCount\nend\n\n\naura_env.hasLockSpell = function(guid)\n    local Details = Details \n    \n    if (Details and Details.realversion >= 134) then\n        local spec = Details:GetSpecByGUID (guid)\n        if (spec and aura_env.healerSpecNoLock [spec]) then\n            return  false\n        end\n    end\n    \n    return  true\nend\n\n\naura_env.classIcons = {\n    [\"DEATHKNIGHT\"] = 625998,\n    [\"DEMONHUNTER\"] = 1260827,\n    [\"PRIEST\"] = 626004,\n    [\"PALADIN\"] = 626003,\n    [\"DRUID\"] = 625999,\n    \n    [\"WARRIOR\"] = 626008,\n    \n    \n    [\"WARLOCK\"] =626007,\n    \n    [\"SHAMAN\"] = 626006,\n    [\"HUNTER\"] = 626000,\n    [\"MAGE\"] = 626001,\n    \n    [\"ROGUE\"] = 626005,\n    [\"MONK\"] = 610018,\n}\naura_env.spells = {\n    \n    -- Death Knight\n    \n    [47528] = { default = true, duration = 15, class = \"DEATHKNIGHT\", interrupt = true,range=15 }, -- Mind Freeze \n    \n    -- Demon Hunter\n    \n    \n    [183752] = { default = true, duration = 15, class = \"DEMONHUNTER\", interrupt = true,range=5 }, -- Disrupt\n    \n    \n    -- Shadow\n    \n    \n    [15487] = { duration = 45, class = \"PRIEST\", specID = { 258 }, interrupt = true,range=20 }, -- Silence\n    \n    \n    [96231] = { default = true, duration = 15, class = \"PALADIN\", specID = { 66, 70 }, interrupt = true,range=5 }, -- Rebuke\n    \n    \n    [78675] = { default = true, duration = 60, class = \"DRUID\", specID = { 102 }, interrupt = true ,range=40 }, -- Solar Beam\n    \n    [106839] = { default = true, duration = 15, class = \"DRUID\", specID = { 103, 104 }, interrupt = true,range=13 }, -- Skull Bash\n    \n    [6552] = { default = true, duration = 15, class = \"WARRIOR\", interrupt = true,range=5 }, -- Pummel\n    \n    \n    [119910] = { default = true, duration = 24, class = \"WARLOCK\", interrupt = true,range=40 }, -- Spell Lock (Command Demon)\n    \n    \n    [57994] = { default = true, duration = 12, class = \"SHAMAN\", interrupt = true,range=30 }, -- Wind Shear\n    \n    [147362] = { default = true, duration = 24, class = \"HUNTER\", specID = { 253, 254 }, interrupt = true,range=40 }, -- Counter Shot\n    \n    [187707] = { default = true, duration = 15, class = \"HUNTER\", specID = { 255 }, interrupt = true,range=40 }, -- Muzzle\n    \n    [2139] = { default = true, duration = 24, class = \"MAGE\", interrupt = true, range=40 }, -- Counterspell\n    \n    \n    [1766] = { default = true, duration = 15, class = \"ROGUE\", interrupt = true ,range=5}, -- Kick\n    \n    [116705] = { default = true, duration = 15, class = \"MONK\", specID = { 268, 269 }, interrupt = true ,range=5},  -- Spear Hand Strike\n    \n    \n}\n\nfor k, d in pairs(aura_env.spells) do\n    local _, _, icon = GetSpellInfo(k)\n    if icon then\n        d.icon = icon\n    end\nend\n\n\n",
					["do_custom"] = true,
				},
			},
			["authorOptions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["scalex"] = 3,
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = true,
					["duration"] = ".53",
					["type"] = "custom",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["scaley"] = 3,
					["alpha"] = 0,
					["easeStrength"] = 3,
					["y"] = 388,
					["x"] = -10,
					["use_scale"] = true,
					["translateType"] = "straightTranslate",
					["colorA"] = 1,
					["rotate"] = 0,
					["scaleType"] = "straightScale",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "alphaPulse",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["colorR"] = 1,
					["scalex"] = 5,
					["colorA"] = 1,
					["colorG"] = 1,
					["duration"] = "1",
					["duration_type"] = "seconds",
					["use_translate"] = true,
					["easeStrength"] = 3,
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["type"] = "none",
					["use_color"] = true,
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    local prog\n    if(progress < 0.25) then\n        prog = progress * 4\n    elseif(progress < .75) then\n        prog = 2 - (progress * 4)\n    else\n        prog = (progress - 1) * 4\n    end\n    return startX + (prog * deltaX), startY + (prog * deltaY)\nend\n",
					["scaley"] = 5,
					["alpha"] = 0,
					["x"] = 33,
					["y"] = 33,
					["colorType"] = "pulseColor",
					["scaleType"] = "straightScale",
					["translateType"] = "shake",
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    local newProgress = ((math.sin(angle) + 1)/2);\n    return r1 + (newProgress * (r2 - r1)),\n         g1 + (newProgress * (g2 - g1)),\n         b1 + (newProgress * (b2 - b1)),\n         a1 + (newProgress * (a2 - a1))\nend\n",
					["rotate"] = 0,
					["use_scale"] = true,
					["colorB"] = 1,
				},
			},
			["config"] = {
			},
			["semver"] = "1.0.5",
			["zoom"] = 0,
			["auto"] = true,
			["tocversion"] = 80300,
			["id"] = "SpellsCast WARING",
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 1,
			["width"] = 33,
			["alpha"] = 1,
			["uid"] = "b(JUMzLJ0TD",
			["inverse"] = true,
			["parent"] = "0SPellLock G CASTING WARN",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "interrupt",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.2.glow",
						}, -- [1]
						{
							["value"] = 21,
							["property"] = "sub.1.text_anchorYOffset",
						}, -- [2]
					},
				}, -- [1]
			},
			["cooldown"] = true,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
		},
		["补诅咒"] = {
			["parent"] = "SS通用",
			["yOffset"] = -10,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["rem"] = "2",
						["useRem"] = true,
						["subeventSuffix"] = "_CAST_START",
						["names"] = {
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "target",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["matchesShowOn"] = "showOnMissing",
						["remOperator"] = "<=",
						["auranames"] = {
							"虚弱诅咒", -- [1]
							"语言诅咒", -- [2]
							"疲劳诅咒", -- [3]
						},
						["useName"] = true,
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["rem"] = "5",
						["debuffType"] = "HARMFUL",
						["subeventSuffix"] = "_CAST_START",
						["useName"] = true,
						["ownOnly"] = true,
						["event"] = "Health",
						["names"] = {
						},
						["auranames"] = {
							"虚弱诅咒", -- [1]
							"语言诅咒", -- [2]
							"疲劳诅咒", -- [3]
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["matchesShowOn"] = "showOnActive",
						["remOperator"] = "<=",
						["unit"] = "target",
						["subeventPrefix"] = "SPELL",
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "function (t)\n    return (t[1] or  t[2])  and t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 304.2225036621094,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						[3] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "656728",
			["config"] = {
			},
			["rotation"] = 177,
			["width"] = 214.4442443847656,
			["id"] = "补诅咒",
			["xOffset"] = 150,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				0.8745098039215686, -- [1]
				0.9568627450980391, -- [2]
				1, -- [3]
				0.75, -- [4]
			},
			["uid"] = "V0kL5e62wb)",
			["authorOptions"] = {
			},
			["selfPoint"] = "CENTER",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["frameStrata"] = 9,
		},
		["死亡之剑"] = {
			["parent"] = "痛苦ss",
			["yOffset"] = 177.5556030273438,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["debuffClass"] = {
							["curse"] = true,
							["magic"] = true,
							["disease"] = true,
						},
						["useStacks"] = false,
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["useHostility"] = true,
						["use_unit"] = true,
						["useMatch_count"] = false,
						["stacks"] = "1",
						["unit"] = "target",
						["group_count"] = "0",
						["match_count"] = "3",
						["debuffType"] = "HARMFUL",
						["type"] = "aura2",
						["group_countOperator"] = ">",
						["subeventSuffix"] = "_CAST_START",
						["useName"] = true,
						["stacksOperator"] = ">=",
						["unevent"] = "auto",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["event"] = "Health",
						["ownOnly"] = true,
						["use_debuffClass"] = false,
						["match_countOperator"] = ">=",
						["spellIds"] = {
						},
						["rem"] = "11",
						["remOperator"] = ">=",
						["duration"] = "1",
						["names"] = {
						},
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["useMatch_count"] = false,
						["useStacks"] = false,
						["auranames"] = {
							"痛楚", -- [1]
						},
						["rem"] = "13",
						["use_absorbMode"] = true,
						["useHostility"] = true,
						["use_unit"] = true,
						["duration"] = "1",
						["stacks"] = "1",
						["unit"] = "target",
						["group_count"] = "0",
						["match_count"] = "3",
						["group_countOperator"] = ">",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
						["match_countOperator"] = ">=",
						["type"] = "aura2",
						["stacksOperator"] = ">=",
						["subeventSuffix"] = "_CAST_START",
						["use_debuffClass"] = false,
						["ownOnly"] = true,
						["event"] = "Health",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["unevent"] = "auto",
						["spellIds"] = {
						},
						["debuffClass"] = {
							["curse"] = true,
							["magic"] = true,
							["disease"] = true,
						},
						["remOperator"] = ">=",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["useMatch_count"] = true,
						["useStacks"] = false,
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["rem"] = "12",
						["use_absorbMode"] = true,
						["useHostility"] = true,
						["use_unit"] = true,
						["duration"] = "1",
						["stacks"] = "1",
						["unit"] = "target",
						["group_count"] = "0",
						["match_count"] = "3",
						["group_countOperator"] = ">",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
						["match_countOperator"] = ">=",
						["type"] = "aura2",
						["stacksOperator"] = ">=",
						["subeventSuffix"] = "_CAST_START",
						["use_debuffClass"] = false,
						["ownOnly"] = true,
						["event"] = "Health",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["unevent"] = "auto",
						["spellIds"] = {
						},
						["debuffClass"] = {
							["curse"] = true,
							["magic"] = true,
							["disease"] = true,
						},
						["remOperator"] = ">=",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Action Usable",
						["unit"] = "player",
						["realSpellName"] = 264106,
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["genericShowOn"] = "showOnReady",
						["use_genericShowOn"] = true,
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["spellName"] = 264106,
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [4]
				{
					["trigger"] = {
						["debuffClass"] = {
							["curse"] = true,
							["magic"] = true,
							["disease"] = true,
						},
						["useStacks"] = false,
						["auranames"] = {
							"灵魂腐化", -- [1]
						},
						["names"] = {
						},
						["use_absorbMode"] = true,
						["useHostility"] = true,
						["subeventPrefix"] = "SPELL",
						["use_unit"] = true,
						["stacks"] = "1",
						["useMatch_count"] = true,
						["group_count"] = "0",
						["match_count"] = "3",
						["rem"] = "5",
						["type"] = "aura2",
						["group_countOperator"] = ">",
						["unevent"] = "auto",
						["useName"] = true,
						["stacksOperator"] = ">=",
						["match_countOperator"] = ">=",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["event"] = "Health",
						["ownOnly"] = true,
						["use_debuffClass"] = false,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["debuffType"] = "HARMFUL",
						["remOperator"] = ">=",
						["unit"] = "target",
						["duration"] = "1",
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["useMatch_count"] = true,
						["useStacks"] = false,
						["auranames"] = {
							"诡异魅影", -- [1]
						},
						["unit"] = "target",
						["duration"] = "1",
						["useHostility"] = true,
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["stacks"] = "1",
						["use_absorbMode"] = true,
						["group_count"] = "0",
						["match_count"] = "3",
						["debuffClass"] = {
							["curse"] = true,
							["magic"] = true,
							["disease"] = true,
						},
						["useName"] = true,
						["debuffType"] = "HARMFUL",
						["subeventSuffix"] = "_CAST_START",
						["type"] = "aura2",
						["stacksOperator"] = ">=",
						["unevent"] = "auto",
						["use_debuffClass"] = false,
						["ownOnly"] = true,
						["event"] = "Health",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["match_countOperator"] = ">=",
						["spellIds"] = {
						},
						["group_countOperator"] = ">",
						["remOperator"] = ">=",
						["rem"] = "9",
						["use_unit"] = true,
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [6]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "fade",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = true,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 333.0003662109375,
			["rotate"] = true,
			["load"] = {
				["use_spec"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "1029140",
			["xOffset"] = -118.8890533447266,
			["selfPoint"] = "CENTER",
			["alpha"] = 0.96,
			["id"] = "死亡之剑",
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 5,
			["width"] = 244.2220611572266,
			["authorOptions"] = {
			},
			["uid"] = "ilg8cIAXs6N",
			["config"] = {
			},
			["color"] = {
				0.9686274509803922, -- [1]
				0.9921568627450981, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 6,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0.6235294117647059, -- [1]
								0.1725490196078431, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 5,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0.1058823529411765, -- [1]
								0.01568627450980392, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [2]
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["补暗影之拥"] = {
			["parent"] = "痛苦ss",
			["yOffset"] = 260,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
					["do_custom"] = false,
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["rem"] = "2",
						["debuffType"] = "HARMFUL",
						["subeventSuffix"] = "_CAST_START",
						["useName"] = true,
						["ownOnly"] = true,
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["auranames"] = {
							"暗影之拥", -- [1]
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["matchesShowOn"] = "showOnMissing",
						["remOperator"] = "<=",
						["unit"] = "target",
						["names"] = {
						},
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["rem"] = "6",
						["auranames"] = {
							"暗影之拥", -- [1]
						},
						["totalOperator"] = ">",
						["matchesShowOn"] = "showOnActive",
						["names"] = {
						},
						["debuffType"] = "HARMFUL",
						["total"] = "10",
						["subeventSuffix"] = "_CAST_START",
						["useTotal"] = false,
						["event"] = "Health",
						["type"] = "aura2",
						["unit"] = "target",
						["spellIds"] = {
						},
						["useName"] = true,
						["remOperator"] = "<=",
						["ownOnly"] = true,
						["subeventPrefix"] = "SPELL",
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "function (t)\n    return (t[1] or  t[2])  and t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 94,
			["rotate"] = true,
			["load"] = {
				["use_size"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						[3] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["size"] = {
					["multi"] = {
						["flexible"] = true,
						["party"] = true,
						["scenario"] = true,
						["twenty"] = true,
						["ten"] = true,
						["twentyfive"] = true,
						["fortyman"] = true,
						["none"] = true,
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = true,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "Interface\\PVPFrame\\PVP-Banner-Emblem-5",
			["config"] = {
			},
			["discrete_rotation"] = 0,
			["alpha"] = 0.71,
			["id"] = "补暗影之拥",
			["xOffset"] = 140,
			["frameStrata"] = 9,
			["width"] = 59,
			["authorOptions"] = {
			},
			["uid"] = "MlWB9oAmwH4",
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				0.3843137254901961, -- [1]
				0.7450980392156863, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["duration"] = ".33",
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = true,
					["duration_type"] = "seconds",
					["scalex"] = 2.7,
					["type"] = "custom",
					["easeStrength"] = 3,
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["preset"] = "slidetop",
					["alpha"] = 0,
					["use_scale"] = true,
					["y"] = -95,
					["x"] = -75,
					["scaley"] = 2.7,
					["colorA"] = 1,
					["translateType"] = "straightTranslate",
					["rotate"] = 0,
					["scaleType"] = "straightScale",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
		},
		["爆燃"] = {
			["iconSource"] = -1,
			["xOffset"] = -55.110595703125,
			["yOffset"] = 239.1112365722656,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["useName"] = true,
						["auranames"] = {
							"爆燃冲刺", -- [1]
						},
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["type"] = "aura2",
						["names"] = {
						},
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowXOffset"] = 0,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glow"] = false,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 64,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["authorOptions"] = {
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["cooldown"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["zoom"] = 0,
			["cooldownTextDisabled"] = false,
			["frameStrata"] = 1,
			["id"] = "爆燃",
			["config"] = {
			},
			["alpha"] = 1,
			["width"] = 64,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "rTTpGLm2cpe",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
			},
			["parent"] = "SS通用",
		},
		["PVP无常提醒非jjc"] = {
			["parent"] = "痛苦ss",
			["yOffset"] = 287.3332672119141,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["rem"] = "5",
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["matchesShowOn"] = "showOnActive",
						["useHostility"] = false,
						["subeventPrefix"] = "SPELL",
						["match_count"] = "3",
						["debuffType"] = "HARMFUL",
						["showClones"] = false,
						["useName"] = true,
						["group_count"] = "3",
						["subeventSuffix"] = "_CAST_START",
						["group_countOperator"] = ">=",
						["useGroup_count"] = false,
						["event"] = "Health",
						["match_countOperator"] = "<",
						["useMatch_count"] = true,
						["type"] = "aura2",
						["spellIds"] = {
						},
						["ownOnly"] = true,
						["remOperator"] = "<=",
						["names"] = {
						},
						["unit"] = "nameplate",
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["useMatch_count"] = false,
						["useGroup_count"] = true,
						["matchesShowOn"] = "showOnActive",
						["unit"] = "nameplate",
						["subeventPrefix"] = "SPELL",
						["ownOnly"] = true,
						["use_absorbMode"] = true,
						["match_count"] = "3",
						["group_count"] = "3",
						["names"] = {
						},
						["rem"] = "5",
						["group_countOperator"] = "<",
						["duration"] = "1",
						["useName"] = true,
						["unevent"] = "auto",
						["match_countOperator"] = "<=",
						["debuffType"] = "HARMFUL",
						["type"] = "status",
						["event"] = "PvP Talent Selected",
						["talent"] = {
							["single"] = 1,
						},
						["subeventSuffix"] = "_CAST_START",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_talent"] = true,
						["remOperator"] = "<=",
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["use_unit"] = true,
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["useMatch_count"] = true,
						["useGroup_count"] = false,
						["matchesShowOn"] = "showOnActive",
						["useHostility"] = false,
						["subeventPrefix"] = "SPELL",
						["group_count"] = "3",
						["debuffType"] = "HARMFUL",
						["useName"] = true,
						["match_count"] = "3",
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "nameplate",
						["names"] = {
						},
						["event"] = "Health",
						["auranames"] = {
							"痛楚", -- [1]
						},
						["ownOnly"] = true,
						["type"] = "aura2",
						["spellIds"] = {
						},
						["rem"] = "5",
						["remOperator"] = "<=",
						["match_countOperator"] = "<",
						["group_countOperator"] = ">=",
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["useMatch_count"] = true,
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["matchesShowOn"] = "showOnActive",
						["useHostility"] = false,
						["unit"] = "nameplate",
						["match_count"] = "3",
						["debuffType"] = "HARMFUL",
						["useName"] = true,
						["group_count"] = "3",
						["subeventSuffix"] = "_CAST_START",
						["group_countOperator"] = ">=",
						["match_countOperator"] = "<",
						["event"] = "Health",
						["useGroup_count"] = false,
						["rem"] = "5",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["ownOnly"] = true,
						["remOperator"] = "<=",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["useGroup_count"] = true,
						["duration"] = "1",
						["useHostility"] = true,
						["unit"] = "nameplate",
						["genericShowOn"] = "showOnCooldown",
						["use_genericShowOn"] = true,
						["group_count"] = "2",
						["spellName"] = 0,
						["check"] = "update",
						["debuffType"] = "HELPFUL",
						["group_countOperator"] = ">=",
						["type"] = "custom",
						["custom_type"] = "status",
						["unevent"] = "auto",
						["subeventPrefix"] = "",
						["hostility"] = "hostile",
						["event"] = "Cooldown Progress (Spell)",
						["use_eventtype"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["custom"] = "function()\n    local count = 0\n    for i = 1, 40 do\n        local unit = \"nameplate\"..i\n        local plateFrame = C_NamePlate.GetNamePlateForUnit (unit, issecure())\n        if UnitCanAttack(\"player\", unit)\n        and WeakAuras.CheckRange(unit, 40, \"<=\")\n        then\n            if (Plater.GetUnitType (plateFrame) == \"normal\" )\n            and ( UnitPlayerControlled(unit) or ((not UnitPlayerControlled(unit)) and UnitAffectingCombat(unit) ))  then \n                \n                count = count + 1\n            end \n            \n        end\n    end\n    \n    return count >=3;\n    \nend",
						["subeventSuffix"] = "",
						["namePattern_name"] = ".",
						["useNamePattern"] = true,
						["use_track"] = true,
						["namePattern_operator"] = "match('%s')",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["instance_size"] = {
						},
						["type"] = "status",
						["spellName"] = 0,
						["unevent"] = "auto",
						["use_pvpflagged"] = true,
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["event"] = "Conditions",
						["subeventPrefix"] = "",
						["use_genericShowOn"] = true,
						["subeventSuffix"] = "",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["useGroup_count"] = true,
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "arena3",
						["specificUnit"] = "arena3",
						["use_genericShowOn"] = true,
						["debuffType"] = "HELPFUL",
						["health_operator"] = ">",
						["type"] = "status",
						["use_health"] = true,
						["unevent"] = "auto",
						["use_specific_unit"] = true,
						["use_absorbMode"] = true,
						["event"] = "Health",
						["use_unit"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["health"] = "1",
						["spellName"] = 0,
						["namePattern_name"] = ".",
						["useNamePattern"] = true,
						["use_track"] = true,
						["namePattern_operator"] = "match('%s')",
					},
					["untrigger"] = {
						["use_specific_unit"] = true,
						["unit"] = "arena3",
					},
				}, -- [7]
				{
					["trigger"] = {
						["instance_size"] = {
							["multi"] = {
								["arena"] = true,
							},
						},
						["type"] = "status",
						["unevent"] = "auto",
						["spellName"] = 0,
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["event"] = "Conditions",
						["use_instance_size"] = false,
						["ingroup"] = {
						},
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [8]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n    return ((t[1] and  t[2] ) or t[3] or t[4]) and t[5] and  t[6] and not t[8]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = true,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 296,
			["rotate"] = true,
			["load"] = {
				["ingroup"] = {
					["single"] = "group",
					["multi"] = {
						["group"] = true,
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						[3] = true,
					},
				},
				["difficulty"] = {
				},
				["use_zone"] = false,
				["use_spec"] = true,
				["use_size"] = false,
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "arena",
					["multi"] = {
						["none"] = true,
						["pvp"] = true,
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = true,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura32",
			["uid"] = "dNbqAI(bYIi",
			["discrete_rotation"] = 0,
			["anchorFrameType"] = "SCREEN",
			["id"] = "PVP无常提醒非jjc",
			["xOffset"] = 136.0001859664917,
			["frameStrata"] = 7,
			["width"] = 151.2227630615234,
			["color"] = {
				1, -- [1]
				0.5529411764705883, -- [2]
				0.1294117647058823, -- [3]
				1, -- [4]
			},
			["config"] = {
			},
			["authorOptions"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["easeStrength"] = 3,
					["preset"] = "grow",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 3,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["property"] = "color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 4,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0.3098039215686275, -- [1]
								1, -- [2]
								0.8470588235294118, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 2,
								["variable"] = "show",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "show",
								["value"] = 1,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0.5333333333333333, -- [2]
								0.00784313725490196, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [3]
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["alpha"] = 1,
		},
		["暗怒气"] = {
			["parent"] = "SS通用",
			["yOffset"] = 133.1112976074219,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["useGroup_count"] = true,
						["duration"] = "1",
						["useHostility"] = true,
						["names"] = {
						},
						["group_count"] = "2",
						["subeventPrefix"] = "",
						["debuffType"] = "HELPFUL",
						["spellName"] = 0,
						["custom_type"] = "status",
						["type"] = "custom",
						["check"] = "update",
						["subeventSuffix"] = "",
						["hostility"] = "hostile",
						["custom"] = "function()\n    local count = 0\n    for i = 1, 40 do\n        local unit = \"nameplate\"..i\n        local plateFrame = C_NamePlate.GetNamePlateForUnit (unit, issecure())\n        if UnitCanAttack(\"player\", unit)\n        and WeakAuras.CheckRange(unit, 33, \"<=\")\n        then\n            if Plater.GetUnitType (plateFrame) == \"normal\"  then\n                count = count + 1\n            end \n            \n        end\n    end\n    \n    return count >=1;\n    \nend",
						["event"] = "Combat Events",
						["unevent"] = "timed",
						["use_eventtype"] = true,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unit"] = "nameplate",
						["namePattern_name"] = ".",
						["useNamePattern"] = true,
						["group_countOperator"] = ">=",
						["namePattern_operator"] = "match('%s')",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "暗影之怒",
						["use_spellName"] = true,
						["spellName"] = 30283,
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [2]
				{
					["trigger"] = {
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_unit"] = true,
						["powertype"] = 7,
						["use_powertype"] = true,
						["spellName"] = 0,
						["type"] = "status",
						["unevent"] = "auto",
						["power_operator"] = ">",
						["event"] = "Power",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["power"] = "3",
						["use_power"] = true,
						["duration"] = "1",
						["unit"] = "player",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function (t)\n    return ((t[1] and  t[2] ) or t[3] or t[4]) and t[5] and  t[6] and (t[8] and not t[7])\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = true,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 138.2232513427734,
			["rotate"] = true,
			["load"] = {
				["difficulty"] = {
				},
				["use_zone"] = false,
				["ingroup"] = {
					["single"] = "group",
					["multi"] = {
						["group"] = true,
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						true, -- [1]
						[3] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "arena",
					["multi"] = {
						["arena"] = true,
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura50",
			["uid"] = "c8r0G6k3f6s",
			["discrete_rotation"] = 0,
			["anchorFrameType"] = "SCREEN",
			["id"] = "暗怒气",
			["authorOptions"] = {
			},
			["frameStrata"] = 9,
			["width"] = 143.2217712402344,
			["xOffset"] = -136.6668701171875,
			["config"] = {
			},
			["color"] = {
				0.7254901960784313, -- [1]
				0.08235294117647059, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["easeStrength"] = 3,
					["preset"] = "grow",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["alpha"] = 0.83,
		},
		["Details! Boss Mods Group"] = {
			["grow"] = "DOWN",
			["controlledChildren"] = {
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["xOffset"] = 0,
			["yOffset"] = 370,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["space"] = 2,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["debuffType"] = "HELPFUL",
						["type"] = "aura",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["selfPoint"] = "TOP",
			["align"] = "CENTER",
			["rotation"] = 0,
			["height"] = 121.503601074219,
			["load"] = {
				["difficulty"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["use_class"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["internalVersion"] = 40,
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["arcLength"] = 360,
			["animate"] = true,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["scale"] = 1,
			["fullCircle"] = true,
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["sort"] = "none",
			["authorOptions"] = {
			},
			["limit"] = 5,
			["constantFactor"] = "RADIUS",
			["borderInset"] = 0,
			["borderOffset"] = 16,
			["gridType"] = "RD",
			["width"] = 359.096801757813,
			["id"] = "Details! Boss Mods Group",
			["frameStrata"] = 1,
			["gridWidth"] = 5,
			["anchorFrameType"] = "SCREEN",
			["useLimit"] = false,
			["config"] = {
			},
			["uid"] = "zQInGRZbBJD",
			["rowSpace"] = 1,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["stagger"] = 0,
		},
		["灵魂碎片1 Group"] = {
			["grow"] = "RIGHT",
			["controlledChildren"] = {
				"灵魂碎片1", -- [1]
				"灵魂碎片2", -- [2]
				"灵魂碎片3", -- [3]
				"灵魂碎片4", -- [4]
				"灵魂碎片5", -- [5]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["xOffset"] = -56.88836669921875,
			["yOffset"] = -42.79986572265625,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["space"] = -16,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["event"] = "Health",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["selfPoint"] = "CENTER",
			["align"] = "CENTER",
			["stagger"] = 0,
			["uid"] = "omgLJ(ELFmj",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["limit"] = 5,
			["animate"] = false,
			["fullCircle"] = true,
			["scale"] = 1,
			["anchorPerUnit"] = "NAMEPLATE",
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["sort"] = "none",
			["authorOptions"] = {
			},
			["internalVersion"] = 40,
			["constantFactor"] = "RADIUS",
			["gridType"] = "RD",
			["borderOffset"] = 4,
			["useLimit"] = false,
			["frameStrata"] = 1,
			["id"] = "灵魂碎片1 Group",
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["anchorFrameType"] = "SCREEN",
			["rowSpace"] = 1,
			["config"] = {
			},
			["useAnchorPerUnit"] = false,
			["rotation"] = 0,
			["conditions"] = {
			},
			["information"] = {
			},
			["arcLength"] = 360,
		},
		["被控制提醒狗技能"] = {
			["iconSource"] = 4,
			["xOffset"] = 76.444091796875,
			["yOffset"] = -80,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["auranames"] = {
							"变形术", -- [1]
							"恐惧", -- [2]
							"冰冻陷阱", -- [3]
							"闷棍", -- [4]
							"致盲", -- [5]
							"肾击", -- [6]
							"破胆怒吼", -- [7]
							"惊骇", -- [8]
							"", -- [9]
						},
						["totalOperator"] = ">",
						["duration"] = "1",
						["names"] = {
						},
						["debuffType"] = "HARMFUL",
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["useTotal"] = true,
						["use_controlled"] = true,
						["event"] = "Crowd Controlled",
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["total"] = "2",
						["spellIds"] = {
						},
						["useName"] = true,
						["subeventPrefix"] = "SPELL",
						["unit"] = "party",
						["unevent"] = "auto",
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_unit"] = true,
						["spellName"] = 0,
						["type"] = "status",
						["unevent"] = "auto",
						["percenthealth"] = "70",
						["event"] = "Health",
						["debuffType"] = "HELPFUL",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["percenthealth_operator"] = ">=",
						["use_absorbMode"] = true,
						["duration"] = "1",
						["use_percenthealth"] = true,
						["use_track"] = true,
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_unit"] = true,
						["spellName"] = 0,
						["type"] = "status",
						["unevent"] = "auto",
						["percenthealth"] = "94",
						["event"] = "Health",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["use_track"] = true,
						["duration"] = "1",
						["use_genericShowOn"] = true,
						["use_percenthealth"] = true,
						["percenthealth_operator"] = "<=",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = 132413,
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["use_exact_spellName"] = true,
						["genericShowOn"] = "showOnReady",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 132413,
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [4]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    \n    return ((t[1] and t[2] and t[3])   or ( t[2] and t[3]) ) and t[4]\n    \nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowXOffset"] = 0,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glow"] = true,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 64,
			["load"] = {
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_vehicle"] = false,
				["use_combat"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["parent"] = "SS通用",
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["use_scale"] = true,
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = true,
					["scalex"] = 3.8,
					["type"] = "custom",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["scaley"] = 3.8,
					["alpha"] = 0,
					["rotate"] = 0,
					["y"] = 75,
					["x"] = 65,
					["duration_type"] = "seconds",
					["colorA"] = 1,
					["scaleType"] = "straightScale",
					["easeStrength"] = 3,
					["translateType"] = "straightTranslate",
					["duration"] = ".66",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["cooldown"] = false,
			["authorOptions"] = {
			},
			["zoom"] = 0,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["alpha"] = 1,
			["id"] = "被控制提醒狗技能",
			["config"] = {
			},
			["frameStrata"] = 1,
			["width"] = 64,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "LiMtyYyBvPz",
			["inverse"] = false,
			["cooldownTextDisabled"] = false,
			["conditions"] = {
			},
			["information"] = {
			},
			["icon"] = true,
		},
		["1Remaining CD Display"] = {
			["iconSource"] = -1,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.70000001788139, -- [4]
			},
			["preferToUpdate"] = false,
			["customText"] = "function()\n    if aura_env.spellId then\n        local remaining = math.max(0, aura_env.start + aura_env.duration - GetTime())\n        return string.format(\"%.1f\", remaining)\n    end\nend",
			["yOffset"] = 24.88894653320313,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "0.5",
						["names"] = {
						},
						["customIcon"] = "function()\n    return GetSpellTexture(aura_env.spellId);\nend",
						["debuffType"] = "HELPFUL",
						["type"] = "custom",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["custom_hide"] = "timed",
						["custom_type"] = "event",
						["event"] = "Health",
						["customStacks"] = "\n\n",
						["customDuration"] = "function()\n    local s,d = GetSpellCooldown(aura_env.spellId)\n    --print(s, d)\n    return d+s - GetTime(), GetTime() + 1\nend",
						["customName"] = "function(a)\n    return GetSpellInfo(aura_env.spellId)\nend\n\n\n\n\n\n\n",
						["events"] = "UNIT_SPELLCAST_FAILED",
						["subeventPrefix"] = "SPELL",
						["custom"] = "function(event, unitId, lineId, spellId)\n    if(unitId ~= \"player\") then\n        return false\n    end\n    \n    local gcd = WeakAuras.gcdDuration()\n    local start, duration = GetSpellCooldown(spellId)\n    local remaining = start + duration - GetTime()\n    if(duration == gcd or remaining < 0) then\n        return false\n    else\n        aura_env.spellId = spellId\n        aura_env.start = start\n        aura_env.duration = duration\n        return true  \n    end\nend",
						["spellIds"] = {
						},
						["dynamicDuration"] = false,
						["buffShowOn"] = "showOnActive",
					},
					["untrigger"] = {
						["custom"] = "function()\n    print(GetTime(), endTime)\n    if (GetTime() - endTime) > 0 then\n        return true\n    end\n    return false\nend",
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 1,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						0.50196078431373, -- [3]
						1, -- [4]
					},
					["text_font"] = "Accidental Presidency",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["text_text_format_n_format"] = "none",
					["text_fontSize"] = 16,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%c",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						0, -- [2]
						0, -- [3]
						0.70000001788139, -- [4]
					},
					["text_font"] = "Accidental Presidency",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "THICKOUTLINE",
					["text_anchorPoint"] = "CENTER",
					["text_fontSize"] = 32,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [2]
			},
			["height"] = 64.000099182129,
			["load"] = {
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["translateType"] = "custom",
					["scalex"] = 1,
					["colorA"] = 1,
					["colorG"] = 1,
					["use_translate"] = true,
					["type"] = "none",
					["easeType"] = "none",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n\n\n",
					["scaley"] = 1,
					["alpha"] = 0,
					["y"] = 0,
					["x"] = 0,
					["duration_type"] = "seconds",
					["rotate"] = 0,
					["easeStrength"] = 3,
					["colorB"] = 1,
					["colorR"] = 1,
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["preset"] = "fade",
				},
			},
			["regionType"] = "icon",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "WeakAuras.WatchGCD()",
					["do_custom"] = true,
				},
			},
			["stickyDuration"] = false,
			["xOffset"] = 6.2225341796875,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["zoom"] = 0,
			["auto"] = true,
			["semver"] = "1.0.0",
			["id"] = "1Remaining CD Display",
			["width"] = 64,
			["frameStrata"] = 9,
			["anchorFrameType"] = "MOUSE",
			["alpha"] = 1,
			["uid"] = "WMzbjelm7Xk",
			["inverse"] = false,
			["authorOptions"] = {
			},
			["conditions"] = {
			},
			["cooldown"] = false,
			["url"] = "https://wago.io/swamA6O7P/1",
		},
		["魅惑"] = {
			["iconSource"] = -1,
			["xOffset"] = -104.8887329101563,
			["yOffset"] = 153.7784729003906,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["remaining"] = "3",
						["debuffType"] = "HELPFUL",
						["use_remaining"] = true,
						["unevent"] = "auto",
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["event"] = "Cooldown Progress (Spell)",
						["subeventSuffix"] = "_CAST_START",
						["realSpellName"] = "诱惑",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["duration"] = "1",
						["type"] = "status",
						["spellName"] = 6358,
						["use_track"] = true,
						["remaining_operator"] = "<=",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["use_scale"] = true,
					["colorB"] = 1,
					["colorG"] = 1,
					["type"] = "custom",
					["easeType"] = "easeOutIn",
					["scaley"] = 3,
					["alpha"] = 0,
					["scalex"] = 3,
					["y"] = 0,
					["x"] = 0,
					["colorA"] = 1,
					["rotate"] = 0,
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["scaleType"] = "straightScale",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "grow",
					["easeStrength"] = 3,
				},
			},
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 26,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
			},
			["height"] = 65.77757263183594,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["actions"] = {
				["start"] = {
					["do_custom"] = false,
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["selfPoint"] = "CENTER",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["frameStrata"] = 9,
			["zoom"] = 0,
			["auto"] = true,
			["anchorFrameType"] = "SCREEN",
			["id"] = "魅惑",
			["uid"] = "mCxjROOpQ27",
			["alpha"] = 1,
			["width"] = 65.77791595458984,
			["authorOptions"] = {
			},
			["config"] = {
			},
			["inverse"] = false,
			["cooldownTextDisabled"] = false,
			["conditions"] = {
			},
			["cooldown"] = true,
			["parent"] = "SS通用",
		},
		["群控"] = {
			["parent"] = "SS通用",
			["yOffset"] = 125.3332214355469,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["useGroup_count"] = true,
						["duration"] = "1",
						["useHostility"] = true,
						["unit"] = "nameplate",
						["group_count"] = "2",
						["names"] = {
						},
						["spellName"] = 0,
						["debuffType"] = "HELPFUL",
						["subeventSuffix"] = "",
						["type"] = "custom",
						["namePattern_name"] = ".",
						["custom_type"] = "status",
						["group_countOperator"] = ">=",
						["spellIds"] = {
						},
						["event"] = "Combat Events",
						["unevent"] = "timed",
						["use_eventtype"] = true,
						["use_spellName"] = true,
						["custom"] = "function()\n    local count = 0\n    for i = 1, 40 do\n        local unit = \"nameplate\"..i\n        local plateFrame = C_NamePlate.GetNamePlateForUnit (unit, issecure())\n        if UnitCanAttack(\"player\", unit)\n        and WeakAuras.CheckRange(unit, 9, \"<=\")\n        then\n            if Plater.GetUnitType (plateFrame) == \"normal\"  then\n                count = count + 1\n            end \n            \n        end\n    end\n    \n    return count >=1;\n    \nend",
						["hostility"] = "hostile",
						["check"] = "update",
						["useNamePattern"] = true,
						["subeventPrefix"] = "",
						["namePattern_operator"] = "match('%s')",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "恐惧嚎叫",
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["use_track"] = true,
						["spellName"] = 5484,
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [2]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function (t)\n    return ((t[1] and  t[2] ) or t[3] or t[4]) and t[5] and  t[6] and (t[8] and not t[7])\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = true,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 156.0002288818359,
			["rotate"] = true,
			["load"] = {
				["difficulty"] = {
				},
				["ingroup"] = {
					["single"] = "group",
					["multi"] = {
						["group"] = true,
					},
				},
				["use_zone"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						true, -- [1]
						[3] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["size"] = {
					["single"] = "arena",
					["multi"] = {
						["arena"] = true,
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = true,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura79",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["preset"] = "grow",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["alpha"] = 0.83,
			["id"] = "群控",
			["authorOptions"] = {
			},
			["frameStrata"] = 9,
			["width"] = 145.3338317871094,
			["color"] = {
				0.7254901960784313, -- [1]
				0.08235294117647059, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["uid"] = "3Su83Dx(0xX",
			["xOffset"] = 32.88909912109375,
			["anchorFrameType"] = "SCREEN",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["discrete_rotation"] = 0,
		},
		["DOTS"] = {
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["controlledChildren"] = {
				"补无常", -- [1]
				"补腐蚀", -- [2]
				"补痛楚", -- [3]
				"补盟约", -- [4]
				"补邪恶污染", -- [5]
				"补魅影", -- [6]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["xOffset"] = 56.00018310546875,
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "group",
			["borderSize"] = 2,
			["scale"] = 1,
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["event"] = "Health",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["information"] = {
			},
			["borderOffset"] = 4,
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["id"] = "DOTS",
			["yOffset"] = 329.5557556152344,
			["frameStrata"] = 9,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "r6(C7Xtm8FK",
			["config"] = {
			},
			["borderInset"] = 1,
			["selfPoint"] = "CENTER",
			["conditions"] = {
			},
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorOptions"] = {
			},
		},
		["Alert!"] = {
			["outline"] = "OUTLINE",
			["color"] = {
				0.16470588235294, -- [1]
				1, -- [2]
				0.12156862745098, -- [3]
				1, -- [4]
			},
			["displayText"] = "KILL THE POD",
			["yOffset"] = 0,
			["displayText_format_p_time_dynamic"] = false,
			["customTextUpdate"] = "event",
			["url"] = "https://wago.io/Wi5b8_TmZ/5",
			["actions"] = {
				["start"] = {
					["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BananaPeelSlip.ogg",
					["do_sound"] = true,
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["useName"] = true,
						["type"] = "aura2",
						["unevent"] = "auto",
						["duration"] = "1",
						["use_absorbMode"] = true,
						["event"] = "Health",
						["use_unit"] = true,
						["auranames"] = {
							"320224", -- [1]
						},
						["unit"] = "member",
						["spellIds"] = {
						},
						["specificUnit"] = "arena1",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"320224", -- [1]
						},
						["event"] = "Health",
						["unit"] = "member",
						["specificUnit"] = "arena2",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"320224", -- [1]
						},
						["event"] = "Health",
						["unit"] = "member",
						["specificUnit"] = "arena3",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 40,
			["wordWrap"] = "WordWrap",
			["font"] = "DorisPP",
			["version"] = 5,
			["subRegions"] = {
			},
			["load"] = {
				["use_size"] = false,
				["use_petbattle"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_vehicleUi"] = false,
				["use_vehicle"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["arena"] = true,
						["pvp"] = true,
						["none"] = true,
					},
				},
			},
			["fontSize"] = 24,
			["shadowXOffset"] = 1,
			["selfPoint"] = "BOTTOM",
			["regionType"] = "text",
			["automaticWidth"] = "Auto",
			["preferToUpdate"] = false,
			["fixedWidth"] = 200,
			["displayText_format_p_time_precision"] = 1,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["easeStrength"] = 3,
					["preset"] = "alphaPulse",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["semver"] = "2.0.3",
			["uid"] = "(FF)zDmPf))",
			["justify"] = "LEFT",
			["tocversion"] = 90002,
			["id"] = "Alert!",
			["authorOptions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["shadowYOffset"] = -1,
			["config"] = {
			},
			["anchorPoint"] = "CENTER",
			["xOffset"] = 0,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
			},
			["parent"] = "3KILL THE POD",
		},
		["开黑魂 3"] = {
			["user_y"] = 0,
			["user_x"] = 0,
			["authorOptions"] = {
			},
			["yOffset"] = 260,
			["anchorPoint"] = "CENTER",
			["desaturateBackground"] = false,
			["sameTexture"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["track"] = "auto",
						["use_totemNamePattern"] = true,
						["use_absorbMode"] = true,
						["totemNamePattern"] = "地狱火",
						["subeventPrefix"] = "SPELL",
						["remaining"] = "3",
						["remaining_operator"] = ">=",
						["use_unit"] = true,
						["spellName"] = 113860,
						["duration"] = "1",
						["use_remaining"] = true,
						["subeventSuffix"] = "_CAST_START",
						["unevent"] = "auto",
						["type"] = "status",
						["use_genericShowOn"] = true,
						["event"] = "Action Usable",
						["use_exact_spellName"] = false,
						["realSpellName"] = "黑暗灵魂：哀难",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["genericShowOn"] = "showOnReady",
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
						["use_track"] = true,
						["names"] = {
						},
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [1]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["group_countOperator"] = ">=",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "nameplate",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["group_count"] = "1",
						["rem"] = "5",
						["remOperator"] = ">=",
						["useRem"] = true,
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["debuffType"] = "HARMFUL",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "target",
						["type"] = "aura2",
						["useRem"] = false,
						["remOperator"] = ">=",
						["rem"] = "5",
						["group_count"] = "2",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["group_countOperator"] = ">=",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"痛楚", -- [1]
						},
						["group_countOperator"] = ">=",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "target",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["group_count"] = "2",
						["rem"] = "5",
						["remOperator"] = ">=",
						["useRem"] = true,
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function (t)\n    return  (t[1] and  t[2] ) and (t[3] or (t[4] and t[5]) or  (t[6] and t[7]  and t[8] and t[9]) )\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "痛苦ss",
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["subRegions"] = {
				{
					["text_text_format_p_time_precision"] = 1,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						0.05882352941176471, -- [2]
						0.06666666666666667, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_shadowXOffset"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "MONOCHROME|THICKOUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = false,
					["text_anchorPoint"] = "CENTER",
					["text_text_format_p_format"] = "timed",
					["text_text_format_n_format"] = "none",
					["text_fontSize"] = 40,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [1]
			},
			["height"] = 56,
			["load"] = {
				["use_spec"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["color"] = {
			},
			["useAdjustededMax"] = false,
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["crop_y"] = 0.41,
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura52",
			["crop_x"] = 0.44,
			["selfPoint"] = "CENTER",
			["mirror"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "progresstexture",
			["fontSize"] = 12,
			["blendMode"] = "BLEND",
			["xOffset"] = 110,
			["config"] = {
			},
			["slantMode"] = "INSIDE",
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 5,
			["foregroundColor"] = {
				1, -- [1]
				0.396078431372549, -- [2]
				0.9215686274509803, -- [3]
				0.7199999988079071, -- [4]
			},
			["backgroundColor"] = {
				0.3058823529411765, -- [1]
				0.3176470588235294, -- [2]
				0.3019607843137255, -- [3]
				0.4000000357627869, -- [4]
			},
			["compress"] = false,
			["id"] = "开黑魂 3",
			["textureWrapMode"] = "CLAMP",
			["alpha"] = 1,
			["width"] = 56,
			["startAngle"] = 0,
			["uid"] = "(3y98Zvo)HA",
			["inverse"] = false,
			["desaturateForeground"] = false,
			["orientation"] = "VERTICAL",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["backgroundOffset"] = 0,
		},
		["黑魂"] = {
			["iconSource"] = -1,
			["parent"] = "SS通用",
			["yOffset"] = 139.5561828613281,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["use_castType"] = false,
						["use_destFlags2"] = false,
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["names"] = {
						},
						["remaining"] = "5",
						["unit"] = "player",
						["use_track"] = true,
						["use_sourceFlags3"] = false,
						["spellName"] = 113860,
						["debuffType"] = "HELPFUL",
						["remaining_operator"] = "<=",
						["type"] = "status",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_FAILED",
						["use_remaining"] = true,
						["use_exact_spellName"] = false,
						["event"] = "Cooldown Progress (Spell)",
						["use_sourceFlags2"] = false,
						["realSpellName"] = "黑暗灵魂：哀难",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_sourceUnit"] = true,
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["sourceUnit"] = "player",
						["use_unit"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["preset"] = "grow",
				},
			},
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 26,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
			},
			["height"] = 25,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["selfPoint"] = "CENTER",
			["authorOptions"] = {
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["frameStrata"] = 9,
			["cooldownTextDisabled"] = false,
			["auto"] = true,
			["anchorFrameType"] = "SCREEN",
			["id"] = "黑魂",
			["config"] = {
			},
			["alpha"] = 1,
			["width"] = 25,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["uid"] = "vfSgah8u14R",
			["inverse"] = false,
			["zoom"] = 0,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["xOffset"] = -95.9996337890625,
		},
		["Infernal Timer #3"] = {
			["iconSource"] = 0,
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["customText"] = "",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Afenar_Warlock/88",
			["actions"] = {
				["start"] = {
					["do_glow"] = false,
				},
				["init"] = {
				},
				["finish"] = {
					["do_glow"] = false,
					["sound"] = "Interface\\Addons\\MikScrollingBattleText\\Sounds\\Cooldown.ogg",
					["do_sound"] = false,
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["duration"] = "1",
						["event"] = "Totem",
						["unit"] = "player",
						["unevent"] = "auto",
						["use_absorbMode"] = true,
						["spellIds"] = {
						},
						["totemType"] = 3,
						["use_unit"] = true,
						["names"] = {
						},
						["use_totemType"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["useTooltip"] = false,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						0.4352941176470588, -- [1]
						1, -- [2]
						0.3686274509803922, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_shadowYOffset"] = 5,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_TOP",
					["text_fontSize"] = 64,
					["anchorXOffset"] = 0,
					["text_fontType"] = "THICKOUTLINE",
				}, -- [1]
			},
			["height"] = 77,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["role"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["size"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_vehicle"] = false,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[2] = true,
						[3] = true,
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["use_petbattle"] = false,
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["use_vehicleUi"] = false,
				["race"] = {
					["multi"] = {
					},
				},
				["spellknown"] = 1122,
				["faction"] = {
					["multi"] = {
					},
				},
			},
			["authorMode"] = true,
			["anchorFrameType"] = "SCREEN",
			["stickyDuration"] = false,
			["cooldownEdge"] = false,
			["icon"] = true,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["regionType"] = "icon",
			["conditions"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
			},
			["internalVersion"] = 40,
			["config"] = {
			},
			["frameStrata"] = 4,
			["xOffset"] = 0,
			["zoom"] = 0.3,
			["auto"] = false,
			["tocversion"] = 80205,
			["id"] = "Infernal Timer #3",
			["semver"] = "2.2.2",
			["alpha"] = 1,
			["width"] = 77,
			["cooldownTextDisabled"] = false,
			["uid"] = "3d2rZ5Y3Njw",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayIcon"] = 136219,
			["cooldown"] = true,
			["parent"] = "Infernal Timer ",
		},
		["补痛楚"] = {
			["xOffset"] = 96,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["useName"] = true,
						["debuffType"] = "HARMFUL",
						["subeventSuffix"] = "_CAST_START",
						["rem"] = "2",
						["ownOnly"] = true,
						["event"] = "Health",
						["names"] = {
						},
						["auranames"] = {
							"痛楚", -- [1]
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["matchesShowOn"] = "showOnMissing",
						["remOperator"] = "<=",
						["unit"] = "target",
						["subeventPrefix"] = "SPELL",
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["useName"] = true,
						["useRem"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["ownOnly"] = true,
						["event"] = "Health",
						["names"] = {
						},
						["unit"] = "target",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["matchesShowOn"] = "showOnActive",
						["remOperator"] = "<=",
						["auranames"] = {
							"痛楚", -- [1]
						},
						["rem"] = "5",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "function (t)\n    return (t[1] or  t[2])  and t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["use_rotate"] = false,
					["duration_type"] = "seconds",
					["duration"] = ".66",
					["alphaType"] = "hide",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "function()\n    return 0\nend\n",
					["rotateType"] = "wobble",
					["rotateFunc"] = "function(progress, start, delta)\n    local angle = progress * 2 * math.pi\n    return start + math.sin(angle) * delta\nend\n",
					["use_translate"] = true,
					["use_alpha"] = false,
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["type"] = "custom",
					["translateType"] = "straightTranslate",
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["preset"] = "slideright",
					["alpha"] = 0,
					["scaleType"] = "straightScale",
					["y"] = -200,
					["x"] = -200,
					["colorA"] = 1,
					["scaley"] = 5,
					["rotate"] = 333,
					["easeStrength"] = 3,
					["scalex"] = 5,
					["use_scale"] = true,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 50,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						[3] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura45",
			["parent"] = "DOTS",
			["selfPoint"] = "CENTER",
			["alpha"] = 0.93,
			["id"] = "补痛楚",
			["width"] = 50,
			["frameStrata"] = 7,
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				1, -- [1]
				0.9490196078431372, -- [2]
				0.9568627450980391, -- [3]
				1, -- [4]
			},
			["uid"] = "p7VyzDOop97",
			["config"] = {
			},
			["authorOptions"] = {
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["discrete_rotation"] = 0,
		},
		["Details! Aura Group"] = {
			["grow"] = "RIGHT",
			["controlledChildren"] = {
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["xOffset"] = -678.999450683594,
			["yOffset"] = 212.765991210938,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["space"] = 0,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["debuffType"] = "HELPFUL",
						["type"] = "aura",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["selfPoint"] = "LEFT",
			["align"] = "CENTER",
			["rotation"] = 0,
			["height"] = 20,
			["load"] = {
				["race"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["arcLength"] = 360,
			["animate"] = true,
			["internalVersion"] = 40,
			["scale"] = 1,
			["fullCircle"] = true,
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["sort"] = "none",
			["authorOptions"] = {
			},
			["limit"] = 5,
			["constantFactor"] = "RADIUS",
			["borderInset"] = 0,
			["borderOffset"] = 16,
			["gridType"] = "RD",
			["width"] = 199.999969482422,
			["id"] = "Details! Aura Group",
			["frameStrata"] = 1,
			["gridWidth"] = 5,
			["anchorFrameType"] = "SCREEN",
			["useLimit"] = false,
			["config"] = {
			},
			["uid"] = "AjJPhLqNEHF",
			["rowSpace"] = 1,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["stagger"] = 0,
		},
		["快速传染"] = {
			["user_y"] = 0,
			["user_x"] = 0,
			["authorOptions"] = {
			},
			["yOffset"] = 258.2213745117188,
			["anchorPoint"] = "CENTER",
			["desaturateBackground"] = false,
			["sameTexture"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["auranames"] = {
							"", -- [1]
						},
						["ownOnly"] = true,
						["names"] = {
						},
						["use_totemType"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "aura2",
						["duration"] = "1",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["matchesShowOn"] = "showOnMissing",
						["event"] = "Stance/Form/Aura",
						["totemType"] = 1,
						["use_unit"] = true,
						["use_absorbMode"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["namePattern_name"] = "快速传染",
						["useNamePattern"] = true,
						["unit"] = "player",
						["namePattern_operator"] = "find('%s')",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_totemNamePattern"] = true,
						["use_absorbMode"] = true,
						["totemNamePattern"] = "地狱火",
						["subeventPrefix"] = "SPELL",
						["remaining"] = "3",
						["spellName"] = 344566,
						["unit"] = "player",
						["use_remaining"] = true,
						["subeventSuffix"] = "_CAST_START",
						["unevent"] = "auto",
						["use_unit"] = true,
						["duration"] = "1",
						["event"] = "Action Usable",
						["use_exact_spellName"] = false,
						["realSpellName"] = "快速传染",
						["use_spellName"] = true,
						["type"] = "status",
						["remaining_operator"] = ">=",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [2]
				{
					["trigger"] = {
						["use_totemNamePattern"] = true,
						["use_totemName"] = false,
						["totemNamePattern"] = "黑眼",
						["unit"] = "player",
						["remaining"] = "20",
						["debuffType"] = "HELPFUL",
						["use_remaining"] = true,
						["unevent"] = "auto",
						["event"] = "Totem",
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["duration"] = "1",
						["use_inverse"] = false,
						["subeventPrefix"] = "SPELL",
						["type"] = "status",
						["remaining_operator"] = "<=",
						["use_unit"] = true,
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["debuffType"] = "HARMFUL",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "nameplate",
						["type"] = "aura2",
						["useRem"] = true,
						["remOperator"] = ">=",
						["rem"] = "5",
						["group_count"] = "2",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["group_countOperator"] = ">=",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["group_countOperator"] = ">=",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "nameplate",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["group_count"] = "3",
						["rem"] = "5",
						["remOperator"] = ">=",
						["useRem"] = true,
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["debuffType"] = "HARMFUL",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "target",
						["type"] = "aura2",
						["useRem"] = true,
						["remOperator"] = ">=",
						["rem"] = "5",
						["group_count"] = "2",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["group_countOperator"] = ">=",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"痛楚", -- [1]
						},
						["group_countOperator"] = ">=",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "target",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["group_count"] = "2",
						["rem"] = "5",
						["remOperator"] = ">=",
						["useRem"] = true,
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [7]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["debuffType"] = "HARMFUL",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "target",
						["type"] = "aura2",
						["useRem"] = true,
						["remOperator"] = ">=",
						["rem"] = "5",
						["group_count"] = "2",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["group_countOperator"] = ">=",
					},
					["untrigger"] = {
					},
				}, -- [8]
				{
					["trigger"] = {
						["useName"] = true,
						["use_debuffClass"] = false,
						["auranames"] = {
							"诡异魅影", -- [1]
						},
						["group_countOperator"] = ">=",
						["ownOnly"] = true,
						["useHostility"] = false,
						["unit"] = "target",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["group_count"] = "2",
						["rem"] = "5",
						["remOperator"] = ">=",
						["useRem"] = true,
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n    return  (t[1] and  t[2] ) and (t[3] or (t[4] and t[5]) or  (t[6] and t[7]  and t[8]) )\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["startAngle"] = 0,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["subRegions"] = {
				{
					["text_text_format_p_time_precision"] = 1,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						0.05882352941176471, -- [2]
						0.06666666666666667, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_shadowXOffset"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "MONOCHROME|THICKOUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = false,
					["text_anchorPoint"] = "CENTER",
					["text_text_format_p_format"] = "timed",
					["text_text_format_n_format"] = "none",
					["text_fontSize"] = 40,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [1]
			},
			["height"] = 60.76644515991211,
			["load"] = {
				["use_spec"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["xOffset"] = 112.1837768554688,
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["desaturateForeground"] = false,
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura10",
			["crop_x"] = 0.44,
			["color"] = {
			},
			["mirror"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "progresstexture",
			["crop_y"] = 0.41,
			["blendMode"] = "BLEND",
			["parent"] = "痛苦ss",
			["config"] = {
			},
			["slantMode"] = "INSIDE",
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 8,
			["foregroundColor"] = {
				1, -- [1]
				0.403921568627451, -- [2]
				0.6274509803921569, -- [3]
				0.7070705890655518, -- [4]
			},
			["backgroundColor"] = {
				0.3058823529411765, -- [1]
				0.3176470588235294, -- [2]
				0.3019607843137255, -- [3]
				0.4000000357627869, -- [4]
			},
			["compress"] = false,
			["id"] = "快速传染",
			["textureWrapMode"] = "CLAMP",
			["alpha"] = 1,
			["width"] = 42.05552291870117,
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["uid"] = "(9ubLMTuAbq",
			["inverse"] = false,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["orientation"] = "VERTICAL",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["backgroundOffset"] = 0,
		},
		["虚空防护"] = {
			["xOffset"] = -2.4439697265625,
			["yOffset"] = 6.44500732421875,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["unit"] = "player",
						["remaining"] = "0",
						["spellName"] = 212295,
						["names"] = {
						},
						["type"] = "status",
						["subeventPrefix"] = "SPELL",
						["unevent"] = "auto",
						["use_spellCount"] = false,
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Action Usable",
						["duration"] = "1",
						["realSpellName"] = "虚空守卫",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_remaining"] = true,
						["remaining_operator"] = "==",
						["useName"] = false,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["use_spell"] = true,
						["subeventPrefix"] = "SPELL",
						["powertype"] = 7,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["power"] = "3.8",
						["power_operator"] = ">=",
						["event"] = "Cast",
						["spell"] = "混乱之箭",
						["subeventSuffix"] = "_CAST_START",
						["names"] = {
						},
						["spellIds"] = {
						},
						["use_power"] = true,
						["unevent"] = "auto",
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["use_castType"] = false,
						["use_inverse"] = false,
						["class"] = "DEMONHUNTER",
						["subeventPrefix"] = "SPELL",
						["use_class"] = false,
						["powertype"] = 7,
						["use_power"] = true,
						["use_absorbMode"] = true,
						["remaining"] = "1.66",
						["use_unit"] = true,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["use_remaining"] = true,
						["type"] = "status",
						["nameplateType"] = "hostile",
						["power"] = "3.8",
						["power_operator"] = ">=",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cast",
						["duration"] = "1",
						["unit"] = "nameplate",
						["unevent"] = "auto",
						["spellIds"] = {
						},
						["remaining_operator"] = ">=",
						["use_nameplateType"] = true,
						["use_destUnit"] = true,
						["destUnit"] = "player",
						["names"] = {
						},
					},
					["untrigger"] = {
						["unit"] = "nameplate",
					},
				}, -- [3]
				{
					["trigger"] = {
						["duration"] = "1",
						["use_spell"] = true,
						["names"] = {
						},
						["powertype"] = 7,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["spell"] = "灾难狂欢",
						["subeventSuffix"] = "_CAST_START",
						["power_operator"] = ">=",
						["use_absorbMode"] = true,
						["event"] = "Cast",
						["unit"] = "player",
						["use_unit"] = true,
						["use_spellId"] = false,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["type"] = "status",
						["use_power"] = true,
						["power"] = "3.8",
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["use_spell"] = true,
						["unit"] = "player",
						["powertype"] = 7,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["spell"] = "痛苦无常",
						["subeventSuffix"] = "_CAST_START",
						["power_operator"] = ">=",
						["subeventPrefix"] = "SPELL",
						["event"] = "Cast",
						["power"] = "3.8",
						["use_power"] = true,
						["use_spellId"] = false,
						["spellIds"] = {
						},
						["type"] = "status",
						["unevent"] = "auto",
						["use_unit"] = true,
						["duration"] = "1",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [5]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n    return  t[1] and ( t[2] or  t[3] or  t[4] or  t[5])\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "fade",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 195.221435546875,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[3] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorMode"] = true,
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "166757",
			["width"] = 189.1117095947266,
			["parent"] = "SS通用",
			["rotation"] = 0,
			["id"] = "虚空防护",
			["alpha"] = 1,
			["frameStrata"] = 5,
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				0.3686274509803922, -- [1]
				1, -- [2]
				0.2941176470588235, -- [3]
				0.75, -- [4]
			},
			["config"] = {
			},
			["authorOptions"] = {
			},
			["uid"] = "jZV3eRxE4vV",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["selfPoint"] = "CENTER",
		},
		["补盟约"] = {
			["parent"] = "DOTS",
			["yOffset"] = -26,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["rem"] = "2",
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["subeventPrefix"] = "SPELL",
						["ownOnly"] = true,
						["debuffType"] = "HARMFUL",
						["useName"] = true,
						["type"] = "status",
						["unit"] = "target",
						["subeventSuffix"] = "_CAST_START",
						["matchesShowOn"] = "showOnMissing",
						["duration"] = "1",
						["event"] = "Action Usable",
						["spellName"] = 325640,
						["realSpellName"] = "灵魂腐化",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["names"] = {
						},
						["remOperator"] = "<=",
						["unevent"] = "auto",
						["use_track"] = true,
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["powertype"] = 7,
						["use_powertype"] = true,
						["spellName"] = 0,
						["type"] = "status",
						["unevent"] = "auto",
						["power_operator"] = ">=",
						["event"] = "Power",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["power"] = "1",
						["use_power"] = true,
						["use_genericShowOn"] = true,
						["use_unit"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function (t)\n    return (t[1] or  t[2])  and t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 50,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						true, -- [1]
						[3] = true,
					},
				},
				["use_combat"] = true,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura45",
			["uid"] = "nGF73Ot6pAT",
			["rotation"] = 0,
			["width"] = 50,
			["id"] = "补盟约",
			["color"] = {
				0.3568627450980392, -- [1]
				0.4431372549019608, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["alpha"] = 0.93,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 66,
			["config"] = {
			},
			["authorOptions"] = {
			},
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["duration"] = ".66",
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = true,
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["scaleType"] = "straightScale",
					["type"] = "custom",
					["easeStrength"] = 3,
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["preset"] = "grow",
					["alpha"] = 0,
					["translateType"] = "straightTranslate",
					["y"] = -200,
					["x"] = -200,
					["colorA"] = 1,
					["scaley"] = 5,
					["duration_type"] = "seconds",
					["rotate"] = 0,
					["use_scale"] = true,
					["scalex"] = 5,
				},
				["main"] = {
					["colorR"] = 1,
					["use_rotate"] = false,
					["duration"] = ".88",
					["colorB"] = 1,
					["colorG"] = 1,
					["rotateType"] = "straight",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\nend\n",
					["type"] = "custom",
					["rotateFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
					["easeType"] = "none",
					["scaleType"] = "pulse",
					["preset"] = "pulse",
					["alpha"] = 0,
					["colorA"] = 1,
					["y"] = 0,
					["x"] = 0,
					["scaley"] = 1.5,
					["duration_type"] = "seconds",
					["rotate"] = 0,
					["easeStrength"] = 3,
					["scalex"] = 1.5,
					["use_scale"] = true,
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["frameStrata"] = 7,
		},
		["战斗状态目标"] = {
			["color"] = {
				1, -- [1]
				0, -- [2]
				0.0196078431372549, -- [3]
				0.75, -- [4]
			},
			["yOffset"] = -255.1112213134766,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_showAbsorb"] = false,
						["use_incombat"] = true,
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "target",
						["use_inCombat"] = true,
						["use_absorbMode"] = true,
						["use_track"] = true,
						["names"] = {
						},
						["spellName"] = 0,
						["debuffType"] = "HELPFUL",
						["duration"] = "1",
						["type"] = "status",
						["use_health"] = false,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["percenthealth"] = "43",
						["event"] = "Unit Characteristics",
						["health_operator"] = "<=",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["health"] = "43",
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_percenthealth"] = true,
						["percenthealth_operator"] = "<=",
						["use_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "target",
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 48.88936996459961,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "166984",
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["discrete_rotation"] = 0,
			["anchorFrameType"] = "SCREEN",
			["id"] = "战斗状态目标",
			["authorOptions"] = {
			},
			["alpha"] = 1,
			["width"] = 51.55559158325195,
			["xOffset"] = 198.6666259765625,
			["uid"] = "UehXZ2Pr32B",
			["config"] = {
			},
			["frameStrata"] = 1,
			["conditions"] = {
			},
			["information"] = {
			},
			["parent"] = "SS通用",
		},
		["黑眼"] = {
			["parent"] = "痛苦ss",
			["yOffset"] = 263.7783203125,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["debuffClass"] = {
							["curse"] = true,
							["magic"] = true,
							["disease"] = true,
						},
						["useStacks"] = false,
						["auranames"] = {
							"痛苦无常", -- [1]
						},
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["useHostility"] = true,
						["use_unit"] = true,
						["useMatch_count"] = false,
						["stacks"] = "1",
						["unit"] = "target",
						["group_count"] = "0",
						["match_count"] = "3",
						["debuffType"] = "HARMFUL",
						["type"] = "aura2",
						["group_countOperator"] = ">",
						["subeventSuffix"] = "_CAST_START",
						["useName"] = true,
						["stacksOperator"] = ">=",
						["unevent"] = "auto",
						["useGroup_count"] = true,
						["hostility"] = "hostile",
						["event"] = "Health",
						["ownOnly"] = true,
						["use_debuffClass"] = false,
						["match_countOperator"] = ">=",
						["spellIds"] = {
						},
						["rem"] = "3",
						["remOperator"] = ">=",
						["duration"] = "1",
						["names"] = {
						},
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["useMatch_count"] = false,
						["useStacks"] = false,
						["auranames"] = {
							"痛楚", -- [1]
						},
						["rem"] = "3",
						["use_absorbMode"] = true,
						["useHostility"] = true,
						["use_unit"] = true,
						["duration"] = "1",
						["stacks"] = "1",
						["unit"] = "target",
						["group_count"] = "0",
						["match_count"] = "3",
						["group_countOperator"] = ">",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
						["match_countOperator"] = ">=",
						["type"] = "aura2",
						["stacksOperator"] = ">=",
						["subeventSuffix"] = "_CAST_START",
						["use_debuffClass"] = false,
						["ownOnly"] = true,
						["event"] = "Health",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["unevent"] = "auto",
						["spellIds"] = {
						},
						["debuffClass"] = {
							["curse"] = true,
							["magic"] = true,
							["disease"] = true,
						},
						["remOperator"] = ">=",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["useMatch_count"] = true,
						["useStacks"] = false,
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["rem"] = "3",
						["use_absorbMode"] = true,
						["useHostility"] = true,
						["use_unit"] = true,
						["duration"] = "1",
						["stacks"] = "1",
						["unit"] = "target",
						["group_count"] = "0",
						["match_count"] = "3",
						["group_countOperator"] = ">",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
						["match_countOperator"] = ">=",
						["type"] = "aura2",
						["stacksOperator"] = ">=",
						["subeventSuffix"] = "_CAST_START",
						["use_debuffClass"] = false,
						["ownOnly"] = true,
						["event"] = "Health",
						["hostility"] = "hostile",
						["useGroup_count"] = true,
						["unevent"] = "auto",
						["spellIds"] = {
						},
						["debuffClass"] = {
							["curse"] = true,
							["magic"] = true,
							["disease"] = true,
						},
						["remOperator"] = ">=",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["useRem"] = false,
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["use_unit"] = true,
						["powertype"] = 7,
						["subeventPrefix"] = "SPELL",
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["unit"] = "player",
						["type"] = "status",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["power_operator"] = ">=",
						["power"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["use_absorbMode"] = true,
						["realSpellName"] = "召唤黑眼",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["spellName"] = 205180,
						["use_power"] = true,
						["names"] = {
						},
						["use_track"] = true,
						["duration"] = "1",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [4]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function (t)\n    return ( (t[1] and  t[2]  and t[3] ) or t[5])  and t[4]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "fade",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 126.7781448364258,
			["rotate"] = true,
			["load"] = {
				["use_spec"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "627609",
			["xOffset"] = 91.33245849609375,
			["rotation"] = 270,
			["frameStrata"] = 6,
			["id"] = "黑眼",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 0.78,
			["width"] = 141.9995422363281,
			["authorOptions"] = {
			},
			["uid"] = "YoE9VMVbedG",
			["config"] = {
			},
			["color"] = {
				0.8313725490196078, -- [1]
				0.7764705882352941, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["selfPoint"] = "CENTER",
		},
		["地狱火"] = {
			["iconSource"] = -1,
			["authorOptions"] = {
			},
			["yOffset"] = 171.5559997558594,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_castType"] = false,
						["use_destFlags2"] = false,
						["remaining_operator"] = "<=",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["remaining"] = "4",
						["debuffType"] = "HELPFUL",
						["use_sourceFlags3"] = false,
						["use_track"] = true,
						["spellName"] = 1122,
						["subeventPrefix"] = "SPELL",
						["type"] = "status",
						["duration"] = "1",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_FAILED",
						["use_remaining"] = true,
						["event"] = "Cooldown Progress (Spell)",
						["use_sourceFlags2"] = false,
						["realSpellName"] = "召唤地狱火",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_sourceUnit"] = true,
						["use_genericShowOn"] = true,
						["use_unit"] = true,
						["sourceUnit"] = "player",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["preset"] = "grow",
				},
			},
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 26,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
			},
			["height"] = 62.22222137451172,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["use_combat"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["parent"] = "毁灭ss",
			["icon"] = true,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["cooldownTextDisabled"] = false,
			["zoom"] = 0,
			["auto"] = true,
			["anchorFrameType"] = "SCREEN",
			["id"] = "地狱火",
			["config"] = {
			},
			["alpha"] = 1,
			["width"] = 63.11123275756836,
			["xOffset"] = 1.33355712890625,
			["uid"] = "x380eZyT1J0",
			["inverse"] = false,
			["frameStrata"] = 9,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["selfPoint"] = "CENTER",
		},
		[" 法阵不可用！"] = {
			["iconSource"] = 2,
			["xOffset"] = 90,
			["preferToUpdate"] = false,
			["yOffset"] = 180,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showAlways",
						["unit"] = "player",
						["remaining"] = "6",
						["spellName"] = 48020,
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["remaining_operator"] = "<=",
						["use_remaining"] = true,
						["event"] = "Cooldown Progress (Spell)",
						["debuffType"] = "HELPFUL",
						["realSpellName"] = "恶魔法阵：传送",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["duration"] = "1",
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_track"] = true,
						["names"] = {
						},
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Action Usable",
						["subeventPrefix"] = "SPELL",
						["realSpellName"] = "恶魔法阵：传送",
						["use_spellName"] = true,
						["use_inverse"] = true,
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["spellName"] = 48020,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["use_vehicle"] = false,
						["duration"] = "1",
						["event"] = "Conditions",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["genericShowOn"] = "showOnCooldown",
						["use_genericShowOn"] = true,
						["use_resting"] = false,
						["use_track"] = true,
						["spellName"] = 0,
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function(t) \n    return t[1] and t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 1,
			["subRegions"] = {
			},
			["height"] = 55.11082458496094,
			["load"] = {
				["use_class"] = true,
				["use_never"] = false,
				["talent"] = {
					["single"] = 15,
					["multi"] = {
						[15] = true,
					},
				},
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[2] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["config"] = {
			},
			["url"] = "https://wago.io/bfMwlftxG/1",
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["scalex"] = 2.3,
					["duration"] = "0.83",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["alphaType"] = "straight",
					["colorB"] = 0.05098039215686274,
					["colorG"] = 0,
					["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
					["rotate"] = 0,
					["colorA"] = 1,
					["use_translate"] = false,
					["use_alpha"] = false,
					["scaleType"] = "straightScale",
					["type"] = "custom",
					["scaley"] = 2.3,
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["use_color"] = true,
					["alpha"] = 0,
					["colorType"] = "straightColor",
					["y"] = 50,
					["x"] = -60,
					["preset"] = "grow",
					["use_scale"] = true,
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    return r1 + (progress * (r2 - r1)), g1 + (progress * (g2 - g1)), b1 + (progress * (b2 - b1)), a1 + (progress * (a2 - a1))\nend\n",
					["easeStrength"] = 3,
					["translateType"] = "straightTranslate",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["colorR"] = 1,
					["scalex"] = 1,
					["alphaType"] = "straight",
					["colorB"] = 0.203921568627451,
					["colorG"] = 0,
					["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
					["use_alpha"] = true,
					["type"] = "custom",
					["easeType"] = "easeOut",
					["duration"] = "0.83",
					["use_color"] = true,
					["alpha"] = 0.83,
					["duration_type"] = "seconds",
					["y"] = 0,
					["colorType"] = "straightColor",
					["easeStrength"] = 3,
					["colorA"] = 1,
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    return r1 + (progress * (r2 - r1)), g1 + (progress * (g2 - g1)), b1 + (progress * (b2 - b1)), a1 + (progress * (a2 - a1))\nend\n",
					["rotate"] = 0,
					["x"] = 0,
					["scaley"] = 1,
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["regionType"] = "icon",
			["stickyDuration"] = false,
			["cooldown"] = true,
			["displayIcon"] = "",
			["authorOptions"] = {
			},
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["width"] = 56.88884735107422,
			["cooldownTextDisabled"] = false,
			["semver"] = "1.0.0",
			["frameStrata"] = 4,
			["id"] = " 法阵不可用！",
			["zoom"] = 0,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["auto"] = true,
			["uid"] = "bf01s29BGIf",
			["inverse"] = true,
			["icon"] = true,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["parent"] = "SS通用",
		},
		["补献祭了"] = {
			["parent"] = "毁灭ss",
			["yOffset"] = 14.00006103515625,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["useName"] = true,
						["debuffType"] = "HARMFUL",
						["subeventSuffix"] = "_CAST_START",
						["rem"] = "2",
						["ownOnly"] = true,
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["auranames"] = {
							"献祭", -- [1]
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["matchesShowOn"] = "showOnMissing",
						["remOperator"] = "<=",
						["unit"] = "target",
						["names"] = {
						},
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"献祭", -- [1]
						},
						["event"] = "Health",
						["unit"] = "target",
						["debuffType"] = "HARMFUL",
						["useName"] = true,
						["subeventSuffix"] = "_CAST_START",
						["remOperator"] = "<=",
						["subeventPrefix"] = "SPELL",
						["rem"] = "2",
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "大灾变",
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_track"] = true,
						["spellName"] = 152108,
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n    return (t[1] or  t[2])  and t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["rotation"] = 177,
			["subRegions"] = {
			},
			["height"] = 304.2225036621094,
			["rotate"] = true,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "449491",
			["color"] = {
				0.8745098039215686, -- [1]
				0.9568627450980391, -- [2]
				1, -- [3]
				0.75, -- [4]
			},
			["selfPoint"] = "CENTER",
			["anchorFrameType"] = "SCREEN",
			["id"] = "补献祭了",
			["xOffset"] = 137.5554809570313,
			["frameStrata"] = 9,
			["width"] = 214.4442443847656,
			["authorOptions"] = {
			},
			["uid"] = ")1exFO8b5jg",
			["discrete_rotation"] = 0,
			["config"] = {
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["alpha"] = 1,
		},
		["狗吃魔法"] = {
			["iconSource"] = -1,
			["parent"] = "SS通用",
			["yOffset"] = 171.5562438964844,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["unit"] = "target",
						["use_stealable"] = true,
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_castType"] = false,
						["use_destFlags2"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["subeventPrefix"] = "SPELL",
						["remaining"] = "3",
						["names"] = {
						},
						["use_sourceFlags3"] = false,
						["sourceUnit"] = "player",
						["debuffType"] = "HELPFUL",
						["use_unit"] = true,
						["type"] = "status",
						["use_genericShowOn"] = true,
						["subeventSuffix"] = "_CAST_FAILED",
						["unevent"] = "auto",
						["use_remaining"] = true,
						["event"] = "Cooldown Progress (Spell)",
						["use_sourceFlags2"] = false,
						["realSpellName"] = "吞噬魔法",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_sourceUnit"] = true,
						["remaining_operator"] = "<=",
						["unit"] = "player",
						["use_track"] = true,
						["spellName"] = 19505,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				{
					["trigger"] = {
						["use_castType"] = false,
						["use_destFlags2"] = false,
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["remaining"] = "5",
						["spellName"] = 19505,
						["use_sourceFlags3"] = false,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
						["unit"] = "player",
						["type"] = "status",
						["remaining_operator"] = "<=",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_FAILED",
						["use_remaining"] = true,
						["event"] = "Action Usable",
						["use_sourceFlags2"] = false,
						["realSpellName"] = "吞噬魔法",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_sourceUnit"] = true,
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["sourceUnit"] = "player",
						["use_unit"] = true,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [3]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "grow",
					["easeStrength"] = 3,
				},
			},
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 26,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
			},
			["height"] = 65.77757263183594,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["selfPoint"] = "CENTER",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["icon"] = true,
			["frameStrata"] = 9,
			["zoom"] = 0,
			["auto"] = true,
			["anchorFrameType"] = "SCREEN",
			["id"] = "狗吃魔法",
			["uid"] = "(hSfTboX8(s",
			["alpha"] = 1,
			["width"] = 65.77791595458984,
			["authorOptions"] = {
			},
			["config"] = {
			},
			["inverse"] = false,
			["cooldownTextDisabled"] = false,
			["conditions"] = {
			},
			["cooldown"] = true,
			["xOffset"] = -225.777587890625,
		},
		["开黑魂 4"] = {
			["user_y"] = 0,
			["user_x"] = 0,
			["color"] = {
			},
			["yOffset"] = 297.7774505615234,
			["anchorPoint"] = "CENTER",
			["desaturateBackground"] = false,
			["sameTexture"] = true,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["track"] = "auto",
						["use_totemNamePattern"] = true,
						["duration"] = "1",
						["totemNamePattern"] = "地狱火",
						["use_unit"] = true,
						["remaining"] = "3",
						["names"] = {
						},
						["remaining_operator"] = ">=",
						["spellName"] = 113858,
						["debuffType"] = "HELPFUL",
						["use_remaining"] = true,
						["subeventSuffix"] = "_CAST_START",
						["unevent"] = "auto",
						["genericShowOn"] = "showOnReady",
						["use_genericShowOn"] = true,
						["event"] = "Cooldown Progress (Spell)",
						["use_exact_spellName"] = false,
						["realSpellName"] = "黑暗灵魂：动荡",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["type"] = "status",
						["use_absorbMode"] = true,
						["unit"] = "player",
						["use_track"] = true,
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_totemNamePattern"] = true,
						["remaining_operator"] = ">",
						["totemNamePattern"] = "地狱火",
						["use_unit"] = true,
						["remaining"] = "8",
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["use_remaining"] = true,
						["powertype"] = 7,
						["unevent"] = "auto",
						["power_operator"] = ">=",
						["power"] = "2",
						["event"] = "Power",
						["use_power"] = true,
						["use_totemName"] = false,
						["subeventSuffix"] = "_CAST_START",
						["type"] = "status",
						["use_absorbMode"] = true,
						["duration"] = "1",
						["use_inverse"] = false,
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["xOffset"] = 38.85113525390625,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						0.05882352941176471, -- [2]
						0.06666666666666667, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_text_format_p_time_precision"] = 1,
					["text_shadowYOffset"] = 0,
					["text_visible"] = false,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "MONOCHROME|THICKOUTLINE",
					["text_anchorPoint"] = "CENTER",
					["text_text_format_p_format"] = "timed",
					["text_text_format_n_format"] = "none",
					["text_fontSize"] = 40,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [1]
			},
			["height"] = 65.21068572998047,
			["load"] = {
				["use_class"] = true,
				["use_spec"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorOptions"] = {
			},
			["useAdjustededMax"] = false,
			["textureWrapMode"] = "CLAMP",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura52",
			["conditions"] = {
			},
			["crop_y"] = 0.41,
			["mirror"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "progresstexture",
			["startAngle"] = 0,
			["blendMode"] = "BLEND",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["uid"] = "X9bcEaypd4d",
			["slantMode"] = "INSIDE",
			["width"] = 55.38860321044922,
			["alpha"] = 1,
			["backgroundColor"] = {
				0.3058823529411765, -- [1]
				0.3176470588235294, -- [2]
				0.3019607843137255, -- [3]
				0.4000000357627869, -- [4]
			},
			["foregroundColor"] = {
				1, -- [1]
				0.2392156862745098, -- [2]
				0.7725490196078432, -- [3]
				1, -- [4]
			},
			["compress"] = false,
			["id"] = "开黑魂 4",
			["desaturateForeground"] = false,
			["frameStrata"] = 8,
			["anchorFrameType"] = "SCREEN",
			["fontSize"] = 12,
			["config"] = {
			},
			["inverse"] = false,
			["parent"] = "毁灭ss",
			["orientation"] = "VERTICAL",
			["crop_x"] = 0.44,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["backgroundOffset"] = 0,
		},
		["补邪恶污染"] = {
			["authorOptions"] = {
			},
			["yOffset"] = -26,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["rem"] = "2",
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["subeventPrefix"] = "SPELL",
						["ownOnly"] = true,
						["debuffType"] = "HARMFUL",
						["useName"] = true,
						["type"] = "status",
						["unit"] = "target",
						["unevent"] = "auto",
						["matchesShowOn"] = "showOnMissing",
						["duration"] = "1",
						["event"] = "Action Usable",
						["spellName"] = 278350,
						["realSpellName"] = "邪恶污染",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["names"] = {
						},
						["remOperator"] = "<=",
						["subeventSuffix"] = "_CAST_START",
						["use_track"] = true,
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["powertype"] = 7,
						["use_powertype"] = true,
						["spellName"] = 0,
						["type"] = "status",
						["unevent"] = "auto",
						["power_operator"] = ">",
						["event"] = "Power",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["power"] = "1",
						["use_power"] = true,
						["use_genericShowOn"] = true,
						["use_unit"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function (t)\n    return (t[1] or  t[2])  and t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["duration"] = ".66",
					["colorB"] = 1,
					["colorG"] = 1,
					["use_translate"] = true,
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["scaleType"] = "straightScale",
					["type"] = "custom",
					["easeStrength"] = 3,
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["preset"] = "grow",
					["alpha"] = 0,
					["translateType"] = "straightTranslate",
					["y"] = -200,
					["x"] = -200,
					["colorA"] = 1,
					["scaley"] = 5,
					["duration_type"] = "seconds",
					["rotate"] = 0,
					["use_scale"] = true,
					["scalex"] = 5,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 50,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						[3] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura45",
			["uid"] = "hmewbA4JdPM",
			["frameStrata"] = 7,
			["width"] = 50,
			["id"] = "补邪恶污染",
			["color"] = {
				0.00392156862745098, -- [1]
				0.1137254901960784, -- [2]
				0.01568627450980392, -- [3]
				1, -- [4]
			},
			["alpha"] = 0.93,
			["anchorFrameType"] = "SCREEN",
			["parent"] = "DOTS",
			["config"] = {
			},
			["selfPoint"] = "CENTER",
			["xOffset"] = 77,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["discrete_rotation"] = 0,
		},
		["毁灭ss"] = {
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["controlledChildren"] = {
				"浩劫提醒", -- [1]
				"地狱火", -- [2]
				"1发快速", -- [3]
				"2发快速", -- [4]
				"大灾变献祭", -- [5]
				"开黑魂", -- [6]
				"开黑魂 4", -- [7]
				"开地狱火", -- [8]
				"急速触发快速", -- [9]
				"暗灼2发", -- [10]
				"暗灼1", -- [11]
				"燃烧层满", -- [12]
				"统御层数", -- [13]
				"虚空守卫2发", -- [14]
				"补燃烧搓2发", -- [15]
				"补献祭了", -- [16]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["authorOptions"] = {
			},
			["border"] = false,
			["yOffset"] = 7.111328125,
			["regionType"] = "group",
			["borderSize"] = 2,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["unit"] = "player",
						["spellIds"] = {
						},
						["buffShowOn"] = "showOnActive",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = 1,
			},
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["talent3"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["borderOffset"] = 4,
			["borderEdge"] = "Square Full White",
			["selfPoint"] = "BOTTOMLEFT",
			["id"] = "毁灭ss",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["internalVersion"] = 40,
			["config"] = {
			},
			["uid"] = "lIoTPF91fhO",
			["borderInset"] = 1,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
				["groupOffset"] = true,
			},
			["xOffset"] = 2.666748046875,
		},
		["hp"] = {
			["sparkWidth"] = 10,
			["sparkOffsetX"] = 0,
			["xOffset"] = 0,
			["yOffset"] = -47.88873291015625,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_showAbsorb"] = true,
						["use_absorbMode"] = true,
						["use_absorb"] = false,
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["use_health"] = false,
						["unevent"] = "auto",
						["percenthealth"] = "83",
						["event"] = "Health",
						["subeventSuffix"] = "_CAST_START",
						["use_showIncomingHeal"] = true,
						["unit"] = "player",
						["spellIds"] = {
						},
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["use_percenthealth"] = true,
						["percenthealth_operator"] = "<=",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0.4666666666666667, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["subRegions"] = {
				{
					["type"] = "aurabar_bar",
				}, -- [1]
			},
			["height"] = 11,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["zoom"] = 0,
			["iconSource"] = -1,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["icon"] = false,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["icon_side"] = "RIGHT",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkHeight"] = 30,
			["texture"] = "MaUI 7",
			["config"] = {
			},
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["alpha"] = 0.73,
			["sparkHidden"] = "NEVER",
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 1,
			["width"] = 200,
			["id"] = "hp",
			["uid"] = "SiinhjaCsy(",
			["inverse"] = false,
			["authorOptions"] = {
			},
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["information"] = {
			},
			["parent"] = "SS通用",
		},
		["Infernal Timer #4"] = {
			["iconSource"] = 0,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["preferToUpdate"] = false,
			["customText"] = "",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Afenar_Warlock/88",
			["actions"] = {
				["start"] = {
					["do_glow"] = false,
				},
				["finish"] = {
					["do_glow"] = false,
					["sound"] = "Interface\\Addons\\MikScrollingBattleText\\Sounds\\Cooldown.ogg",
					["do_sound"] = false,
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["totemType"] = 4,
						["duration"] = "1",
						["event"] = "Totem",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["spellIds"] = {
						},
						["names"] = {
						},
						["use_unit"] = true,
						["unit"] = "player",
						["use_totemType"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						0.4352941176470588, -- [1]
						1, -- [2]
						0.3686274509803922, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_shadowYOffset"] = 5,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_TOP",
					["text_fontSize"] = 64,
					["anchorXOffset"] = 0,
					["text_fontType"] = "THICKOUTLINE",
				}, -- [1]
			},
			["height"] = 77,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["role"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["size"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_vehicle"] = false,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[2] = true,
						[3] = true,
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["faction"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["use_vehicleUi"] = false,
				["race"] = {
					["multi"] = {
					},
				},
				["spellknown"] = 1122,
				["use_petbattle"] = false,
			},
			["authorMode"] = true,
			["width"] = 77,
			["useTooltip"] = false,
			["stickyDuration"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "fade",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["easeType"] = "none",
					["preset"] = "fade",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["regionType"] = "icon",
			["displayIcon"] = 136219,
			["cooldownEdge"] = false,
			["authorOptions"] = {
			},
			["uid"] = "5VSDmnqWhdp",
			["alpha"] = 1,
			["icon"] = true,
			["zoom"] = 0.3,
			["auto"] = false,
			["tocversion"] = 80205,
			["id"] = "Infernal Timer #4",
			["semver"] = "2.2.2",
			["frameStrata"] = 4,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["xOffset"] = 0,
			["conditions"] = {
			},
			["cooldown"] = true,
			["parent"] = "Infernal Timer ",
		},
		["补腐蚀"] = {
			["xOffset"] = 73,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["useName"] = true,
						["useRem"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["ownOnly"] = true,
						["event"] = "Health",
						["names"] = {
						},
						["unit"] = "target",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["matchesShowOn"] = "showOnMissing",
						["remOperator"] = "<=",
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["rem"] = "2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["rem"] = "5",
						["auranames"] = {
							"腐蚀术", -- [1]
						},
						["totalOperator"] = ">",
						["matchesShowOn"] = "showOnActive",
						["unit"] = "target",
						["debuffType"] = "HARMFUL",
						["useName"] = true,
						["subeventSuffix"] = "_CAST_START",
						["useTotal"] = true,
						["event"] = "Health",
						["total"] = "10",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["ownOnly"] = true,
						["remOperator"] = "<=",
						["type"] = "aura2",
						["names"] = {
						},
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "function (t)\n    return (t[1] or  t[2])  and t[3]\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["use_rotate"] = false,
					["duration_type"] = "seconds",
					["duration"] = ".66",
					["alphaType"] = "hide",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "function()\n    return 0\nend\n",
					["rotateType"] = "wobble",
					["rotateFunc"] = "function(progress, start, delta)\n    local angle = progress * 2 * math.pi\n    return start + math.sin(angle) * delta\nend\n",
					["use_translate"] = true,
					["use_alpha"] = false,
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["type"] = "custom",
					["translateType"] = "straightTranslate",
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["preset"] = "slideright",
					["alpha"] = 0,
					["scaleType"] = "straightScale",
					["y"] = -200,
					["x"] = -200,
					["colorA"] = 1,
					["scaley"] = 5,
					["rotate"] = 333,
					["easeStrength"] = 3,
					["scalex"] = 5,
					["use_scale"] = true,
				},
				["main"] = {
					["colorR"] = 1,
					["use_rotate"] = false,
					["use_scale"] = true,
					["duration"] = "0.66",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\nend\n",
					["colorB"] = 1,
					["colorG"] = 1,
					["rotateFunc"] = "function(progress, start, delta)\n    local prog\n    if(progress < 0.25) then\n        prog = progress * 4\n    elseif(progress < .75) then\n        prog = 2 - (progress * 4)\n    else\n        prog = (progress - 1) * 4\n    end\n    return start + (prog * delta)\nend\n",
					["rotate"] = 0,
					["translateType"] = "straightTranslate",
					["use_translate"] = false,
					["rotateType"] = "backandforth",
					["colorType"] = "straightHSV",
					["type"] = "custom",
					["use_color"] = false,
					["easeType"] = "none",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["preset"] = "pulse",
					["alpha"] = 0,
					["scaleType"] = "pulse",
					["y"] = -55,
					["x"] = 60,
					["scaley"] = 1.6,
					["colorA"] = 1,
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    return WeakAuras.GetHSVTransition(progress, r1, g1, b1, a1, r2, g2, b2, a2)\nend\n",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["scalex"] = 1.6,
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 50,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						[3] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura45",
			["parent"] = "DOTS",
			["discrete_rotation"] = 0,
			["anchorFrameType"] = "SCREEN",
			["id"] = "补腐蚀",
			["authorOptions"] = {
			},
			["frameStrata"] = 7,
			["width"] = 50,
			["color"] = {
				0.1098039215686275, -- [1]
				1, -- [2]
				0.6666666666666666, -- [3]
				1, -- [4]
			},
			["config"] = {
			},
			["uid"] = "QMWExv1pQb0",
			["selfPoint"] = "CENTER",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["alpha"] = 0.93,
		},
		["燃烧层满"] = {
			["parent"] = "毁灭ss",
			["yOffset"] = 263.7776794433594,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["unit"] = "player",
						["powertype"] = 7,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["subeventPrefix"] = "SPELL",
						["power"] = "1.33",
						["power_operator"] = ">",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Power",
						["use_percentpower"] = false,
						["use_unit"] = true,
						["unevent"] = "auto",
						["spellIds"] = {
						},
						["names"] = {
						},
						["use_power"] = true,
						["duration"] = "1",
						["percentpower"] = "32",
						["percentpower_operator"] = ">=",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["genericShowOn"] = "showAlways",
						["unit"] = "player",
						["remaining"] = "0.2",
						["spellName"] = 17962,
						["charges_operator"] = ">=",
						["charges"] = "2",
						["use_unit"] = true,
						["subeventSuffix"] = "_CAST_START",
						["remaining_operator"] = "<",
						["subeventPrefix"] = "SPELL",
						["event"] = "Cooldown Progress (Spell)",
						["duration"] = "1",
						["realSpellName"] = "燃烧",
						["use_spellName"] = true,
						["unevent"] = "auto",
						["type"] = "status",
						["use_remaining"] = false,
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["use_charges"] = true,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeType"] = "none",
					["easeStrength"] = 3,
					["preset"] = "bounceDecay",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 120.7778625488281,
			["rotate"] = true,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "450915",
			["uid"] = "RzPF6M2bPVY",
			["selfPoint"] = "CENTER",
			["frameStrata"] = 6,
			["id"] = "燃烧层满",
			["authorOptions"] = {
			},
			["alpha"] = 0.88,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 71.5557861328125,
			["config"] = {
			},
			["width"] = 130.555419921875,
			["color"] = {
				1, -- [1]
				0.6549019607843137, -- [2]
				0.3843137254901961, -- [3]
				0.75, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 264,
		},
		["Infernal Timer #2"] = {
			["iconSource"] = 0,
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["customText"] = "",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Afenar_Warlock/88",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["totemType"] = 2,
						["duration"] = "1",
						["event"] = "Totem",
						["subeventPrefix"] = "SPELL",
						["unevent"] = "auto",
						["use_absorbMode"] = true,
						["spellIds"] = {
						},
						["names"] = {
						},
						["use_unit"] = true,
						["unit"] = "player",
						["use_totemType"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["useTooltip"] = false,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						0.4352941176470588, -- [1]
						1, -- [2]
						0.3686274509803922, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_shadowYOffset"] = 5,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "THICKOUTLINE",
					["text_anchorPoint"] = "INNER_TOP",
					["text_fontSize"] = 64,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [1]
			},
			["height"] = 77,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["role"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["size"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_vehicle"] = false,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[2] = true,
						[3] = true,
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["use_vehicleUi"] = false,
				["race"] = {
					["multi"] = {
					},
				},
				["spellknown"] = 1122,
				["use_petbattle"] = false,
			},
			["authorMode"] = true,
			["width"] = 77,
			["stickyDuration"] = false,
			["actions"] = {
				["start"] = {
					["do_glow"] = false,
				},
				["finish"] = {
					["do_glow"] = false,
					["sound"] = "Interface\\Addons\\MikScrollingBattleText\\Sounds\\Cooldown.ogg",
					["do_sound"] = false,
				},
				["init"] = {
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "fade",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["easeType"] = "none",
					["preset"] = "fade",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["regionType"] = "icon",
			["displayIcon"] = 136219,
			["internalVersion"] = 40,
			["cooldownEdge"] = false,
			["uid"] = "NiOlq8j4mhZ",
			["alpha"] = 1,
			["xOffset"] = 0,
			["zoom"] = 0.3,
			["semver"] = "2.2.2",
			["tocversion"] = 80205,
			["id"] = "Infernal Timer #2",
			["auto"] = false,
			["frameStrata"] = 4,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["cooldown"] = true,
			["parent"] = "Infernal Timer ",
		},
		["魔甲术"] = {
			["iconSource"] = -1,
			["xOffset"] = 2.6668701171875,
			["yOffset"] = 241.7777404785156,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["itemName"] = 5512,
						["use_count"] = true,
						["auranames"] = {
							"爆燃冲刺", -- [1]
						},
						["duration"] = "1",
						["unit"] = "player",
						["use_includeCharges"] = true,
						["debuffType"] = "HELPFUL",
						["use_absorbMode"] = true,
						["type"] = "status",
						["names"] = {
						},
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["use_itemName"] = true,
						["event"] = "Action Usable",
						["count"] = "1",
						["realSpellName"] = "魔甲术",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_unit"] = true,
						["useName"] = true,
						["spellName"] = 285933,
						["subeventPrefix"] = "SPELL",
						["count_operator"] = "<",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"魔甲术", -- [1]
						},
						["unit"] = "player",
						["matchesShowOn"] = "showOnMissing",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowXOffset"] = 0,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glow"] = false,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 58.6668701171875,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["cooldownTextDisabled"] = false,
			["cooldown"] = false,
			["parent"] = "SS通用",
			["zoom"] = 0,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["anchorFrameType"] = "SCREEN",
			["id"] = "魔甲术",
			["config"] = {
			},
			["frameStrata"] = 1,
			["width"] = 58.66664123535156,
			["alpha"] = 1,
			["uid"] = "8UFd)HdAV5d",
			["inverse"] = false,
			["authorOptions"] = {
			},
			["conditions"] = {
			},
			["information"] = {
			},
			["icon"] = true,
		},
		["灵魂碎片4"] = {
			["parent"] = "灵魂碎片1 Group",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_showAbsorb"] = false,
						["use_incombat"] = true,
						["subeventPrefix"] = "SPELL",
						["percenthealth_operator"] = "<=",
						["use_power"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["duration"] = "1",
						["powertype"] = 7,
						["names"] = {
						},
						["power"] = "4",
						["health"] = "43",
						["subeventSuffix"] = "_CAST_START",
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["unevent"] = "auto",
						["type"] = "status",
						["use_health"] = false,
						["health_operator"] = "<=",
						["power_operator"] = ">=",
						["percenthealth"] = "43",
						["event"] = "Power",
						["use_unit"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["spellName"] = 0,
						["use_absorbMode"] = true,
						["use_percenthealth"] = true,
						["use_track"] = true,
						["use_genericShowOn"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 43,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_AlphaGradient_Out.tga",
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "slideright",
					["easeStrength"] = 3,
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
			},
			["discrete_rotation"] = 0,
			["frameStrata"] = 1,
			["id"] = "灵魂碎片4",
			["xOffset"] = 0,
			["alpha"] = 1,
			["width"] = 43,
			["color"] = {
				0.7058823529411764, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["config"] = {
			},
			["anchorFrameType"] = "SCREEN",
			["uid"] = "HOGYdkpeC4n",
			["conditions"] = {
			},
			["information"] = {
			},
			["authorOptions"] = {
			},
		},
		["OmniBuds Nameplate Retail"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 160,
			["gridType"] = "DR",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["useAnchorPerUnit"] = true,
			["url"] = "https://wago.io/xCC0qe6Lp/1",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 5,
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["align"] = "CENTER",
			["gridWidth"] = 5,
			["stagger"] = 0,
			["limit"] = 5,
			["version"] = 1,
			["subRegions"] = {
			},
			["grow"] = "RIGHT",
			["space"] = 2,
			["load"] = {
				["use_class"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["fullCircle"] = true,
			["animate"] = false,
			["rotation"] = 0,
			["scale"] = 1,
			["useLimit"] = false,
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["sort"] = "none",
			["borderInset"] = 1,
			["config"] = {
			},
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 15,
			["borderOffset"] = 4,
			["semver"] = "1.0.0",
			["tocversion"] = 90002,
			["id"] = "OmniBuds Nameplate Retail",
			["authorOptions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["anchorPerUnit"] = "NAMEPLATE",
			["uid"] = "6HVaoZYu(oI",
			["anchorPoint"] = "CENTER",
			["groupIcon"] = 132349,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["radius"] = 200,
		},
		["虚空守卫2发"] = {
			["color"] = {
				1, -- [1]
				0.7568627450980392, -- [2]
				0, -- [3]
				0.75, -- [4]
			},
			["yOffset"] = 270,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["unit"] = "player",
						["powertype"] = 7,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["unevent"] = "auto",
						["power_operator"] = ">=",
						["event"] = "Power",
						["use_unit"] = true,
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["duration"] = "1",
						["power"] = "3.8",
						["use_power"] = true,
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["useName"] = true,
						["useStacks"] = true,
						["auranames"] = {
							"爆燃", -- [1]
						},
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
						["unit"] = "player",
						["stacks"] = "2",
						["spellIds"] = {
						},
						["type"] = "aura2",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["stacksOperator"] = ">=",
						["buffShowOn"] = "showOnActive",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnReady",
						["unit"] = "player",
						["remaining"] = "0",
						["spellName"] = 212295,
						["use_remaining"] = true,
						["unevent"] = "auto",
						["use_spellCount"] = false,
						["event"] = "Action Usable",
						["realSpellName"] = "虚空守卫",
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["useName"] = false,
						["remaining_operator"] = "==",
						["use_track"] = true,
						["duration"] = "1",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [3]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "fade",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 317,
			["rotate"] = true,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorMode"] = true,
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "1029139",
			["alpha"] = 0.9500000000000001,
			["parent"] = "毁灭ss",
			["selfPoint"] = "CENTER",
			["id"] = "虚空守卫2发",
			["authorOptions"] = {
			},
			["frameStrata"] = 4,
			["width"] = 302,
			["config"] = {
			},
			["uid"] = "3V6QDNsTahG",
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 130,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["Change Focus"] = {
			["outline"] = "OUTLINE",
			["iconSource"] = 0,
			["authorOptions"] = {
			},
			["displayText"] = "CHANGE FOCUS！\n",
			["shadowYOffset"] = -1,
			["displayText_format_p_time_dynamic"] = false,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/UVsQmiaHX/1",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["spellId"] = "Création d’un puits des âmes",
						["duration"] = "20",
						["use_spell"] = true,
						["group_count"] = "0",
						["use_petspec"] = false,
						["group_countOperator"] = ">=",
						["use_health"] = false,
						["subeventSuffix"] = "_CAST_SUCCESS",
						["percenthealth"] = "33",
						["event"] = "Action Usable",
						["use_behavior"] = false,
						["use_spellId"] = false,
						["use_track"] = true,
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "pet",
						["use_genericShowOn"] = true,
						["use_HasPet"] = false,
						["use_mounted"] = false,
						["use_unit"] = true,
						["type"] = "status",
						["use_percenthealth"] = true,
						["unevent"] = "auto",
						["use_vehicle"] = false,
						["spellName"] = 132409,
						["subeventPrefix"] = "SPELL",
						["names"] = {
							"Puits des âmes", -- [1]
						},
						["realSpellName"] = "法术封锁",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["debuffType"] = "HELPFUL",
						["spell"] = "Création d’un puits des âmes",
						["use_alive"] = true,
						["percenthealth_operator"] = "<=",
						["namerealm"] = "Création d’un puits des âmes",
					},
					["untrigger"] = {
						["unit"] = "pet",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["debuffType"] = "HELPFUL",
						["unevent"] = "auto",
						["remaining"] = "5",
						["remaining_operator"] = "<=",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "法术封锁",
						["use_spellName"] = true,
						["use_remaining"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_genericShowOn"] = true,
						["duration"] = "1",
						["use_track"] = true,
						["spellName"] = 132409,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["use_specId"] = false,
						["use_unitisunit"] = false,
						["use_hostility"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "focus",
						["use_class"] = false,
						["powertype"] = 0,
						["use_unit"] = true,
						["spellName"] = 0,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["class"] = "DRUID",
						["type"] = "status",
						["use_level"] = false,
						["unevent"] = "auto",
						["power_operator"] = "<=",
						["specId"] = {
						},
						["event"] = "Power",
						["use_requirePowerType"] = false,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["use_genericShowOn"] = true,
						["use_power"] = true,
						["power"] = "0",
						["classification"] = {
						},
						["use_track"] = true,
						["use_character"] = false,
					},
					["untrigger"] = {
						["unit"] = "focus",
					},
				}, -- [3]
				{
					["trigger"] = {
						["use_specId"] = false,
						["use_unitisunit"] = false,
						["use_hostility"] = false,
						["duration"] = "1",
						["use_character"] = false,
						["unit"] = "focus",
						["use_class"] = true,
						["powertype"] = 0,
						["class"] = "DRUID",
						["spellName"] = 0,
						["use_powertype"] = false,
						["debuffType"] = "HELPFUL",
						["genericShowOn"] = "showOnCooldown",
						["classification"] = {
						},
						["use_level"] = false,
						["unevent"] = "auto",
						["power_operator"] = ">",
						["power"] = "0",
						["event"] = "Power",
						["use_power"] = false,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["use_genericShowOn"] = true,
						["use_requirePowerType"] = false,
						["specId"] = {
						},
						["type"] = "status",
						["use_track"] = true,
						["use_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "focus",
					},
				}, -- [4]
				{
					["trigger"] = {
						["use_specId"] = false,
						["use_unitisunit"] = false,
						["use_hostility"] = false,
						["class"] = "PRIEST",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "focus",
						["use_class"] = true,
						["powertype"] = 0,
						["duration"] = "1",
						["spellName"] = 0,
						["use_powertype"] = false,
						["debuffType"] = "HELPFUL",
						["use_character"] = false,
						["type"] = "status",
						["use_level"] = false,
						["unevent"] = "auto",
						["power_operator"] = ">",
						["classification"] = {
						},
						["event"] = "Power",
						["specId"] = {
						},
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["use_requirePowerType"] = false,
						["use_genericShowOn"] = true,
						["use_power"] = true,
						["power"] = "0",
						["use_track"] = true,
						["use_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "focus",
					},
				}, -- [5]
				{
					["trigger"] = {
						["use_specId"] = false,
						["use_unitisunit"] = false,
						["use_hostility"] = false,
						["duration"] = "1",
						["use_character"] = false,
						["use_unit"] = true,
						["use_class"] = true,
						["powertype"] = 0,
						["class"] = "SHAMAN",
						["genericShowOn"] = "showOnCooldown",
						["use_powertype"] = false,
						["debuffType"] = "HELPFUL",
						["spellName"] = 0,
						["type"] = "status",
						["use_level"] = false,
						["power"] = "0",
						["power_operator"] = ">",
						["unevent"] = "auto",
						["event"] = "Power",
						["use_power"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["use_genericShowOn"] = true,
						["use_requirePowerType"] = false,
						["specId"] = {
						},
						["classification"] = {
						},
						["use_track"] = true,
						["unit"] = "focus",
					},
					["untrigger"] = {
						["unit"] = "focus",
					},
				}, -- [6]
				{
					["trigger"] = {
						["use_specId"] = false,
						["use_unitisunit"] = false,
						["use_hostility"] = false,
						["class"] = "MAGE",
						["genericShowOn"] = "showOnCooldown",
						["use_unit"] = true,
						["use_class"] = true,
						["powertype"] = 0,
						["duration"] = "1",
						["debuffType"] = "HELPFUL",
						["use_powertype"] = false,
						["spellName"] = 0,
						["use_character"] = false,
						["classification"] = {
						},
						["use_level"] = false,
						["power"] = "0",
						["power_operator"] = ">",
						["type"] = "status",
						["event"] = "Power",
						["specId"] = {
						},
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["use_requirePowerType"] = false,
						["use_genericShowOn"] = true,
						["use_power"] = true,
						["unevent"] = "auto",
						["use_track"] = true,
						["unit"] = "focus",
					},
					["untrigger"] = {
						["unit"] = "focus",
					},
				}, -- [7]
				{
					["trigger"] = {
						["use_specId"] = false,
						["use_unitisunit"] = false,
						["use_hostility"] = false,
						["class"] = "PRIEST",
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "focus",
						["use_class"] = true,
						["powertype"] = 0,
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
						["use_powertype"] = false,
						["spellName"] = 0,
						["use_power"] = true,
						["classification"] = {
						},
						["use_level"] = false,
						["unevent"] = "auto",
						["power_operator"] = ">",
						["use_genericShowOn"] = true,
						["event"] = "Power",
						["use_requirePowerType"] = false,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["specId"] = {
						},
						["type"] = "status",
						["power"] = "0",
						["use_character"] = false,
						["use_track"] = true,
						["duration"] = "1",
					},
					["untrigger"] = {
						["unit"] = "focus",
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom"] = "\nfunction()\n    \n    if not  UnitExists(\"focus\") then \n        return false\n    end \n    \n    \n    local count = 0\n    for i = 1, 40 do\n        local unit = \"nameplate\"..i\n        if UnitExists(unit) then \n            -- local plateFrame = C_NamePlate.GetNamePlateForUnit (unit, issecure())\n            \n            -- plateFrame:SetPoint(\"CENTER\", UIParent, \"CENTER\", 0, -150);\n            \n            -- plateFrame:SetScale(10)\n            print(aura_env.canKick(unit))\n            \n            if \n            UnitCanAttack(\"player\", unit)\n            and UnitPlayerControlled(unit)\n            and WeakAuras.CheckRange(unit, 41, \"<=\")\n            and aura_env.canKick(unit)\n            then\n                count = count + 1\n            end\n        end\n    end\n    \n    \n    return ( count > 0) and  not aura_env.canKick(\"focus\")\nend\n\n\n\n",
						["custom_type"] = "stateupdate",
						["check"] = "event",
						["debuffType"] = "HELPFUL",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [9]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function (t)\n    return  (t[1] or  t[2]) and  t[3] and not t[4] and not t[5] and not t[6] and not t[7] and not t[8]\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["duration_type"] = "seconds",
					["alphaType"] = "straight",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "function(progress, start, delta)\n    return start + (progress * delta)\nend\n",
					["duration"] = ".66",
					["use_translate"] = true,
					["use_alpha"] = false,
					["scalex"] = 1,
					["type"] = "custom",
					["easeStrength"] = 3,
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["use_color"] = false,
					["alpha"] = 0,
					["x"] = 155,
					["y"] = -200,
					["colorType"] = "pulseHSV",
					["scaley"] = 1,
					["colorA"] = 1,
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    local newProgress = ((math.sin(angle) + 1)/2);\n    return WeakAuras.GetHSVTransition(newProgress, r1, g1, b1, a1, r2, g2, b2, a2)\nend\n",
					["rotate"] = 0,
					["preset"] = "fade",
					["translateType"] = "straightTranslate",
				},
				["main"] = {
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["scalex"] = 1,
					["alphaType"] = "straight",
					["colorA"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["duration_type"] = "seconds",
					["colorB"] = 1,
					["use_alpha"] = false,
					["rotate"] = 0,
					["scaleType"] = "pulse",
					["use_scale"] = false,
					["easeType"] = "none",
					["preset"] = "alphaPulse",
					["scaley"] = 1,
					["alpha"] = 0,
					["x"] = 0,
					["y"] = 0,
					["colorType"] = "straightHSV",
					["duration"] = "5",
					["use_color"] = true,
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    return WeakAuras.GetHSVTransition(progress, r1, g1, b1, a1, r2, g2, b2, a2)\nend\n",
					["easeStrength"] = 3,
					["type"] = "preset",
					["colorR"] = 1,
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
			},
			["auto"] = false,
			["stickyDuration"] = false,
			["anchorPoint"] = "CENTER",
			["font"] = "默认",
			["version"] = 1,
			["subRegions"] = {
			},
			["height"] = 55,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["load"] = {
				["ingroup"] = {
					["single"] = "raid",
					["multi"] = {
						["raid"] = true,
					},
				},
				["use_size"] = false,
				["affixes"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
						["WARLOCK"] = true,
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						true, -- [1]
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["talent3"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["use_encounter"] = false,
				["size"] = {
					["single"] = "pvp",
					["multi"] = {
						["pvp"] = true,
						["none"] = true,
					},
				},
			},
			["displayIcon"] = 132163,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["do_custom"] = true,
					["custom"] = "aura_env.SpecList = { --private\n    \n    [105] = true, -->  druid resto\n    [270] = true, --> monk mw\n    [65] = true, --> paladin holy\n    [256] = true,  --> priest disc\n    [257] = true,  --> priest holy\n    [264] = true, --> shaman resto  \n    \n    -- [\"WARLOCK\"] = {\n    [265] = true,\n    [266] = true,\n    [267] = true,\n    -- },\n    -- [\"MAGE\"] = {\n    [62] = true,\n    [63] = true,\n    [64] = true,\n    --},\n    -- [\"DRUID\"] = {\n    [102] = true,\n    -- [103] = true,\n    \n    [258] = true,\n    -- },\n    -- [\"HUNTER\"] = {\n    --     [253] = true,\n    --     [254] = true,        \n    --     [255] = true,\n    -- },\n    -- [\"SHAMAN\"] = {\n    [262] = true,\n    -- [263] = true,   \n}\n\naura_env.canKick = function(unit)\n    local Details = Details \n    \n    local guid = UnitGUID(unit)\n    -- print(\"UnitExists unit\",guid)    \n    if (Details and Details.realversion >= 134) then\n        local spec = Details:GetSpecByGUID (guid)\n        print(\"spec\",spec)\n        if (spec and aura_env.SpecList[spec]) then\n            return true \n        end\n    end  \n    \n    return false\nend",
				},
				["finish"] = {
				},
			},
			["fontSize"] = 72,
			["wordWrap"] = "WordWrap",
			["desaturate"] = false,
			["shadowXOffset"] = 1,
			["config"] = {
			},
			["parent"] = "SS通用",
			["width"] = 55,
			["regionType"] = "text",
			["frameStrata"] = 1,
			["justify"] = "LEFT",
			["selfPoint"] = "CENTER",
			["preferToUpdate"] = false,
			["displayText_format_p_time_precision"] = 1,
			["zoom"] = 0,
			["fixedWidth"] = 200,
			["cooldownTextDisabled"] = true,
			["semver"] = "1.0.0",
			["xOffset"] = -109.22216796875,
			["id"] = "Change Focus",
			["cooldownEdge"] = false,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["yOffset"] = 244.0004577636719,
			["uid"] = "jHs9FvOzD7t",
			["inverse"] = false,
			["automaticWidth"] = "Auto",
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["cooldown"] = true,
			["color"] = {
				1, -- [1]
				0, -- [2]
				0.04313725490196078, -- [3]
				1, -- [4]
			},
		},
		["0SPellLock G CASTING WARN"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"SpellsCast WARING", -- [1]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = -337.9999694824219,
			["gridType"] = "DR",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["space"] = -1,
			["url"] = "https://wago.io/OmniBudsNameplateRetail/6",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["event"] = "Health",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 5,
			["radius"] = 200,
			["selfPoint"] = "CENTER",
			["align"] = "CENTER",
			["frameStrata"] = 8,
			["stagger"] = 0,
			["limit"] = 5,
			["version"] = 6,
			["subRegions"] = {
			},
			["fullCircle"] = true,
			["internalVersion"] = 40,
			["load"] = {
				["use_class"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["groupIcon"] = 132349,
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["useLimit"] = false,
			["animate"] = false,
			["rotation"] = 0,
			["scale"] = 1,
			["rowSpace"] = 15,
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["anchorPerUnit"] = "CUSTOM",
			["config"] = {
			},
			["sort"] = "none",
			["constantFactor"] = "RADIUS",
			["useAnchorPerUnit"] = false,
			["borderOffset"] = 4,
			["semver"] = "1.0.5",
			["tocversion"] = 80300,
			["id"] = "0SPellLock G CASTING WARN",
			["xOffset"] = -2.66607666015625,
			["gridWidth"] = 5,
			["anchorFrameType"] = "SCREEN",
			["borderInset"] = 1,
			["uid"] = "2dviSPV27Ta",
			["grow"] = "HORIZONTAL",
			["anchorPoint"] = "CENTER",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["灵魂碎片2"] = {
			["authorOptions"] = {
			},
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_showAbsorb"] = false,
						["use_incombat"] = true,
						["names"] = {
						},
						["percenthealth_operator"] = "<=",
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["powertype"] = 7,
						["duration"] = "1",
						["health_operator"] = "<=",
						["health"] = "43",
						["power"] = "2",
						["use_powertype"] = true,
						["spellName"] = 0,
						["unevent"] = "auto",
						["type"] = "status",
						["use_health"] = false,
						["subeventSuffix"] = "_CAST_START",
						["power_operator"] = ">=",
						["percenthealth"] = "43",
						["event"] = "Power",
						["use_unit"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["debuffType"] = "HELPFUL",
						["use_power"] = true,
						["use_percenthealth"] = true,
						["use_track"] = true,
						["use_genericShowOn"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "slideright",
					["easeStrength"] = 3,
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 43,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_AlphaGradient_Out.tga",
			["selfPoint"] = "CENTER",
			["color"] = {
				0.7058823529411764, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["frameStrata"] = 1,
			["id"] = "灵魂碎片2",
			["xOffset"] = 0,
			["alpha"] = 1,
			["width"] = 43,
			["parent"] = "灵魂碎片1 Group",
			["uid"] = "fIJHgfuQhqn",
			["anchorFrameType"] = "SCREEN",
			["config"] = {
			},
			["conditions"] = {
			},
			["information"] = {
			},
			["rotation"] = 0,
		},
		["FAST SPELL LOCK"] = {
			["outline"] = "OUTLINE",
			["iconSource"] = 0,
			["xOffset"] = -248.7774658203125,
			["preferToUpdate"] = false,
			["yOffset"] = 316.8897399902344,
			["displayText_format_p_time_dynamic"] = false,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/UVsQmiaHX/1",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["spellId"] = "Création d’un puits des âmes",
						["use_genericShowOn"] = true,
						["use_spell"] = true,
						["group_count"] = "0",
						["use_petspec"] = false,
						["group_countOperator"] = ">=",
						["namerealm"] = "Création d’un puits des âmes",
						["subeventSuffix"] = "_CAST_SUCCESS",
						["percenthealth"] = "33",
						["event"] = "Action Usable",
						["use_behavior"] = false,
						["use_spellId"] = false,
						["use_track"] = true,
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_unit"] = true,
						["spellName"] = 333889,
						["use_HasPet"] = false,
						["use_mounted"] = false,
						["spell"] = "Création d’un puits des âmes",
						["type"] = "status",
						["use_percenthealth"] = true,
						["unevent"] = "auto",
						["use_vehicle"] = false,
						["unit"] = "pet",
						["duration"] = "20",
						["names"] = {
							"Puits des âmes", -- [1]
						},
						["realSpellName"] = "邪能统御",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["use_alive"] = true,
						["percenthealth_operator"] = "<=",
						["use_health"] = false,
					},
					["untrigger"] = {
						["unit"] = "pet",
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["subeventPrefix"] = "",
						["remaining"] = "5",
						["debuffType"] = "HELPFUL",
						["use_remaining"] = true,
						["unevent"] = "auto",
						["event"] = "Cooldown Progress (Spell)",
						["remaining_operator"] = ">",
						["realSpellName"] = "恶魔掌控",
						["use_spellName"] = true,
						["type"] = "status",
						["subeventSuffix"] = "",
						["duration"] = "1",
						["unit"] = "player",
						["use_track"] = true,
						["spellName"] = 119898,
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["track"] = "auto",
						["auranames"] = {
							"牺牲魔典", -- [1]
						},
						["remaining_operator"] = ">",
						["genericShowOn"] = "showOnCooldown",
						["subeventPrefix"] = "",
						["remaining"] = "5",
						["use_HasPet"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "aura2",
						["subeventSuffix"] = "",
						["useName"] = true,
						["event"] = "Conditions",
						["spellName"] = 119898,
						["realSpellName"] = "恶魔掌控",
						["use_spellName"] = true,
						["duration"] = "1",
						["use_remaining"] = true,
						["unit"] = "player",
						["unevent"] = "auto",
						["use_track"] = true,
						["use_genericShowOn"] = true,
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "function (t) \n    return  (t[1] or  t[2])  and (  t[3]  and  t[4]) and t[5]\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
				["main"] = {
					["colorR"] = 1,
					["use_scale"] = false,
					["alphaType"] = "straight",
					["colorA"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["use_alpha"] = false,
					["type"] = "preset",
					["scalex"] = 1,
					["easeType"] = "none",
					["colorB"] = 1,
					["scaley"] = 1,
					["alpha"] = 0,
					["rotate"] = 0,
					["y"] = 0,
					["x"] = 0,
					["duration"] = "5",
					["preset"] = "alphaPulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["scaleType"] = "pulse",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
			},
			["auto"] = false,
			["desaturate"] = false,
			["authorOptions"] = {
			},
			["font"] = "默认",
			["version"] = 1,
			["subRegions"] = {
			},
			["height"] = 55,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["load"] = {
				["talent2"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
						["WARLOCK"] = true,
					},
				},
				["use_never"] = false,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						true, -- [1]
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["talent3"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["ingroup"] = {
					["single"] = "raid",
					["multi"] = {
						["raid"] = true,
					},
				},
				["size"] = {
					["single"] = "pvp",
					["multi"] = {
						["pvp"] = true,
					},
				},
			},
			["displayIcon"] = 132163,
			["shadowYOffset"] = -1,
			["fontSize"] = 37,
			["anchorPoint"] = "CENTER",
			["stickyDuration"] = false,
			["shadowXOffset"] = 1,
			["config"] = {
			},
			["selfPoint"] = "CENTER",
			["width"] = 55,
			["regionType"] = "text",
			["alpha"] = 1,
			["cooldownEdge"] = false,
			["wordWrap"] = "WordWrap",
			["color"] = {
				0.6823529411764706, -- [1]
				0.2392156862745098, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_time_precision"] = 1,
			["cooldownTextDisabled"] = true,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["zoom"] = 0,
			["semver"] = "1.0.0",
			["displayText"] = "FAST PET！\n",
			["id"] = "FAST SPELL LOCK",
			["justify"] = "LEFT",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["parent"] = "SS通用",
			["uid"] = "EDuNyEzRWvW",
			["inverse"] = false,
			["automaticWidth"] = "Auto",
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["cooldown"] = true,
			["fixedWidth"] = 200,
		},
		["补燃烧搓2发"] = {
			["parent"] = "毁灭ss",
			["yOffset"] = 264.6667175292969,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["powertype"] = 7,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["names"] = {
						},
						["unevent"] = "auto",
						["power_operator"] = ">=",
						["unit"] = "player",
						["event"] = "Power",
						["use_percentpower"] = false,
						["subeventPrefix"] = "SPELL",
						["power"] = "3.5",
						["spellIds"] = {
						},
						["duration"] = "1",
						["use_power"] = true,
						["subeventSuffix"] = "_CAST_START",
						["percentpower"] = "32",
						["percentpower_operator"] = ">=",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_charges"] = true,
						["genericShowOn"] = "showAlways",
						["unit"] = "player",
						["remaining"] = "0.2",
						["names"] = {
						},
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
						["spellName"] = 17962,
						["charges_operator"] = "==",
						["use_remaining"] = false,
						["duration"] = "1",
						["subeventSuffix"] = "_CAST_START",
						["charges"] = "1",
						["subeventPrefix"] = "SPELL",
						["event"] = "Cooldown Progress (Spell)",
						["unevent"] = "auto",
						["realSpellName"] = "燃烧",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["remaining_operator"] = "<",
						["use_genericShowOn"] = true,
						["type"] = "status",
						["use_track"] = true,
						["use_absorbMode"] = true,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeType"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["preset"] = "bounceDecay",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 119.0001831054688,
			["rotate"] = true,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "450915",
			["authorOptions"] = {
			},
			["selfPoint"] = "CENTER",
			["width"] = 122.555534362793,
			["id"] = "补燃烧搓2发",
			["color"] = {
				0.5254901960784314, -- [1]
				1, -- [2]
				0.8980392156862745, -- [3]
				0.75, -- [4]
			},
			["alpha"] = 0.78,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 72.00054931640625,
			["config"] = {
			},
			["rotation"] = 264,
			["uid"] = "t(No2Ivbs84",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["frameStrata"] = 6,
		},
		["门快好了"] = {
			["iconSource"] = -1,
			["authorOptions"] = {
			},
			["yOffset"] = 170.2226257324219,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_castType"] = false,
						["rem"] = "3",
						["auranames"] = {
							"恶魔传送门", -- [1]
						},
						["remaining_operator"] = "<=",
						["remaining"] = "4",
						["spellName"] = 30283,
						["use_debuffClass"] = false,
						["subeventSuffix"] = "_CAST_FAILED",
						["event"] = "Conditions",
						["use_sourceFlags2"] = false,
						["use_sourceUnit"] = true,
						["use_track"] = true,
						["use_destFlags2"] = false,
						["genericShowOn"] = "showOnCooldown",
						["names"] = {
						},
						["use_sourceFlags3"] = false,
						["debuffType"] = "HARMFUL",
						["ownOnly"] = true,
						["use_remaining"] = true,
						["useName"] = true,
						["unevent"] = "auto",
						["type"] = "aura2",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["duration"] = "1",
						["realSpellName"] = "暗影之怒",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_unit"] = true,
						["remOperator"] = "<=",
						["use_genericShowOn"] = true,
						["sourceUnit"] = "player",
						["useRem"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["preset"] = "grow",
				},
			},
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 26,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
			},
			["height"] = 25,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["parent"] = "SS通用",
			["icon"] = true,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["cooldownTextDisabled"] = false,
			["zoom"] = 0,
			["auto"] = true,
			["alpha"] = 1,
			["id"] = "门快好了",
			["config"] = {
			},
			["frameStrata"] = 9,
			["width"] = 25,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "eFnz8MYYmWO",
			["inverse"] = false,
			["xOffset"] = -48.88873291015625,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["selfPoint"] = "CENTER",
		},
		["灵魂碎片1"] = {
			["xOffset"] = 0,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_showAbsorb"] = false,
						["use_incombat"] = true,
						["use_absorbMode"] = true,
						["use_track"] = true,
						["use_power"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["use_genericShowOn"] = true,
						["powertype"] = 7,
						["names"] = {
						},
						["spellName"] = 0,
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["power"] = "1",
						["type"] = "status",
						["use_health"] = false,
						["unevent"] = "auto",
						["power_operator"] = ">=",
						["percenthealth"] = "43",
						["event"] = "Power",
						["use_unit"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["health"] = "43",
						["health_operator"] = "<=",
						["duration"] = "1",
						["use_percenthealth"] = true,
						["percenthealth_operator"] = "<=",
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "slideright",
					["easeStrength"] = 3,
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["duration_type"] = "seconds",
					["preset"] = "fade",
					["easeStrength"] = 3,
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 43,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_AlphaGradient_Out.tga",
			["uid"] = "50ic6GC253L",
			["color"] = {
				0.7058823529411764, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["anchorFrameType"] = "SCREEN",
			["id"] = "灵魂碎片1",
			["authorOptions"] = {
			},
			["frameStrata"] = 1,
			["width"] = 43,
			["parent"] = "灵魂碎片1 Group",
			["config"] = {
			},
			["selfPoint"] = "CENTER",
			["rotation"] = 0,
			["conditions"] = {
			},
			["information"] = {
			},
			["alpha"] = 1,
		},
		["统御层数"] = {
			["parent"] = "毁灭ss",
			["yOffset"] = 142.0426940917969,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["useStacks"] = true,
						["ownOnly"] = true,
						["subeventPrefix"] = "SPELL",
						["stacks"] = "1",
						["debuffType"] = "HELPFUL",
						["type"] = "aura2",
						["stacksOperator"] = ">=",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["buffShowOn"] = "showOnActive",
						["names"] = {
						},
						["spellIds"] = {
						},
						["matchesShowOn"] = "showOnActive",
						["namePattern_name"] = "统御魔",
						["useNamePattern"] = true,
						["unit"] = "player",
						["namePattern_operator"] = "find('%s')",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 1,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "CENTER",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 173,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						0.4156862745098039, -- [2]
						0.8901960784313725, -- [3]
						1, -- [4]
					},
					["text_font"] = "MSBT ARKai_C",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "MONOCHROME|THICKOUTLINE",
					["text_anchorPoint"] = "CENTER",
					["text_text_format_n_format"] = "none",
					["text_fontSize"] = 166,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [1]
			},
			["height"] = 315.0000305175781,
			["rotate"] = true,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMP",
			["mirror"] = true,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_Smooth2.tga",
			["uid"] = "0kGZOT)2TmU",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeType"] = "none",
					["easeStrength"] = 3,
					["preset"] = "bounceDecay",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["alpha"] = 0.8,
			["id"] = "统御层数",
			["xOffset"] = 152.1674194335938,
			["frameStrata"] = 4,
			["anchorFrameType"] = "SCREEN",
			["authorOptions"] = {
			},
			["config"] = {
			},
			["width"] = 329,
			["color"] = {
				1, -- [1]
				0.6627450980392157, -- [2]
				0.6274509803921569, -- [3]
				0.75, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["目标距离"] = {
			["glow"] = false,
			["text1FontSize"] = 15,
			["authorOptions"] = {
			},
			["displayText"] = "%c",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["url"] = "https://wago.io/rJWQDzuZX/1",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["wordWrap"] = "WordWrap",
			["desaturate"] = false,
			["rotation"] = 315,
			["text1Point"] = "RIGHT",
			["text2FontFlags"] = "OUTLINE",
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["shadowXOffset"] = 1,
			["text1FontFlags"] = "OUTLINE",
			["regionType"] = "text",
			["blendMode"] = "BLEND",
			["text2FontSize"] = 24,
			["texture"] = "Interface\\ICONS\\NeonRedArrow.tga",
			["zoom"] = 0,
			["auto"] = true,
			["text2Enabled"] = false,
			["uid"] = "QaChREEc9UE",
			["displayIcon"] = "Interface\\ICONS\\NeonRedArrowH.tga",
			["outline"] = "OUTLINE",
			["color"] = {
				1, -- [1]
				0, -- [2]
				0.0196078431372549, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    if not UnitExists(\"target\") then return \"\" end\n    \n    local minDistance, maxDistance = WeakAuras.GetRange(\"target\")\n    if not minDistance then minDistance = 0 end\n    if not maxDistance then maxDistance = 200 end\n    \n    local color = (minDistance >= 40) and \"ff6666\" or \"ffffff\"\n    return string.format(\"|cff%s%d~%s|r\", color, minDistance, maxDistance)\nend",
			["shadowYOffset"] = -1,
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["custom_type"] = "status",
						["names"] = {
						},
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnActive",
						["use_unit"] = true,
						["unit"] = "player",
						["spellIds"] = {
						},
						["custom"] = "function()\n    local region = aura_env.region\n    local plate = C_NamePlate.GetNamePlateForUnit(\"target\")\n    if plate then\n        region:ClearAllPoints()\n        region:SetPoint(\"CENTER\", plate, \"CENTER\",0, 0)\n        region:Show()\n    else\n        region:Hide()\n    end\n    return true\nend",
						["subeventPrefix"] = "SPELL",
						["check"] = "update",
						["event"] = "Health",
						["unevent"] = "auto",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
				["main"] = {
					["colorR"] = 0.501960784313726,
					["use_scale"] = true,
					["colorA"] = 1,
					["colorG"] = 1,
					["colorB"] = 0,
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["scaleType"] = "pulse",
					["rotate"] = 0,
					["easeType"] = "none",
					["preset"] = "pulse",
					["use_color"] = true,
					["alpha"] = 0,
					["scaley"] = 1.3,
					["y"] = 0,
					["colorType"] = "pulseHSV",
					["type"] = "none",
					["x"] = 0,
					["colorFunc"] = "    function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      local newProgress = ((math.sin(angle) + 1)/2);\n      return WeakAuras.GetHSVTransition(newProgress, r1, g1, b1, a1, r2, g2, b2, a2)\n    end\n  ",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["scalex"] = 1.3,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["stickyDuration"] = false,
			["discrete_rotation"] = 270,
			["version"] = 1,
			["height"] = 30,
			["rotate"] = false,
			["fontSize"] = 14,
			["text2Containment"] = "INSIDE",
			["text1Font"] = "聊天",
			["mirror"] = false,
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["xOffset"] = 0,
			["config"] = {
			},
			["text1Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["cooldownTextDisabled"] = false,
			["text1Containment"] = "OUTSIDE",
			["alpha"] = 1,
			["text1"] = "%c",
			["font"] = "默认",
			["selfPoint"] = "CENTER",
			["anchorFrameType"] = "SCREEN",
			["justify"] = "LEFT",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.displayMinimalDistanceOnly = false\naura_env.nextDistance = {\n    [0] = 1,\n    [1] = 2,\n    [2] = 3,\n    [3] = 4,\n    [4] = 5,\n    [5] = 7,\n    [7] = 8,\n    [8] = 10,\n    [10] = 15,\n    [15] = 20,\n    [20] = 25,\n    [25] = 28,\n    [28] = 30,\n    [30] = 35,\n    [35] = 38,\n    [38] = 40,\n    [40] = 45,\n    [45] = 50,\n    [50] = 55,\n    [55] = 60,\n    [60] = 70,\n    [70] = 80,\n    [80] = 90,\n    [90] = 100,\n    [100] = 150,\n    [150] = \"more\",\n}\n\n\n\n",
					["do_custom"] = false,
				},
				["finish"] = {
				},
			},
			["id"] = "目标距离",
			["text2Font"] = "Friz Quadrata TT",
			["frameStrata"] = 1,
			["width"] = 45,
			["fixedWidth"] = 200,
			["text2"] = "%p",
			["inverse"] = false,
			["text2Point"] = "CENTER",
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["preferToUpdate"] = false,
		},
		["暗灼1"] = {
			["authorOptions"] = {
			},
			["yOffset"] = 274.4444274902344,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_charges"] = true,
						["genericShowOn"] = "showOnReady",
						["names"] = {
						},
						["remaining"] = "0",
						["unit"] = "player",
						["remaining_operator"] = "==",
						["use_genericShowOn"] = true,
						["debuffType"] = "HELPFUL",
						["charges_operator"] = "==",
						["useName"] = false,
						["subeventSuffix"] = "_CAST_START",
						["use_targetRequired"] = false,
						["duration"] = "1",
						["type"] = "status",
						["event"] = "Action Usable",
						["charges"] = "1",
						["realSpellName"] = "暗影灼烧",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["spellName"] = 17877,
						["use_remaining"] = true,
						["use_track"] = true,
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_unit"] = true,
						["spellName"] = 0,
						["type"] = "status",
						["use_health"] = false,
						["unevent"] = "auto",
						["percenthealth"] = "53",
						["event"] = "Health",
						["debuffType"] = "HELPFUL",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["percenthealth_operator"] = "<=",
						["use_absorbMode"] = true,
						["duration"] = "1",
						["use_percenthealth"] = true,
						["use_track"] = true,
						["unit"] = "target",
					},
					["untrigger"] = {
						["unit"] = "target",
					},
				}, -- [2]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "fade",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["main"] = {
					["type"] = "preset",
					["easeType"] = "none",
					["preset"] = "pulse",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 237.0001373291016,
			["rotate"] = true,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "WARLOCK",
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["spec"] = {
					["single"] = 3,
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorMode"] = true,
			["textureWrapMode"] = "CLAMP",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "1028136",
			["anchorFrameType"] = "SCREEN",
			["rotation"] = 0,
			["selfPoint"] = "CENTER",
			["id"] = "暗灼1",
			["alpha"] = 1,
			["frameStrata"] = 6,
			["width"] = 234.4446716308594,
			["uid"] = "m0cJi82DxYW",
			["config"] = {
			},
			["parent"] = "毁灭ss",
			["xOffset"] = 4.2222900390625,
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["color"] = {
				0.9450980392156862, -- [1]
				0.6039215686274509, -- [2]
				1, -- [3]
				0.75, -- [4]
			},
		},
		["pod hp"] = {
			["user_y"] = 0,
			["iconSource"] = 0,
			["user_x"] = 0,
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				0.25882352941176, -- [2]
				0.24313725490196, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/Wi5b8_TmZ/5",
			["backgroundColor"] = {
				0.07843137254902, -- [1]
				0.07843137254902, -- [2]
				0.07843137254902, -- [3]
				0.8773990124464, -- [4]
			},
			["slant"] = 0.1,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["selfPoint"] = "CENTER",
			["barColor"] = {
				0.82745098039216, -- [1]
				0, -- [2]
				0.24313725490196, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["smoothProgress"] = true,
			["useAdjustededMin"] = false,
			["regionType"] = "progresstexture",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "Solid",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["auto"] = true,
			["tocversion"] = 90002,
			["alpha"] = 1,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayIcon"] = 656440,
			["backgroundOffset"] = 2,
			["sparkOffsetX"] = 0,
			["parent"] = "3KILL THE POD",
			["desaturateBackground"] = false,
			["sparkRotationMode"] = "AUTO",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["npcId"] = "164589",
						["duration"] = "1",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["use_health"] = true,
						["unevent"] = "auto",
						["names"] = {
						},
						["use_absorbMode"] = true,
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["use_showIncomingHeal"] = true,
						["spellIds"] = {
						},
						["health"] = "1",
						["health_operator"] = ">=",
						["use_showAbsorb"] = true,
						["use_npcId"] = true,
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "nameplate",
					},
					["untrigger"] = {
						["unit"] = "nameplate",
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeType"] = "none",
					["easeStrength"] = 3,
					["preset"] = "pulse",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 5,
			["subRegions"] = {
				{
					["type"] = "subborder",
					["border_anchor"] = "bar",
					["border_offset"] = 0,
					["border_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "1 Pixel",
					["border_size"] = 2,
				}, -- [1]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%1.health",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "RIGHT",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_text_format_1.health_format"] = "none",
					["type"] = "subtext",
					["text_anchorXOffset"] = -10,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "DorisPP",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "RIGHT",
					["rotateText"] = "NONE",
					["text_visible"] = true,
					["text_fontSize"] = 14,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 1,
				}, -- [2]
			},
			["height"] = 20,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["sparkWidth"] = 10,
			["authorOptions"] = {
			},
			["conditions"] = {
			},
			["mirror"] = false,
			["overlays"] = {
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.40000003576279, -- [4]
				}, -- [1]
			},
			["compress"] = false,
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["spark"] = false,
			["icon_side"] = "RIGHT",
			["icon"] = true,
			["width"] = 200,
			["sparkHeight"] = 30,
			["config"] = {
			},
			["load"] = {
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_vehicle"] = false,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						true, -- [1]
						true, -- [2]
					},
				},
				["race"] = {
				},
				["use_vehicleUi"] = false,
				["class"] = {
					["single"] = "SHAMAN",
					["multi"] = {
						["SHAMAN"] = true,
					},
				},
				["role"] = {
					["single"] = "DAMAGER",
					["multi"] = {
						["DAMAGER"] = true,
					},
				},
				["use_size"] = false,
				["size"] = {
					["multi"] = {
						["arena"] = true,
						["pvp"] = true,
						["none"] = true,
					},
				},
			},
			["sparkHidden"] = "NEVER",
			["semver"] = "2.0.3",
			["startAngle"] = 0,
			["id"] = "pod hp",
			["actions"] = {
				["start"] = {
					["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BananaPeelSlip.ogg",
					["do_sound"] = false,
				},
				["init"] = {
					["custom"] = "",
					["do_custom"] = false,
				},
				["finish"] = {
				},
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["anchorPoint"] = "CENTER",
			["uid"] = "KDXVM6biVap",
			["inverse"] = false,
			["zoom"] = 0.34,
			["orientation"] = "HORIZONTAL",
			["crop_x"] = 0.41,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["slanted"] = false,
		},
		["FREAR CC"] = {
			["iconSource"] = 0,
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["customText"] = "function()\n    if aura_env.state.class then\n        return RAID_CLASS_COLORS[aura_env.state.class]:WrapTextInColorCode(aura_env.state.name)\n    else\n        return aura_env.state.name\n    end\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = true,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.spells = {}\naura_env.nameplates = {}\naura_env.guids = {}\naura_env.temp = {}\naura_env.DRCOUNT = {}\naura_env.UnitDebuff = function (uId, spellInput, spellInput2, spellInput3, spellInput4)\n    for i = 1, 60 do\n        local spellName, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, nameplateShowPersonal, spellId, canApplyAura, isBossDebuff, nameplateShowAll, timeMod, value1, value2, value3 = UnitDebuff(uId, i)\n        if not spellName then return end\n        if spellInput == spellName or spellInput == spellId or spellInput2 == spellName or spellInput2 == spellId or spellInput3 == spellName or spellInput3 == spellId or spellInput4 == spellName or spellInput4 == spellId then\n            return spellName, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, nameplateShowPersonal, spellId, canApplyAura, isBossDebuff, nameplateShowAll, timeMod, value1, value2, value3\n        end\n    end\nend\naura_env.spells = {\n    \n    [5782]={duration = 6,cc = true},   -- lock fear\n    [130616]={duration = 6,cc = true},   -- lock fear\n    [118699]={duration = 6,cc = true},   -- lock fear\n    [207167]={duration = 4,cc = true}, -- dk blinding sleet\n    [33786]={duration = 6,cc = true},  -- druid cyclone\n    [209753]={duration = 6,cc = true},  -- druid cyclone\n    -- [99]={duration = 3,cc = true},     -- druid incap roar\n    --[31661]={duration = 3,cc = true},  -- mage dragon's breath\n    [198898]={duration = 6,cc = true}, -- monk song of chiji\n    [198909]={duration = 6,cc = true}, -- monk song of chiji\n    [115750]={duration = 6,cc = true}, -- pally blinding light    \n    [23733]={duration = 6,cc = true}, -- pally blinding light    \n    [605]={duration = 8,cc = true},    -- priest mind control\n    [8122]={duration = 6,cc = true},   -- priest psychic scream\n    [43432]={duration = 4,cc = true},   -- priest psychic scream\n    [2094]={duration = 8,cc = true},   -- rogue blind\n    [43433]={duration = 8,cc = true},   -- rogue blind\n    [6358]={duration = 8,cc = true},   -- warlock seduce\n    [176174]={duration = 8,cc = true},   -- warlock seduce\n    [5484]={duration = 6,cc = true},   -- warlock howl of terror\n    [138562]={duration = 6,cc = true},   -- warlock howl of terror\n    [115268]={duration = 8,cc = true}, -- warlock mesmerize\n    [5246]={duration = 8,cc = true},   -- warrior intimidating shout\n    \n}\n\nfor k, d in pairs(aura_env.spells) do\n    local _, _, icon = GetSpellInfo(k)\n    if icon then\n        d.icon = icon\n    end\nend\n\n\n",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "2",
						["subeventPrefix"] = "SPELL",
						["destUnit"] = "target",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
						["spellName"] = "Battle Stance",
						["type"] = "custom",
						["use_destNpcId"] = false,
						["custom_type"] = "stateupdate",
						["names"] = {
						},
						["unevent"] = "timed",
						["event"] = "Combat Log",
						["events"] = "CLEU:SPELL_AURA_REMOVED CLEU:SPELL_AURA_REFRESH CLEU:SPELL_AURA_APPLIED  CLEU:UNIT_DIED CLEU:UNIT_DESTROYED NAME_PLATE_UNIT_ADDED NAME_PLATE_UNIT_REMOVED  ",
						["spellIds"] = {
						},
						["use_spellName"] = true,
						["custom"] = "function(states, e, ...)\n    \n    if e == \"NAME_PLATE_UNIT_ADDED\" then\n        local unit = ...\n        if unit then\n            local guid = UnitGUID(unit)\n            \n            aura_env.nameplates[unit] = guid\n            aura_env.guids[guid] = unit\n            \n            \n            local now = GetTime()\n            for k, state in pairs(aura_env.temp) do\n                if state.guid == guid\n                and state.expirationTime > now\n                then\n                    state.unit = unit\n                    state.show = true\n                    state.changed = true\n                    states[k] = state     \n                end\n                if state.expirationTime < now then\n                    aura_env.temp[k] = nil\n                end\n            end\n        end\n    elseif e == \"NAME_PLATE_UNIT_REMOVED\" then\n        local unit = ...\n        if unit then\n            local guid = UnitGUID(unit)\n            if guid then\n                aura_env.nameplates[unit] = nil\n                aura_env.guids[guid] = nil\n                for k, state in pairs(states) do\n                    if state.guid == guid then\n                        aura_env.temp[k] = state\n                        state.show = false\n                        state.changed = true\n                        \n                    end\n                end\n            end\n        end\n    elseif e == \"COMBAT_LOG_EVENT_UNFILTERED\" then\n        \n        \n        local spell\n        local _, subevent, _, castGuid,castName, flags, _, tarGuid, tarName , _, _, debuffID,debuffName,auraID = ...  \n        \n        if flags\n        and tarGuid \n        and debuffID\n        then\n            spell = debuffID and aura_env.spells[debuffID] \n        end\n        if (subevent == \"UNIT_DIED\" or subevent == \"UNIT_DESTROYED\") then \n            return false\n        end\n        \n        \n        \n        if spell  then\n            if spell.duration and type(spell.duration) == \"number\" and spell.duration > 0 then\n                local key = tarGuid..debuffID\n                \n                \n                -- local dur = select(5, aura_env.UnitDebuff(aura_env.guids[tarGuid], debuffName)) or spell.duration\n                \n                \n                if (subevent == \"SPELL_AURA_APPLIED\" \n                    or subevent == \"SPELL_AURA_REFRESH\" \n                )\n                then \n                    \n                    if aura_env.guids[tarGuid] then\n                        if not states[key] then\n                            states[key] = {\n                                show = true,\n                                changed = true,\n                                duration = spell.duration,\n                                expirationTime = GetTime() + 18,\n                                icon = spell.icon,\n                                progressType = \"timed\",\n                                autoHide = true,\n                                guid = tarGuid,\n                                unit = aura_env.guids[tarGuid],\n                                interrupt = spell.cc, \n                                ccCount=1, \n                            }  \n                        else\n                            states[key].ccCount = states[key].ccCount + 1 \n                            if states[key].ccCount > 3 then \n                                states[key].ccCount = 3\n                            end\n                            states[key].expirationTime = GetTime() + 18\n                            states[key].changed = true\n                        end\n                        \n                        \n                    else\n                        \n                        if not aura_env.temp[key] then\n                            aura_env.temp[key] = {\n                                show = true,\n                                changed = true,\n                                duration = spell.duration,\n                                expirationTime = GetTime() + 18,\n                                icon = spell.icon,\n                                progressType = \"timed\",\n                                autoHide = true,\n                                guid = tarGuid,\n                                unit = aura_env.guids[tarGuid],\n                                interrupt = spell.cc, \n                                ccCount=1, \n                            }  \n                        else\n                            aura_env.temp[key].ccCount = aura_env.temp[key].ccCount + 1 \n                            if aura_env.temp[key].ccCount > 3 then \n                                aura_env.temp[key].ccCount = 3\n                            end\n                            \n                            aura_env.temp[key].expirationTime = GetTime() + 18\n                            aura_env.temp[key].changed = true\n                            \n                        end \n                    end\n                    \n                    \n                    \n                    \n                    \n                    \n                end\n                \n                \n                \n                if  subevent == \"SPELL_AURA_REMOVED\" then \n                    \n                    if aura_env.guids[tarGuid] then\n                        if not states[key] then\n                            states[key] = {\n                                show = true,\n                                changed = true,\n                                duration = spell.duration,\n                                expirationTime = GetTime() + 18,\n                                icon = spell.icon,\n                                progressType = \"timed\",\n                                autoHide = true,\n                                guid = tarGuid,\n                                unit = aura_env.guids[tarGuid],\n                                interrupt = spell.cc, \n                                ccCount=1, \n                            }  \n                        else\n                            \n                            states[key].expirationTime = GetTime() + 18\n                            states[key].changed = true\n                        end\n                        \n                        \n                    else\n                        \n                        if not aura_env.temp[key] then\n                            aura_env.temp[key] = {\n                                show = true,\n                                changed = true,\n                                duration = spell.duration,\n                                expirationTime = GetTime() + 18,\n                                icon = spell.icon,\n                                progressType = \"timed\",\n                                autoHide = true,\n                                guid = tarGuid,\n                                unit = aura_env.guids[tarGuid],\n                                interrupt = spell.cc, \n                                ccCount=1, \n                            }  \n                        else\n                            \n                            aura_env.temp[key].expirationTime = GetTime() + 18\n                            aura_env.temp[key].changed = true\n                            \n                        end \n                    end\n                    \n                    \n                end\n                \n            end\n            \n            \n            \n            \n        end\n    end\n    return true\nend",
						["subeventSuffix"] = "_CAST_SUCCESS",
						["check"] = "event",
						["use_destUnit"] = true,
						["unit"] = "player",
						["customVariables"] = "{ interrupt = \"bool\",\n    ccCount = {\n        display = \"color\",\n        type = \"select\",\n        values = {\n            [1] = \"green\",\n            [2] = \"yellow\",\n            [3] = \"red\",\n        }\n    }\n}",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["debuffType"] = "HELPFUL",
						["custom_type"] = "status",
						["use_genericShowOn"] = true,
						["duration"] = "1",
						["event"] = "Global Cooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["custom"] = "function()\n    if aura_env.state and aura_env.state.ccCount then\n        print(\"In trigger 2\")\n        aura_env.setColor(aura_env.state.ccCount)\n    end\nend",
						["genericShowOn"] = "showOnCooldown",
						["check"] = "update",
						["unevent"] = "auto",
						["use_track"] = true,
						["spellName"] = 0,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = true,
			["version"] = 6,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						0.8980392156862745, -- [1]
						0.9921568627450981, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_text_format_p_time_precision"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["text_visible"] = false,
					["text_text_format_p_format"] = "timed",
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["useGlowColor"] = true,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glowYOffset"] = 0,
					["glowColor"] = {
						0.4823529411764706, -- [1]
						0.4196078431372549, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["glowXOffset"] = 0,
					["glowType"] = "Pixel",
					["glow"] = false,
					["glowLength"] = 10,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 30,
			["load"] = {
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_encounter"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["authorMode"] = true,
			["uid"] = "sJxTQGUG831",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["parent"] = "0FEAR CC Nameplate ",
			["regionType"] = "icon",
			["icon"] = true,
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "interrupt",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.2.glow",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "ccCount",
						["op"] = "==",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0.1294117647058823, -- [1]
								1, -- [2]
								0.03529411764705882, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "ccCount",
						["op"] = "==",
						["value"] = 3,
					},
					["linked"] = false,
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.09411764705882353, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "ccCount",
						["op"] = "==",
						["value"] = 2,
					},
					["changes"] = {
						{
							["value"] = {
								0.9568627450980391, -- [1]
								1, -- [2]
								0.1490196078431373, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "1.0.5",
			["width"] = 30,
			["zoom"] = 0,
			["auto"] = true,
			["tocversion"] = 80300,
			["id"] = "FREAR CC",
			["alpha"] = 1,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["url"] = "https://wago.io/OmniBudsNameplateRetail/6",
			["displayIcon"] = 136183,
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["duration_type"] = "seconds",
					["colorA"] = 1,
					["colorG"] = 1,
					["colorB"] = 1,
					["use_scale"] = true,
					["use_translate"] = true,
					["rotate"] = 0,
					["translateType"] = "shake",
					["type"] = "custom",
					["scaley"] = 5,
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    local prog\n    if(progress < 0.25) then\n        prog = progress * 4\n    elseif(progress < .75) then\n        prog = 2 - (progress * 4)\n    else\n        prog = (progress - 1) * 4\n    end\n    return startX + (prog * deltaX), startY + (prog * deltaY)\nend\n",
					["use_color"] = true,
					["alpha"] = 0,
					["scaleType"] = "straightScale",
					["y"] = 33,
					["x"] = 33,
					["colorType"] = "pulseColor",
					["colorR"] = 1,
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    local newProgress = ((math.sin(angle) + 1)/2);\n    return r1 + (newProgress * (r2 - r1)),\n         g1 + (newProgress * (g2 - g1)),\n         b1 + (newProgress * (b2 - b1)),\n         a1 + (newProgress * (a2 - a1))\nend\n",
					["easeStrength"] = 3,
					["scalex"] = 5,
					["duration"] = "1",
				},
			},
		},
		["3cast bar on me"] = {
			["grow"] = "DOWN",
			["controlledChildren"] = {
				"whois casting me", -- [1]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["xOffset"] = 56.00054931640625,
			["yOffset"] = 335.1111450195313,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["space"] = 2,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["debuffType"] = "HELPFUL",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["selfPoint"] = "TOP",
			["align"] = "CENTER",
			["stagger"] = 0,
			["subRegions"] = {
			},
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["animate"] = false,
			["arcLength"] = 360,
			["scale"] = 1,
			["internalVersion"] = 40,
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["sort"] = "none",
			["useLimit"] = false,
			["fullCircle"] = true,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["config"] = {
			},
			["uid"] = "ZzZKCt350Uj",
			["id"] = "3cast bar on me",
			["gridWidth"] = 5,
			["frameStrata"] = 6,
			["anchorFrameType"] = "SCREEN",
			["gridType"] = "RD",
			["borderInset"] = 1,
			["limit"] = 5,
			["rotation"] = 0,
			["conditions"] = {
			},
			["information"] = {
			},
			["authorOptions"] = {
			},
		},
		["whois casting me"] = {
			["sparkWidth"] = 10,
			["sparkOffsetX"] = 0,
			["xOffset"] = 1.52587890625e-05,
			["yOffset"] = 9.500028610229492,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["use_castType"] = false,
						["type"] = "status",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "nameplate",
						["duration"] = "1",
						["event"] = "Cast",
						["subeventPrefix"] = "SPELL",
						["destUnit"] = "player",
						["use_unit"] = true,
						["spellIds"] = {
						},
						["use_absorbMode"] = true,
						["use_nameplateType"] = false,
						["use_destUnit"] = true,
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["unit"] = "nameplate",
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_castType"] = false,
						["type"] = "status",
						["duration"] = "1",
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Cast",
						["names"] = {
						},
						["destUnit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["unit"] = "arena",
						["use_nameplateType"] = false,
						["use_destUnit"] = true,
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["unit"] = "arena",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["barColor"] = {
				0.7098039215686275, -- [1]
				1, -- [2]
				0.9411764705882353, -- [3]
				0.4444444179534912, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["subRegions"] = {
				{
					["type"] = "aurabar_bar",
				}, -- [1]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%p",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_anchorXOffset"] = -20,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = -1,
					["text_anchorYOffset"] = 0,
					["text_visible"] = true,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_BOTTOMLEFT",
					["text_text_format_p_time_precision"] = 1,
					["text_text_format_p_format"] = "timed",
					["text_fontSize"] = 11,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_dynamic"] = false,
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_anchorXOffset"] = 0,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMLEFT",
					["text_fontType"] = "None",
					["text_text_format_n_format"] = "none",
					["text_fontSize"] = 11,
					["anchorXOffset"] = 0,
					["text_anchorYOffset"] = 0,
				}, -- [3]
				{
					["text_shadowXOffset"] = 1,
					["text_text_format_1.sourceName_format"] = "none",
					["text_text"] = "%1.sourceName",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_anchorXOffset"] = 0,
					["text_color"] = {
						1, -- [1]
						0, -- [2]
						0.06666666666666667, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_TOPLEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_text_format_n_format"] = "none",
				}, -- [4]
			},
			["height"] = 26.55557823181152,
			["load"] = {
				["use_never"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["config"] = {
			},
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["parent"] = "3cast bar on me",
			["authorOptions"] = {
			},
			["icon_side"] = "LEFT",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["sparkHeight"] = 30,
			["texture"] = "Blizzard",
			["spark"] = false,
			["zoom"] = 0,
			["auto"] = true,
			["width"] = 102.2222900390625,
			["id"] = "whois casting me",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["sparkHidden"] = "NEVER",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["inverse"] = true,
			["uid"] = "MQefvinXgWK",
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["information"] = {
			},
			["iconSource"] = -1,
		},
		["战斗状态"] = {
			["xOffset"] = -195.1112060546875,
			["yOffset"] = -256.8890686035156,
			["anchorPoint"] = "CENTER",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_showAbsorb"] = false,
						["use_incombat"] = true,
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["names"] = {
						},
						["unit"] = "player",
						["percenthealth_operator"] = "<=",
						["use_absorbMode"] = true,
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["subeventSuffix"] = "_CAST_START",
						["type"] = "status",
						["use_health"] = false,
						["health_operator"] = "<=",
						["health"] = "43",
						["percenthealth"] = "43",
						["event"] = "Conditions",
						["use_unit"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["spellName"] = 0,
						["use_percenthealth"] = true,
						["use_track"] = true,
						["use_genericShowOn"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["rotation"] = 0,
			["subRegions"] = {
			},
			["height"] = 48.88936996459961,
			["rotate"] = true,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "ADD",
			["texture"] = "166984",
			["config"] = {
			},
			["alpha"] = 1,
			["width"] = 51.55559158325195,
			["id"] = "战斗状态",
			["parent"] = "SS通用",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["authorOptions"] = {
			},
			["uid"] = "QUcIqz76H1a",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["color"] = {
				1, -- [1]
				0, -- [2]
				0.0196078431372549, -- [3]
				0.75, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
			},
			["discrete_rotation"] = 0,
		},
		["控心术"] = {
			["iconSource"] = -1,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["yOffset"] = 194.6667175292969,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["auranames"] = {
							"控心术", -- [1]
						},
						["unit"] = "player",
						["names"] = {
						},
						["useName"] = true,
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 40,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [1]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["useGlowColor"] = false,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["glowXOffset"] = 0,
					["glow"] = false,
					["glowThickness"] = 1,
					["glowScale"] = 1,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [2]
			},
			["height"] = 64,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["authorOptions"] = {
			},
			["information"] = {
			},
			["xOffset"] = 126.2222290039063,
			["zoom"] = 0,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["anchorFrameType"] = "SCREEN",
			["id"] = "控心术",
			["uid"] = "rzIIDQ6NfK7",
			["alpha"] = 1,
			["width"] = 64,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["frameStrata"] = 1,
			["conditions"] = {
			},
			["cooldown"] = true,
			["parent"] = "SS通用",
		},
		["3人3dots 有盟约有sp"] = {
			["sparkWidth"] = 10,
			["sparkOffsetX"] = 0,
			["color"] = {
				0.8313725490196078, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["yOffset"] = 54.44416809082031,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
					["do_custom"] = true,
					["custom"] = "\n\nlocal e = aura_env\ne.myGUID = UnitGUID(\"player\")\nif e.config.debug_mode then print(\"INIT START\") end\n\n-- For debugging\n\ne.dump = function(t)\n    local s = '{\\n'\n    for k,v in pairs(t) do\n        s = s..tostring(k)..': '..tostring(v)..',\\n'\n    end\n    print(s..'}')\nend\n\naura_env.spells = {}\naura_env.nameplates = {}\naura_env.guids = {}\naura_env.temp = {}\n\ne.maxDotsCountReach = false;\ne.maxDotsPerson = false;\n\n\naura_env.healerSpecNoLock = {\n    [105] = true, -->  druid resto\n    [270] = true, --> monk mw\n    [65] = true, --> paladin holy\n    [256] = true,  --> priest disc\n    [257] = true,  --> priest holy\n    --[264] = true, --> shaman resto\n}\n\nlocal uaID = 316099\naura_env.tracked_dots = {\n    [980]    = true, -- Agony\n    [63106]  = true, -- Siphon Life\n    [146739] = true, -- Corruption\n    [uaID]   = true, -- UA\n    [342938]   = true, -- UA\n    [278350] = true, -- Vile Taint\n    [205179] = true, -- Phantom Singularity\n    [325640] = true, -- Soul Rot\n    [312321] = true, -- Scouring Tithe\n    [321792] = true, -- Impending Catastrophe\n}\n\n\ne.myUnitDebuffCount = function (uId)\n    local dotsCount = 0\n    --print(\"uid\",uId)\n    for i = 1, 10 do\n        local spellName, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, nameplateShowPersonal, spellId, canApplyAura, isBossDebuff, nameplateShowAll, timeMod, value1, value2, value3 = UnitDebuff(uId, i)\n        \n        \n        \n        if spellName and  e.tracked_dots[spellId] and (UnitGUID(unitCaster)==e.myGUID or unitCaster==e.myGUID) then  \n            \n            dotsCount = dotsCount + 1 \n            \n            --print(\"dotsCount\",dotsCount)\n        end \n        --if spellName then print(\"spellName, unitCaster,spellId\",spellName, unitCaster,spellId) end \n        \n    end\n    \n    return dotsCount\nend\n\n\n\n\n\n",
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["genericShowOn"] = "showOnActive",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
						["type"] = "custom",
						["custom_type"] = "status",
						["custom_hide"] = "timed",
						["spellIds"] = {
						},
						["event"] = "Health",
						["customStacks"] = "\n\n",
						["customDuration"] = "\n\n",
						["customName"] = "\n\n",
						["events"] = "CLEU,UNIT_AURA:player ",
						["unit"] = "player",
						["check"] = "event",
						["subeventSuffix"] = "_CAST_START",
						["custom"] = "function(event, ...)\n    local e = aura_env\n    \n    if event ~= \"COMBAT_LOG_EVENT_UNFILTERED\" then\n        \n        return  aura_env.maxDotsPerson or aura_env.maxDotsCountReach\n    end\n    \n    local subevent = select(2, ...)\n    local source = select(4, ...)\n    local target = select(8, ...)\n    local spellID = select(12, ...)\n    local stacks = select(16, ...)\n    \n    \n    \n    \n    if (source == e.myGUID) and (e.tracked_dots[spellID]) then\n        aura_env.maxDotsPerson = false\n        aura_env.maxDotsCountReach = false\n        local lotsDotsCount = 0\n        local platerCount = 0\n        \n        for i = 1, 40 do\n            local unit = \"nameplate\"..i \n            if UnitExists(unit) then \n                \n                \n                \n                local _guid = UnitGUID(unit)\n                local plateFrame = C_NamePlate.GetNamePlateForUnit (unit, issecure()) \n                \n                \n                \n                if (Plater.GetUnitType (plateFrame) == \"normal\" )\n               -- and ( UnitPlayerControlled(unit) \n                   -- or ((not UnitPlayerControlled(unit)) and UnitAffectingCombat(unit) )) \n                then  \n                    \n                    platerCount = platerCount + 1\n                    local dotsCount = aura_env.myUnitDebuffCount(unit)\n                    if dotsCount >=3 then \n                        lotsDotsCount = lotsDotsCount + 1\n                    end \n                    if dotsCount > 3 then \n                        aura_env.maxDotsCountReach = true\n                    end\n                    \n                    \n                end\n            end\n        end\n        \n        \n        local max  = math.min(3,platerCount)\n        \n        aura_env.maxDotsPerson = lotsDotsCount>=max;\n        \n        if max <= 1 then \n            aura_env.maxDotsPerson = false   \n        end \n        \n        return aura_env.maxDotsPerson or aura_env.maxDotsCountReach\n    end\n    \n    \n    \n    \n    \n    return  aura_env.maxDotsPerson or aura_env.maxDotsCountReach\nend\n\n\n\n\n\n",
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_power"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["powertype"] = 7,
						["use_powertype"] = true,
						["spellName"] = 0,
						["type"] = "status",
						["unevent"] = "auto",
						["power_operator"] = ">=",
						["event"] = "Power",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["power"] = "1",
						["duration"] = "1",
						["use_genericShowOn"] = true,
						["use_unit"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Action Usable",
						["unit"] = "player",
						["realSpellName"] = "灵魂腐化",
						["use_spellName"] = true,
						["debuffType"] = "HELPFUL",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["use_track"] = true,
						["spellName"] = 325640,
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["debuffType"] = "HELPFUL",
						["duration"] = "1",
						["event"] = "Cooldown Progress (Equipment Slot)",
						["unit"] = "player",
						["realSpellName"] = 0,
						["itemSlot"] = 14,
						["use_itemSlot"] = true,
						["genericShowOn"] = "showOnReady",
						["use_genericShowOn"] = true,
						["use_spellName"] = true,
						["use_track"] = true,
						["spellName"] = 0,
					},
					["untrigger"] = {
						["genericShowOn"] = "showOnReady",
						["itemSlot"] = 14,
					},
				}, -- [4]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    return t[1] and t[2]\nend",
				["activeTriggerMode"] = 1,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 40,
			["animation"] = {
				["start"] = {
					["colorR"] = 1,
					["use_rotate"] = false,
					["duration_type"] = "seconds",
					["use_scale"] = true,
					["alphaType"] = "hide",
					["rotateType"] = "wobble",
					["colorG"] = 1,
					["alphaFunc"] = "function()\n    return 0\nend\n",
					["scalex"] = 3.3,
					["easeStrength"] = 3,
					["use_translate"] = true,
					["use_alpha"] = false,
					["rotate"] = 333,
					["type"] = "custom",
					["preset"] = "slideright",
					["easeType"] = "easeOutIn",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["scaley"] = 3.3,
					["alpha"] = 0,
					["colorA"] = 1,
					["y"] = -80,
					["x"] = -88,
					["scaleType"] = "straightScale",
					["translateType"] = "straightTranslate",
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\nend\n",
					["rotateFunc"] = "function(progress, start, delta)\n    local angle = progress * 2 * math.pi\n    return start + math.sin(angle) * delta\nend\n",
					["duration"] = ".66",
					["colorB"] = 1,
				},
				["main"] = {
					["scaleFunc"] = "function(progress, startX, startY, scaleX, scaleY)\n    local angle = (progress * 2 * math.pi) - (math.pi / 2)\n    return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\nend\n",
					["use_rotate"] = false,
					["use_scale"] = true,
					["scalex"] = 1.6,
					["duration_type"] = "seconds",
					["colorB"] = 1,
					["colorG"] = 1,
					["easeStrength"] = 3,
					["translateType"] = "straightTranslate",
					["colorA"] = 1,
					["use_translate"] = false,
					["preset"] = "alphaPulse",
					["x"] = 60,
					["type"] = "preset",
					["scaley"] = 1.6,
					["easeType"] = "none",
					["translateFunc"] = "function(progress, startX, startY, deltaX, deltaY)\n    return startX + (progress * deltaX), startY + (progress * deltaY)\nend\n",
					["use_color"] = false,
					["alpha"] = 0,
					["scaleType"] = "pulse",
					["y"] = -55,
					["colorType"] = "straightHSV",
					["colorR"] = 1,
					["duration"] = "0.66",
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    return WeakAuras.GetHSVTransition(progress, r1, g1, b1, a1, r2, g2, b2, a2)\nend\n",
					["rotateFunc"] = "function(progress, start, delta)\n    local prog\n    if(progress < 0.25) then\n        prog = progress * 4\n    elseif(progress < .75) then\n        prog = 2 - (progress * 4)\n    else\n        prog = (progress - 1) * 4\n    end\n    return start + (prog * delta)\nend\n",
					["rotate"] = 0,
					["rotateType"] = "backandforth",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
					["easeStrength"] = 3,
					["easeType"] = "none",
				},
			},
			["uid"] = "rK(wOU2LOnr",
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["parent"] = "痛苦ss",
			["sparkOffsetY"] = 0,
			["subRegions"] = {
			},
			["height"] = 508.5560913085938,
			["rotate"] = true,
			["load"] = {
				["use_spec"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
						[3] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["textureWrapMode"] = "CLAMP",
			["rotation"] = 87,
			["xOffset"] = 152.444694519043,
			["selfPoint"] = "CENTER",
			["icon"] = false,
			["mirror"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "texture",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["blendMode"] = "ADD",
			["icon_side"] = "RIGHT",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkHeight"] = 30,
			["texture"] = "186214",
			["anchorFrameType"] = "SCREEN",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["frameStrata"] = 9,
			["id"] = "3人3dots 有盟约有sp",
			["sparkHidden"] = "NEVER",
			["alpha"] = 1,
			["width"] = 166.5552825927734,
			["zoom"] = 0,
			["config"] = {
			},
			["inverse"] = false,
			["iconSource"] = -1,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 4,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.08627450980392157, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 3,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0.02352941176470588, -- [1]
								0, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 2,
								["variable"] = "show",
								["value"] = 0,
							}, -- [1]
							{
								["trigger"] = 4,
								["variable"] = "show",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0.7333333333333333, -- [1]
								0, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [3]
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["authorOptions"] = {
			},
		},
	},
	["frame"] = {
		["xOffset"] = -499.7796630859375,
		["width"] = 974.000244140625,
		["height"] = 766.3334350585938,
		["yOffset"] = -183.9996948242188,
	},
	["editor_theme"] = "Monokai",
}
