
MEETINGSTONE_UI_DB = {
	["profileKeys"] = {
		["Ennyin - 索瑞森"] = "Default",
		["云雨別 - 索瑞森"] = "Default",
		["Ennyin - 埃加洛尔"] = "Default",
		["借你流年 - 燃烧之刃"] = "Default",
		["绑住了风 - 索瑞森"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["你诺 - 索瑞森"] = "Default",
		["海雅 - 索瑞森"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["別雨 - 索瑞森"] = "Default",
		["Rainylone - 末日行者"] = "Default",
	},
	["global"] = {
		["serverDatas"] = {
			["MallData"] = {
				["data"] = "^1^SMallData^T^S宠物#1^S2006;1500,,每周限量;23713;16943#2007;850,,每周限量;72134;38919^S消耗品#3^S1002;150;46779^S玩具#2^S7001;750,,每周限量;54212;31756#3006;1500,,每月限量;79769#3007;450,,每月限量;69227^t^^",
			},
			["FilterData"] = {
				["data"] = "^1^S![Vv][Xx]^S下单^S付款^S某宝^S站桩^S代打^S陪练^S低价^S便宜^S超低^S老板^S门票^S包车^S![Ww][ⅩXx]^S另接^S全躺^S咨询^S陪打^S看戏^S实惠^S价格^S贵宾^S陪聊^S支付^SV信^S带小号^S有偿^S可淘^S卧铺^S代唰^S代做^S安全效率^S臣卜^S拼车^S可指定^S装备送^S莱%h*外%h*恩^S５^S⒌^S⒏^S后彡^^",
				["new"] = true,
			},
			["AnnData"] = {
				["data"] = "^1^SAnnData^T^Stitle^S集合石插件积分兑换维护^Scontent^S集合石插件积分兑换功能正在维护中，目前暂时无法正常使用，大家还是可以正常登录战网进行兑换，给大家造成的不便还请谅解。^t^^",
				["new"] = false,
			},
			["AnnList"] = {
				["data"] = "^1^SAnnList^T^N1^T^St^S开始冒险之前，先了解一下暗影界的信息吧，有备无患哦！暗影国度回归玩家需知的十件事。^Su^Shttps://www.battlenet.com.cn/support/zh/article/277708^t^N2^T^St^S新接触魔兽世界的小伙伴，了解下当前版本的内容才能更好的融入这个世界！暗影国度新手玩家需知的十件事。^Su^Shttps://www.battlenet.com.cn/support/zh/article/277709^t^N3^T^St^S暗影国度的噬渊行者们，了解下四个盟约选择适合自己的去加入吧！~`盟约系统。^Su^Shttps://wow.blizzard.cn/wow/shadowlands/covenant#type=venthyr^t^t^^",
				["new"] = false,
			},
			["ActivitiesData"] = {
				["data"] = "$1$Z$S319`魔兽主播活动`艾泽拉斯足球大赛`4月3日（周六）晚8点，斗鱼TV人气主播：菓苒（房间号：3475426）艾泽拉斯足鱼大赛*J召集亲朋好友一起参与这场比赛，在足鱼大赛中传递快乐，精彩活动数不胜数！`http://w.163.com/special/convene-stone/`2`3$$",
			},
		},
		["spamWord"] = {
			{
				["text"] = "%d+元",
			}, -- [1]
			{
				["pain"] = true,
				["text"] = "5173",
			}, -- [2]
			{
				["pain"] = true,
				["text"] = "lfg:",
			}, -- [3]
			{
				["text"] = "tao.*bao",
			}, -- [4]
			{
				["pain"] = true,
				["text"] = "平台",
			}, -- [5]
			{
				["text"] = "支.*付.*宝",
			}, -- [6]
			{
				["text"] = "淘.*宝",
			}, -- [7]
			{
				["pain"] = true,
				["text"] = "门票",
			}, -- [8]
			["default"] = true,
		},
		["version"] = "90002.03",
		["ActivityProfiles"] = {
			["地渊孢林（史诗钥石）"] = {
				["ItemLevel"] = 440,
				["HonorLevel"] = 0,
			},
			["评级战场"] = {
				["ItemLevel"] = 400,
				["HonorLevel"] = 0,
			},
			["随机海岛（史诗）"] = {
				["ItemLevel"] = 466,
				["HonorLevel"] = 0,
			},
			["竞技场（2v2）"] = {
				["ItemLevel"] = 0,
				["HonorLevel"] = 0,
			},
			["风暴神殿（史诗钥石）"] = {
				["ItemLevel"] = 470,
				["HonorLevel"] = 0,
			},
			["围攻伯拉勒斯（史诗钥石）"] = {
				["ItemLevel"] = 440,
				["HonorLevel"] = 0,
			},
			["维克雷斯庄园（史诗钥石）"] = {
				["ItemLevel"] = 448,
				["HonorLevel"] = 0,
			},
			["诸王之眠（史诗钥石）"] = {
				["ItemLevel"] = 472,
				["HonorLevel"] = 0,
			},
			["塞塔里斯神庙（史诗钥石）"] = {
				["ItemLevel"] = 440,
				["HonorLevel"] = 0,
			},
			["阿塔达萨（史诗钥石）"] = {
				["ItemLevel"] = 440,
				["HonorLevel"] = 0,
			},
		},
		["filters"] = {
			[3] = {
				["BossKilled"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["Age"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["Members"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["ItemLevel"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
			},
			[2] = {
				["BossKilled"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["Age"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["Members"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["ItemLevel"] = {
					["min"] = 455,
					["max"] = 480,
					["enable"] = true,
				},
			},
			[9] = {
				["BossKilled"] = {
					["min"] = 0,
					["enable"] = false,
					["max"] = 0,
				},
				["ItemLevel"] = {
					["min"] = 180,
					["enable"] = true,
					["max"] = 0,
				},
				["Age"] = {
					["min"] = 0,
					["enable"] = false,
					["max"] = 0,
				},
				["Members"] = {
					["min"] = 0,
					["enable"] = false,
					["max"] = 0,
				},
			},
			[4] = {
				["BossKilled"] = {
					["min"] = 0,
					["enable"] = false,
					["max"] = 0,
				},
				["Age"] = {
					["min"] = 0,
					["enable"] = false,
					["max"] = 0,
				},
				["Members"] = {
					["min"] = 0,
					["enable"] = false,
					["max"] = 0,
				},
				["ItemLevel"] = {
					["min"] = 0,
					["enable"] = false,
					["max"] = 0,
				},
			},
		},
	},
}
MEETINGSTONE_UI_E_POINTS = {
	["y"] = 32.05559158325195,
	["x"] = -200.6665344238281,
	["a1"] = "CENTER",
	["a2"] = "CENTER",
}
MEETINGSTONE_UI_BLACKLISTEDLEADERS = {
	"治死打机-凤凰之神", -- [1]
	"艾派德丶秃-死亡之翼", -- [2]
	"鎏丶清凉油兒-克尔苏加德", -- [3]
	"幻羽追风箭-布兰卡德", -- [4]
	"蓝色的梦-无尽之海", -- [5]
}
MEETINGSTONE_UI_E_FILTERAD = false
