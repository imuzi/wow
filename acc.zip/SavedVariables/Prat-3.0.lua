
Prat3DB = {
	["namespaces"] = {
		["Prat_TellTarget"] = {
		},
		["Prat_AltNames"] = {
		},
		["Prat_PlayerNames"] = {
		},
		["Prat_Memory"] = {
		},
		["Prat_Frames"] = {
			["profiles"] = {
				["Default"] = {
					["minchatwidthdefault"] = 296,
					["maxchatwidthdefault"] = 608,
					["maxchatheightdefault"] = 400,
					["initialized"] = true,
				},
				["ENNYIN"] = {
					["minchatwidthdefault"] = 296,
					["maxchatheightdefault"] = 400,
					["maxchatwidthdefault"] = 608,
					["initialized"] = true,
				},
			},
		},
		["Prat_ChannelColorMemory"] = {
			["profiles"] = {
				["Default"] = {
					["colors"] = {
						["打"] = {
							["b"] = 0.7529412508010864,
							["g"] = 0.7529412508010864,
							["r"] = 1,
						},
					},
				},
				["ENNYIN"] = {
					["colors"] = {
						["打"] = {
							["r"] = 1,
							["g"] = 0.7529412508010864,
							["b"] = 0.7529412508010864,
						},
					},
				},
			},
		},
		["Prat_Editbox"] = {
		},
		["Prat_Fading"] = {
		},
		["Prat_ChannelSticky"] = {
		},
		["Prat_UrlCopy"] = {
		},
		["Prat_ChannelNames"] = {
		},
		["Prat_KeyBindings"] = {
		},
		["Prat_Font"] = {
			["profiles"] = {
				["Default"] = {
					["size"] = {
						["ChatFrame8"] = 15,
						["ChatFrame1"] = 16,
					},
				},
				["ENNYIN"] = {
					["size"] = {
						["ChatFrame8"] = 15,
						["ChatFrame1"] = 16,
					},
				},
			},
		},
		["Prat_Bubbles"] = {
		},
		["Prat_ChatLog"] = {
		},
		["Prat_Scroll"] = {
		},
		["Prat_Achievements"] = {
		},
		["Prat_Mentions"] = {
		},
		["Prat_History"] = {
			["profiles"] = {
				["Default"] = {
					["chatlines"] = 300,
					["scrollbacklen"] = 30,
				},
				["ENNYIN"] = {
					["chatlines"] = 300,
					["scrollbacklen"] = 30,
				},
			},
		},
		["Prat_Alias"] = {
		},
		["Prat_OriginalButtons"] = {
		},
		["Prat_Highlight"] = {
		},
		["Prat_PopupMessage"] = {
		},
		["Prat_Paragraph"] = {
		},
		["Prat_Invites"] = {
		},
		["Prat_Sounds"] = {
		},
		["Prat_CopyChat"] = {
		},
		["Prat_Timestamps"] = {
			["profiles"] = {
				["Default"] = {
					["show"] = {
						["ChatFrame3"] = false,
					},
				},
				["ENNYIN"] = {
					["show"] = {
						["ChatFrame3"] = false,
					},
				},
			},
		},
		["Prat_Search"] = {
		},
		["Prat_Buttons"] = {
		},
		["Prat_ServerNames"] = {
		},
		["Prat_HoverTips"] = {
		},
	},
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["Ennyin - 埃加洛尔"] = "ENNYIN",
	},
	["profiles"] = {
		["Default"] = {
			["modules"] = {
				["PopupMessage"] = 2,
				["AltNames"] = 2,
				["Mentions"] = 2,
				["Sounds"] = 2,
				["Paragraph"] = 2,
				["OriginalButtons"] = 2,
				["Alias"] = 2,
				["ChatLog"] = 2,
				["KeyBindings"] = 2,
			},
		},
		["ENNYIN"] = {
			["modules"] = {
				["Alias"] = 2,
				["Mentions"] = 2,
				["PopupMessage"] = 2,
				["AltNames"] = 2,
				["Sounds"] = 2,
				["Paragraph"] = 2,
				["KeyBindings"] = 2,
				["OriginalButtons"] = 2,
				["ChatLog"] = 2,
			},
		},
	},
}
