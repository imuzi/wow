
FnpEnableKeys = {
	["onlyShowEnable"] = false,
}
Fnp_ONameList = {
	"爆炸物", -- [1]
}
Fnp_OtherNPFlag = 0
Fnp_SavedScaleList = {
	["normal"] = 1,
	["killline_r"] = 0,
	["small"] = 0.2,
	["only"] = 1.3,
	["killline"] = 100,
}
Fnp_MyVersion = 670
