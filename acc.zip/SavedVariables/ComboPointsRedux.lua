
CPRDB2 = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "Default",
		["绑住了风 - 索瑞森"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["Ennyin - 索瑞森"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["別雨 - 索瑞森"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["modules"] = {
				["Arcane Blast"] = {
					["graphicsX"] = 407.9999756813049,
					["textX"] = 520.8000666141452,
					["textY"] = 410.4000243663759,
					["graphicsY"] = 480.4000201940507,
				},
				["Soul Shards"] = {
					["outline"] = "THICKOUTLINE",
					["graphicsX"] = 490.1027051626006,
					["font"] = "默认",
					["fontsize"] = 53,
					["textX"] = 630.1690542358701,
					["textY"] = 721.9895077473193,
					["graphicsY"] = 270.1827719817884,
					["disableGraphics"] = true,
					["textColor"] = {
						0.1882352941176471, -- [1]
						[3] = 0.1803921568627451,
					},
				},
				["Combo Points"] = {
					["enabled"] = false,
					["graphicsX"] = 34.42272438867531,
					["disableText"] = true,
					["textX"] = 182.6514905779659,
					["textY"] = 462.4458708735765,
					["graphicsY"] = 376.217043005403,
					["disableGraphics"] = true,
				},
			},
			["locked"] = true,
		},
	},
}
