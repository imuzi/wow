
MacroToolkitDB = {
	["char"] = {
		["Ennyin - 索瑞森"] = {
			["backups"] = {
			},
		},
	},
	["global"] = {
		["backups"] = {
		},
		["ebackups"] = {
		},
	},
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "profile",
		["Rainylone - 末日行者"] = "profile",
		["Ennyin - 索瑞森"] = "profile",
		["Madeep - 冰风岗"] = "profile",
		["Ennyin - 埃加洛尔"] = "profile",
	},
	["profiles"] = {
		["profile"] = {
			["y"] = 501.6000366210938,
			["x"] = 220.8857116699219,
		},
	},
}
