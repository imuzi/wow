
OmniCDDB = {
	["profileKeys"] = {
		["Ennyin - 索瑞森"] = "Default",
		["云雨別 - 索瑞森"] = "Default",
		["Ennyin - 埃加洛尔"] = "Default",
		["借你流年 - 燃烧之刃"] = "Default",
		["绑住了风 - 索瑞森"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["你诺 - 索瑞森"] = "Default",
		["海雅 - 索瑞森"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["別雨 - 索瑞森"] = "Default",
		["Rainylone - 末日行者"] = "Default",
	},
	["global"] = {
		["disableElvMsg"] = true,
	},
	["cooldowns"] = {
	},
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["version"] = 2,
	["profiles"] = {
		["Default"] = {
			["modules"] = {
				["Party"] = false,
			},
			["Party"] = {
				["disableElvMsg"] = true,
				["visibility"] = {
					["none"] = true,
				},
			},
		},
	},
}
