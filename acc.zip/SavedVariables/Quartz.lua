
Quartz3DB = {
	["namespaces"] = {
		["Swing"] = {
		},
		["Buff"] = {
		},
		["Interrupt"] = {
		},
		["Flight"] = {
		},
		["Pet"] = {
			["profiles"] = {
				["Default"] = {
					["y"] = 15.9998426437378,
					["x"] = 1156,
				},
				["ENNYIN"] = {
					["y"] = 15.9998426437378,
					["x"] = 1156,
				},
			},
		},
		["LibDualSpec-1.0"] = {
		},
		["Player"] = {
			["profiles"] = {
				["Default"] = {
					["y"] = 348.486083984375,
					["h"] = 31,
					["x"] = 548.114501953125,
					["w"] = 455,
					["texture"] = "Armory",
				},
				["ENNYIN"] = {
					["h"] = 31,
					["timefontsize"] = 11,
					["w"] = 395,
					["y"] = 93,
					["point"] = "BOTTOM",
					["border"] = "None",
					["fontsize"] = 12,
					["x"] = 0,
					["nametextx"] = 2,
					["timetextx"] = 2,
					["texture"] = "MaUI 7",
				},
			},
		},
		["EnemyCasts"] = {
			["profiles"] = {
				["ENNYIN"] = {
					["instanceonly"] = false,
					["anchor"] = "target",
					["y"] = 434,
				},
			},
		},
		["GCD"] = {
			["profiles"] = {
				["Default"] = {
					["gcdheight"] = 5,
				},
				["ENNYIN"] = {
					["y"] = 902,
					["x"] = 541,
					["sparkcolor"] = {
						nil, -- [1]
						0, -- [2]
						0.07058823529411765, -- [3]
						1, -- [4]
					},
					["gcdheight"] = 2,
					["gcdgap"] = -2,
				},
			},
		},
		["Focus"] = {
			["profiles"] = {
				["Default"] = {
					["noInterruptBorderColor"] = {
						0.7294117647058823, -- [1]
						0.04705882352941176, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["iconposition"] = "right",
					["noInterruptChangeBorder"] = true,
					["w"] = 615,
					["noInterruptChangeColor"] = true,
					["y"] = 606.4296875,
					["noInterruptColor"] = {
						nil, -- [1]
						0.01568627450980392, -- [2]
						nil, -- [3]
						1, -- [4]
					},
					["fontsize"] = 20,
					["iconalpha"] = 1,
					["x"] = 489.4579772949219,
					["timefontsize"] = 19,
					["h"] = 32,
					["nametextposition"] = "center",
				},
				["ENNYIN"] = {
					["h"] = 48,
					["timefontsize"] = 16,
					["noInterruptBorderColor"] = {
						0.9882352941176471, -- [1]
						1, -- [2]
						0.9647058823529412, -- [3]
						1, -- [4]
					},
					["y"] = -197.333251953125,
					["x"] = -147.3148803710938,
					["iconalpha"] = 1,
					["icongap"] = 0,
					["point"] = "TOP",
					["border"] = "1 Pixel",
					["noInterruptColor"] = {
						0.9921568627450981, -- [1]
						1, -- [2]
						0.9490196078431372, -- [3]
						1, -- [4]
					},
					["fontsize"] = 16,
					["texture"] = "DarkBottom",
					["nametextx"] = -12,
					["noInterruptChangeBorder"] = true,
					["noInterruptChangeColor"] = true,
					["nametextposition"] = "centerback",
				},
			},
		},
		["Target"] = {
			["profiles"] = {
				["Default"] = {
					["noInterruptBorderColor"] = {
						0.7294117647058823, -- [1]
						0.07450980392156863, -- [2]
						0.07058823529411765, -- [3]
						1, -- [4]
					},
					["noInterruptChangeBorder"] = true,
					["w"] = 150,
					["noInterruptChangeColor"] = true,
					["y"] = 708.8861694335938,
					["h"] = 20,
					["x"] = 926.5137329101562,
					["noInterruptColor"] = {
						nil, -- [1]
						0.05882352941176471, -- [2]
						0.04705882352941176, -- [3]
						1, -- [4]
					},
					["iconposition"] = "left",
				},
				["ENNYIN"] = {
					["h"] = 23,
					["timefontsize"] = 11,
					["noInterruptBorderColor"] = {
						0.7176470588235294, -- [1]
						0.7294117647058823, -- [2]
						0.6588235294117647, -- [3]
						1, -- [4]
					},
					["w"] = 153,
					["y"] = 180.0000152587891,
					["font"] = "默认",
					["point"] = "BOTTOM",
					["border"] = "None",
					["noInterruptColor"] = {
						0.9411764705882353, -- [1]
						1, -- [2]
						0.9647058823529412, -- [3]
						1, -- [4]
					},
					["fontsize"] = 10,
					["texture"] = "Raven Black",
					["x"] = 142.9999084472656,
					["noInterruptChangeBorder"] = true,
					["timetextx"] = 0,
					["noInterruptChangeColor"] = true,
					["nametextx"] = 6,
				},
			},
		},
		["Mirror"] = {
		},
		["Range"] = {
		},
		["Latency"] = {
			["profiles"] = {
				["ENNYIN"] = {
					["lagtextalignment"] = "right",
					["lagtextcolor"] = {
						0.5450980392156862, -- [1]
						0.5450980392156862, -- [2]
						0.5450980392156862, -- [3]
						0.3199999928474426, -- [4]
					},
					["lagfontsize"] = 6,
				},
			},
		},
	},
	["profileKeys"] = {
		["Haiya - 索瑞森"] = "Default",
		["Ifey - 冰风岗"] = "Default",
		["嘿嘿牛 - 达尔坎"] = "Default",
		["Whsi - 伊森利恩"] = "Default",
		["香水般的温柔 - 恶魔之翼"] = "Default",
		["Ennysoul - 索瑞森"] = "Default",
		["失重 - 无尽之海"] = "Default",
		["Boneshoc - 夏维安"] = "Default",
		["额为我 - 战歌"] = "Default",
		["那片云的味道 - 恶魔之翼"] = "Default",
		["你诺 - 索瑞森"] = "Default",
		["Ennyin - 埃加洛尔"] = "ENNYIN",
		["Elytolpain - 夏维安"] = "Default",
		["Eofol - 沙怒"] = "Default",
		["我过年好 - 鬼雾峰"] = "Default",
		["Sotu - 燃烧之刃"] = "Default",
		["孤涯 - 索瑞森"] = "Default",
		["Ylno - 夏维安"] = "Default",
		["绑住了风 - 恶魔之翼"] = "Default",
		["Rinaly - 索瑞森"] = "Default",
		["Esserbella - 索瑞森"] = "Default",
		["Oow - 达文格尔"] = "Default",
		["Nuc - 阿拉希"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["Rainylone - 夏维安"] = "Default",
		["Wenderpai - 熊猫酒仙"] = "Default",
		["Ennyin - 提瑞斯法"] = "Default",
		["Lure - 达文格尔"] = "Default",
		["画雨 - 索瑞森"] = "Default",
		["Revp - 黑铁"] = "Default",
		["Rainylone - 末日行者"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["modules"] = {
				["EnemyCasts"] = true,
				["Pet"] = false,
				["Buff"] = false,
			},
		},
		["ENNYIN"] = {
			["channelingcolor"] = {
				1, -- [1]
				0.3098039215686275, -- [2]
				0.6941176470588235, -- [3]
				1, -- [4]
			},
			["completecolor"] = {
				0.05098039215686274, -- [1]
				0.2823529411764706, -- [2]
				0.00392156862745098, -- [3]
				1, -- [4]
			},
			["backgroundalpha"] = 0.83,
			["bordercolor"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				1, -- [4]
			},
			["backgroundcolor"] = {
				0.02352941176470588, -- [1]
				0.02352941176470588, -- [2]
				0.02352941176470588, -- [3]
				1, -- [4]
			},
			["modules"] = {
				["Buff"] = false,
				["Timer"] = false,
				["Flight"] = false,
				["Pet"] = false,
			},
			["castingcolor"] = {
				nil, -- [1]
				0.2901960784313725, -- [2]
				0.7568627450980392, -- [3]
				1, -- [4]
			},
		},
	},
}
