
HandyNotesDB = {
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "借你流年 - 燃烧之刃",
		["Esserbella - 索瑞森"] = "Esserbella - 索瑞森",
		["Ennyin - 索瑞森"] = "Ennyin - 索瑞森",
		["Madeep - 冰风岗"] = "Madeep - 冰风岗",
		["Ennyin - 埃加洛尔"] = "Ennyin - 埃加洛尔",
		["Rainylone - 末日行者"] = "Rainylone - 末日行者",
	},
	["profiles"] = {
		["借你流年 - 燃烧之刃"] = {
		},
		["Esserbella - 索瑞森"] = {
		},
		["Ennyin - 索瑞森"] = {
		},
		["Madeep - 冰风岗"] = {
		},
		["Ennyin - 埃加洛尔"] = {
		},
		["Rainylone - 末日行者"] = {
		},
	},
}
HandyNotes_HandyNotesDB = {
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "借你流年 - 燃烧之刃",
		["Esserbella - 索瑞森"] = "Esserbella - 索瑞森",
		["Ennyin - 索瑞森"] = "Ennyin - 索瑞森",
		["Madeep - 冰风岗"] = "Madeep - 冰风岗",
		["Ennyin - 埃加洛尔"] = "Ennyin - 埃加洛尔",
		["Rainylone - 末日行者"] = "Rainylone - 末日行者",
	},
	["profiles"] = {
		["借你流年 - 燃烧之刃"] = {
		},
		["Esserbella - 索瑞森"] = {
		},
		["Ennyin - 索瑞森"] = {
		},
		["Madeep - 冰风岗"] = {
		},
		["Ennyin - 埃加洛尔"] = {
		},
		["Rainylone - 末日行者"] = {
		},
	},
}
