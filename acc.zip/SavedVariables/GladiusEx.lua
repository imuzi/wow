
GladiusExDB = {
	["namespaces"] = {
		["party_CastBar"] = {
			["profiles"] = {
				["木诺子其 - 索瑞森"] = {
					["castTextAlign"] = "LEFT",
					["castBarAnchor"] = "TOPRIGHT",
					["castTimeTextOffsetX"] = -2,
					["castTextOffsetX"] = 2,
					["castTimeTextAlign"] = "RIGHT",
					["castIconPosition"] = "LEFT",
					["castBarRelativePoint"] = "TOPLEFT",
				},
			},
		},
		["Highlight"] = {
		},
		["LibDualSpec-1.0"] = {
		},
		["party_Alerts"] = {
		},
		["party_HealthBar"] = {
		},
		["party_ClassIcon"] = {
			["profiles"] = {
				["木诺子其 - 索瑞森"] = {
					["classIconPosition"] = "LEFT",
				},
			},
		},
		["party_Highlight"] = {
		},
		["party_DRTracker"] = {
			["profiles"] = {
				["木诺子其 - 索瑞森"] = {
					["drTrackerAnchor"] = "RIGHT",
					["drTrackerOffsetX"] = -2,
					["drTrackerRelativePoint"] = "LEFT",
					["drTrackerGrowDirection"] = "LEFT",
				},
			},
		},
		["DRTracker"] = {
		},
		["party_PowerBar"] = {
		},
		["SkillHistory"] = {
		},
		["party_TargetBar"] = {
			["profiles"] = {
				["木诺子其 - 索瑞森"] = {
					["IconPosition"] = "LEFT",
					["Anchor"] = "BOTTOMLEFT",
					["RelativePoint"] = "TOPLEFT",
				},
			},
		},
		["Cooldowns"] = {
		},
		["arena"] = {
			["profiles"] = {
				["借你流年 - 燃烧之刃"] = {
					["modules"] = {
						["SkillHistory"] = false,
						["Clicks"] = true,
					},
					["barsHeight"] = 37,
					["y"] = {
						["anchor_arena"] = 440.2282584097302,
						["arena2"] = 460.2802438966537,
						["arena3"] = 390.2722314484672,
						["arena1"] = 530.2882128878118,
					},
					["x"] = {
						["anchor_arena"] = 899.6127225806194,
						["arena2"] = 899.6127225806194,
						["arena3"] = 899.6127225806194,
						["arena1"] = 899.6127225806194,
					},
					["borderSize"] = 0,
					["frameScale"] = 0.89,
					["barWidth"] = 107,
				},
				["Madeep - 冰风岗"] = {
					["y"] = {
						["anchor_arena"] = 373.6686788994848,
						["arena2"] = 393.2687265593559,
						["arena3"] = 320.468755312635,
						["arena1"] = 466.0686733920156,
					},
					["x"] = {
						["anchor_arena"] = 932.8924248640251,
						["arena2"] = 966.492422861309,
						["arena3"] = 966.492422861309,
						["arena1"] = 966.492422861309,
					},
				},
				["木诺子其 - 索瑞森"] = {
					["y"] = {
						["anchor_arena"] = 444.600042134116,
						["arena3"] = 261.419245913792,
						["arena2"] = 430.320099741151,
						["arena1"] = 495.200044271245,
					},
					["x"] = {
						["anchor_arena"] = 1063.10120209318,
						["arena3"] = 751.08806454092,
						["arena2"] = 1090.46119311061,
						["arena1"] = 1090.46119311061,
					},
					["frameScale"] = 0.68,
				},
				["Ennyin - 索瑞森"] = {
					["y"] = {
						["anchor_arena"] = 418.0514711887809,
						["arena3"] = 254.5534102417696,
						["arena2"] = 276.8504047498573,
						["arena1"] = 321.4444582191572,
					},
					["borderSize"] = 0,
					["backgroundPadding"] = 0,
					["modMargin"] = 0,
					["frameScale"] = 0.96,
					["margin"] = 0,
					["x"] = {
						["anchor_arena"] = 848.834004000164,
						["arena3"] = 606.8054146807117,
						["arena2"] = 606.8054146807117,
						["arena1"] = 606.8054146807117,
					},
				},
			},
		},
		["Auras"] = {
		},
		["CastBar"] = {
			["profiles"] = {
				["借你流年 - 燃烧之刃"] = {
					["castBarHeight"] = 35,
				},
			},
		},
		["party"] = {
			["profiles"] = {
				["借你流年 - 燃烧之刃"] = {
					["y"] = {
						["anchor_party"] = 412.4343504169956,
						["player"] = 449.3025205034028,
						["party2"] = 319.7185725520831,
						["party1"] = 384.5105682562571,
					},
					["x"] = {
						["anchor_party"] = 119.360002651214,
						["player"] = 166.0384628683041,
						["party2"] = 166.0384628683041,
						["party1"] = 166.0384628683041,
					},
				},
				["Ennyin - 索瑞森"] = {
					["y"] = {
						["anchor_party"] = 496.017776609151,
						["player"] = 539.4418447332282,
						["party2"] = 462.385781674202,
						["party1"] = 485.4577766663715,
					},
					["borderSize"] = 0,
					["x"] = {
						["anchor_party"] = 133.2802558696039,
						["player"] = 177.18423390319,
						["party2"] = 177.18423390319,
						["party1"] = 177.18423390319,
					},
					["barsHeight"] = 55,
					["backgroundPadding"] = 0,
					["frameScale"] = 0.66,
					["margin"] = 0,
					["barWidth"] = 197,
				},
				["木诺子其 - 索瑞森"] = {
					["y"] = {
						["anchor_party"] = 563.600018135239,
						["player"] = 612.049520597979,
						["arena2"] = 429.270086289238,
						["party1"] = 549.319976481129,
						["anchor_arena"] = 444.600042134116,
						["party2"] = 342.339184509086,
						["arena3"] = 279.911253651429,
						["arena1"] = 499.09006125803,
					},
					["x"] = {
						["anchor_party"] = 68.60006419813,
						["player"] = 96.7792246507815,
						["arena2"] = 1092.66121263115,
						["party1"] = 96.7792246507815,
						["anchor_arena"] = 1063.10120209318,
						["party2"] = 75.0448478962903,
						["arena3"] = 806.315140696359,
						["arena1"] = 1092.66121263115,
					},
					["frameScale"] = 0.68,
				},
				["Madeep - 冰风岗"] = {
					["y"] = {
						["anchor_party"] = 474.605635773798,
						["player"] = 567.0055814382067,
						["party1"] = 494.205683433669,
						["party2"] = 421.4056877728872,
					},
					["x"] = {
						["anchor_party"] = 129.2343184689089,
						["player"] = 196.4343510845683,
						["party1"] = 196.4343510845683,
						["party2"] = 196.4343510845683,
					},
				},
				["Ennysoul - 索瑞森"] = {
					["y"] = {
						["anchor_party"] = 400.999969482422,
						["player"] = 516.499938964844,
					},
					["x"] = {
						["anchor_party"] = 1000.99993896484,
						["player"] = 1043,
					},
				},
			},
		},
		["party_SkillHistory"] = {
			["profiles"] = {
				["木诺子其 - 索瑞森"] = {
					["Anchor"] = "RIGHT",
					["RelativePoint"] = "LEFT",
					["OffsetX"] = -2,
					["GrowDirection"] = "LEFT",
				},
			},
		},
		["PowerBar"] = {
		},
		["Interrupts"] = {
		},
		["party_Announcements"] = {
		},
		["HealthBar"] = {
		},
		["PetBar"] = {
		},
		["Alerts"] = {
		},
		["party_Cooldowns"] = {
			["profiles"] = {
				["木诺子其 - 索瑞森"] = {
					["groups"] = {
						["group_2"] = {
							["cooldownsGrow"] = "DOWNRIGHT",
							["cooldownsAnchor"] = "TOPLEFT",
							["cooldownsRelativePoint"] = "TOPRIGHT",
						},
						["group_1"] = {
							["cooldownsGrow"] = "DOWNRIGHT",
							["cooldownsAnchor"] = "TOPLEFT",
							["cooldownsRelativePoint"] = "BOTTOMLEFT",
						},
					},
				},
			},
		},
		["party_Clicks"] = {
		},
		["TargetBar"] = {
		},
		["party_Interrupts"] = {
		},
		["party_Tags"] = {
		},
		["party_Auras"] = {
			["profiles"] = {
				["木诺子其 - 索瑞森"] = {
					["aurasDebuffsRelativePoint"] = "TOPRIGHT",
					["aurasBuffsRelativePoint"] = "TOPLEFT",
					["aurasDebuffsGrow"] = "UPLEFT",
					["aurasDebuffsAnchor"] = "BOTTOMRIGHT",
					["aurasBuffsAnchor"] = "BOTTOMLEFT",
					["aurasBuffsGrow"] = "UPRIGHT",
				},
			},
		},
		["Tags"] = {
		},
		["Announcements"] = {
		},
		["Clicks"] = {
		},
		["party_PetBar"] = {
			["profiles"] = {
				["木诺子其 - 索瑞森"] = {
					["IconPosition"] = "RIGHT",
					["Anchor"] = "BOTTOMRIGHT",
					["RelativePoint"] = "TOPRIGHT",
				},
			},
		},
		["ClassIcon"] = {
		},
	},
	["profileKeys"] = {
		["香水般的温柔 - 恶魔之翼"] = "香水般的温柔 - 恶魔之翼",
		["Ennysoul - 索瑞森"] = "Ennysoul - 索瑞森",
		["借你流年 - 燃烧之刃"] = "借你流年 - 燃烧之刃",
		["额为我 - 战歌"] = "额为我 - 战歌",
		["那片云的味道 - 恶魔之翼"] = "那片云的味道 - 恶魔之翼",
		["幽笠巫 - 熊猫酒仙"] = "幽笠巫 - 熊猫酒仙",
		["Madeep - 冰风岗"] = "Madeep - 冰风岗",
		["Lure - 达文格尔"] = "Lure - 达文格尔",
		["Sotu - 燃烧之刃"] = "Sotu - 燃烧之刃",
		["Ennyin - 埃加洛尔"] = "Ennyin - 索瑞森",
		["绑住了风 - 恶魔之翼"] = "绑住了风 - 恶魔之翼",
		["海雅 - 索瑞森"] = "海雅 - 索瑞森",
		["Rainylone - 末日行者"] = "借你流年 - 燃烧之刃",
		["云雨別 - 索瑞森"] = "云雨別 - 索瑞森",
		["Nuc - 阿拉希"] = "Nuc - 阿拉希",
		["Ennyin - 提瑞斯法"] = "Ennyin - 提瑞斯法",
		["绑住了风 - 索瑞森"] = "绑住了风 - 索瑞森",
		["浮雲 - 恶魔之翼"] = "浮雲 - 恶魔之翼",
		["Ennyin - 索瑞森"] = "借你流年 - 燃烧之刃",
		["木诺子其 - 索瑞森"] = "木诺子其 - 索瑞森",
		["画雨 - 索瑞森"] = "画雨 - 索瑞森",
		["別雨 - 索瑞森"] = "別雨 - 索瑞森",
		["Esserbella - 索瑞森"] = "Esserbella - 索瑞森",
	},
	["profiles"] = {
		["香水般的温柔 - 恶魔之翼"] = {
			["locked"] = true,
		},
		["Ennysoul - 索瑞森"] = {
			["locked"] = true,
		},
		["借你流年 - 燃烧之刃"] = {
			["showParty"] = false,
			["locked"] = true,
		},
		["额为我 - 战歌"] = {
		},
		["那片云的味道 - 恶魔之翼"] = {
		},
		["幽笠巫 - 熊猫酒仙"] = {
		},
		["Madeep - 冰风岗"] = {
			["locked"] = true,
		},
		["Lure - 达文格尔"] = {
		},
		["Sotu - 燃烧之刃"] = {
			["locked"] = true,
		},
		["绑住了风 - 恶魔之翼"] = {
			["locked"] = true,
		},
		["Ennyin - 埃加洛尔"] = {
		},
		["海雅 - 索瑞森"] = {
		},
		["Rainylone - 末日行者"] = {
			["locked"] = true,
		},
		["Nuc - 阿拉希"] = {
		},
		["云雨別 - 索瑞森"] = {
		},
		["绑住了风 - 索瑞森"] = {
			["locked"] = true,
		},
		["浮雲 - 恶魔之翼"] = {
			["locked"] = true,
		},
		["Ennyin - 索瑞森"] = {
			["locked"] = true,
		},
		["木诺子其 - 索瑞森"] = {
			["locked"] = true,
		},
		["画雨 - 索瑞森"] = {
		},
		["別雨 - 索瑞森"] = {
			["locked"] = true,
		},
		["Ennyin - 提瑞斯法"] = {
		},
	},
}
