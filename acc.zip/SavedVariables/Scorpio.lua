
Scorpio_DB = {
	["LogLevel"] = 3,
	["TaskFactor"] = 0.4,
	["TaskThreshold"] = 15,
	["OvertimeFactor"] = 0.3,
}
