
EnemyGridDB = {
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["Ennyin - 索瑞森"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["path_7_11_warning"] = true,
			["frame_range_alpha"] = 0.299999982118607,
		},
	},
}
