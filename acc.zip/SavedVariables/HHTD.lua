
HHTD_SavedVariables = {
	["char"] = {
		["Ennyin - 索瑞森"] = {
			["settingsMigrated"] = false,
		},
		["云雨別 - 索瑞森"] = {
			["settingsMigrated"] = false,
		},
		["Ennyin - 埃加洛尔"] = {
			["settingsMigrated"] = false,
		},
		["借你流年 - 燃烧之刃"] = {
			["settingsMigrated"] = false,
		},
		["绑住了风 - 索瑞森"] = {
			["settingsMigrated"] = false,
		},
		["浮雲 - 恶魔之翼"] = {
			["settingsMigrated"] = false,
		},
		["你诺 - 索瑞森"] = {
			["settingsMigrated"] = false,
		},
		["別雨 - 索瑞森"] = {
			["settingsMigrated"] = false,
		},
		["Madeep - 冰风岗"] = {
			["settingsMigrated"] = false,
		},
		["海雅 - 索瑞森"] = {
			["settingsMigrated"] = false,
		},
		["Rainylone - 末日行者"] = {
			["settingsMigrated"] = false,
		},
	},
	["namespaces"] = {
		["Announcer"] = {
			["global"] = {
				["Sounds"] = false,
			},
		},
		["CM"] = {
		},
		["NPH"] = {
			["global"] = {
				["marker_Scale"] = 0.9299999999999999,
			},
		},
	},
	["profileKeys"] = {
		["Ennyin - 索瑞森"] = "Ennyin - 索瑞森",
		["云雨別 - 索瑞森"] = "云雨別 - 索瑞森",
		["Ennyin - 埃加洛尔"] = "Ennyin - 埃加洛尔",
		["借你流年 - 燃烧之刃"] = "借你流年 - 燃烧之刃",
		["绑住了风 - 索瑞森"] = "绑住了风 - 索瑞森",
		["浮雲 - 恶魔之翼"] = "浮雲 - 恶魔之翼",
		["你诺 - 索瑞森"] = "你诺 - 索瑞森",
		["別雨 - 索瑞森"] = "別雨 - 索瑞森",
		["Madeep - 冰风岗"] = "Madeep - 冰风岗",
		["海雅 - 索瑞森"] = "海雅 - 索瑞森",
		["Rainylone - 末日行者"] = "Rainylone - 末日行者",
	},
	["global"] = {
		["settingsMigrated"] = false,
		["oldNameEnableState"] = 0,
		["PHMDAP"] = 0.8200000000000001,
	},
}
