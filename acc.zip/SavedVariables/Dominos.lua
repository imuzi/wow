
DominosDB = {
	["namespaces"] = {
		["ProgressBars"] = {
			["char"] = {
				["Ennyin - 索瑞森"] = {
					["bars"] = {
						["artifact"] = {
							["mode"] = "azerite",
						},
						["exp"] = {
							["mode"] = "reputation",
						},
					},
				},
				["云雨別 - 索瑞森"] = {
					["bars"] = {
						["artifact"] = {
							["mode"] = "azerite",
						},
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["Ennyin - 埃加洛尔"] = {
					["bars"] = {
						["artifact"] = {
							["mode"] = "azerite",
						},
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["借你流年 - 燃烧之刃"] = {
					["bars"] = {
						["artifact"] = {
							["mode"] = "azerite",
						},
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["绑住了风 - 索瑞森"] = {
					["bars"] = {
						["artifact"] = {
							["mode"] = "azerite",
						},
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["浮雲 - 恶魔之翼"] = {
					["bars"] = {
						["artifact"] = {
							["mode"] = "azerite",
						},
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["你诺 - 索瑞森"] = {
					["bars"] = {
						["artifact"] = {
							["mode"] = "azerite",
						},
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["海雅 - 索瑞森"] = {
					["bars"] = {
						["artifact"] = {
							["mode"] = "azerite",
						},
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["Madeep - 冰风岗"] = {
					["bars"] = {
						["artifact"] = {
							["mode"] = "azerite",
						},
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["別雨 - 索瑞森"] = {
					["bars"] = {
						["artifact"] = {
							["mode"] = "azerite",
						},
						["exp"] = {
							["mode"] = "reputation",
						},
					},
				},
				["Rainylone - 末日行者"] = {
					["bars"] = {
						["artifact"] = {
							["mode"] = "azerite",
						},
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
			},
			["global"] = {
				["version"] = 2,
			},
			["profiles"] = {
				["ENNYIN"] = {
					["one_bar"] = false,
					["skip_inactive_modes"] = true,
				},
			},
		},
	},
	["global"] = {
		["configVersion"] = 1,
		["addonVersion"] = "9.0.21",
	},
	["profileKeys"] = {
		["Ennyin - 埃加洛尔"] = "ENNYIN",
	},
	["profiles"] = {
		["ENNYIN"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.84,
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["spacing"] = 1,
					["padH"] = 1,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.75,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = -306,
					["columns"] = 3,
					["spacing"] = 1,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
					},
					["fadeAlpha"] = 0,
				}, -- [2]
				{
					["point"] = "BOTTOM",
					["scale"] = 0.7,
					["padW"] = 2,
					["showstates"] = "",
					["fadeOutDuration"] = 0.1000000014901161,
					["spacing"] = 4,
					["fadeInDuration"] = 0.1000000014901161,
					["pages"] = {
						["MAGE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
					},
					["showInPetBattleUI"] = false,
					["columns"] = 3,
					["showInOverrideUI"] = false,
					["fadeOutDelay"] = false,
					["x"] = 327,
					["padH"] = 2,
					["fadeInDelay"] = false,
					["fadeAlpha"] = 0,
					["numButtons"] = 12,
				}, -- [3]
				{
					["point"] = "BOTTOM",
					["scale"] = 0.92,
					["padW"] = 5,
					["showstates"] = "",
					["fadeOutDuration"] = 0.1000000014901161,
					["clickThrough"] = false,
					["fadeInDuration"] = 0.1000000014901161,
					["pages"] = {
						["MAGE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
					},
					["showInPetBattleUI"] = false,
					["columns"] = 5,
					["showInOverrideUI"] = false,
					["alpha"] = 0.69,
					["y"] = 5,
					["x"] = -391,
					["fadeAlpha"] = 0,
					["fadeOutDelay"] = false,
					["padH"] = 5,
					["fadeInDelay"] = false,
					["spacing"] = 0,
					["numButtons"] = 12,
				}, -- [4]
				{
					["point"] = "RIGHT",
					["scale"] = 0.57,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["fadeOutDuration"] = 0.1000000014901161,
					["spacing"] = 4,
					["fadeInDuration"] = 0.1000000014901161,
					["pages"] = {
						["MAGE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
					},
					["showInPetBattleUI"] = false,
					["columns"] = 2,
					["showInOverrideUI"] = false,
					["y"] = 112,
					["showstates"] = "",
					["padH"] = 2,
					["fadeInDelay"] = false,
					["fadeOutDelay"] = false,
					["numButtons"] = 12,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["pages"] = {
						["MAGE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
					},
					["point"] = "BOTTOM",
					["fadeOutDelay"] = false,
					["scale"] = 0.84,
					["showInOverrideUI"] = false,
					["fadeInDuration"] = 0.1000000014901161,
					["y"] = 38,
					["showstates"] = "",
					["fadeOutDuration"] = 0.1000000014901161,
					["spacing"] = 1,
					["padH"] = 1,
					["fadeInDelay"] = false,
					["numButtons"] = 12,
					["padW"] = 1,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 3,
					["scale"] = 0.78,
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["fadeAlpha"] = 0,
					["y"] = -244,
					["spacing"] = 3,
					["padH"] = 1,
					["pages"] = {
						["MAGE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["point"] = "RIGHT",
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "TOPRIGHT",
					["scale"] = 0.5,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
					},
					["numButtons"] = 8,
					["columns"] = 1,
				}, -- [8]
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 1.07,
					["padW"] = 2,
					["showstates"] = "[@pet,exists,nopossessbar]show;hide;",
					["fadeOutDuration"] = 0.1000000014901161,
					["clickThrough"] = false,
					["fadeInDuration"] = 0.1000000014901161,
					["numButtons"] = 1,
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["alpha"] = 0.9,
					["fadeAlpha"] = 0.11,
					["y"] = 59.90524673461915,
					["relPoint"] = "BOTTOM",
					["fadeOutDelay"] = false,
					["pages"] = {
						["MAGE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
					},
					["padH"] = 2,
					["fadeInDelay"] = false,
					["spacing"] = 1,
					["x"] = -134.5088868437867,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 0.57,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["y"] = -118,
					["spacing"] = 0,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["columns"] = 2,
				}, -- [10]
				["artifact"] = {
					["point"] = "BOTTOMLEFT",
					["scale"] = 1,
					["lockMode"] = false,
					["padW"] = 2,
					["fadeAlpha"] = 0.86,
					["spacing"] = 1,
					["mode"] = "azerite",
					["numButtons"] = 20,
					["texture"] = "Minimalist (GladiusEx)",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["showInOverrideUI"] = false,
					["showLabels"] = true,
					["width"] = 566,
					["y"] = 12,
					["font"] = "MSBT ARKai_C",
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["height"] = 6,
					["padH"] = 2,
					["alwaysShowText"] = false,
				},
				["exp"] = {
					["point"] = "BOTTOMLEFT",
					["scale"] = 1,
					["lockMode"] = false,
					["padW"] = 2,
					["fadeAlpha"] = 0.81,
					["spacing"] = 1,
					["mode"] = "reputation",
					["numButtons"] = 20,
					["texture"] = "Cabaret",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["showInOverrideUI"] = false,
					["showLabels"] = true,
					["width"] = 566,
					["font"] = "ClearFont",
					["padH"] = 2,
					["height"] = 6,
					["display"] = {
						["label"] = true,
						["max"] = true,
						["value"] = true,
						["percent"] = true,
						["bonus"] = true,
					},
					["alwaysShowText"] = false,
				},
				["extra"] = {
					["y"] = 161,
					["x"] = 354,
					["spacing"] = 0,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["zone"] = {
					["y"] = 0,
					["x"] = 0,
					["point"] = "RIGHT",
					["showInOverrideUI"] = true,
					["showInPetBattleUI"] = true,
				},
				["possess"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["y"] = 0,
					["x"] = 244,
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOPRIGHT",
					["scale"] = 0.76,
					["showInOverrideUI"] = false,
					["fadeAlpha"] = 0,
					["numButtons"] = 5,
					["x"] = -308,
				},
				["xp"] = {
					["showInPetBattleUI"] = false,
					["alwaysShowXP"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.88,
					["showInOverrideUI"] = false,
					["width"] = 0.86,
					["y"] = 129,
					["x"] = -61,
					["height"] = 3,
					["alwaysShowText"] = 1,
					["texture"] = "Healbot",
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["width"] = 28,
					["y"] = 30,
					["x"] = 0,
					["showText"] = true,
					["height"] = 8,
					["padding"] = 0,
					["font"] = "Friz Quadrata TT",
					["display"] = {
						["time"] = true,
						["border"] = true,
						["icon"] = false,
					},
				},
				["roll"] = {
					["showInPetBattleUI"] = false,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = false,
					["numButtons"] = 4,
					["columns"] = 1,
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["x"] = -28,
					["point"] = "TOPRIGHT",
					["disabled"] = {
					},
					["scale"] = 0.72,
					["showInOverrideUI"] = false,
					["fadeAlpha"] = 0,
				},
				["encounter"] = {
					["showInPetBattleUI"] = true,
					["x"] = 18,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = true,
					["y"] = 197,
				},
				["class"] = {
					["y"] = -358.000071934939,
					["x"] = 523.000122398803,
					["point"] = "TOPLEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = false,
					["numButtons"] = 0,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 61,
					["x"] = 214,
					["point"] = "LEFT",
					["showInOverrideUI"] = false,
					["numButtons"] = 3,
					["showInPetBattleUI"] = false,
				},
				["talk"] = {
					["y"] = -123,
					["x"] = -58,
					["showInOverrideUI"] = true,
					["showInPetBattleUI"] = true,
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["y"] = 89.99999237060548,
					["scale"] = 0.73,
					["showInOverrideUI"] = false,
					["fadeInDelay"] = false,
					["padW"] = 5,
					["showstates"] = "[@pet,exists,nopossessbar]show;hide",
					["fadeOutDuration"] = 0.1000000014901161,
					["spacing"] = 2,
					["padH"] = 5,
					["fadeInDuration"] = 0.1000000014901161,
					["x"] = -0.0001272434338418685,
					["fadeOutDelay"] = false,
				},
			},
			["minimap"] = {
				["minimapPos"] = 346.6384430495825,
			},
			["showBindingText"] = 1,
			["showgrid"] = true,
			["sticky"] = false,
		},
		["T"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["y"] = 0,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 120,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 160,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 200,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 360,
				}, -- [10]
				["exp"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["lockMode"] = true,
					["numButtons"] = 20,
					["showInOverrideUI"] = false,
					["y"] = 0,
					["padH"] = 2,
					["padW"] = 2,
					["x"] = 0,
					["columns"] = 20,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["font"] = "Friz Quadrata TT",
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["encounter"] = {
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["point"] = "CENTER",
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["talk"] = {
					["y"] = 74,
					["x"] = 0,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = true,
					["showInPetBattleUI"] = true,
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["extra"] = {
					["y"] = 160,
					["x"] = 0,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = true,
					["showInPetBattleUI"] = true,
				},
				["possess"] = {
					["showInPetBattleUI"] = false,
					["x"] = 244,
					["point"] = "CENTER",
					["spacing"] = 4,
					["padH"] = 2,
					["showInOverrideUI"] = false,
					["y"] = 0,
					["padW"] = 2,
				},
			},
		},
	},
}
