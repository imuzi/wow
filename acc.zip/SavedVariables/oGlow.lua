
oGlowDB = {
	["version"] = 1,
	["FilterSettings"] = {
	},
	["EnabledPipes"] = {
		["merchant"] = true,
		["bags"] = true,
		["char"] = true,
		["char-flyout"] = true,
		["gbank"] = true,
		["trade"] = true,
		["mail"] = true,
		["inspect"] = true,
		["tradeskill"] = true,
		["bank"] = true,
	},
	["Colors"] = {
	},
	["EnabledFilters"] = {
		["Quality border"] = {
			["merchant"] = true,
			["bags"] = true,
			["char"] = true,
			["char-flyout"] = true,
			["gbank"] = true,
			["trade"] = true,
			["mail"] = true,
			["inspect"] = true,
			["tradeskill"] = true,
			["bank"] = true,
		},
	},
}
