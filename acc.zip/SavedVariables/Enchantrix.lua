
EnchantConfig = {
	["profile.Default"] = {
	},
}
EnchantedLocal = {
}
EnchantedItemTypes = {
}
NonDisenchantablesLocal = {
}
ProspectedLocal = {
}
MillingLocal = {
}
