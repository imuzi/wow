
MasterPlanAG = {
	["埃加洛尔"] = {
		["Ennyin"] = {
			["class"] = "WARLOCK",
			["summary"] = {
				["ti1"] = 118529,
				["ti2"] = 122484,
				["tt1"] = true,
				["tt2"] = true,
			},
			["faction"] = "Horde",
		},
	},
	["索瑞森"] = {
		["Ennyin"] = {
			["curOil"] = 315,
			["faction"] = "Horde",
			["lastCacheTime"] = 1451191692,
			["curRes"] = 3146,
			["class"] = "WARLOCK",
		},
	},
}
