
oUF_LegionGridDB = {
	["powercolor"] = {
		["a"] = 1,
		["b"] = 1,
		["g"] = 1,
		["r"] = 1,
	},
	["otherhealcolor"] = {
		["a"] = 0.4,
		["b"] = 0,
		["g"] = 1,
		["r"] = 0,
	},
	["cluster"] = {
		["enabled"] = false,
		["textcolor"] = {
			["a"] = 1,
			["b"] = 0.6,
			["g"] = 0.9,
			["r"] = 0,
		},
		["perc"] = 90,
		["freq"] = 250,
		["range"] = 30,
	},
	["powerbgcolor"] = {
		["a"] = 1,
		["b"] = 0.33,
		["g"] = 0.33,
		["r"] = 0.33,
	},
	["scale"] = 0.85,
	["hpcolor"] = {
		["a"] = 1,
		["b"] = 0.1,
		["g"] = 0.1,
		["r"] = 0.1,
	},
	["gradient"] = {
		["a"] = 1,
		["b"] = 0,
		["g"] = 0,
		["r"] = 1,
	},
	["hpbgcolor"] = {
		["a"] = 1,
		["b"] = 0.33,
		["g"] = 0.33,
		["r"] = 0.33,
	},
	["myhealcolor"] = {
		["a"] = 0.4,
		["b"] = 0.5,
		["g"] = 1,
		["r"] = 0,
	},
}
LegionGridomf2 = {
	["__INITIAL"] = {
		["Legiongrid"] = {
			["oUF_LegiongridRaidFrame"] = "LEFTUIParent80",
		},
	},
	["Legiongrid"] = {
		["oUF_LegiongridRaidFrame"] = "LEFTUIParent1696",
	},
}
