
DebuffFilterDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Haiya - 索瑞森"] = "Haiya - 索瑞森",
		["Whsi - 伊森利恩"] = "Whsi - 伊森利恩",
		["云雨別 - 索瑞森"] = "木诺子其 - 索瑞森",
		["Ennysoul - 索瑞森"] = "Ennysoul - 索瑞森",
		["Boneshoc - 夏维安"] = "Boneshoc - 夏维安",
		["额为我 - 战歌"] = "额为我 - 战歌",
		["那片云的味道 - 恶魔之翼"] = "那片云的味道 - 恶魔之翼",
		["幽笠巫 - 熊猫酒仙"] = "木诺子其 - 索瑞森",
		["我过年好 - 鬼雾峰"] = "我过年好 - 鬼雾峰",
		["Sotu - 燃烧之刃"] = "Sotu - 燃烧之刃",
		["Ennyin - 索瑞森"] = "木诺子其 - 索瑞森",
		["Rinaly - 索瑞森"] = "Rinaly - 索瑞森",
		["Oow - 达文格尔"] = "Oow - 达文格尔",
		["Nuc - 阿拉希"] = "Nuc - 阿拉希",
		["Rainylone - 夏维安"] = "Rainylone - 夏维安",
		["浮雲 - 恶魔之翼"] = "木诺子其 - 索瑞森",
		["木诺子其 - 索瑞森"] = "木诺子其 - 索瑞森",
		["Eofol - 沙怒"] = "Eofol - 沙怒",
		["Revp - 黑铁"] = "Revp - 黑铁",
		["撕雨 - 索瑞森"] = "撕雨 - 索瑞森",
		["Ifey - 冰风岗"] = "Ifey - 冰风岗",
		["嘿嘿牛 - 达尔坎"] = "嘿嘿牛 - 达尔坎",
		["Wonderain - 伊森利恩"] = "Wonderain - 伊森利恩",
		["香水般的温柔 - 恶魔之翼"] = "香水般的温柔 - 恶魔之翼",
		["Elytolpain - 夏维安"] = "Elytolpain - 夏维安",
		["Ylno - 夏维安"] = "Ylno - 夏维安",
		["Esserbella - 索瑞森"] = "木诺子其 - 索瑞森",
		["你诺 - 索瑞森"] = "你诺 - 索瑞森",
		["Ennyin - 提瑞斯法"] = "Ennyin - 提瑞斯法",
		["孤涯 - 索瑞森"] = "孤涯 - 索瑞森",
		["绑住了风 - 恶魔之翼"] = "Ennyin - 索瑞森",
		["闰汐 - 伊森利恩"] = "闰汐 - 伊森利恩",
		["海雅 - 索瑞森"] = "木诺子其 - 索瑞森",
		["绑住了风 - 索瑞森"] = "绑住了风 - 索瑞森",
		["Wenderpai - 熊猫酒仙"] = "Wenderpai - 熊猫酒仙",
		["失重 - 无尽之海"] = "失重 - 无尽之海",
		["Lure - 达文格尔"] = "Lure - 达文格尔",
		["画雨 - 索瑞森"] = "画雨 - 索瑞森",
		["別雨 - 索瑞森"] = "木诺子其 - 索瑞森",
		["失重 - 冰风岗"] = "木诺子其 - 索瑞森",
	},
	["profiles"] = {
		["Haiya - 索瑞森"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Whsi - 伊森利恩"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["云雨別 - 索瑞森"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Ennysoul - 索瑞森"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Boneshoc - 夏维安"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["额为我 - 战歌"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["那片云的味道 - 恶魔之翼"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["幽笠巫 - 熊猫酒仙"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["我过年好 - 鬼雾峰"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Sotu - 燃烧之刃"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Ennyin - 索瑞森"] = {
			["Cooldowns"] = {
				["CO"] = {
					["showAll"] = true,
				},
			},
			["Buffs"] = {
				["target"] = {
					["Buffs"] = {
						["showAllMyBuffs"] = false,
					},
					["Debuffs"] = {
						["enabled"] = false,
						["showAllMyBuffs"] = false,
						["showAllStealableBuffs"] = true,
					},
				},
				["player"] = {
					["Debuffs"] = {
						["showAllBuffs"] = true,
					},
				},
			},
			["General"] = {
				["scale"] = 0.8,
				["tooltips"] = true,
				["cooldown"] = 1,
				["lock"] = false,
			},
			["Frames"] = {
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							755.875183105469, -- [4]
							541.874816894531, -- [5]
						},
						["frametarget"] = "player",
						["cooldown"] = 1,
					},
					["Buffs"] = {
						["intervalFractionSecond"] = 0.3,
						["frametarget"] = "player",
						["sort"] = 3,
						["time_tb"] = "top",
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							470.750091552734, -- [4]
							589.000061035156, -- [5]
						},
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							722.50000098786, -- [4]
							193.749977005565, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["grow"] = "leftup",
						["frametarget"] = "focus",
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							597.499932250338, -- [4]
							193.749977005565, -- [5]
						},
					},
				},
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							1001.07011031843, -- [4]
							475.893293387087, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							1571.87329101563, -- [4]
							314.124938964844, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							722.50000098786, -- [4]
							268.749951728773, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							597.499932250338, -- [4]
							268.749951728773, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["CO"] = {
					["Cooldowns"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							678, -- [4]
							515, -- [5]
						},
						["frametarget"] = "cooldown",
					},
				},
			},
		},
		["Rinaly - 索瑞森"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Oow - 达文格尔"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Nuc - 阿拉希"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Rainylone - 夏维安"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["浮雲 - 恶魔之翼"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["木诺子其 - 索瑞森"] = {
			["General"] = {
				["scale"] = 0.8,
				["tooltips"] = true,
				["lock"] = false,
				["cooldown"] = 1,
			},
			["Cooldowns"] = {
				["CO"] = {
					["showAll"] = true,
				},
			},
			["Buffs"] = {
				["target"] = {
					["Buffs"] = {
						["showAllMyBuffs"] = false,
					},
					["Debuffs"] = {
						["enabled"] = false,
						["showAllMyBuffs"] = false,
						["showAllStealableBuffs"] = true,
					},
				},
				["player"] = {
					["Debuffs"] = {
						["showAllBuffs"] = true,
					},
				},
			},
			["Frames"] = {
				["player"] = {
					["Buffs"] = {
						["frametarget"] = "player",
						["intervalFractionSecond"] = 0.3,
						["sort"] = 3,
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							258.000030517578, -- [4]
							683.999938964844, -- [5]
						},
						["time_tb"] = "top",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							898.000061035156, -- [4]
							603, -- [5]
						},
						["cooldown"] = 1,
						["frametarget"] = "player",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["frametarget"] = "focus",
						["grow"] = "leftup",
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							597.499932250338, -- [4]
							193.749977005565, -- [5]
						},
					},
					["Debuffs"] = {
						["frametarget"] = "focus",
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							722.50000098786, -- [4]
							193.749977005565, -- [5]
						},
					},
				},
				["target"] = {
					["Buffs"] = {
						["frametarget"] = "target",
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							1571.49987792969, -- [4]
							313.999969482422, -- [5]
						},
					},
					["Debuffs"] = {
						["frametarget"] = "target",
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							1001.07011031843, -- [4]
							475.893293387087, -- [5]
						},
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["frametarget"] = "targettarget",
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
					},
					["Debuffs"] = {
						["frametarget"] = "targettarget",
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
					},
				},
				["CO"] = {
					["Cooldowns"] = {
						["frametarget"] = "cooldown",
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							719.333374023438, -- [4]
							540.33349609375, -- [5]
						},
					},
				},
			},
		},
		["Eofol - 沙怒"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Revp - 黑铁"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["撕雨 - 索瑞森"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Ifey - 冰风岗"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["嘿嘿牛 - 达尔坎"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Wonderain - 伊森利恩"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["香水般的温柔 - 恶魔之翼"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Elytolpain - 夏维安"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Ylno - 夏维安"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Esserbella - 索瑞森"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["你诺 - 索瑞森"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Ennyin - 提瑞斯法"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["孤涯 - 索瑞森"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["绑住了风 - 恶魔之翼"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["闰汐 - 伊森利恩"] = {
			["Cooldowns"] = {
				["CO"] = {
					["showAll"] = true,
				},
			},
			["Buffs"] = {
				["target"] = {
					["Buffs"] = {
						["showAllMyBuffs"] = false,
					},
					["Debuffs"] = {
						["enabled"] = false,
						["showAllMyBuffs"] = false,
						["showAllStealableBuffs"] = true,
					},
				},
				["player"] = {
					["Debuffs"] = {
						["showAllBuffs"] = true,
					},
				},
			},
			["General"] = {
				["scale"] = 0.8,
				["tooltips"] = true,
				["cooldown"] = 1,
				["lock"] = false,
			},
			["Frames"] = {
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							755.875183105469, -- [4]
							541.874816894531, -- [5]
						},
						["frametarget"] = "player",
						["cooldown"] = 1,
					},
					["Buffs"] = {
						["intervalFractionSecond"] = 0.3,
						["frametarget"] = "player",
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							487.249877929688, -- [4]
							479.375152587891, -- [5]
						},
						["time_tb"] = "top",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							722.50000098786, -- [4]
							193.749977005565, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["grow"] = "leftup",
						["frametarget"] = "focus",
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							597.499932250338, -- [4]
							193.749977005565, -- [5]
						},
					},
				},
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							1001.07011031843, -- [4]
							475.893293387087, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							1541.87353515625, -- [4]
							447.874786376953, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							722.50000098786, -- [4]
							268.749951728773, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							597.499932250338, -- [4]
							268.749951728773, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["CO"] = {
					["Cooldowns"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							678, -- [4]
							515, -- [5]
						},
						["frametarget"] = "cooldown",
					},
				},
			},
		},
		["海雅 - 索瑞森"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["绑住了风 - 索瑞森"] = {
			["Buffs"] = {
				["target"] = {
					["Debuffs"] = {
						["enabled"] = false,
						["showAllMyBuffs"] = false,
						["showAllStealableBuffs"] = true,
					},
					["Buffs"] = {
						["showAllMyBuffs"] = false,
					},
				},
				["player"] = {
					["Debuffs"] = {
						["showAllBuffs"] = true,
					},
				},
			},
			["General"] = {
				["scale"] = 0.9,
				["lock"] = false,
			},
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							889.840014780852, -- [4]
							423.016285605231, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							1063.8888263295, -- [4]
							583.666638722359, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							707.888919872273, -- [4]
							376.666649252759, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							262.555757578161, -- [4]
							421.888783387351, -- [5]
						},
						["frametarget"] = "player",
						["time_tb"] = "top",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							642.222235417562, -- [4]
							238.888830257991, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							531.111052245486, -- [4]
							238.888830257991, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							642.222235417562, -- [4]
							172.222221884208, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							531.111052245486, -- [4]
							172.222221884208, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
		},
		["Wenderpai - 熊猫酒仙"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["失重 - 无尽之海"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["Lure - 达文格尔"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["画雨 - 索瑞森"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["別雨 - 索瑞森"] = {
			["Frames"] = {
				["target"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
		["失重 - 冰风岗"] = {
			["Frames"] = {
				["target"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							335, -- [5]
						},
						["frametarget"] = "target",
					},
				},
				["player"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							275, -- [5]
						},
						["frametarget"] = "player",
					},
				},
				["targettarget"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							215, -- [5]
						},
						["frametarget"] = "targettarget",
					},
				},
				["focus"] = {
					["Buffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							478, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
					["Debuffs"] = {
						["anchor"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"BOTTOMLEFT", -- [3]
							578, -- [4]
							155, -- [5]
						},
						["frametarget"] = "focus",
					},
				},
			},
			["Buffs"] = {
				["target"] = {
				},
				["player"] = {
				},
			},
		},
	},
}
DebuffFilter_Config = nil
