
diminfo = {
	["AutoCollect"] = true,
	["Sortingby"] = 9,
	["gold"] = {
		["熊猫酒仙"] = {
			["幽笠巫"] = 1003493,
		},
		["索瑞森"] = {
			["木诺子其"] = 134772572,
		},
	},
	["AutoSell"] = true,
	["AutoRepair"] = true,
	["Sortingbystring"] = "职业",
}
BloodHelperDB = nil
StaggerDB = nil
MshrmDB = nil
TotemsDB = nil
