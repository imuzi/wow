
_NPCScanOptions = {
	["Achievements"] = {
		[2257] = true,
		[1312] = true,
		[7439] = true,
	},
	["Version"] = "5.0.0.5",
	["CacheWarnings"] = true,
}
