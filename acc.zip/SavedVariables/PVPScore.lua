
PVPScoreCache = {
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "冰霜恶灵-恶魔之魂",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "法师",
		["PVPScore"] = 56.28303035413732,
		["Star"] = "★★★☆",
	}, -- [1]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "單手扶墙-安苏",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "猎人",
		["PVPScore"] = 28.41927001998207,
		["Star"] = "★☆",
	}, -- [2]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "落羽静静-密林游侠",
		["Faction"] = "部落",
		["Star"] = "★★★☆",
		["Class"] = "战士",
		["PVPScore"] = 57.57486946388138,
		["FactionGroup"] = "Horde",
	}, -- [3]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "Ennyin-埃加洛尔",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "术士",
		["PVPScore"] = 79.13295749905426,
		["FactionGroup"] = "Horde",
	}, -- [4]
}
PVPScoreCacheDate = 1611571784
