
PVPScoreCache = {
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "冰霜恶灵-恶魔之魂",
		["Faction"] = "部落",
		["Star"] = "★★★☆",
		["Class"] = "法师",
		["PVPScore"] = 56.28303035413732,
		["FactionGroup"] = "Horde",
	}, -- [1]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "Ennyin-埃加洛尔",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "术士",
		["PVPScore"] = 79.13295749905426,
		["FactionGroup"] = "Horde",
	}, -- [2]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "單手扶墙-安苏",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "猎人",
		["PVPScore"] = 28.41927001998207,
		["FactionGroup"] = "Horde",
	}, -- [3]
}
PVPScoreCacheDate = 1611571784
