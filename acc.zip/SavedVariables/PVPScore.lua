
PVPScoreCache = {
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "媳妇擔當丶-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 25.3870242537772,
		["Class"] = "德鲁伊",
	}, -- [1]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "崽儿小瘪三-燃烧之刃",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★★",
		["PVPScore"] = 73.65137017082898,
		["Class"] = "德鲁伊",
	}, -- [2]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "鼠来寶-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "战神",
		["PVPScore"] = 80.91497939574496,
		["Class"] = "德鲁伊",
	}, -- [3]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "孙山-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 3.714652942380304,
		["Class"] = "圣骑士",
	}, -- [4]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Elsnz-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 25.79042265981744,
		["Class"] = "潜行者",
	}, -- [5]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "侏儒",
		["NameServer"] = "紅袖輕舞-桑德兰",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★☆",
		["PVPScore"] = 67.03838259626434,
		["Class"] = "牧师",
	}, -- [6]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "虚空精灵",
		["NameServer"] = "阿士匹靈-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★☆",
		["PVPScore"] = 68.7641537486462,
		["Class"] = "牧师",
	}, -- [7]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "虚空精灵",
		["NameServer"] = "Axibale-加基森",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 25.11918516738424,
		["Class"] = "牧师",
	}, -- [8]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "人类",
		["NameServer"] = "邪月苍炎-阿拉希",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "战神",
		["PVPScore"] = 85.43759201243185,
		["Class"] = "术士",
	}, -- [9]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "Fvanguardz-回音山",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 26.67603159688705,
		["Class"] = "圣骑士",
	}, -- [10]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "思念的味道-暗影议会",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 21.18865702181712,
		["Class"] = "牧师",
	}, -- [11]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "雪中魂-埃加洛尔",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★★",
		["PVPScore"] = 60.50723327020111,
		["Class"] = "德鲁伊",
	}, -- [12]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "丶汽水罐子丶-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 12.18748297598986,
		["Class"] = "法师",
	}, -- [13]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "兽人",
		["NameServer"] = "Tiktoo-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 20.37763542101014,
		["Class"] = "术士",
	}, -- [14]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "柒灬老板-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 45.96197058952511,
		["Class"] = "法师",
	}, -- [15]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "清清浅浅丶-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 36.70441283706327,
		["Class"] = "法师",
	}, -- [16]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "潺潺霜林晚-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★☆",
		["PVPScore"] = 66.01326612320683,
		["Class"] = "战士",
	}, -- [17]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "凯露-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 11.19420814380148,
		["Class"] = "德鲁伊",
	}, -- [18]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "无信者阿比斯-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★☆",
		["PVPScore"] = 68.94806069704879,
		["Class"] = "牧师",
	}, -- [19]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "侏儒",
		["NameServer"] = "泡芙圈圈丶-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 38.72204793285654,
		["Class"] = "武僧",
	}, -- [20]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "放吧下一把-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 14.28058603807387,
		["Class"] = "潜行者",
	}, -- [21]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "生活像条船-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★☆",
		["PVPScore"] = 67.95526972180834,
		["Class"] = "牧师",
	}, -- [22]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "酱紫戳-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★",
		["PVPScore"] = 53.84029172524346,
		["Class"] = "圣骑士",
	}, -- [23]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "机械侏儒",
		["NameServer"] = "超奶思靡靡酱-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 21.97061203790092,
		["Class"] = "术士",
	}, -- [24]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "星璇紫夜-灰谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.0002,
		["Class"] = "恶魔猎手",
	}, -- [25]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "兽人",
		["NameServer"] = "耗子爱傻喵-血色十字军",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★",
		["PVPScore"] = 52.18289538951295,
		["Class"] = "术士",
	}, -- [26]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "轩辕星舞-凤凰之神",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 13.9121795801168,
		["Class"] = "恶魔猎手",
	}, -- [27]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "丿书沁骨-凤凰之神",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 40.65204756679461,
		["Class"] = "法师",
	}, -- [28]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "覺醒-寒冰皇冠",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★★",
		["PVPScore"] = 78.93944860157066,
		["Class"] = "潜行者",
	}, -- [29]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "熊猫人",
		["NameServer"] = "风猫-冰风岗",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 14.09508784247328,
		["Class"] = "武僧",
	}, -- [30]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "地精",
		["NameServer"] = "煄小炮-死亡之翼",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 14.85151736530735,
		["Class"] = "牧师",
	}, -- [31]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "七月与安生-冰风岗",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 37.77991382355715,
		["Class"] = "德鲁伊",
	}, -- [32]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "重型装鉀-格瑞姆巴托",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 23.86455263216115,
		["Class"] = "圣骑士",
	}, -- [33]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "啊奶粉-霍格",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 11.7479933649362,
		["Class"] = "圣骑士",
	}, -- [34]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "Yeats-伊森利恩",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 23.85998407837749,
		["Class"] = "牧师",
	}, -- [35]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "夏一可毒舌-布兰卡德",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 21.36822902825,
		["Class"] = "法师",
	}, -- [36]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "维宝的小太阳-寒冰皇冠",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 37.54065140345925,
		["Class"] = "圣骑士",
	}, -- [37]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "圣佑喵喵-贫瘠之地",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 29.07743018351592,
		["Class"] = "圣骑士",
	}, -- [38]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "Zzongzi-血色十字军",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 14.7654283833349,
		["Class"] = "牧师",
	}, -- [39]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "血精灵",
		["NameServer"] = "哥最凶猛-死亡之翼",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 7.214090101692634,
		["Class"] = "战士",
	}, -- [40]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "Breadlol-布兰卡德",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★☆",
		["PVPScore"] = 59.12747091786336,
		["Class"] = "牧师",
	}, -- [41]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "顽石丶-影之哀伤",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★",
		["PVPScore"] = 51.60271794777756,
		["Class"] = "德鲁伊",
	}, -- [42]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "反语-死亡之翼",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 11.7294630783244,
		["Class"] = "潜行者",
	}, -- [43]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "三哥一摆跨-伊森利恩",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 21.68319697758204,
		["Class"] = "法师",
	}, -- [44]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "夜之子",
		["NameServer"] = "马冬梅-影之哀伤",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 45.65895814061024,
		["Class"] = "术士",
	}, -- [45]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "Neueziel-冰风岗",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 12.12820636119651,
		["Class"] = "恶魔猎手",
	}, -- [46]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "極易-燃烧之刃",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★★",
		["PVPScore"] = 64.9228331971797,
		["Class"] = "潜行者",
	}, -- [47]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "Blessing-幽暗沼泽",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 2.099545364431487,
		["Class"] = "圣骑士",
	}, -- [48]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "熊猫人",
		["NameServer"] = "Wwvv-斩魔者",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 40.17421159993696,
		["Class"] = "猎人",
	}, -- [49]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "Karry-斩魔者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 7.139390628124326,
		["Class"] = "法师",
	}, -- [50]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "上善若丶水-斩魔者",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 38.2982863174809,
		["Class"] = "圣骑士",
	}, -- [51]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "双子星枫-斩魔者",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 0.8102858650164962,
		["Class"] = "猎人",
	}, -- [52]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "至高岭牛头人",
		["NameServer"] = "Wx-阿扎达斯",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 15.32326187130736,
		["Class"] = "武僧",
	}, -- [53]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "Kephiroth-主宰之剑",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★",
		["PVPScore"] = 54.33964021996892,
		["Class"] = "潜行者",
	}, -- [54]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "Twistzj-安苏",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 19.72202636104815,
		["Class"] = "潜行者",
	}, -- [55]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "虚空精灵",
		["NameServer"] = "听丨雪-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "死亡骑士",
	}, -- [56]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "虚空精灵",
		["NameServer"] = "丧彪-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "战士",
	}, -- [57]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "巨魔",
		["NameServer"] = "九山八海小号-凤凰之神",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "术士",
	}, -- [58]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "保罗虐爆哈登-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★★",
		["PVPScore"] = 70.60676306731156,
		["Class"] = "牧师",
	}, -- [59]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "黎明狩猎-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.0002,
		["Class"] = "恶魔猎手",
	}, -- [60]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "聖靈無雙-织亡者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★",
		["PVPScore"] = 62.73142306306238,
		["Class"] = "圣骑士",
	}, -- [61]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "恐懼劍刃-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★",
		["PVPScore"] = 50.99691946918218,
		["Class"] = "潜行者",
	}, -- [62]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "澄海单挑狂丶-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 9.570063309134493,
		["Class"] = "恶魔猎手",
	}, -- [63]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "流水不管-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★",
		["PVPScore"] = 52.72841420452662,
		["Class"] = "法师",
	}, -- [64]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "空空诺言-瑞文戴尔",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 34.76247514955079,
		["Class"] = "德鲁伊",
	}, -- [65]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "Eclogue-熔火之心",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "牧师",
		["PVPScore"] = 68.25423215754569,
		["Star"] = "★★★★☆",
	}, -- [66]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "黑铁矮人",
		["NameServer"] = "风离-利刃之拳",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "萨满祭司",
		["PVPScore"] = 7.098825802179409,
		["Star"] = "☆",
	}, -- [67]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "術丨士-利刃之拳",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "术士",
		["PVPScore"] = 14.22579693479375,
		["Star"] = "★",
	}, -- [68]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "德莱尼",
		["NameServer"] = "狼亦侠-阿古斯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "萨满祭司",
		["PVPScore"] = 0.2649873698115123,
		["Star"] = "☆",
	}, -- [69]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "无敌狼人-图拉扬",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "猎人",
		["PVPScore"] = 0.4157077735311699,
		["Star"] = "☆",
	}, -- [70]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Angular-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "德鲁伊",
		["PVPScore"] = 27.46358500443483,
		["Star"] = "★☆",
	}, -- [71]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "萌萌的小军军-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "圣骑士",
		["PVPScore"] = 60.9460391937655,
		["Star"] = "★★★★",
	}, -- [72]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "Easyw-安苏",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "战士",
		["PVPScore"] = 24.96040310768154,
		["Star"] = "★☆",
	}, -- [73]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "未知目标-埃加洛尔",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "圣骑士",
		["PVPScore"] = 6.06074862869546,
		["Star"] = "☆",
	}, -- [74]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "别跑那妞-安苏",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "圣骑士",
		["PVPScore"] = 6.06074862869546,
		["Star"] = "☆",
	}, -- [75]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "纲手奶奶-回音山",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "猎人",
		["PVPScore"] = 15.53524262491808,
		["Star"] = "★",
	}, -- [76]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "侏儒",
		["NameServer"] = "辛幼薰-格瑞姆巴托",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "法师",
		["PVPScore"] = 48.40823344865943,
		["Star"] = "★★☆",
	}, -- [77]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "狼人",
		["NameServer"] = "酥木泉-托尔巴拉德",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "术士",
		["PVPScore"] = 19.443727683097,
		["Star"] = "★",
	}, -- [78]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "煮熟了还要飞-熊猫酒仙",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "德鲁伊",
		["PVPScore"] = 61.4045737335305,
		["Star"] = "★★★★",
	}, -- [79]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "地精",
		["NameServer"] = "幕幕丨朝朝-无尽之海",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "萨满祭司",
		["PVPScore"] = 8.140015172863494,
		["Star"] = "☆",
	}, -- [80]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "四号位-丽丽（四川）",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "战士",
		["PVPScore"] = 71.56727916895017,
		["Star"] = "★★★★★",
	}, -- [81]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "曾经吻过谁-燃烧之刃",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "圣骑士",
		["PVPScore"] = 55.9260306666661,
		["Star"] = "★★★☆",
	}, -- [82]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "钻你被窝哦-影之哀伤",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "德鲁伊",
		["PVPScore"] = 58.69120362722123,
		["Star"] = "★★★☆",
	}, -- [83]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "卖丶丶萌-凤凰之神",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "德鲁伊",
		["PVPScore"] = 46.29142538050773,
		["Star"] = "★★☆",
	}, -- [84]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "丨祈求者丨-血色十字军",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "法师",
		["PVPScore"] = 28.48324705841534,
		["Star"] = "★☆",
	}, -- [85]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "Macchiatolol-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "潜行者",
		["PVPScore"] = 80.73923114890152,
		["Star"] = "战神",
	}, -- [86]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "皇家禮炮-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 34.32601150521833,
		["Star"] = "★★",
	}, -- [87]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "Peekaboo-安苏",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "潜行者",
		["PVPScore"] = 16.50468873363289,
		["Star"] = "★",
	}, -- [88]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "狐人",
		["NameServer"] = "绯红挽歌-燃烧之刃",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "法师",
		["PVPScore"] = 8.111014963001978,
		["Star"] = "☆",
	}, -- [89]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "Txy-埃加洛尔",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "死亡骑士",
		["PVPScore"] = 57.22040419480685,
		["Star"] = "★★★☆",
	}, -- [90]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "刃舞者-贫瘠之地",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 4.813909155239445,
		["Star"] = "☆",
	}, -- [91]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "Cheri-鹰巢山",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "潜行者",
		["PVPScore"] = 68.25345929708539,
		["Star"] = "★★★★☆",
	}, -- [92]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "你真好看-托塞德林",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "猎人",
		["PVPScore"] = 22.50070936204785,
		["Star"] = "★☆",
	}, -- [93]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "蟹黄蟹膏蟹油-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "牧师",
		["PVPScore"] = 42.62193989466115,
		["Star"] = "★★☆",
	}, -- [94]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "格鲁什丶血贼-贫瘠之地",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "潜行者",
		["PVPScore"] = 4.591092772669026,
		["Star"] = "☆",
	}, -- [95]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "对你心动-死亡之翼",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "德鲁伊",
		["PVPScore"] = 12.08678689529797,
		["Star"] = "★",
	}, -- [96]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "威廉大王-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "潜行者",
		["PVPScore"] = 58.47733562045411,
		["Star"] = "★★★☆",
	}, -- [97]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "暴走荔枝肉-安苏",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "战士",
		["PVPScore"] = 27.01065426352268,
		["Star"] = "★☆",
	}, -- [98]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "冷锋灬天照-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "圣骑士",
		["PVPScore"] = 43.67487747336196,
		["Star"] = "★★☆",
	}, -- [99]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "疯芓丶-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "德鲁伊",
		["PVPScore"] = 41.99628469869015,
		["Star"] = "★★☆",
	}, -- [100]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "神圣大艾姆-无尽之海",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "法师",
		["PVPScore"] = 26.31622397251452,
		["Star"] = "★☆",
	}, -- [101]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "瘋子-布兰卡德",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "牧师",
		["PVPScore"] = 35.49476284568556,
		["Star"] = "★★",
	}, -- [102]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "無雙丶逆天-布兰卡德",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "死亡骑士",
		["PVPScore"] = 61.04090010188915,
		["Star"] = "★★★★",
	}, -- [103]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "懒懒爱你-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "潜行者",
		["PVPScore"] = 77.84533654602691,
		["Star"] = "★★★★★",
	}, -- [104]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "暴躁的柠檬-朵丹尼尔",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "潜行者",
		["PVPScore"] = 45.05102292154927,
		["Star"] = "★★☆",
	}, -- [105]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "Vodeka-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "潜行者",
		["PVPScore"] = 54.19903817253889,
		["Star"] = "★★★",
	}, -- [106]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "一车斤一-塞拉摩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "战士",
		["PVPScore"] = 33.45105025737869,
		["Star"] = "★★",
	}, -- [107]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "秦仲海-恐怖图腾",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "战士",
		["PVPScore"] = 1.91241403551483,
		["FactionGroup"] = "Horde",
	}, -- [108]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "橙戒骑丶呐喊-大地之怒",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "圣骑士",
		["PVPScore"] = 62.27913616693095,
		["Star"] = "★★★★",
	}, -- [109]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "Tiizzy-安苏",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★★☆",
		["PVPScore"] = 41.69831068223103,
		["FactionGroup"] = "Horde",
	}, -- [110]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "灬泽灬-狂热之刃",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "★",
		["PVPScore"] = 15.52033092738788,
		["FactionGroup"] = "Horde",
	}, -- [111]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "国服第一卡尔-安苏",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "☆",
		["PVPScore"] = 0.0008,
		["FactionGroup"] = "Horde",
	}, -- [112]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "丷查无此人丷-黑暗魅影",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 0.4157077735311699,
		["Class"] = "潜行者",
	}, -- [113]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "狼人",
		["NameServer"] = "Oswald-扎拉赞恩",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 21.50891632373114,
		["Class"] = "德鲁伊",
	}, -- [114]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "狼人",
		["NameServer"] = "狮王之傲-暗影之月",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "战士",
	}, -- [115]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "曾经的无奈-暗影之月",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 15.78034755322238,
		["Class"] = "圣骑士",
	}, -- [116]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "阿尓萨斯-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 26.77072898879436,
		["Class"] = "圣骑士",
	}, -- [117]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "人类",
		["NameServer"] = "戀戰狂人彡-奥达曼",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★★",
		["PVPScore"] = 72.50945561897693,
		["Class"] = "死亡骑士",
	}, -- [118]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "野文儿-暗影之月",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.001,
		["Class"] = "德鲁伊",
	}, -- [119]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "青云烟-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 15.11004801494014,
		["Class"] = "德鲁伊",
	}, -- [120]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "瓦里安王-洛肯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 8.813911294557503,
		["Class"] = "德鲁伊",
	}, -- [121]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "矮人",
		["NameServer"] = "洛泰姆中尉-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 15.24365889212828,
		["Class"] = "战士",
	}, -- [122]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "熊猫人",
		["NameServer"] = "七匹狠-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 31.94307673799031,
		["Class"] = "法师",
	}, -- [123]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "無誡-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★☆",
		["PVPScore"] = 57.54085512736232,
		["Class"] = "潜行者",
	}, -- [124]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "黑铁矮人",
		["NameServer"] = "無影無踪-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 4.970067780411235,
		["Class"] = "潜行者",
	}, -- [125]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "暗夜精灵",
		["NameServer"] = "堕落凋零丶-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.07633964463140128,
		["Class"] = "死亡骑士",
	}, -- [126]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "杀戮乄夜默-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 24.24093694520968,
		["Class"] = "潜行者",
	}, -- [127]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "迪妮莎的薇笑-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "德鲁伊",
	}, -- [128]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "未耒昰末-弗塞雷迦",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 10.66398737688913,
		["Class"] = "猎人",
	}, -- [129]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "丶那个暗牧-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 37.85279541878963,
		["Class"] = "德鲁伊",
	}, -- [130]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "拿图腾当板凳-伊萨里奥斯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 38.54844583241551,
		["Class"] = "萨满祭司",
	}, -- [131]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "熊猫人",
		["NameServer"] = "别惹碧绿色-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 39.41179352999752,
		["Class"] = "武僧",
	}, -- [132]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "矮人",
		["NameServer"] = "别跟着我呀-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 26.53235749261176,
		["Class"] = "圣骑士",
	}, -- [133]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "紫凌霜-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 39.38545353878394,
		["Class"] = "战士",
	}, -- [134]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "双妃-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 8.61335798611111,
		["Class"] = "法师",
	}, -- [135]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "趵突泉没泉-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 41.11715619554863,
		["Class"] = "法师",
	}, -- [136]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "侏儒",
		["NameServer"] = "六弦之首-斯克提斯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 18.78529028610329,
		["Class"] = "猎人",
	}, -- [137]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "迅捷斥候-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★☆",
		["PVPScore"] = 57.53915763289257,
		["Class"] = "德鲁伊",
	}, -- [138]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "黑铁矮人",
		["NameServer"] = "王大妈丶铜须-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 13.66007627193325,
		["Class"] = "牧师",
	}, -- [139]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "大戮善的-贫瘠之地",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 31.36098833684423,
		["Class"] = "圣骑士",
	}, -- [140]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "太难德-幽暗沼泽",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 1.87164036645989,
		["Class"] = "德鲁伊",
	}, -- [141]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "妹妹你恐惧-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 8.542899712283624,
		["Class"] = "术士",
	}, -- [142]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "叫我死鬼-燃烧之刃",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 46.85730430709804,
		["Class"] = "法师",
	}, -- [143]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "水门龙廷-幽暗沼泽",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "法师",
		["PVPScore"] = 29.08823715221708,
		["FactionGroup"] = "Horde",
	}, -- [144]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "胖鲸鱼-埃加洛尔",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "法师",
		["PVPScore"] = 8.822668903422525,
		["FactionGroup"] = "Horde",
	}, -- [145]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "下沙-阿拉索",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "战士",
		["PVPScore"] = 11.27149367697816,
		["Star"] = "★",
	}, -- [146]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "德莱尼",
		["NameServer"] = "指导员-加里索斯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "圣骑士",
		["PVPScore"] = 0.4157077735311699,
		["Star"] = "☆",
	}, -- [147]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "暗夜精灵",
		["NameServer"] = "青峰丶小布-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "战士",
		["PVPScore"] = 11.93481913260608,
		["Star"] = "★",
	}, -- [148]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "熊猫人",
		["NameServer"] = "澡雪-雷克萨",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "武僧",
		["PVPScore"] = 13.83066739815527,
		["Star"] = "★",
	}, -- [149]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "临河-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "潜行者",
		["PVPScore"] = 26.10049940926202,
		["Star"] = "★☆",
	}, -- [150]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "刀锋使者-冬泉谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 0.0002,
		["Star"] = "☆",
	}, -- [151]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "人类",
		["NameServer"] = "性感扭臀-迅捷微风",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "武僧",
		["PVPScore"] = 25.70266179651862,
		["Star"] = "★☆",
	}, -- [152]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "阿卡丽之魂-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "圣骑士",
		["PVPScore"] = 8.579293551206579,
		["Star"] = "☆",
	}, -- [153]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "人类",
		["NameServer"] = "Sundays-诺兹多姆",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "武僧",
		["PVPScore"] = 19.13885527775208,
		["Star"] = "★",
	}, -- [154]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "机械侏儒",
		["NameServer"] = "能量和钱-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "武僧",
		["PVPScore"] = 7.411096135508354,
		["Star"] = "☆",
	}, -- [155]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "Priestdao-暗影迷宫",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "牧师",
		["PVPScore"] = 0.06747779200375865,
		["Star"] = "☆",
	}, -- [156]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "小貂灬蘑菇-布兰卡德",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "法师",
		["PVPScore"] = 18.01049874608873,
		["Star"] = "★",
	}, -- [157]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "机械侏儒",
		["NameServer"] = "蠢鑫的门牙-破碎岭",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "武僧",
		["PVPScore"] = 16.06046411153516,
		["Star"] = "★",
	}, -- [158]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "兽人",
		["NameServer"] = "西撒-无尽之海",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "武僧",
		["PVPScore"] = 0.5291747396230246,
		["Star"] = "☆",
	}, -- [159]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "鱼鱼熊-诺兹多姆",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "猎人",
		["PVPScore"] = 0.2649873698115123,
		["Star"] = "☆",
	}, -- [160]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "爾等-石锤",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "德鲁伊",
		["PVPScore"] = 28.68603860244425,
		["Star"] = "★☆",
	}, -- [161]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "秦之殇-狂热之刃",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "圣骑士",
		["PVPScore"] = 30.98387629975284,
		["Star"] = "★★",
	}, -- [162]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "绝境悠贼爱-无尽之海",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "德鲁伊",
		["PVPScore"] = 36.66835942305765,
		["Star"] = "★★",
	}, -- [163]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "巨魔",
		["NameServer"] = "Raconteur-无尽之海",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "术士",
		["PVPScore"] = 12.42690609923988,
		["Star"] = "★",
	}, -- [164]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "灬不朽-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "法师",
		["PVPScore"] = 0,
		["Star"] = "?",
	}, -- [165]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "至高岭牛头人",
		["NameServer"] = "伴缘-黑暗魅影",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★★★★★",
		["PVPScore"] = 79.29789212934608,
		["FactionGroup"] = "Horde",
	}, -- [166]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "暗灵洛神-黑铁",
		["Faction"] = "部落",
		["Class"] = "死亡骑士",
		["Star"] = "★★★★☆",
		["PVPScore"] = 66.25685012940887,
		["FactionGroup"] = "Horde",
	}, -- [167]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "丶流云-安苏",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "☆",
		["PVPScore"] = 8.313224875672212,
		["FactionGroup"] = "Horde",
	}, -- [168]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "玛格汉兽人",
		["NameServer"] = "哦牛批-梅尔加尼",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★☆",
		["PVPScore"] = 21.29963927622558,
		["FactionGroup"] = "Horde",
	}, -- [169]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "巨魔",
		["NameServer"] = "尸意暗然-黑铁",
		["Faction"] = "部落",
		["Class"] = "术士",
		["Star"] = "★★★☆",
		["PVPScore"] = 59.89196989517649,
		["FactionGroup"] = "Horde",
	}, -- [170]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "赵英俊-龙骨平原",
		["Faction"] = "部落",
		["Class"] = "猎人",
		["Star"] = "★★",
		["PVPScore"] = 33.04919975685661,
		["FactionGroup"] = "Horde",
	}, -- [171]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "夜之子",
		["NameServer"] = "Greatdeads-贫瘠之地",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★☆",
		["PVPScore"] = 21.33814189879784,
		["FactionGroup"] = "Horde",
	}, -- [172]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "钢琴师-塞拉摩",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★",
		["PVPScore"] = 15.31241727879745,
		["FactionGroup"] = "Horde",
	}, -- [173]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "诙尘-死亡之翼",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★★★☆",
		["PVPScore"] = 56.59407462622347,
		["FactionGroup"] = "Horde",
	}, -- [174]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "至高岭牛头人",
		["NameServer"] = "斌儿儿-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "萨满祭司",
		["Star"] = "☆",
		["PVPScore"] = 9.015285646746875,
		["FactionGroup"] = "Horde",
	}, -- [175]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "虚空精灵",
		["NameServer"] = "未知启示-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "术士",
		["Star"] = "☆",
		["PVPScore"] = 0.2081538867655849,
		["FactionGroup"] = "Alliance",
	}, -- [176]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "德莱尼",
		["NameServer"] = "哈提乄-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "猎人",
		["Star"] = "★★★★★",
		["PVPScore"] = 78.2491363335536,
		["FactionGroup"] = "Alliance",
	}, -- [177]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "我是壹条疯狗-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★☆",
		["PVPScore"] = 20.45260688204995,
		["FactionGroup"] = "Horde",
	}, -- [178]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "Nurfed-燃烧之刃",
		["Faction"] = "部落",
		["Class"] = "猎人",
		["Star"] = "★",
		["PVPScore"] = 15.22213044684885,
		["FactionGroup"] = "Horde",
	}, -- [179]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "阿丝忒丶瑞亚-月光林地",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "☆",
		["PVPScore"] = 7.946429334832963,
		["FactionGroup"] = "Horde",
	}, -- [180]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "妳裤子破了-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "战神",
		["PVPScore"] = 84.83474683864463,
		["FactionGroup"] = "Horde",
	}, -- [181]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "熊猫人",
		["NameServer"] = "雪大海-闪电之刃",
		["Faction"] = "部落",
		["Class"] = "武僧",
		["Star"] = "★",
		["PVPScore"] = 18.08169615658285,
		["FactionGroup"] = "Horde",
	}, -- [182]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "桃尺-格瑞姆巴托",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★",
		["PVPScore"] = 13.65211147856576,
		["FactionGroup"] = "Horde",
	}, -- [183]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "Proletariat-鹰巢山",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★★☆",
		["PVPScore"] = 45.63554342110573,
		["FactionGroup"] = "Horde",
	}, -- [184]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "Prettypig-死亡之翼",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★★☆",
		["PVPScore"] = 40.615790975539,
		["FactionGroup"] = "Horde",
	}, -- [185]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "丶春尽红颜老-克尔苏加德",
		["Faction"] = "部落",
		["Class"] = "牧师",
		["Star"] = "☆",
		["PVPScore"] = 0.2649873698115123,
		["FactionGroup"] = "Horde",
	}, -- [186]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "暧恋丶-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "德鲁伊",
		["Star"] = "★★☆",
		["PVPScore"] = 41.69925624307071,
		["FactionGroup"] = "Horde",
	}, -- [187]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "至高岭牛头人",
		["NameServer"] = "收丨集丨德-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "德鲁伊",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [188]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "巨魔",
		["NameServer"] = "地狱风雷-地狱之石",
		["Faction"] = "部落",
		["Class"] = "萨满祭司",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [189]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "半丶度-埃德萨拉",
		["Faction"] = "部落",
		["Class"] = "德鲁伊",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [190]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "Kbook-血色十字军",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "☆",
		["PVPScore"] = 7.811938107202275,
		["FactionGroup"] = "Horde",
	}, -- [191]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "夜之子",
		["NameServer"] = "好好抱抱你-红龙军团",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "☆",
		["PVPScore"] = 8.420621409136007,
		["FactionGroup"] = "Horde",
	}, -- [192]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "狐人",
		["NameServer"] = "风流小僧-血色十字军",
		["Faction"] = "部落",
		["Class"] = "武僧",
		["Star"] = "★★★☆",
		["PVPScore"] = 58.31410514686518,
		["FactionGroup"] = "Horde",
	}, -- [193]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "玛格汉兽人",
		["NameServer"] = "弟欲咆哮-布兰卡德",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "☆",
		["PVPScore"] = 0.07633964463140128,
		["FactionGroup"] = "Horde",
	}, -- [194]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "丶寒夜挽歌-无尽之海",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★★★☆",
		["PVPScore"] = 59.09314822825346,
		["FactionGroup"] = "Horde",
	}, -- [195]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "离岸-加里索斯",
		["Faction"] = "部落",
		["Class"] = "牧师",
		["Star"] = "★",
		["PVPScore"] = 16.70915239026105,
		["FactionGroup"] = "Horde",
	}, -- [196]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "悲傷禮拜堂-埃德萨拉",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★★★★☆",
		["PVPScore"] = 66.3293194286889,
		["FactionGroup"] = "Horde",
	}, -- [197]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "叔叔被迫的-狂热之刃",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★",
		["PVPScore"] = 13.09710935359944,
		["FactionGroup"] = "Horde",
	}, -- [198]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "程少-符文图腾",
		["Faction"] = "联盟",
		["Class"] = "圣骑士",
		["Star"] = "★★☆",
		["PVPScore"] = 40.34188902472889,
		["FactionGroup"] = "Alliance",
	}, -- [199]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "侏儒",
		["NameServer"] = "入幕北晨-玛里苟斯",
		["Faction"] = "联盟",
		["Class"] = "术士",
		["Star"] = "★★★★",
		["PVPScore"] = 61.30877098152559,
		["FactionGroup"] = "Alliance",
	}, -- [200]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "紫爓涧-泰兰德",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "★★★★",
		["PVPScore"] = 60.01284677003096,
		["FactionGroup"] = "Alliance",
	}, -- [201]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "暗夜精灵",
		["NameServer"] = "快乐小护士-泰兰德",
		["Faction"] = "联盟",
		["Class"] = "牧师",
		["Star"] = "★★★",
		["PVPScore"] = 53.56193845352435,
		["FactionGroup"] = "Alliance",
	}, -- [202]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "小小乾-泰兰德",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "★★★☆",
		["PVPScore"] = 58.96051752494798,
		["FactionGroup"] = "Alliance",
	}, -- [203]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "叶凌风-泰兰德",
		["Faction"] = "联盟",
		["Class"] = "法师",
		["Star"] = "★",
		["PVPScore"] = 13.61373678793491,
		["FactionGroup"] = "Alliance",
	}, -- [204]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "狼人",
		["NameServer"] = "先救那个骑士-末日行者",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "★",
		["PVPScore"] = 13.11351045757319,
		["FactionGroup"] = "Alliance",
	}, -- [205]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "翔天战神-破碎岭",
		["Faction"] = "联盟",
		["Class"] = "法师",
		["Star"] = "★",
		["PVPScore"] = 16.90876644801445,
		["FactionGroup"] = "Alliance",
	}, -- [206]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "摩卡丶泡沫-安苏",
		["Faction"] = "联盟",
		["Class"] = "猎人",
		["Star"] = "★☆",
		["PVPScore"] = 21.00293480992064,
		["FactionGroup"] = "Alliance",
	}, -- [207]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "冲冠一怒-贫瘠之地",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "☆",
		["PVPScore"] = 5.293944382121469,
		["FactionGroup"] = "Alliance",
	}, -- [208]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "兽人",
		["NameServer"] = "雾丶绣念-死亡熔炉",
		["Faction"] = "部落",
		["Class"] = "武僧",
		["Star"] = "★☆",
		["PVPScore"] = 23.23961150213138,
		["FactionGroup"] = "Horde",
	}, -- [209]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "兽兽好猎手-安苏",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "☆",
		["PVPScore"] = 4.892063574396302,
		["FactionGroup"] = "Horde",
	}, -- [210]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "至高岭牛头人",
		["NameServer"] = "Tyrandell-安苏",
		["Faction"] = "部落",
		["Class"] = "德鲁伊",
		["Star"] = "★★★☆",
		["PVPScore"] = 59.8647053546929,
		["FactionGroup"] = "Horde",
	}, -- [211]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "兽人",
		["NameServer"] = "Taylorlol-金色平原",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★★★★★",
		["PVPScore"] = 79.58595344648171,
		["FactionGroup"] = "Horde",
	}, -- [212]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "马里奥大猪-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "德鲁伊",
		["Star"] = "★★★★",
		["PVPScore"] = 60.18988641065576,
		["FactionGroup"] = "Horde",
	}, -- [213]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "熊猫人",
		["NameServer"] = "萌萌的子串-暗影之月",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 17.69997873613911,
		["Class"] = "武僧",
	}, -- [214]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "人类",
		["NameServer"] = "剧场-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 13.3100801647895,
		["Class"] = "武僧",
	}, -- [215]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "机械侏儒",
		["NameServer"] = "没事瞎玩-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.07633964463140128,
		["Class"] = "术士",
	}, -- [216]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "虚空精灵",
		["NameServer"] = "我能闪-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 20.96664668811582,
		["Class"] = "猎人",
	}, -- [217]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "虚空精灵",
		["NameServer"] = "胖鱼哥-永恒之井",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 22.14578881161753,
		["Class"] = "战士",
	}, -- [218]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "我随便逛逛的-血色十字军",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 33.4159972922388,
		["Class"] = "圣骑士",
	}, -- [219]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "魔法兄贵真安-伊瑟拉",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★☆",
		["PVPScore"] = 66.8576317269149,
		["Class"] = "圣骑士",
	}, -- [220]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "小漠大白菜-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★☆",
		["PVPScore"] = 59.36300119001631,
		["Class"] = "潜行者",
	}, -- [221]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "那个老奶骑-无尽之海",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 47.33941426392738,
		["Class"] = "猎人",
	}, -- [222]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "养只大白鹅-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 45.63302801008894,
		["Class"] = "圣骑士",
	}, -- [223]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "聖翼-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 16.48307652250835,
		["Class"] = "德鲁伊",
	}, -- [224]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "哈喽毛宇恒-闪电之刃",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 37.96565058276386,
		["Class"] = "潜行者",
	}, -- [225]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "Dreamhunter-闪电之刃",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 2.657019115890083,
		["Class"] = "恶魔猎手",
	}, -- [226]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "东风村村花-鲜血熔炉",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "恶魔猎手",
	}, -- [227]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "人类",
		["NameServer"] = "祝君好-安苏",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "术士",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [228]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "庄小萌-布兰卡德",
		["Faction"] = "部落",
		["Star"] = "★★★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 59.14859201352444,
		["FactionGroup"] = "Horde",
	}, -- [229]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "死亦骑生亦骑-塞拉摩",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 25.0860373564291,
		["FactionGroup"] = "Horde",
	}, -- [230]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "Floydz-布兰卡德",
		["Faction"] = "部落",
		["Star"] = "★★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 51.53619038365449,
		["FactionGroup"] = "Horde",
	}, -- [231]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "地精",
		["NameServer"] = "松舍问霞-布兰卡德",
		["Faction"] = "部落",
		["Star"] = "战神",
		["Class"] = "猎人",
		["PVPScore"] = 83.31065344930184,
		["FactionGroup"] = "Horde",
	}, -- [232]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "你与少年-冰风岗",
		["Faction"] = "部落",
		["Star"] = "★★★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 51.94301280758236,
		["FactionGroup"] = "Horde",
	}, -- [233]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "布莱登史塔克-迅捷微风",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 25.63355561914675,
		["FactionGroup"] = "Horde",
	}, -- [234]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "兽人",
		["NameServer"] = "Acelady-布兰卡德",
		["Faction"] = "部落",
		["Star"] = "★★★★☆",
		["Class"] = "法师",
		["PVPScore"] = 68.84220038027738,
		["FactionGroup"] = "Horde",
	}, -- [235]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "丶林田惠-冰风岗",
		["Faction"] = "部落",
		["Star"] = "★★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 57.9821937497842,
		["FactionGroup"] = "Horde",
	}, -- [236]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "Arakimentari-塞拉摩",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "潜行者",
		["PVPScore"] = 76.37519779636453,
		["FactionGroup"] = "Horde",
	}, -- [237]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "紫蓝灬-黑铁",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 47.06820307843071,
		["FactionGroup"] = "Horde",
	}, -- [238]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "兽人",
		["NameServer"] = "Darkleft-塞拉摩",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "术士",
		["PVPScore"] = 9.9416163981909,
		["FactionGroup"] = "Alliance",
	}, -- [239]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "傲慢-海克泰尔",
		["Faction"] = "联盟",
		["Star"] = "战神",
		["Class"] = "圣骑士",
		["PVPScore"] = 84.46133736843667,
		["FactionGroup"] = "Alliance",
	}, -- [240]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "劈柴三年-血色十字军",
		["Faction"] = "联盟",
		["Star"] = "★★★☆",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 59.03580231064835,
		["FactionGroup"] = "Alliance",
	}, -- [241]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "时间安排者-狂热之刃",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "战士",
		["PVPScore"] = 27.42832140194845,
		["FactionGroup"] = "Alliance",
	}, -- [242]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "巨魔",
		["NameServer"] = "Beli-血色十字军",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "术士",
		["PVPScore"] = 39.6310306332273,
		["FactionGroup"] = "Alliance",
	}, -- [243]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "阿梨诃他-影之哀伤",
		["Faction"] = "联盟",
		["Star"] = "★★★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 53.33015404650296,
		["FactionGroup"] = "Alliance",
	}, -- [244]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "歆妤丶-影之哀伤",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "牧师",
		["PVPScore"] = 17.7064310619281,
		["FactionGroup"] = "Alliance",
	}, -- [245]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "Lowo-普罗德摩",
		["Faction"] = "联盟",
		["Star"] = "★★★★★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 75.08467496191778,
		["FactionGroup"] = "Alliance",
	}, -- [246]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "芬黎道上丶-影之哀伤",
		["Faction"] = "联盟",
		["Star"] = "★★★",
		["Class"] = "牧师",
		["PVPScore"] = 53.13005225830304,
		["FactionGroup"] = "Alliance",
	}, -- [247]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "兽人",
		["NameServer"] = "凌灀丶-海克泰尔",
		["Faction"] = "联盟",
		["Star"] = "★★★☆",
		["Class"] = "法师",
		["PVPScore"] = 59.23903608290378,
		["FactionGroup"] = "Alliance",
	}, -- [248]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "楽漁-凤凰之神",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "法师",
		["PVPScore"] = 7.512045443101261,
		["FactionGroup"] = "Alliance",
	}, -- [249]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "Ekz-无尽之海",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "萨满祭司",
		["PVPScore"] = 43.63658874209974,
		["FactionGroup"] = "Horde",
	}, -- [250]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "Jefferies-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "战神",
		["Class"] = "法师",
		["PVPScore"] = 85.65368554990472,
		["FactionGroup"] = "Alliance",
	}, -- [251]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "虚空精灵",
		["NameServer"] = "澎湃快感-末日行者",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "术士",
		["PVPScore"] = 23.41164024152852,
		["FactionGroup"] = "Alliance",
	}, -- [252]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "Bluetoothz-末日行者",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "潜行者",
		["PVPScore"] = 13.96191981875423,
		["FactionGroup"] = "Alliance",
	}, -- [253]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "阿克萌德丨-阿古斯",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 29.30412874748552,
		["FactionGroup"] = "Alliance",
	}, -- [254]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Hanseyzz-罗宁",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 43.41273227749149,
		["FactionGroup"] = "Alliance",
	}, -- [255]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "人类",
		["NameServer"] = "大惑惑-罗宁",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "武僧",
		["PVPScore"] = 29.02815396385557,
		["FactionGroup"] = "Alliance",
	}, -- [256]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "少年輕狂-熊猫酒仙",
		["Faction"] = "联盟",
		["Star"] = "战神",
		["Class"] = "圣骑士",
		["PVPScore"] = 82.7821039203105,
		["FactionGroup"] = "Alliance",
	}, -- [257]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "矮人",
		["NameServer"] = "Windfuryy-罗宁",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "萨满祭司",
		["PVPScore"] = 2.548296296296296,
		["FactionGroup"] = "Alliance",
	}, -- [258]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "暗夜精灵",
		["NameServer"] = "南风逍遥-末日行者",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "牧师",
		["PVPScore"] = 3.090344849082485,
		["FactionGroup"] = "Alliance",
	}, -- [259]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "鸽几王-罗宁",
		["Faction"] = "联盟",
		["Star"] = "★★★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 57.1305814421339,
		["FactionGroup"] = "Alliance",
	}, -- [260]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "劎慕晨-安苏",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "潜行者",
		["PVPScore"] = 15.52363214087816,
		["FactionGroup"] = "Horde",
	}, -- [261]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "燃烧的小酒桌-凤凰之神",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 30.9185940032092,
		["FactionGroup"] = "Alliance",
	}, -- [262]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "丶清龍-冰风岗",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 30.80395583190821,
		["FactionGroup"] = "Alliance",
	}, -- [263]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "狐人",
		["NameServer"] = "执手阳春丶-凤凰之神",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "术士",
		["PVPScore"] = 47.40439102327572,
		["FactionGroup"] = "Alliance",
	}, -- [264]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "地精",
		["NameServer"] = "光猪-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 49.73774450428092,
		["FactionGroup"] = "Horde",
	}, -- [265]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "虚空精灵",
		["NameServer"] = "Sethlord-回音山",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "术士",
		["PVPScore"] = 24.02774681130052,
		["FactionGroup"] = "Alliance",
	}, -- [266]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "飘如灬上尘-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 48.54879403317499,
		["FactionGroup"] = "Alliance",
	}, -- [267]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "虚空精灵",
		["NameServer"] = "纲乄手-布兰卡德",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "牧师",
		["PVPScore"] = 34.88676843702446,
		["FactionGroup"] = "Alliance",
	}, -- [268]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "Drchen-白银之手",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "圣骑士",
		["PVPScore"] = 18.10578182423933,
		["FactionGroup"] = "Alliance",
	}, -- [269]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "灬豪崽灬-罗宁",
		["Faction"] = "联盟",
		["Star"] = "★★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 58.58852806539794,
		["FactionGroup"] = "Alliance",
	}, -- [270]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "疯小牧-白银之手",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "牧师",
		["PVPScore"] = 16.77076766391144,
		["FactionGroup"] = "Alliance",
	}, -- [271]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "消失的洛薩-破碎岭",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 48.27669851456161,
		["FactionGroup"] = "Alliance",
	}, -- [272]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Darkhumor-国王之谷",
		["Faction"] = "联盟",
		["Star"] = "★★★★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 73.48329636204048,
		["FactionGroup"] = "Alliance",
	}, -- [273]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "月下独酌一杯-世界之树",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 35.06131600637484,
		["FactionGroup"] = "Horde",
	}, -- [274]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "Deathballoon-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 28.36044280481701,
		["FactionGroup"] = "Horde",
	}, -- [275]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "彭于暥-埃加洛尔",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 44.01144922840675,
		["FactionGroup"] = "Horde",
	}, -- [276]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "岁月丨神偷-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "死亡骑士",
		["PVPScore"] = 33.45708779863023,
		["FactionGroup"] = "Horde",
	}, -- [277]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "麻团子丶-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 13.46721197622553,
		["FactionGroup"] = "Horde",
	}, -- [278]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "快递咕-贫瘠之地",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 33.3094384707288,
		["FactionGroup"] = "Horde",
	}, -- [279]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "落叶丶归根-血色十字军",
		["Faction"] = "部落",
		["Star"] = "★★★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 54.39093031719796,
		["FactionGroup"] = "Horde",
	}, -- [280]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "大橘已定丶-燃烧之刃",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 78.8277120372831,
		["FactionGroup"] = "Horde",
	}, -- [281]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "巨魔",
		["NameServer"] = "元宝是个孩子-布兰卡德",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "术士",
		["PVPScore"] = 39.79941096218428,
		["FactionGroup"] = "Horde",
	}, -- [282]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "地精",
		["NameServer"] = "千小鶴-死亡之翼",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "牧师",
		["PVPScore"] = 25.62902641863202,
		["FactionGroup"] = "Horde",
	}, -- [283]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "翎丿伤-冰风岗",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "牧师",
		["PVPScore"] = 75.12545895917691,
		["FactionGroup"] = "Horde",
	}, -- [284]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "纨劣小毒-寒冰皇冠",
		["Faction"] = "部落",
		["Star"] = "★★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 51.96074680091999,
		["FactionGroup"] = "Horde",
	}, -- [285]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "狐人",
		["NameServer"] = "你家饺子真棒-龙骨平原",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "术士",
		["PVPScore"] = 14.65399894782747,
		["FactionGroup"] = "Horde",
	}, -- [286]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "江湖再無熊哥-加基森",
		["Faction"] = "部落",
		["Star"] = "★★★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 66.39619633492941,
		["FactionGroup"] = "Horde",
	}, -- [287]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "诗眠-燃烧之刃",
		["Faction"] = "部落",
		["Star"] = "★★★★",
		["Class"] = "猎人",
		["PVPScore"] = 61.2551944887087,
		["FactionGroup"] = "Horde",
	}, -- [288]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "夏影舞-燃烧之刃",
		["Faction"] = "部落",
		["Star"] = "★★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 59.36688879706442,
		["FactionGroup"] = "Horde",
	}, -- [289]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "伱父親-盖斯",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 21.68785344402509,
		["FactionGroup"] = "Horde",
	}, -- [290]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "新沂盐豆子-亡语者",
		["Faction"] = "部落",
		["Star"] = "★★★★",
		["Class"] = "牧师",
		["PVPScore"] = 64.01024619899565,
		["FactionGroup"] = "Horde",
	}, -- [291]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "萌萌飞起来-白银之手",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 46.39232197750582,
		["FactionGroup"] = "Alliance",
	}, -- [292]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "小地瓜-末日祷告祭坛",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "法师",
		["PVPScore"] = 41.823765761496,
		["FactionGroup"] = "Alliance",
	}, -- [293]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Assdestroyer-埃德萨拉",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 41.3297576708828,
		["FactionGroup"] = "Alliance",
	}, -- [294]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "海棠府三公主-熊猫酒仙",
		["Faction"] = "联盟",
		["Star"] = "★★★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 73.01768730876367,
		["FactionGroup"] = "Alliance",
	}, -- [295]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "虚空精灵",
		["NameServer"] = "丨排丷骨丶-末日行者",
		["Faction"] = "联盟",
		["Star"] = "★★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 57.01602569369594,
		["FactionGroup"] = "Alliance",
	}, -- [296]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "王子阿拉贡-罗宁",
		["Faction"] = "联盟",
		["Star"] = "★★★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 62.1129288017836,
		["FactionGroup"] = "Alliance",
	}, -- [297]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "神圣之守护者-末日行者",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 40.35856964480882,
		["FactionGroup"] = "Alliance",
	}, -- [298]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "联盟圣骑兵-加里索斯",
		["Faction"] = "联盟",
		["Star"] = "★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 54.30950978676943,
		["FactionGroup"] = "Alliance",
	}, -- [299]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "人类",
		["NameServer"] = "Sigvard-白银之手",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "术士",
		["PVPScore"] = 16.84660275724503,
		["FactionGroup"] = "Alliance",
	}, -- [300]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "Emingloli-熊猫酒仙",
		["Faction"] = "联盟",
		["Star"] = "★★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 58.45472480802309,
		["FactionGroup"] = "Alliance",
	}, -- [301]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "巨魔",
		["NameServer"] = "元牧-安苏",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "牧师",
		["PVPScore"] = 15.29570892916502,
		["FactionGroup"] = "Horde",
	}, -- [302]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "安德鲁杰哥-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "★★★★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 60.07107189404744,
		["FactionGroup"] = "Horde",
	}, -- [303]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "帝乡-埃德萨拉",
		["Faction"] = "部落",
		["Star"] = "战神",
		["Class"] = "萨满祭司",
		["PVPScore"] = 81.94187212579469,
		["FactionGroup"] = "Horde",
	}, -- [304]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "龙胄-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "战士",
		["PVPScore"] = 48.99629107868994,
		["FactionGroup"] = "Alliance",
	}, -- [305]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "喵星人丶逆袭-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 34.71865928429506,
		["FactionGroup"] = "Alliance",
	}, -- [306]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "九乄鬼-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "★★★★☆",
		["Class"] = "猎人",
		["PVPScore"] = 65.70985972682845,
		["FactionGroup"] = "Alliance",
	}, -- [307]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "Angelguards-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "★★★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 74.41682405763875,
		["FactionGroup"] = "Alliance",
	}, -- [308]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "圣光照不到你-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "★★★★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 67.48048106532111,
		["FactionGroup"] = "Alliance",
	}, -- [309]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "小丶源-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "牧师",
		["PVPScore"] = 26.19154971845876,
		["FactionGroup"] = "Alliance",
	}, -- [310]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "黄乄昏-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "★★★★☆",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 69.95084419595669,
		["FactionGroup"] = "Alliance",
	}, -- [311]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "血精灵",
		["NameServer"] = "殺生院丶祈荒-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "术士",
		["PVPScore"] = 46.62475111708067,
		["FactionGroup"] = "Alliance",
	}, -- [312]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "大元先生-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 14.73547992603323,
		["FactionGroup"] = "Alliance",
	}, -- [313]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "夜好深-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "★★★★★",
		["Class"] = "潜行者",
		["PVPScore"] = 77.23143055369152,
		["FactionGroup"] = "Alliance",
	}, -- [314]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "常老湿-死亡之翼",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 40.89674078590208,
		["FactionGroup"] = "Alliance",
	}, -- [315]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "阿加瑞斯-伊森利恩",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 40.71167450228649,
		["FactionGroup"] = "Alliance",
	}, -- [316]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "渣渣貓-影之哀伤",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "萨满祭司",
		["PVPScore"] = 42.249453821663,
		["FactionGroup"] = "Alliance",
	}, -- [317]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "梦采清莲-凤凰之神",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "法师",
		["PVPScore"] = 10.82314540633239,
		["FactionGroup"] = "Alliance",
	}, -- [318]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "関中刀客-埃德萨拉",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "牧师",
		["PVPScore"] = 16.17878323966012,
		["FactionGroup"] = "Alliance",
	}, -- [319]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "至高岭牛头人",
		["NameServer"] = "万灵之召-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [320]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "福丶将-格瑞姆巴托",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "潜行者",
		["PVPScore"] = 36.83691911911703,
		["FactionGroup"] = "Alliance",
	}, -- [321]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "巨魔",
		["NameServer"] = "斐思洛-伊森利恩",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "术士",
		["PVPScore"] = 47.70327635947874,
		["FactionGroup"] = "Alliance",
	}, -- [322]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "熊猫人",
		["NameServer"] = "行哎行哎-死亡之翼",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "牧师",
		["PVPScore"] = 18.36766533358366,
		["FactionGroup"] = "Alliance",
	}, -- [323]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "血精灵",
		["NameServer"] = "血色徨镞-永恒之井",
		["Faction"] = "联盟",
		["Star"] = "★★★★☆",
		["Class"] = "术士",
		["PVPScore"] = 66.54961307321581,
		["FactionGroup"] = "Alliance",
	}, -- [324]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "Ennyin-埃加洛尔",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "术士",
		["PVPScore"] = 79.11077295981984,
		["FactionGroup"] = "Horde",
	}, -- [325]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "今晚要交粮-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "法师",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [326]
}
PVPScoreCacheDate = 1610895720
