
PVPScoreCache = {
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "软泥怪好怪啊-破碎岭",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "猎人",
		["PVPScore"] = 25.32317843582999,
		["FactionGroup"] = "Alliance",
	}, -- [1]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "浪包-安苏",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 1.772890335807127,
		["FactionGroup"] = "Alliance",
	}, -- [2]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "叶赫-贫瘠之地",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [3]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "景雨亭-死亡之翼",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 44.39170580913589,
		["FactionGroup"] = "Alliance",
	}, -- [4]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "了然于心-贫瘠之地",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 25.29885529132003,
		["FactionGroup"] = "Alliance",
	}, -- [5]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "戆憨憨-玛里苟斯",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 48.13902817892817,
		["FactionGroup"] = "Alliance",
	}, -- [6]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "嘎巴-罗宁",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "潜行者",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [7]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "皎空影月-拉贾克斯",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "潜行者",
		["PVPScore"] = 0.0002,
		["FactionGroup"] = "Alliance",
	}, -- [8]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "寂寞小皇-金度",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 23.91208670602821,
		["FactionGroup"] = "Alliance",
	}, -- [9]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "暗夜精灵",
		["NameServer"] = "蝶之夢-羽月",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 0.0002,
		["FactionGroup"] = "Alliance",
	}, -- [10]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "侑點吙-红云台地",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "术士",
		["PVPScore"] = 49.20791558002916,
		["FactionGroup"] = "Alliance",
	}, -- [11]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "親爱的-燃烧军团",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 1.263208865514651,
		["FactionGroup"] = "Horde",
	}, -- [12]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "狐人",
		["NameServer"] = "狐千岁-贫瘠之地",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "武僧",
		["PVPScore"] = 6.862855653016577,
		["FactionGroup"] = "Horde",
	}, -- [13]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "格格鄔-无尽之海",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 36.13183522900744,
		["FactionGroup"] = "Horde",
	}, -- [14]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "狐人",
		["NameServer"] = "不容易死掉-安苏",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "潜行者",
		["PVPScore"] = 7.981709861781281,
		["FactionGroup"] = "Horde",
	}, -- [15]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "夜之子",
		["NameServer"] = "海无边天作岸-贫瘠之地",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "法师",
		["PVPScore"] = 11.33417937591665,
		["FactionGroup"] = "Horde",
	}, -- [16]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "兽人",
		["NameServer"] = "Desire-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "死亡骑士",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [17]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "迪迪尔-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [18]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "叫我桀桀啊喂-塞拉摩",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "圣骑士",
		["PVPScore"] = 18.94537292400351,
		["FactionGroup"] = "Horde",
	}, -- [19]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "轩辕悟世-主宰之剑",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 0.7519413167490899,
		["FactionGroup"] = "Horde",
	}, -- [20]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "血精灵",
		["NameServer"] = "不知火武-奈法利安",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "武僧",
		["PVPScore"] = 33.35701054158486,
		["FactionGroup"] = "Horde",
	}, -- [21]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "狐人",
		["NameServer"] = "盗亦有刀-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "潜行者",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [22]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "人类",
		["NameServer"] = "長生劍-永夜港",
		["Faction"] = "联盟",
		["Star"] = "★★★★",
		["Class"] = "术士",
		["PVPScore"] = 61.64987537809104,
		["FactionGroup"] = "Alliance",
	}, -- [23]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "德莱尼",
		["NameServer"] = "一抹红尘-暗影之月",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 37.32201998790663,
		["FactionGroup"] = "Alliance",
	}, -- [24]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "传说中的牛牛-大地之怒",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [25]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "丿咩丶霸-凤凰之神",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 45.08659473044914,
		["FactionGroup"] = "Horde",
	}, -- [26]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "卡布的羞涩-冰霜之刃",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "牧师",
		["PVPScore"] = 32.46559883456444,
		["FactionGroup"] = "Horde",
	}, -- [27]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "强力蕉-冰风岗",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "战士",
		["PVPScore"] = 23.75574498848562,
		["FactionGroup"] = "Horde",
	}, -- [28]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "幻世沧海-丹莫德",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 38.85532045792871,
		["FactionGroup"] = "Horde",
	}, -- [29]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "牛头人",
		["NameServer"] = "牧牛人-影之哀伤",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "战士",
		["PVPScore"] = 20.67877508042978,
		["FactionGroup"] = "Horde",
	}, -- [30]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "巨魔",
		["NameServer"] = "本区最骚-加兹鲁维",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "猎人",
		["PVPScore"] = 29.75982478073948,
		["FactionGroup"] = "Horde",
	}, -- [31]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "丹江女侠-雷霆之王",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "潜行者",
		["PVPScore"] = 3.6557541015625,
		["FactionGroup"] = "Horde",
	}, -- [32]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "狐人",
		["NameServer"] = "漩涡九喇麻-影之哀伤",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "猎人",
		["PVPScore"] = 44.19176582055572,
		["FactionGroup"] = "Horde",
	}, -- [33]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "破除万物戒律-埃德萨拉",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "牧师",
		["PVPScore"] = 14.09707610662074,
		["FactionGroup"] = "Horde",
	}, -- [34]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "磚丨頭-影之哀伤",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 36.75630563330982,
		["FactionGroup"] = "Horde",
	}, -- [35]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "木子墨儿-永恒之井",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 16.07605766077653,
		["FactionGroup"] = "Horde",
	}, -- [36]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "锦鲤丶-影之哀伤",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "法师",
		["PVPScore"] = 4.768535957597156,
		["FactionGroup"] = "Horde",
	}, -- [37]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "常梦-影牙要塞",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "牧师",
		["PVPScore"] = 39.29465650013784,
		["FactionGroup"] = "Alliance",
	}, -- [38]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "兽人",
		["NameServer"] = "撕毛比-冰风岗",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 28.23621458099386,
		["FactionGroup"] = "Horde",
	}, -- [39]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "兽人",
		["NameServer"] = "麻麻让我打人-奥尔加隆",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 2.215712919758909,
		["FactionGroup"] = "Horde",
	}, -- [40]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "晓度娘-影之哀伤",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 21.64545973411798,
		["FactionGroup"] = "Horde",
	}, -- [41]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "暗影骨刺-伊森德雷",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 48.62493862859655,
		["FactionGroup"] = "Horde",
	}, -- [42]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "Talaxia-狂热之刃",
		["Faction"] = "部落",
		["Star"] = "★★★",
		["Class"] = "法师",
		["PVPScore"] = 51.91443622460217,
		["FactionGroup"] = "Horde",
	}, -- [43]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "资深酱油-卡拉赞",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 12.37535521157307,
		["FactionGroup"] = "Horde",
	}, -- [44]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "兽人",
		["NameServer"] = "常州赵子龙-国王之谷",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 25.17591493313272,
		["FactionGroup"] = "Horde",
	}, -- [45]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "毛毛德-狂热之刃",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 44.74767817592286,
		["FactionGroup"] = "Horde",
	}, -- [46]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "牛头人",
		["NameServer"] = "幻丶帅-斯克提斯",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "战士",
		["PVPScore"] = 37.26206639237372,
		["FactionGroup"] = "Horde",
	}, -- [47]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "至高岭牛头人",
		["NameServer"] = "丨牛牛丨德-达尔坎",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 28.5816835465967,
		["FactionGroup"] = "Horde",
	}, -- [48]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "好吃吗你-凤凰之神",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 22.80707823130516,
		["FactionGroup"] = "Horde",
	}, -- [49]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "惊鸿-耐普图隆",
		["Faction"] = "部落",
		["Star"] = "★★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 62.68166686872027,
		["FactionGroup"] = "Horde",
	}, -- [50]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "幽雪紫葶-格雷迈恩",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 26.05704086074254,
		["FactionGroup"] = "Horde",
	}, -- [51]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "元智-贫瘠之地",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "法师",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [52]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "輕风之語-塞拉摩",
		["Faction"] = "部落",
		["Star"] = "★★★",
		["Class"] = "战士",
		["PVPScore"] = 50.0264801147847,
		["FactionGroup"] = "Horde",
	}, -- [53]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "今年十八岁-塞拉摩",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 5.80514416232279,
		["FactionGroup"] = "Horde",
	}, -- [54]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "兽人",
		["NameServer"] = "战胜灬倚天-安苏",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "死亡骑士",
		["PVPScore"] = 38.68210446575196,
		["FactionGroup"] = "Horde",
	}, -- [55]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "狐人",
		["NameServer"] = "虎假狐威-主宰之剑",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 48.90216763153085,
		["FactionGroup"] = "Horde",
	}, -- [56]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "妖妖苓-塞拉摩",
		["Faction"] = "联盟",
		["Star"] = "★★★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 55.21056061143982,
		["FactionGroup"] = "Alliance",
	}, -- [57]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "沃兰德教授-银松森林",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "猎人",
		["PVPScore"] = 23.44610920900949,
		["FactionGroup"] = "Alliance",
	}, -- [58]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "丨辣丶椒丨-安苏",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "猎人",
		["PVPScore"] = 23.84963527347842,
		["FactionGroup"] = "Alliance",
	}, -- [59]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "诸神之眼-风暴之眼",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "战士",
		["PVPScore"] = 37.6203553147791,
		["FactionGroup"] = "Alliance",
	}, -- [60]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "孤军丨奋战-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "猎人",
		["PVPScore"] = 10.57576127501828,
		["FactionGroup"] = "Horde",
	}, -- [61]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "丨寻找六六丨-冰风岗",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 16.92499288886042,
		["FactionGroup"] = "Horde",
	}, -- [62]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "血精灵",
		["NameServer"] = "Charger-阿纳克洛斯",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "战士",
		["PVPScore"] = 49.81851742932759,
		["FactionGroup"] = "Horde",
	}, -- [63]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "丶可乐加冰丷-格瑞姆巴托",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "猎人",
		["PVPScore"] = 72.10036812657785,
		["FactionGroup"] = "Horde",
	}, -- [64]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "Mmazkc-死亡之翼",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "战士",
		["PVPScore"] = 19.25793681740605,
		["FactionGroup"] = "Horde",
	}, -- [65]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "嘟当曼-影之哀伤",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 20.20626499674089,
		["FactionGroup"] = "Horde",
	}, -- [66]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "夜之子",
		["NameServer"] = "后视镜的世界-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "法师",
		["PVPScore"] = 25.89343580569449,
		["FactionGroup"] = "Horde",
	}, -- [67]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "淡墨丿-影之哀伤",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "法师",
		["PVPScore"] = 0.0002,
		["FactionGroup"] = "Horde",
	}, -- [68]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "仇伍仁化-风暴之鳞",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "术士",
		["PVPScore"] = 25.18372452283941,
		["FactionGroup"] = "Horde",
	}, -- [69]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "达布妞-雏龙之翼",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "牧师",
		["PVPScore"] = 33.07957024323487,
		["FactionGroup"] = "Horde",
	}, -- [70]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "兽人",
		["NameServer"] = "冷暖哪可休-燃烧之刃",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "法师",
		["PVPScore"] = 45.55477638614897,
		["FactionGroup"] = "Horde",
	}, -- [71]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "玛格汉兽人",
		["NameServer"] = "死亡之擁-影之哀伤",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 0.1207755432457396,
		["FactionGroup"] = "Horde",
	}, -- [72]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "Flowerlet-阿纳克洛斯",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "潜行者",
		["PVPScore"] = 18.48393217146515,
		["FactionGroup"] = "Horde",
	}, -- [73]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "Shourenvokup-阿纳克洛斯",
		["Faction"] = "部落",
		["Star"] = "★★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 57.64741568234787,
		["FactionGroup"] = "Horde",
	}, -- [74]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "血蝶泪-克尔苏加德",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 46.45245142254041,
		["FactionGroup"] = "Horde",
	}, -- [75]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "丨狙丶击丨-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "猎人",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [76]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "狐人",
		["NameServer"] = "过期梦想-克尔苏加德",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "术士",
		["PVPScore"] = 6.815695378894857,
		["FactionGroup"] = "Horde",
	}, -- [77]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "顶天牛肉干店-贫瘠之地",
		["Faction"] = "联盟",
		["Star"] = "★★★★★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 74.93932062115644,
		["FactionGroup"] = "Alliance",
	}, -- [78]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "丂梘-埃德萨拉",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 12.89915768495351,
		["FactionGroup"] = "Horde",
	}, -- [79]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "Sillage-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "潜行者",
		["PVPScore"] = 10.05553302033537,
		["FactionGroup"] = "Horde",
	}, -- [80]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "熊猫人",
		["NameServer"] = "切莫太宰-冰风岗",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 47.75913394692797,
		["FactionGroup"] = "Horde",
	}, -- [81]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "吾慌-死亡之翼",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 24.26399821199387,
		["FactionGroup"] = "Horde",
	}, -- [82]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "玛格汉兽人",
		["NameServer"] = "乄剑在人在灬-贫瘠之地",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "战士",
		["PVPScore"] = 11.73417530335394,
		["FactionGroup"] = "Horde",
	}, -- [83]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "鲸兔-死亡之翼",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [84]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "毒毒-凤凰之神",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "术士",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [85]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "八九小风蛇-无尽之海",
		["Faction"] = "部落",
		["Star"] = "★☆",
		["Class"] = "牧师",
		["PVPScore"] = 29.06050283445618,
		["FactionGroup"] = "Horde",
	}, -- [86]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "天葬破军-鬼雾峰",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "法师",
		["PVPScore"] = 48.08335757285411,
		["FactionGroup"] = "Horde",
	}, -- [87]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "虚空精灵",
		["NameServer"] = "云游者灬-索瑞森",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "战士",
		["PVPScore"] = 0.2244593066791955,
		["FactionGroup"] = "Alliance",
	}, -- [88]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "小犄角哟-战歌",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 12.96100943941234,
		["FactionGroup"] = "Horde",
	}, -- [89]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "Rosebueed-洛肯",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 75.09902176652906,
		["FactionGroup"] = "Horde",
	}, -- [90]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "陳小辰-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "法师",
		["PVPScore"] = 33.01751133050937,
		["FactionGroup"] = "Alliance",
	}, -- [91]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "Ennyin-埃加洛尔",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "术士",
		["PVPScore"] = 79.15543311371218,
		["FactionGroup"] = "Horde",
	}, -- [92]
}
PVPScoreCacheDate = 1617092659
