
PVPScoreCache = {
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "人类",
		["NameServer"] = "Doomart-阿拉希",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★★",
		["PVPScore"] = 74.74914805518198,
		["Class"] = "术士",
	}, -- [1]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "虚空精灵",
		["NameServer"] = "喀耳刻-瑞文戴尔",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "术士",
	}, -- [2]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "二胖胖-凤凰之神",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 37.53874435687153,
		["Class"] = "潜行者",
	}, -- [3]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "虚空精灵",
		["NameServer"] = "光影丶相随-贫瘠之地",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 8.480594059441039,
		["Class"] = "牧师",
	}, -- [4]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "心儿飞了-风暴之眼",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "战神",
		["PVPScore"] = 92.90787977852045,
		["Class"] = "圣骑士",
	}, -- [5]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "圣光奶瓶-迅捷微风",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 32.75768555028346,
		["Class"] = "圣骑士",
	}, -- [6]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "黑铁矮人",
		["NameServer"] = "暗炉城电鳗-艾萨拉",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "萨满祭司",
	}, -- [7]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "邪恶的星星-法拉希姆",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 9.832465889375342,
		["Class"] = "潜行者",
	}, -- [8]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Fauxhemia-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★☆",
		["PVPScore"] = 58.97834922486246,
		["Class"] = "牧师",
	}, -- [9]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "光明行者-拉文凯斯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "圣骑士",
	}, -- [10]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "御浪-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 15.3725688805431,
		["Class"] = "德鲁伊",
	}, -- [11]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "Ziqely-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★",
		["PVPScore"] = 54.43675212074469,
		["Class"] = "圣骑士",
	}, -- [12]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "龍之刺-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 12.72044168948881,
		["Class"] = "战士",
	}, -- [13]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "塞哪里噢-壁炉谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.0002,
		["Class"] = "德鲁伊",
	}, -- [14]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "天上人间-塞泰克",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.6321044327573255,
		["Class"] = "猎人",
	}, -- [15]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "Mcdreamer-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 28.42698684716134,
		["Class"] = "猎人",
	}, -- [16]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Chwehuii-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 2.546726780776826,
		["Class"] = "恶魔猎手",
	}, -- [17]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "逍遥叹-轻风之语",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★☆",
		["PVPScore"] = 55.40465926482786,
		["Class"] = "法师",
	}, -- [18]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "夕画-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★☆",
		["PVPScore"] = 66.68646712374701,
		["Class"] = "法师",
	}, -- [19]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "商炸炸-熔火之心",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.1230370282854206,
		["Class"] = "法师",
	}, -- [20]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "光铸德莱尼",
		["NameServer"] = "幽若雅然-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 41.78666531372114,
		["Class"] = "圣骑士",
	}, -- [21]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "战神彪悍叔-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 8.3364788113596,
		["Class"] = "战士",
	}, -- [22]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "普兰德斯-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "德鲁伊",
	}, -- [23]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "裤裆藏雷-金色平原",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 19.21478060302734,
		["Class"] = "战士",
	}, -- [24]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "月若惜-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "萨满祭司",
	}, -- [25]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "多特梦德-破碎岭",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 32.93699889848091,
		["Class"] = "德鲁伊",
	}, -- [26]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "亡灵",
		["NameServer"] = "莫大-破碎岭",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 44.86343506428029,
		["Class"] = "战士",
	}, -- [27]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "狐人",
		["NameServer"] = "檸檬伈情-石锤",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★",
		["PVPScore"] = 54.90850918950727,
		["Class"] = "猎人",
	}, -- [28]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "黑铁矮人",
		["NameServer"] = "海兽祭司-晴日峰（江苏）",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 4.076074074074073,
		["Class"] = "萨满祭司",
	}, -- [29]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "公务员-壁炉谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 5.190185185185186,
		["Class"] = "法师",
	}, -- [30]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "光铸德莱尼",
		["NameServer"] = "丿聖丶光-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.0002,
		["Class"] = "圣骑士",
	}, -- [31]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Darkkiller-法拉希姆",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 19.01300201226351,
		["Class"] = "恶魔猎手",
	}, -- [32]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Zffx-山丘之王",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 15.07337244413926,
		["Class"] = "战士",
	}, -- [33]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "景雨亭-死亡之翼",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 43.38863612887671,
		["Class"] = "德鲁伊",
	}, -- [34]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "快向我開炮-菲米丝",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 48.10903804781056,
		["Class"] = "圣骑士",
	}, -- [35]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "阿让-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "德鲁伊",
	}, -- [36]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "预言-暗影之月",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 22.31782880075833,
		["Class"] = "圣骑士",
	}, -- [37]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "玩吥起丶绌局-达斯雷玛",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★☆",
		["PVPScore"] = 58.40949399717006,
		["Class"] = "潜行者",
	}, -- [38]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "思维枯竭-克苏恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★",
		["PVPScore"] = 54.06003704958118,
		["Class"] = "牧师",
	}, -- [39]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "任我行丶-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "德鲁伊",
	}, -- [40]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "北冥丶月-奥特兰克",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.0002,
		["Class"] = "德鲁伊",
	}, -- [41]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "淡淡的咖啡香-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 29.40352416801985,
		["Class"] = "德鲁伊",
	}, -- [42]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "德莱尼",
		["NameServer"] = "虎哥哥带我飞-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 23.85524364184308,
		["Class"] = "圣骑士",
	}, -- [43]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "传说中的迷茫-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 47.82648479598279,
		["Class"] = "法师",
	}, -- [44]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "以战灬止战-军团要塞",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 34.4573429920156,
		["Class"] = "战士",
	}, -- [45]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "婉灬茹-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 12.35282476767548,
		["Class"] = "法师",
	}, -- [46]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "入戏哥-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 12.17347213453341,
		["Class"] = "牧师",
	}, -- [47]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "光铸德莱尼",
		["NameServer"] = "西斯灬汉娜-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "圣骑士",
	}, -- [48]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "爆煭之怒-黑铁",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "恶魔猎手",
	}, -- [49]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "血精灵",
		["NameServer"] = "带走妳的橙装-海克泰尔",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 0.0002,
		["Class"] = "战士",
	}, -- [50]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "柳絮-逐日者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★☆",
		["PVPScore"] = 58.65391397876761,
		["Class"] = "潜行者",
	}, -- [51]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "锦衣无暇-迅捷微风",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 39.45071525396892,
		["Class"] = "德鲁伊",
	}, -- [52]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "尐白狐-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 39.19652470262712,
		["Class"] = "牧师",
	}, -- [53]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "飞天一哥-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 47.26667977205946,
		["Class"] = "圣骑士",
	}, -- [54]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "飞天小咪咪-鲜血熔炉",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★★★",
		["PVPScore"] = 70.53616138248941,
		["Class"] = "猎人",
	}, -- [55]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "最爱糖糖-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 16.38900439373248,
		["Class"] = "猎人",
	}, -- [56]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "叶波-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "恶魔猎手",
	}, -- [57]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "真岛吾朗-影之哀伤",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 46.2645550683191,
		["Class"] = "圣骑士",
	}, -- [58]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "Oriana-耳语海岸",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 17.27829994314739,
		["Class"] = "猎人",
	}, -- [59]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "Onetc-格瑞姆巴托",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 14.79642913913348,
		["Class"] = "恶魔猎手",
	}, -- [60]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "阿佑-暗影之月",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 25.41219100776608,
		["Class"] = "潜行者",
	}, -- [61]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "倚偑-凤凰之神",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 34.91959048856132,
		["Class"] = "牧师",
	}, -- [62]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "杀生院祈塃-格瑞姆巴托",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 29.81388837562847,
		["Class"] = "猎人",
	}, -- [63]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "挺直腰板-迦拉克隆",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 21.92855044334475,
		["Class"] = "战士",
	}, -- [64]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "地精",
		["NameServer"] = "风样的自由-阿纳克洛斯",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★☆",
		["PVPScore"] = 55.20346876322495,
		["Class"] = "法师",
	}, -- [65]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "熊猫人",
		["NameServer"] = "不知名小猫咪-格瑞姆巴托",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 10.60161464484027,
		["Class"] = "萨满祭司",
	}, -- [66]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "为仔而战-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 5.764887172390393,
		["Class"] = "牧师",
	}, -- [67]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "张泡泡-死亡之翼",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 15.70662581842267,
		["Class"] = "德鲁伊",
	}, -- [68]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "大迫杰-安苏",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 39.1097167439804,
		["Class"] = "德鲁伊",
	}, -- [69]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "蕾格西-格瑞姆巴托",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 19.94899958828081,
		["Class"] = "圣骑士",
	}, -- [70]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "无职转生-死亡之翼",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "圣骑士",
	}, -- [71]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "玛格汉兽人",
		["NameServer"] = "暴君拳头-纳沙塔尔",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 46.34947780440149,
		["Class"] = "战士",
	}, -- [72]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "鬼大-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★★★",
		["PVPScore"] = 73.55000784878678,
		["Class"] = "法师",
	}, -- [73]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "硬的受不了-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 33.68488132076293,
		["Class"] = "战士",
	}, -- [74]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "抹了油的猪-格瑞姆巴托",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★",
		["PVPScore"] = 54.49942752239062,
		["Class"] = "圣骑士",
	}, -- [75]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "兽人",
		["NameServer"] = "威廉皮皮怪-戈提克",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 1.018505610681232,
		["Class"] = "武僧",
	}, -- [76]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "巨魔",
		["NameServer"] = "犹格一索托斯-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 48.58002290404811,
		["Class"] = "术士",
	}, -- [77]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "Tsunderett-埃德萨拉",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 39.53074679161605,
		["Class"] = "死亡骑士",
	}, -- [78]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "飙月-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 36.85901447497544,
		["Class"] = "战士",
	}, -- [79]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "我爆怪-加基森",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 49.71982132686983,
		["Class"] = "牧师",
	}, -- [80]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "雪沫之夏-布兰卡德",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 27.66590449800593,
		["Class"] = "法师",
	}, -- [81]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "阿哆滴-安苏",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 10.38179905889944,
		["Class"] = "潜行者",
	}, -- [82]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "著名的阿昆达-埃加洛尔",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 30.33051246923693,
		["Class"] = "德鲁伊",
	}, -- [83]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "Kukuzi-安苏",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 20.11677924993025,
		["Class"] = "猎人",
	}, -- [84]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "五氧化碳-海克泰尔",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 16.59756667253889,
		["Class"] = "猎人",
	}, -- [85]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "Uaremyff-玛里苟斯",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 48.92321355582644,
		["Class"] = "牧师",
	}, -- [86]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "雨夜得屠夫-迦拉克隆",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 6.155438419610971,
		["Class"] = "恶魔猎手",
	}, -- [87]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "晚安喵丶-死亡之翼",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★☆",
		["PVPScore"] = 56.00141309708508,
		["Class"] = "潜行者",
	}, -- [88]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "意举橙名-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 9.658400064104827,
		["Class"] = "德鲁伊",
	}, -- [89]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "星动-贫瘠之地",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 30.33051246923693,
		["Class"] = "德鲁伊",
	}, -- [90]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "死神不管我-伊森利恩",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★",
		["PVPScore"] = 51.95036404143859,
		["Class"] = "牧师",
	}, -- [91]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "追风逐云-尘风峡谷",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "圣骑士",
	}, -- [92]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "高看一眼-血色十字军",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 25.3149608790033,
		["Class"] = "恶魔猎手",
	}, -- [93]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "血色邪瞳-埃克索图斯",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "死亡骑士",
	}, -- [94]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "暴力之最-血色十字军",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 16.45537786078717,
		["Class"] = "战士",
	}, -- [95]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "Inparanoia-外域",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 49.56835421174232,
		["Class"] = "潜行者",
	}, -- [96]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "恶魔之舞-狂热之刃",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 10.75387491806329,
		["Class"] = "恶魔猎手",
	}, -- [97]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "兽人",
		["NameServer"] = "灬二大爷灬-格瑞姆巴托",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★☆",
		["PVPScore"] = 58.64255305348861,
		["Class"] = "死亡骑士",
	}, -- [98]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "Woomea-海克泰尔",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 40.90248883926764,
		["Class"] = "死亡骑士",
	}, -- [99]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "Lofty-翡翠梦境",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★★",
		["PVPScore"] = 63.93292124228333,
		["Class"] = "法师",
	}, -- [100]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "阿昆达的阿昆达-埃加洛尔",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★★★",
		["PVPScore"] = 78.27421304024551,
		["Class"] = "圣骑士",
	}, -- [101]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "地精",
		["NameServer"] = "布鲁斯老爷-闪电之刃",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 15.0707745317985,
		["Class"] = "法师",
	}, -- [102]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "地精",
		["NameServer"] = "老把子-符文图腾",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 12.2967915880601,
		["Class"] = "牧师",
	}, -- [103]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "丿红牛丿-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 16.6119503318492,
		["Class"] = "圣骑士",
	}, -- [104]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "五十个蓝猫-燃烧之刃",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 47.8379005242772,
		["Class"] = "潜行者",
	}, -- [105]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "狐人",
		["NameServer"] = "麦吖糖-无尽之海",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "猎人",
	}, -- [106]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "维克多雨果-迦顿",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 5.509889635291575,
		["Class"] = "死亡骑士",
	}, -- [107]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "巨魔",
		["NameServer"] = "沒秂性-血色十字军",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 6.721740311998833,
		["Class"] = "猎人",
	}, -- [108]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "老騒牛-影之哀伤",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "圣骑士",
	}, -- [109]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "可咔茵-布兰卡德",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 25.68715896596822,
		["Class"] = "法师",
	}, -- [110]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "至高岭牛头人",
		["NameServer"] = "紅豆豆的豆-狂热之刃",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 16.94666374553897,
		["Class"] = "德鲁伊",
	}, -- [111]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "狐壹叨-阿纳克洛斯",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "萨满祭司",
	}, -- [112]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "Akain-熊猫酒仙",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★★★",
		["PVPScore"] = 78.27421304024551,
		["Class"] = "圣骑士",
	}, -- [113]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "不太会玩-银松森林",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "牧师",
	}, -- [114]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "月亮粑粑-冬拥湖",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "法师",
	}, -- [115]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "那人是你嘛-无尽之海",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★☆",
		["PVPScore"] = 57.23317962745086,
		["Class"] = "牧师",
	}, -- [116]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "Ellenmoore-无尽之海",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "猎人",
	}, -- [117]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "马德-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 19.60868375909996,
		["Class"] = "德鲁伊",
	}, -- [118]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "一瓶小可乐-影之哀伤",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 1.057549479246049,
		["Class"] = "法师",
	}, -- [119]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "至高岭牛头人",
		["NameServer"] = "趁妳虚要妳命-熔火之心",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 0.0002,
		["Class"] = "德鲁伊",
	}, -- [120]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "巨魔",
		["NameServer"] = "人鱼天使-符文图腾",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 0.2649873698115123,
		["Class"] = "猎人",
	}, -- [121]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "黑铁矮人",
		["NameServer"] = "索瑞森嗖嗖-暗影之月",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 11.67948440612598,
		["Class"] = "猎人",
	}, -- [122]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "Wetrwety-森金",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 0.5291747396230246,
		["Class"] = "恶魔猎手",
	}, -- [123]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "古楓-迦顿",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 31.4657906813519,
		["Class"] = "恶魔猎手",
	}, -- [124]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "时间飞逝-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 15.14848845873972,
		["Class"] = "牧师",
	}, -- [125]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "地精",
		["NameServer"] = "只爱河马-戈提克",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 2.643287277819672,
		["Class"] = "萨满祭司",
	}, -- [126]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "各种斩杀丶-无尽之海",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★☆",
		["PVPScore"] = 41.12913313486389,
		["Class"] = "战士",
	}, -- [127]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "她好像走丢了-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 35.93391569243501,
		["Class"] = "战士",
	}, -- [128]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "Jasonwiliams-库尔提拉斯",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 33.02914998506571,
		["Class"] = "牧师",
	}, -- [129]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "小坏啊小坏-黑铁",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★",
		["PVPScore"] = 53.19182190857719,
		["Class"] = "猎人",
	}, -- [130]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "Elegyz-死亡之翼",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 5.241413454009873,
		["Class"] = "战士",
	}, -- [131]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "香菇炖鸡-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 39.8864008568997,
		["Class"] = "潜行者",
	}, -- [132]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "血精灵",
		["NameServer"] = "一颗豆奶-迅捷微风",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★★★",
		["PVPScore"] = 78.64137933306336,
		["Class"] = "术士",
	}, -- [133]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "徐阿飘-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 14.09839229877747,
		["Class"] = "潜行者",
	}, -- [134]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "Rocha-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 29.56075872096097,
		["Class"] = "潜行者",
	}, -- [135]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "一抹幽香-深渊之巢",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 10.85189415255382,
		["Class"] = "圣骑士",
	}, -- [136]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "幕人-加基森",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "恶魔猎手",
	}, -- [137]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "Aquin-燃烧之刃",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 47.40268708656008,
		["FactionGroup"] = "Horde",
	}, -- [138]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "地精",
		["NameServer"] = "仲尼不死-影之哀伤",
		["Faction"] = "部落",
		["Star"] = "战神",
		["Class"] = "牧师",
		["PVPScore"] = 81.87991384569314,
		["FactionGroup"] = "Horde",
	}, -- [139]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "夜之子",
		["NameServer"] = "含笑半步癫-狂热之刃",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "法师",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [140]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "兽人",
		["NameServer"] = "Nebulous-燃烧之刃",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "术士",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [141]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "骁星星-燃烧之刃",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 16.35410046606144,
		["FactionGroup"] = "Horde",
	}, -- [142]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "不落笙歌-燃烧之刃",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "牧师",
		["PVPScore"] = 15.4314715796269,
		["FactionGroup"] = "Horde",
	}, -- [143]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "巨魔",
		["NameServer"] = "风暴英雄总裁-死亡之翼",
		["Faction"] = "部落",
		["Star"] = "★★★★☆",
		["Class"] = "萨满祭司",
		["PVPScore"] = 67.21022077137508,
		["FactionGroup"] = "Horde",
	}, -- [144]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "玛格汉兽人",
		["NameServer"] = "大欣狗-风暴峭壁",
		["Faction"] = "部落",
		["Star"] = "★★★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 67.9373274692261,
		["FactionGroup"] = "Horde",
	}, -- [145]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "奔放德-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [146]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "长崎冇浅静-燃烧之刃",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "法师",
		["PVPScore"] = 5.835290733962402,
		["FactionGroup"] = "Horde",
	}, -- [147]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "罪恶伯爵-安苏",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "潜行者",
		["PVPScore"] = 18.00528165804877,
		["FactionGroup"] = "Alliance",
	}, -- [148]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "史蒂芬静雨-死亡之翼",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [149]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "Indigoblue-燃烧之刃",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "圣骑士",
		["PVPScore"] = 18.67158910623833,
		["FactionGroup"] = "Horde",
	}, -- [150]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "王老师-熔火之心",
		["Faction"] = "部落",
		["Star"] = "★★★☆",
		["Class"] = "法师",
		["PVPScore"] = 56.01070684888999,
		["FactionGroup"] = "Horde",
	}, -- [151]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "辛子逸-死亡之翼",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 5.382742330671084,
		["FactionGroup"] = "Horde",
	}, -- [152]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "狂暴小蚂蚁-海克泰尔",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "猎人",
		["PVPScore"] = 12.83965333351457,
		["FactionGroup"] = "Horde",
	}, -- [153]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "山的路-死亡之翼",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0.07633964463140128,
		["FactionGroup"] = "Horde",
	}, -- [154]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "淡淡丶月光-格瑞姆巴托",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "潜行者",
		["PVPScore"] = 11.42323984840041,
		["FactionGroup"] = "Horde",
	}, -- [155]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "乌漆嘛黑洲-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 3.711116331153649,
		["FactionGroup"] = "Horde",
	}, -- [156]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "Rolls-梅尔加尼",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "潜行者",
		["PVPScore"] = 14.81074068330285,
		["FactionGroup"] = "Horde",
	}, -- [157]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "舞铲阶级-玛洛加尔",
		["Faction"] = "部落",
		["Star"] = "★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 53.54823125947574,
		["FactionGroup"] = "Horde",
	}, -- [158]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "狼人",
		["NameServer"] = "转世的幽灵-破碎岭",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "德鲁伊",
		["PVPScore"] = 4.349596516012295,
		["Star"] = "☆",
	}, -- [159]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "兽人",
		["NameServer"] = "夯大锤丶-萨菲隆",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "死亡骑士",
		["PVPScore"] = 41.6001674877736,
		["Star"] = "★★☆",
	}, -- [160]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "丶糕富帥-无尽之海",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "圣骑士",
		["PVPScore"] = 45.24525159318699,
		["Star"] = "★★☆",
	}, -- [161]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "葬湮-迅捷微风",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "法师",
		["PVPScore"] = 49.61092376937593,
		["Star"] = "★★☆",
	}, -- [162]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "兽人",
		["NameServer"] = "有关部門-黑铁",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "死亡骑士",
		["PVPScore"] = 13.44522791650651,
		["Star"] = "★",
	}, -- [163]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "乄如烟灬-无尽之海",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 4.446536262519466,
		["Star"] = "☆",
	}, -- [164]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "止战祉殇-血环",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "战士",
		["PVPScore"] = 0,
		["Star"] = "?",
	}, -- [165]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "著名狠人-冰风岗",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "战士",
		["PVPScore"] = 17.28844782040642,
		["Star"] = "★",
	}, -- [166]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "保罗四千万-影之哀伤",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "德鲁伊",
		["PVPScore"] = 65.70164730430038,
		["Star"] = "★★★★☆",
	}, -- [167]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "五秒真男人-符文图腾",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "猎人",
		["PVPScore"] = 26.38917208301452,
		["Star"] = "★☆",
	}, -- [168]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "心塞的小胖-基尔罗格",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0,
		["Star"] = "?",
	}, -- [169]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "主教阿塔尼斯-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "圣骑士",
		["PVPScore"] = 0,
		["Star"] = "?",
	}, -- [170]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "迷人小虎牙-燃烧之刃",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "潜行者",
		["PVPScore"] = 48.50269552234489,
		["Star"] = "★★☆",
	}, -- [171]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "哥特送葬者-恶魔之魂",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "战士",
		["PVPScore"] = 3.76972865055122,
		["Star"] = "☆",
	}, -- [172]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "那货缺德-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "德鲁伊",
		["PVPScore"] = 2.548296296296296,
		["Star"] = "☆",
	}, -- [173]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "丶智-贫瘠之地",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "潜行者",
		["PVPScore"] = 0,
		["Star"] = "?",
	}, -- [174]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "圣光天降-伊莫塔尔",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "圣骑士",
		["PVPScore"] = 12.88110128844165,
		["Star"] = "★",
	}, -- [175]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "阿奎莱拉-冬泉谷",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "法师",
		["PVPScore"] = 26.45053701690809,
		["Star"] = "★☆",
	}, -- [176]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "兽人",
		["NameServer"] = "Unclez-无尽之海",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "法师",
		["PVPScore"] = 17.27093197013596,
		["Star"] = "★",
	}, -- [177]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "雾影药师-银松森林",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "法师",
		["PVPScore"] = 48.25304770503676,
		["Star"] = "★★☆",
	}, -- [178]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "牛头人",
		["NameServer"] = "啾啾少年-冰风岗",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "萨满祭司",
		["PVPScore"] = 49.28552797433834,
		["Star"] = "★★☆",
	}, -- [179]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "牛头人",
		["NameServer"] = "大地行者-神圣之歌",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "萨满祭司",
		["PVPScore"] = 0,
		["Star"] = "?",
	}, -- [180]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "染血黑兎-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "法师",
		["PVPScore"] = 37.51079640648653,
		["Star"] = "★★",
	}, -- [181]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "月盈则冲-塞拉摩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0.6418099795592845,
		["Star"] = "☆",
	}, -- [182]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "絕唱-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★☆",
		["PVPScore"] = 20.4573825575627,
		["FactionGroup"] = "Horde",
	}, -- [183]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "牛头人",
		["NameServer"] = "浑身都是棍儿-阿纳克洛斯",
		["Faction"] = "部落",
		["Class"] = "萨满祭司",
		["Star"] = "★★",
		["PVPScore"] = 30.28981463083849,
		["FactionGroup"] = "Horde",
	}, -- [184]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "兽人",
		["NameServer"] = "大圈圈大波浪-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "武僧",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [185]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "爱泼斯特-黑铁",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★★☆",
		["PVPScore"] = 41.30906232563432,
		["FactionGroup"] = "Horde",
	}, -- [186]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "东海小飞-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★★",
		["PVPScore"] = 39.66367664820274,
		["FactionGroup"] = "Horde",
	}, -- [187]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "美眉吥可以-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★☆",
		["PVPScore"] = 21.36145997430988,
		["FactionGroup"] = "Horde",
	}, -- [188]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "Reinhartdt-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★★★",
		["PVPScore"] = 52.46407095056667,
		["FactionGroup"] = "Horde",
	}, -- [189]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "玛格汉兽人",
		["NameServer"] = "天地人和-黑铁",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [190]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "巨魔",
		["NameServer"] = "化灭丶-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "猎人",
		["Star"] = "★★☆",
		["PVPScore"] = 46.33432714721788,
		["FactionGroup"] = "Horde",
	}, -- [191]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "文藤子美-无尽之海",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★★★",
		["PVPScore"] = 51.2251220629872,
		["FactionGroup"] = "Horde",
	}, -- [192]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "局长为你买单-布兰卡德",
		["Faction"] = "部落",
		["Class"] = "牧师",
		["Star"] = "★",
		["PVPScore"] = 14.52067350512325,
		["FactionGroup"] = "Horde",
	}, -- [193]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "秒到你吐血-布兰卡德",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★★☆",
		["PVPScore"] = 42.68859064208886,
		["FactionGroup"] = "Horde",
	}, -- [194]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "兽人",
		["NameServer"] = "正義的容嬷嬤-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "术士",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [195]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "呆呆的丨娅楠-伊莫塔尔",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "☆",
		["PVPScore"] = 0.6850893911718534,
		["FactionGroup"] = "Horde",
	}, -- [196]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "戒烟一年半了-无尽之海",
		["Faction"] = "部落",
		["Class"] = "萨满祭司",
		["Star"] = "☆",
		["PVPScore"] = 9.319481385691892,
		["FactionGroup"] = "Horde",
	}, -- [197]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "我滴个老天爷-安苏",
		["Faction"] = "部落",
		["Class"] = "牧师",
		["Star"] = "★",
		["PVPScore"] = 18.37928409130687,
		["FactionGroup"] = "Horde",
	}, -- [198]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "胖沫沫-深渊之喉",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★",
		["PVPScore"] = 10.69130258866687,
		["FactionGroup"] = "Horde",
	}, -- [199]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "牛头人",
		["NameServer"] = "不会喊火指挥-血环",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★★☆",
		["PVPScore"] = 44.57749278047758,
		["FactionGroup"] = "Horde",
	}, -- [200]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "萌澄澄-影之哀伤",
		["Faction"] = "部落",
		["Class"] = "死亡骑士",
		["Star"] = "★",
		["PVPScore"] = 17.05909794238683,
		["FactionGroup"] = "Horde",
	}, -- [201]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "灬兔子哥灬-海加尔",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [202]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "几乎没热量-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★★",
		["PVPScore"] = 32.29727357367978,
		["FactionGroup"] = "Horde",
	}, -- [203]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "非洲战-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★★☆",
		["PVPScore"] = 41.81758579098518,
		["FactionGroup"] = "Horde",
	}, -- [204]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "熊猫人",
		["NameServer"] = "洗脚城帮主-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "武僧",
		["Star"] = "★★",
		["PVPScore"] = 30.39083214910662,
		["FactionGroup"] = "Horde",
	}, -- [205]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "流泪的石榴-耐普图隆",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "☆",
		["PVPScore"] = 3.941814053166069,
		["FactionGroup"] = "Horde",
	}, -- [206]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "老舅-艾苏恩",
		["Faction"] = "联盟",
		["Class"] = "死亡骑士",
		["Star"] = "★★",
		["PVPScore"] = 38.40954964370098,
		["FactionGroup"] = "Alliance",
	}, -- [207]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "递延所得税-金色平原",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [208]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "熊猫人",
		["NameServer"] = "几点吃饭啊-影之哀伤",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "☆",
		["PVPScore"] = 0.001,
		["FactionGroup"] = "Horde",
	}, -- [209]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "死玉米-寒冰皇冠",
		["Faction"] = "部落",
		["Class"] = "牧师",
		["Star"] = "★★☆",
		["PVPScore"] = 41.20676196414747,
		["FactionGroup"] = "Horde",
	}, -- [210]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "狐人",
		["NameServer"] = "Renaissance-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "武僧",
		["Star"] = "★",
		["PVPScore"] = 15.22028693283082,
		["FactionGroup"] = "Horde",
	}, -- [211]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "七丨囍-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [212]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "骠骑大将军-暗影迷宫",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★☆",
		["PVPScore"] = 20.20666979724827,
		["FactionGroup"] = "Horde",
	}, -- [213]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "我打不中他啊-回音山",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★★",
		["PVPScore"] = 35.8608017235669,
		["FactionGroup"] = "Horde",
	}, -- [214]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "取不出-遗忘海岸",
		["Faction"] = "部落",
		["Class"] = "牧师",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [215]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "帮我做水果茶-死亡之翼",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★",
		["PVPScore"] = 17.00972880721138,
		["FactionGroup"] = "Horde",
	}, -- [216]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "巨魔",
		["NameServer"] = "失望的老大-死亡之翼",
		["Faction"] = "部落",
		["Class"] = "猎人",
		["Star"] = "★☆",
		["PVPScore"] = 29.25001326148255,
		["FactionGroup"] = "Horde",
	}, -- [217]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "陈天贵-索瑞森",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★",
		["PVPScore"] = 17.14958373614315,
		["FactionGroup"] = "Horde",
	}, -- [218]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "乐心-阿克蒙德",
		["Faction"] = "部落",
		["Class"] = "牧师",
		["Star"] = "★",
		["PVPScore"] = 12.31131972923632,
		["FactionGroup"] = "Horde",
	}, -- [219]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "冷血丶书生-无尽之海",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★★☆",
		["PVPScore"] = 47.02941614001921,
		["FactionGroup"] = "Horde",
	}, -- [220]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "玛格汉兽人",
		["NameServer"] = "却副手-黑铁",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★★",
		["PVPScore"] = 33.37521421370968,
		["FactionGroup"] = "Horde",
	}, -- [221]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "浮城旧世-狂热之刃",
		["Faction"] = "联盟",
		["Class"] = "猎人",
		["Star"] = "★★★★",
		["PVPScore"] = 63.54623536263508,
		["FactionGroup"] = "Alliance",
	}, -- [222]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "一疯扯扯一-伊森利恩",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★",
		["PVPScore"] = 11.42226960197072,
		["FactionGroup"] = "Horde",
	}, -- [223]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "魔法之魂-菲拉斯",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★☆",
		["PVPScore"] = 27.34816109610013,
		["FactionGroup"] = "Horde",
	}, -- [224]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "摩维-奎尔萨拉斯",
		["Faction"] = "部落",
		["Class"] = "死亡骑士",
		["Star"] = "★★★★",
		["PVPScore"] = 62.83904863127093,
		["FactionGroup"] = "Horde",
	}, -- [225]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "暖唇-天空之墙",
		["Faction"] = "部落",
		["Class"] = "牧师",
		["Star"] = "★",
		["PVPScore"] = 16.89333661826781,
		["FactionGroup"] = "Horde",
	}, -- [226]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "龙马的雅号-安纳塞隆",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★",
		["PVPScore"] = 11.29624239440016,
		["FactionGroup"] = "Horde",
	}, -- [227]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "背叛者氵-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [228]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "墙角一支牛-风暴之怒",
		["Faction"] = "部落",
		["Class"] = "德鲁伊",
		["Star"] = "★☆",
		["PVPScore"] = 27.80676962202472,
		["FactionGroup"] = "Horde",
	}, -- [229]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "Paladinlolz-死亡熔炉",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★★★☆",
		["PVPScore"] = 58.14883347479911,
		["FactionGroup"] = "Horde",
	}, -- [230]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "不吃小兔叽-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "★",
		["PVPScore"] = 12.46081938603753,
		["FactionGroup"] = "Horde",
	}, -- [231]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "惊魂-伊森利恩",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [232]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "天翼小雪-伊森利恩",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "★★★★★",
		["PVPScore"] = 72.44756858645414,
		["FactionGroup"] = "Horde",
	}, -- [233]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "Namily-海加尔",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "★",
		["PVPScore"] = 10.48337564473771,
		["FactionGroup"] = "Horde",
	}, -- [234]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "丶菊花开瓶盖-无尽之海",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★",
		["PVPScore"] = 17.12896422070987,
		["FactionGroup"] = "Horde",
	}, -- [235]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "惷三十娘-伊森利恩",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [236]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "偏要与天抗-荆棘谷",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "☆",
		["PVPScore"] = 0.001,
		["FactionGroup"] = "Alliance",
	}, -- [237]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "夜之子",
		["NameServer"] = "荷光者梵蒂-安苏",
		["Faction"] = "部落",
		["Class"] = "牧师",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [238]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "兽人",
		["NameServer"] = "性感的芬迪-伊森利恩",
		["Faction"] = "部落",
		["Class"] = "武僧",
		["Star"] = "★★★☆",
		["PVPScore"] = 58.96858142362356,
		["FactionGroup"] = "Horde",
	}, -- [239]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "地精",
		["NameServer"] = "Savarin-加基森",
		["Faction"] = "部落",
		["Class"] = "牧师",
		["Star"] = "★★★★☆",
		["PVPScore"] = 65.12271413125093,
		["FactionGroup"] = "Horde",
	}, -- [240]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "徐福贵-阿比迪斯",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★★★",
		["PVPScore"] = 52.33068573120892,
		["FactionGroup"] = "Horde",
	}, -- [241]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "疯少-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★★",
		["PVPScore"] = 32.6091395190378,
		["FactionGroup"] = "Horde",
	}, -- [242]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "风云灬-安苏",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★★",
		["PVPScore"] = 34.33806403254736,
		["FactionGroup"] = "Horde",
	}, -- [243]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "傳説中的噔噔-加基森",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★☆",
		["PVPScore"] = 22.42890030093184,
		["FactionGroup"] = "Horde",
	}, -- [244]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "玛格汉兽人",
		["NameServer"] = "神王丨血吼-安苏",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★☆",
		["PVPScore"] = 26.30957892106644,
		["FactionGroup"] = "Horde",
	}, -- [245]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "彩云倾城-海达希亚",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "☆",
		["PVPScore"] = 0.4058429325082482,
		["FactionGroup"] = "Horde",
	}, -- [246]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "Aldur-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "德鲁伊",
		["Star"] = "★★☆",
		["PVPScore"] = 49.34387181723124,
		["FactionGroup"] = "Horde",
	}, -- [247]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "Monseer-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "☆",
		["PVPScore"] = 6.908726040926173,
		["FactionGroup"] = "Horde",
	}, -- [248]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "晓依轩-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "★☆",
		["PVPScore"] = 24.70679018151039,
		["FactionGroup"] = "Horde",
	}, -- [249]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "牛头人",
		["NameServer"] = "冲锋去世-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★★☆",
		["PVPScore"] = 41.7336055166735,
		["FactionGroup"] = "Horde",
	}, -- [250]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "血精灵",
		["NameServer"] = "旋律欧皇-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "☆",
		["PVPScore"] = 6.089793019205352,
		["FactionGroup"] = "Horde",
	}, -- [251]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "血精灵",
		["NameServer"] = "浮生丨未醉-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "武僧",
		["Star"] = "★",
		["PVPScore"] = 12.02072768278936,
		["FactionGroup"] = "Horde",
	}, -- [252]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "依柔-安苏",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★☆",
		["PVPScore"] = 21.60895454661047,
		["FactionGroup"] = "Horde",
	}, -- [253]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "小生空虚-风暴之鳞",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★★★☆",
		["PVPScore"] = 57.63938847885903,
		["FactionGroup"] = "Horde",
	}, -- [254]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "兽人",
		["NameServer"] = "水嫩净白晶华-安苏",
		["Faction"] = "部落",
		["Class"] = "术士",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [255]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "火锅味儿的-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "武僧",
		["Star"] = "☆",
		["PVPScore"] = 6.242570339494126,
		["FactionGroup"] = "Horde",
	}, -- [256]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "装备是我爹-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "★",
		["PVPScore"] = 14.50131477965291,
		["FactionGroup"] = "Horde",
	}, -- [257]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "Supersos-伊森利恩",
		["Faction"] = "部落",
		["Class"] = "术士",
		["Star"] = "★★★",
		["PVPScore"] = 53.67501550615391,
		["FactionGroup"] = "Horde",
	}, -- [258]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "犀利老牛-海克泰尔",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★★",
		["PVPScore"] = 30.45827167642581,
		["FactionGroup"] = "Horde",
	}, -- [259]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "月曦言-黑暗之矛",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★☆",
		["PVPScore"] = 20.14367793055104,
		["FactionGroup"] = "Horde",
	}, -- [260]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "冰封之焰-斩魔者",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★★",
		["PVPScore"] = 38.5015365669511,
		["FactionGroup"] = "Horde",
	}, -- [261]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "智障先锋-天空之墙",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "★☆",
		["PVPScore"] = 25.78690089758845,
		["FactionGroup"] = "Horde",
	}, -- [262]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "伊利蛋怒風-伊森利恩",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "★",
		["PVPScore"] = 13.58256650334092,
		["FactionGroup"] = "Horde",
	}, -- [263]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "亡灵",
		["NameServer"] = "灰烬灵使者-安苏",
		["Faction"] = "部落",
		["Class"] = "猎人",
		["Star"] = "★",
		["PVPScore"] = 18.86342887646757,
		["FactionGroup"] = "Horde",
	}, -- [264]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "牛头人",
		["NameServer"] = "敖鲁古雅-卡拉赞",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★★☆",
		["PVPScore"] = 48.70379635395513,
		["FactionGroup"] = "Horde",
	}, -- [265]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "茅厕咆哮-无尽之海",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "☆",
		["PVPScore"] = 2.64629670781893,
		["FactionGroup"] = "Horde",
	}, -- [266]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "巨魔",
		["NameServer"] = "晓风残月-达斯雷玛",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "☆",
		["PVPScore"] = 7.233011777658644,
		["FactionGroup"] = "Horde",
	}, -- [267]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "一枝红玫瑰-安苏",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★★",
		["PVPScore"] = 38.908616936163,
		["FactionGroup"] = "Horde",
	}, -- [268]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "牛头人",
		["NameServer"] = "丶阿当睡大覚-安苏",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [269]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "血之教父-安苏",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★",
		["PVPScore"] = 11.77963693011335,
		["FactionGroup"] = "Horde",
	}, -- [270]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "台灣爛香蕉-丹莫德",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "★★",
		["PVPScore"] = 37.18206132950946,
		["FactionGroup"] = "Horde",
	}, -- [271]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "兽人",
		["NameServer"] = "差点看破红尘-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★",
		["PVPScore"] = 17.84044251135855,
		["FactionGroup"] = "Horde",
	}, -- [272]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "杀光为止-拉文凯斯",
		["Faction"] = "联盟",
		["Class"] = "圣骑士",
		["Star"] = "★",
		["PVPScore"] = 14.70336444997787,
		["FactionGroup"] = "Alliance",
	}, -- [273]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "暗夜之星海-银松森林",
		["Faction"] = "联盟",
		["Class"] = "圣骑士",
		["Star"] = "★★",
		["PVPScore"] = 38.58409491409593,
		["FactionGroup"] = "Alliance",
	}, -- [274]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "Marlbora-范达尔鹿盔",
		["Faction"] = "联盟",
		["Class"] = "法师",
		["Star"] = "☆",
		["PVPScore"] = 0.7933621094345369,
		["FactionGroup"] = "Alliance",
	}, -- [275]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "乌瑟尔-伊萨里奥斯",
		["Faction"] = "联盟",
		["Class"] = "圣骑士",
		["Star"] = "★",
		["PVPScore"] = 14.68509760143014,
		["FactionGroup"] = "Alliance",
	}, -- [276]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "风飘溢-末日行者",
		["Faction"] = "联盟",
		["Class"] = "圣骑士",
		["Star"] = "★",
		["PVPScore"] = 17.18685520665538,
		["FactionGroup"] = "Alliance",
	}, -- [277]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "人类",
		["NameServer"] = "苍白之主-末日行者",
		["Faction"] = "联盟",
		["Class"] = "死亡骑士",
		["Star"] = "★",
		["PVPScore"] = 17.79768257514938,
		["FactionGroup"] = "Alliance",
	}, -- [278]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "哒嘻姬-范达尔鹿盔",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "★",
		["PVPScore"] = 18.38765744453452,
		["FactionGroup"] = "Alliance",
	}, -- [279]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "月影灵心-暗影之月",
		["Faction"] = "联盟",
		["Class"] = "圣骑士",
		["Star"] = "★★☆",
		["PVPScore"] = 42.80491951588854,
		["FactionGroup"] = "Alliance",
	}, -- [280]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "时有小丨泉-耳语海岸",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "☆",
		["PVPScore"] = 0.145484205735093,
		["FactionGroup"] = "Alliance",
	}, -- [281]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "兽人",
		["NameServer"] = "Fiercefists-燃烧之刃",
		["Faction"] = "联盟",
		["Class"] = "武僧",
		["Star"] = "★",
		["PVPScore"] = 17.21335339913606,
		["FactionGroup"] = "Alliance",
	}, -- [282]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "和雨水一样冰-白银之手",
		["Faction"] = "联盟",
		["Class"] = "恶魔猎手",
		["Star"] = "★",
		["PVPScore"] = 16.93435798105827,
		["FactionGroup"] = "Alliance",
	}, -- [283]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "战死为荣-末日行者",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "★☆",
		["PVPScore"] = 26.91882508746626,
		["FactionGroup"] = "Alliance",
	}, -- [284]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "酒醉三分-加基森",
		["Faction"] = "联盟",
		["Class"] = "恶魔猎手",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [285]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "德莱尼",
		["NameServer"] = "江海起波涛-丽丽（四川）",
		["Faction"] = "联盟",
		["Class"] = "萨满祭司",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [286]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "多啦的口袋-白银之手",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "★★☆",
		["PVPScore"] = 44.95855205561183,
		["FactionGroup"] = "Alliance",
	}, -- [287]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "月丶刹-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "★★★★★",
		["PVPScore"] = 76.5063669634559,
		["FactionGroup"] = "Alliance",
	}, -- [288]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "熊猫人",
		["NameServer"] = "沐小福-萨菲隆",
		["Faction"] = "联盟",
		["Class"] = "萨满祭司",
		["Star"] = "★☆",
		["PVPScore"] = 29.36313654576933,
		["FactionGroup"] = "Alliance",
	}, -- [289]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "品錵人-石锤",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "★★☆",
		["PVPScore"] = 48.15919150034092,
		["FactionGroup"] = "Alliance",
	}, -- [290]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "狐人",
		["NameServer"] = "逝水無痕丶-无尽之海",
		["Faction"] = "部落",
		["Class"] = "术士",
		["Star"] = "☆",
		["PVPScore"] = 4.449608674812708,
		["FactionGroup"] = "Horde",
	}, -- [291]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "萌萌的薇拉-伊瑟拉",
		["Faction"] = "联盟",
		["Class"] = "猎人",
		["Star"] = "★★☆",
		["PVPScore"] = 49.72615303779143,
		["FactionGroup"] = "Alliance",
	}, -- [292]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Ansen-雷斧堡垒",
		["Faction"] = "联盟",
		["Class"] = "潜行者",
		["Star"] = "★★★★",
		["PVPScore"] = 60.56843899250183,
		["FactionGroup"] = "Alliance",
	}, -- [293]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "熊猫人",
		["NameServer"] = "Mmhapiness-死亡之翼",
		["Faction"] = "部落",
		["Class"] = "武僧",
		["Star"] = "★",
		["PVPScore"] = 13.5650357403033,
		["FactionGroup"] = "Horde",
	}, -- [294]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "糖果熊-国王之谷",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [295]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "娴熟的冰法-暗影之月",
		["Faction"] = "联盟",
		["Class"] = "法师",
		["Star"] = "★",
		["PVPScore"] = 12.30236156487523,
		["FactionGroup"] = "Alliance",
	}, -- [296]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "花酿果酒-熊猫酒仙",
		["Faction"] = "联盟",
		["Class"] = "法师",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [297]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "纠结一生-石锤",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "☆",
		["PVPScore"] = 0.6828407273014434,
		["FactionGroup"] = "Alliance",
	}, -- [298]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "伊丁-安苏",
		["Faction"] = "联盟",
		["Class"] = "潜行者",
		["Star"] = "☆",
		["PVPScore"] = 2.215712919758909,
		["FactionGroup"] = "Alliance",
	}, -- [299]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "矮人",
		["NameServer"] = "黢黑大力士-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "圣骑士",
		["Star"] = "☆",
		["PVPScore"] = 7.565642173824545,
		["FactionGroup"] = "Alliance",
	}, -- [300]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "二挡八千转-苏塔恩",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [301]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "那个少年-末日行者",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "★★★★☆",
		["PVPScore"] = 65.34243973395589,
		["FactionGroup"] = "Alliance",
	}, -- [302]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "马哥你好-尘风峡谷",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★",
		["PVPScore"] = 13.5909062028925,
		["FactionGroup"] = "Horde",
	}, -- [303]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "平原君-深渊之巢",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 0.0002,
		["Class"] = "德鲁伊",
	}, -- [304]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "侏儒",
		["NameServer"] = "宁馨儿-银松森林",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 3.238762441700961,
		["Class"] = "法师",
	}, -- [305]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "黑铁矮人",
		["NameServer"] = "香烟配酒-暗影之月",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "法师",
	}, -- [306]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Hamburger-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "恶魔猎手",
	}, -- [307]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "德莱尼",
		["NameServer"] = "白发麻花人-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "圣骑士",
	}, -- [308]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "喵喵耶-铜龙军团",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 26.51976611192794,
		["Class"] = "圣骑士",
	}, -- [309]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "人类",
		["NameServer"] = "令君-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "武僧",
	}, -- [310]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "机械侏儒",
		["NameServer"] = "落花无意丶-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "武僧",
	}, -- [311]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "逢人砍一刀-奥特兰克",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "恶魔猎手",
	}, -- [312]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "蜜西卡-影之哀伤",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 13.77000675654068,
		["Class"] = "法师",
	}, -- [313]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "Exix-提尔之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "圣骑士",
	}, -- [314]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "狼人",
		["NameServer"] = "内鲁基伽特-霜之哀伤",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "死亡骑士",
	}, -- [315]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "不要擀就是怂-冰风岗",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 25.99080327030256,
		["Class"] = "法师",
	}, -- [316]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "調理農務系-迦拉克隆",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 18.42884464704514,
		["Class"] = "法师",
	}, -- [317]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "温暖的火-无尽之海",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★★★",
		["PVPScore"] = 78.23699207661443,
		["Class"] = "圣骑士",
	}, -- [318]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "侏儒",
		["NameServer"] = "默默无蚊-冬拥湖",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "术士",
	}, -- [319]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "堕落的德沃斯-破碎岭",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 1.648018161242791,
		["Class"] = "恶魔猎手",
	}, -- [320]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "闪闪閃-贫瘠之地",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 46.00871935126936,
		["Class"] = "德鲁伊",
	}, -- [321]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Vcancev-风暴峭壁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 46.45985952614184,
		["Class"] = "猎人",
	}, -- [322]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "库库林灬白夜-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 26.79699066833391,
		["Class"] = "圣骑士",
	}, -- [323]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "夏域-石锤",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 12.18314362428326,
		["Class"] = "猎人",
	}, -- [324]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "虚空精灵",
		["NameServer"] = "秋水矶边落雁-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "武僧",
	}, -- [325]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "特斯拉-熊猫酒仙",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "萨满祭司",
	}, -- [326]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "柚叶-埃加洛尔",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 28.23386755955987,
		["Class"] = "法师",
	}, -- [327]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "巨魔",
		["NameServer"] = "毕摩-闪电之刃",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 4.955621063660031,
		["Class"] = "萨满祭司",
	}, -- [328]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "板扎哥-凤凰之神",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 14.55826062824018,
		["Class"] = "圣骑士",
	}, -- [329]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "丶醉枫染墨-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 9.777967303268445,
		["Class"] = "法师",
	}, -- [330]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "德莱尼",
		["NameServer"] = "好多葡萄-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★",
		["PVPScore"] = 51.70960251173912,
		["Class"] = "萨满祭司",
	}, -- [331]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "矮人",
		["NameServer"] = "天雪有痕-艾萨拉",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 13.70903377868829,
		["Class"] = "牧师",
	}, -- [332]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "再次爱-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 2.867721053272244,
		["Class"] = "德鲁伊",
	}, -- [333]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "我侧卧后-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.9476566491359882,
		["Class"] = "法师",
	}, -- [334]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "洛恩-拉文凯斯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "猎人",
	}, -- [335]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "狼人",
		["NameServer"] = "playerlxybxm-萨菲隆",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 10.71218770355938,
		["Class"] = "德鲁伊",
	}, -- [336]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "胸大的先死-甜水绿洲",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 31.78563899577125,
		["Class"] = "恶魔猎手",
	}, -- [337]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "虚空精灵",
		["NameServer"] = "卖火柴的玲-白银之手",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 36.20825082238138,
		["Class"] = "牧师",
	}, -- [338]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "牛头人",
		["NameServer"] = "建党一百年-死亡之翼",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 24.26199532966859,
		["Class"] = "战士",
	}, -- [339]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "曖昧易碎-罗宁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 22.31947861467886,
		["Class"] = "德鲁伊",
	}, -- [340]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "橙州甩棍熊检-暗影之月",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.001,
		["Class"] = "武僧",
	}, -- [341]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "百里屠苏-索拉丁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "?",
		["PVPScore"] = 0,
		["Class"] = "德鲁伊",
	}, -- [342]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "黑火-奥拉基尔",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 28.92936891329762,
		["Class"] = "法师",
	}, -- [343]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "风暴霜刃-国王之谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.0012,
		["Class"] = "法师",
	}, -- [344]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "狼人",
		["NameServer"] = "咕噜颂-萨洛拉丝",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 31.10527834845372,
		["Class"] = "潜行者",
	}, -- [345]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "白云娇霜-蜘蛛王国",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 33.9874176539919,
		["Class"] = "圣骑士",
	}, -- [346]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "非酋退散-深渊之巢",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 4.718700611156715,
		["Class"] = "恶魔猎手",
	}, -- [347]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "兽人",
		["NameServer"] = "恶靈骑士-安苏",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★★★",
		["PVPScore"] = 62.59772765710867,
		["Class"] = "死亡骑士",
	}, -- [348]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "机械侏儒",
		["NameServer"] = "超新萌宠-无尽之海",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 3.633552606818573,
		["Class"] = "潜行者",
	}, -- [349]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "人类",
		["NameServer"] = "血狼乂幽冥-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.0002,
		["Class"] = "死亡骑士",
	}, -- [350]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "小扇扑流萤-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★★",
		["PVPScore"] = 37.89958083283639,
		["Class"] = "牧师",
	}, -- [351]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "熊猫人",
		["NameServer"] = "李琏杰-伊利丹",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "☆",
		["PVPScore"] = 0.07633964463140128,
		["Class"] = "武僧",
	}, -- [352]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "冰镇茉莉清茶-贫瘠之地",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 16.57806404922351,
		["Class"] = "恶魔猎手",
	}, -- [353]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "神丶盖娅-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "☆",
		["PVPScore"] = 0.145484205735093,
		["Class"] = "德鲁伊",
	}, -- [354]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "虚空精灵",
		["NameServer"] = "寻影-天空之墙",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 36.78255526451837,
		["Class"] = "猎人",
	}, -- [355]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "虚空精灵",
		["NameServer"] = "君莫笑丶-破碎岭",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 22.33154295168704,
		["Class"] = "死亡骑士",
	}, -- [356]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "别问问就自閉-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 28.74483735611365,
		["Class"] = "法师",
	}, -- [357]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "乖丨腿分开-荆棘谷",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★★",
		["PVPScore"] = 52.17441110028223,
		["Class"] = "战士",
	}, -- [358]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "張彡丰-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 48.54415916248391,
		["Class"] = "武僧",
	}, -- [359]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "兽人",
		["NameServer"] = "恶魔丶深渊-安苏",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 17.47646622927715,
		["Class"] = "术士",
	}, -- [360]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "黑铁矮人",
		["NameServer"] = "黑加吉红娃-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 13.12955294327714,
		["Class"] = "圣骑士",
	}, -- [361]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "阿尼维尔-扎拉赞恩",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 15.2344752624515,
		["Class"] = "法师",
	}, -- [362]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "黑铁矮人",
		["NameServer"] = "playerxebyhu-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★☆",
		["PVPScore"] = 29.04226443083129,
		["Class"] = "圣骑士",
	}, -- [363]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "Rayjask-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 40.2164887767135,
		["Class"] = "战士",
	}, -- [364]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "哎哟喂灬-末日行者",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 17.1577435304168,
		["Class"] = "恶魔猎手",
	}, -- [365]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "欧汶-祖阿曼",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★",
		["PVPScore"] = 39.81769805573492,
		["Class"] = "猎人",
	}, -- [366]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "侏儒",
		["NameServer"] = "一好汉一-伊萨里奥斯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★★☆",
		["PVPScore"] = 43.3081402519998,
		["Class"] = "潜行者",
	}, -- [367]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "战斗鸡-祖阿曼",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 15.03022648028211,
		["Class"] = "德鲁伊",
	}, -- [368]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "背后的爷-拉文凯斯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 14.55418933748871,
		["Class"] = "潜行者",
	}, -- [369]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "灬乂木乂灬-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Star"] = "★",
		["PVPScore"] = 16.06061932535224,
		["Class"] = "恶魔猎手",
	}, -- [370]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "兀木速台-凤凰之神",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 12.69705062783042,
		["Class"] = "牧师",
	}, -- [371]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "兽人",
		["NameServer"] = "查理-无尽之海",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "术士",
		["PVPScore"] = 46.03193817138776,
		["FactionGroup"] = "Horde",
	}, -- [372]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "温柔情伤-石锤",
		["Faction"] = "联盟",
		["Star"] = "★★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 64.14675504595078,
		["FactionGroup"] = "Alliance",
	}, -- [373]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "浪漫一生-奥特兰克",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 33.78317307208554,
		["FactionGroup"] = "Alliance",
	}, -- [374]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "人类",
		["NameServer"] = "柯南死神-奥蕾莉亚",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 20.50547837869616,
		["FactionGroup"] = "Alliance",
	}, -- [375]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "暗夜精灵",
		["NameServer"] = "邪恶战神-奥特兰克",
		["Faction"] = "联盟",
		["Star"] = "★★★",
		["Class"] = "死亡骑士",
		["PVPScore"] = 50.99949904267179,
		["FactionGroup"] = "Alliance",
	}, -- [376]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "淮泗村-迅捷微风",
		["Faction"] = "联盟",
		["Star"] = "★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 53.09071828802428,
		["FactionGroup"] = "Alliance",
	}, -- [377]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "黑铁矮人",
		["NameServer"] = "狱血狂斩-白银之手",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 48.47261650372855,
		["FactionGroup"] = "Alliance",
	}, -- [378]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "虚空精灵",
		["NameServer"] = "郭小乐-白银之手",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "牧师",
		["PVPScore"] = 5.474811373824935,
		["FactionGroup"] = "Alliance",
	}, -- [379]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "黑铁矮人",
		["NameServer"] = "嚼完松-白银之手",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "潜行者",
		["PVPScore"] = 8.162230878678985,
		["FactionGroup"] = "Alliance",
	}, -- [380]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "虚空精灵",
		["NameServer"] = "月亮和普安村-末日行者",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "术士",
		["PVPScore"] = 18.29166793796315,
		["FactionGroup"] = "Alliance",
	}, -- [381]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "虚空精灵",
		["NameServer"] = "泫乄燃-奥特兰克",
		["Faction"] = "联盟",
		["Star"] = "★★★",
		["Class"] = "术士",
		["PVPScore"] = 51.2767816762543,
		["FactionGroup"] = "Alliance",
	}, -- [382]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "娜娜虾-鹰巢山",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "猎人",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [383]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "餵小飽-燃烧之刃",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "猎人",
		["PVPScore"] = 43.12240615255946,
		["FactionGroup"] = "Alliance",
	}, -- [384]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "百分之十元钱-熵魔",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "圣骑士",
		["PVPScore"] = 13.73058130022344,
		["FactionGroup"] = "Alliance",
	}, -- [385]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "苏通大桥-奥特兰克",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "牧师",
		["PVPScore"] = 25.26462584789744,
		["FactionGroup"] = "Alliance",
	}, -- [386]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "Cge-死亡之翼",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 40.01754001963113,
		["FactionGroup"] = "Horde",
	}, -- [387]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "狼人",
		["NameServer"] = "阿达克什-霍格",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "潜行者",
		["PVPScore"] = 12.79478890391065,
		["FactionGroup"] = "Alliance",
	}, -- [388]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "矮人",
		["NameServer"] = "土鳖-末日行者",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "萨满祭司",
		["PVPScore"] = 45.68794396347056,
		["FactionGroup"] = "Alliance",
	}, -- [389]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "龍叔-安苏",
		["Faction"] = "联盟",
		["Star"] = "★★★★",
		["Class"] = "死亡骑士",
		["PVPScore"] = 63.10728147540354,
		["FactionGroup"] = "Alliance",
	}, -- [390]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "四月-阿比迪斯",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 43.22659094263163,
		["FactionGroup"] = "Alliance",
	}, -- [391]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "丶銀蛊-安苏",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "法师",
		["PVPScore"] = 30.19830330902665,
		["FactionGroup"] = "Alliance",
	}, -- [392]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "丧钟长鸣-迅捷微风",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "潜行者",
		["PVPScore"] = 39.99967733975907,
		["FactionGroup"] = "Alliance",
	}, -- [393]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "秋季丶-无尽之海",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 35.01057553195184,
		["FactionGroup"] = "Alliance",
	}, -- [394]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "黑铁矮人",
		["NameServer"] = "黯然销魂-黄金之路",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "潜行者",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [395]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "圣光晨晓-金色平原",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 0.4087234276180688,
		["FactionGroup"] = "Alliance",
	}, -- [396]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "遁世浮屠-凤凰之神",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 39.18583156636767,
		["FactionGroup"] = "Alliance",
	}, -- [397]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "沐云逐风-凤凰之神",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 0.07633964463140128,
		["FactionGroup"] = "Alliance",
	}, -- [398]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "折腾王子-伊萨里奥斯",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "法师",
		["PVPScore"] = 42.0341521173925,
		["FactionGroup"] = "Alliance",
	}, -- [399]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "狐人",
		["NameServer"] = "咕噜灵波丶-巨龙之吼",
		["Faction"] = "联盟",
		["Class"] = "萨满祭司",
		["Star"] = "★",
		["PVPScore"] = 12.13255040307441,
		["FactionGroup"] = "Alliance",
	}, -- [400]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "扌戈歹匕-亚雷戈斯",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "☆",
		["PVPScore"] = 3.176891696068549,
		["FactionGroup"] = "Horde",
	}, -- [401]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "人类",
		["NameServer"] = "不死幽灵-诺森德",
		["Faction"] = "联盟",
		["Class"] = "死亡骑士",
		["Star"] = "★☆",
		["PVPScore"] = 27.78024980638707,
		["FactionGroup"] = "Alliance",
	}, -- [402]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "毒瘤毒瘤-白银之手",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "★★★☆",
		["PVPScore"] = 56.1588645567856,
		["FactionGroup"] = "Alliance",
	}, -- [403]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "俗雅指间-雷斧堡垒",
		["Faction"] = "联盟",
		["Class"] = "法师",
		["Star"] = "★★",
		["PVPScore"] = 32.81322717160828,
		["FactionGroup"] = "Alliance",
	}, -- [404]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "Sunjj-血色十字军",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "★★☆",
		["PVPScore"] = 42.17139269459631,
		["FactionGroup"] = "Alliance",
	}, -- [405]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "侏儒",
		["NameServer"] = "Xmars-国王之谷",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "☆",
		["PVPScore"] = 0.0008,
		["FactionGroup"] = "Alliance",
	}, -- [406]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "江白夜-基尔加丹",
		["Faction"] = "联盟",
		["Class"] = "猎人",
		["Star"] = "☆",
		["PVPScore"] = 3.229782925443098,
		["FactionGroup"] = "Alliance",
	}, -- [407]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "小独独-贫瘠之地",
		["Faction"] = "联盟",
		["Class"] = "猎人",
		["Star"] = "★★★★☆",
		["PVPScore"] = 67.89794756243377,
		["FactionGroup"] = "Alliance",
	}, -- [408]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "狼人",
		["NameServer"] = "法瓦罗-罗宁",
		["Faction"] = "联盟",
		["Class"] = "潜行者",
		["Star"] = "☆",
		["PVPScore"] = 7.016950278862771,
		["FactionGroup"] = "Alliance",
	}, -- [409]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "晨曦丶幽冥-罗宁",
		["Faction"] = "联盟",
		["Class"] = "圣骑士",
		["Star"] = "★★★★",
		["PVPScore"] = 64.10241288627596,
		["FactionGroup"] = "Alliance",
	}, -- [410]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "亡灵",
		["NameServer"] = "Zippo-大地之怒",
		["Faction"] = "联盟",
		["Class"] = "法师",
		["Star"] = "★★",
		["PVPScore"] = 32.63993378390229,
		["FactionGroup"] = "Alliance",
	}, -- [411]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "烨神-破碎岭",
		["Faction"] = "联盟",
		["Class"] = "恶魔猎手",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [412]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "雾漫北路-黑铁",
		["Faction"] = "联盟",
		["Class"] = "猎人",
		["Star"] = "★",
		["PVPScore"] = 14.98029289414178,
		["FactionGroup"] = "Alliance",
	}, -- [413]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "亦儒-暗影之月",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "★★★",
		["PVPScore"] = 51.80280165227124,
		["FactionGroup"] = "Alliance",
	}, -- [414]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "夜之子",
		["NameServer"] = "拖延症-日落沼泽",
		["Faction"] = "联盟",
		["Class"] = "法师",
		["Star"] = "★☆",
		["PVPScore"] = 26.19127469922248,
		["FactionGroup"] = "Alliance",
	}, -- [415]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "人类",
		["NameServer"] = "流光舞汐尘-末日行者",
		["Faction"] = "联盟",
		["Class"] = "死亡骑士",
		["Star"] = "战神",
		["PVPScore"] = 81.91741256841743,
		["FactionGroup"] = "Alliance",
	}, -- [416]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "江米小金枣-迅捷微风",
		["Faction"] = "联盟",
		["Class"] = "圣骑士",
		["Star"] = "★★★",
		["PVPScore"] = 54.32109784623584,
		["FactionGroup"] = "Alliance",
	}, -- [417]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Lelee-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "法师",
		["Star"] = "★",
		["PVPScore"] = 10.85189415255382,
		["FactionGroup"] = "Alliance",
	}, -- [418]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "暗夜精灵",
		["NameServer"] = "匪席何卷-黑铁",
		["Faction"] = "联盟",
		["Class"] = "牧师",
		["Star"] = "★★",
		["PVPScore"] = 34.70465175450743,
		["FactionGroup"] = "Alliance",
	}, -- [419]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "亡灵",
		["NameServer"] = "Arkham-闪电之刃",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "★★★★",
		["PVPScore"] = 60.07837916171603,
		["FactionGroup"] = "Alliance",
	}, -- [420]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "战狼之老大-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "德鲁伊",
		["Star"] = "★☆",
		["PVPScore"] = 20.59525176961686,
		["FactionGroup"] = "Alliance",
	}, -- [421]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "德莱尼",
		["NameServer"] = "黑翼风暴-白银之手",
		["Faction"] = "联盟",
		["Class"] = "萨满祭司",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [422]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "黑铁矮人",
		["NameServer"] = "丨矮大紧丨-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "萨满祭司",
		["Star"] = "★☆",
		["PVPScore"] = 29.54497581284668,
		["FactionGroup"] = "Alliance",
	}, -- [423]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "神醫喜來樂-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "圣骑士",
		["Star"] = "★☆",
		["PVPScore"] = 29.4616527703372,
		["FactionGroup"] = "Alliance",
	}, -- [424]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "血饮灼燃-希尔瓦娜斯",
		["Faction"] = "部落",
		["Class"] = "术士",
		["Star"] = "★★★★",
		["PVPScore"] = 61.57564303331876,
		["FactionGroup"] = "Horde",
	}, -- [425]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "暴龍哥-安苏",
		["Faction"] = "联盟",
		["Class"] = "猎人",
		["Star"] = "★",
		["PVPScore"] = 18.49943421191857,
		["FactionGroup"] = "Alliance",
	}, -- [426]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "狼人",
		["NameServer"] = "丶戦狼-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "☆",
		["PVPScore"] = 5.370255391568435,
		["FactionGroup"] = "Alliance",
	}, -- [427]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "Littlefreyja-克尔苏加德",
		["Faction"] = "联盟",
		["Class"] = "死亡骑士",
		["Star"] = "★★",
		["PVPScore"] = 35.29659299435335,
		["FactionGroup"] = "Alliance",
	}, -- [428]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "嘻了马哈丶-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "☆",
		["PVPScore"] = 0.145484205735093,
		["FactionGroup"] = "Alliance",
	}, -- [429]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "本心丶-迦拉克隆",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "☆",
		["PVPScore"] = 0.0004,
		["FactionGroup"] = "Alliance",
	}, -- [430]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "德莱尼",
		["NameServer"] = "肥肠芋儿鸡-熊猫酒仙",
		["Faction"] = "联盟",
		["Class"] = "萨满祭司",
		["Star"] = "☆",
		["PVPScore"] = 8.968632311067093,
		["FactionGroup"] = "Alliance",
	}, -- [431]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "夏诺亚-布兰卡德",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 4.189317590150504,
		["FactionGroup"] = "Horde",
	}, -- [432]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "兽人",
		["NameServer"] = "吳彥祖丶-安苏",
		["Faction"] = "部落",
		["Star"] = "?",
		["Class"] = "术士",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [433]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "Darkbabtong-无尽之海",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 75.61378023038631,
		["FactionGroup"] = "Horde",
	}, -- [434]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "奥妮倾城-主宰之剑",
		["Faction"] = "部落",
		["Star"] = "★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 54.45378296810279,
		["FactionGroup"] = "Horde",
	}, -- [435]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "号角-巫妖之王",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 2.154003382058438,
		["FactionGroup"] = "Horde",
	}, -- [436]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "妈妈快救我-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "★★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 50.10664250705616,
		["FactionGroup"] = "Horde",
	}, -- [437]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "桂花載酒-布兰卡德",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "法师",
		["PVPScore"] = 0.2244593066791955,
		["FactionGroup"] = "Horde",
	}, -- [438]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "河南吴京-迅捷微风",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 0.8338094278180117,
		["FactionGroup"] = "Alliance",
	}, -- [439]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "侏儒",
		["NameServer"] = "小裤衩儿-影牙要塞",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "牧师",
		["PVPScore"] = 12.4077972069599,
		["FactionGroup"] = "Alliance",
	}, -- [440]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "虚无名-末日行者",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "牧师",
		["PVPScore"] = 16.84642246517735,
		["FactionGroup"] = "Alliance",
	}, -- [441]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "风筝特工队-末日行者",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "猎人",
		["PVPScore"] = 6.479721779413668,
		["FactionGroup"] = "Alliance",
	}, -- [442]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "秋实亦若欣-玛诺洛斯",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "法师",
		["PVPScore"] = 3.623260220826356,
		["FactionGroup"] = "Alliance",
	}, -- [443]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "熊猫人",
		["NameServer"] = "巭大师-血牙魔王",
		["Faction"] = "联盟",
		["Star"] = "★★★",
		["Class"] = "武僧",
		["PVPScore"] = 50.61230416686075,
		["FactionGroup"] = "Alliance",
	}, -- [444]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "Terminal-末日行者",
		["Faction"] = "联盟",
		["Star"] = "★★★★☆",
		["Class"] = "猎人",
		["PVPScore"] = 68.02307404919205,
		["FactionGroup"] = "Alliance",
	}, -- [445]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "Promises-阿拉索",
		["Faction"] = "联盟",
		["Star"] = "★★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 64.96270353831966,
		["FactionGroup"] = "Alliance",
	}, -- [446]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "至高岭牛头人",
		["NameServer"] = "枯叶不知秋-安苏",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 49.73933513245982,
		["FactionGroup"] = "Alliance",
	}, -- [447]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "岁月神偷-影牙要塞",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "潜行者",
		["PVPScore"] = 11.48540668595398,
		["FactionGroup"] = "Alliance",
	}, -- [448]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "德莱尼",
		["NameServer"] = "椰子与香子兰-艾苏恩",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 16.33748670195736,
		["FactionGroup"] = "Alliance",
	}, -- [449]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "机械侏儒",
		["NameServer"] = "草雉京-白银之手",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "武僧",
		["PVPScore"] = 39.86762605058428,
		["FactionGroup"] = "Alliance",
	}, -- [450]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "黑铁矮人",
		["NameServer"] = "菊花爆炸-白银之手",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 24.14983599482292,
		["FactionGroup"] = "Alliance",
	}, -- [451]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "炭烤生蚝-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "战士",
		["PVPScore"] = 40.47161376327419,
		["FactionGroup"] = "Alliance",
	}, -- [452]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "灰常容易迷路-影牙要塞",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "潜行者",
		["PVPScore"] = 35.93330416466982,
		["FactionGroup"] = "Alliance",
	}, -- [453]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "Firstlight-丹莫德",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "德鲁伊",
		["PVPScore"] = 40.79061290723222,
		["Star"] = "★★☆",
	}, -- [454]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "强强但硬硬-塞拉摩",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "圣骑士",
		["PVPScore"] = 10.86844613251077,
		["Star"] = "★",
	}, -- [455]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "小营养加奶酪-拉文凯斯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "圣骑士",
		["PVPScore"] = 5.314086669163228,
		["Star"] = "☆",
	}, -- [456]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "一條柴-安苏",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "战士",
		["PVPScore"] = 0,
		["Star"] = "?",
	}, -- [457]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "地精",
		["NameServer"] = "Leesh-黑铁",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "牧师",
		["PVPScore"] = 12.60332681703019,
		["Star"] = "★",
	}, -- [458]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "陈小壮-扎拉赞恩",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "战士",
		["PVPScore"] = 54.29661740676522,
		["Star"] = "★★★",
	}, -- [459]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "虚空精灵",
		["NameServer"] = "扎灬啤-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "死亡骑士",
		["PVPScore"] = 26.4928048198498,
		["Star"] = "★☆",
	}, -- [460]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "牛头人",
		["NameServer"] = "乖乖的小汐汐-无尽之海",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "死亡骑士",
		["PVPScore"] = 17.73656576010484,
		["Star"] = "★",
	}, -- [461]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "人类",
		["NameServer"] = "灵感水心武僧-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "武僧",
		["PVPScore"] = 23.01099666167597,
		["Star"] = "★☆",
	}, -- [462]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "无一不是你-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "德鲁伊",
		["PVPScore"] = 16.58923513442209,
		["Star"] = "★",
	}, -- [463]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "打不过掉头跑-破碎岭",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "猎人",
		["PVPScore"] = 40.35584212993537,
		["Star"] = "★★☆",
	}, -- [464]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "幺寿-伊森利恩",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "萨满祭司",
		["PVPScore"] = 59.82004660850239,
		["Star"] = "★★★☆",
	}, -- [465]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "啵娜娜-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "潜行者",
		["PVPScore"] = 9.059463160557197,
		["Star"] = "☆",
	}, -- [466]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "Supercool-翡翠梦境",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "法师",
		["PVPScore"] = 34.5041601230455,
		["Star"] = "★★",
	}, -- [467]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "伤之刃-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 4.901959183673468,
		["Star"] = "☆",
	}, -- [468]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "金豆豆-黄金之路",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "潜行者",
		["PVPScore"] = 37.81896004801708,
		["Star"] = "★★",
	}, -- [469]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "賊帝巜-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "潜行者",
		["PVPScore"] = 13.51886598457003,
		["Star"] = "★",
	}, -- [470]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "中年人的执著-幽暗沼泽",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "圣骑士",
		["PVPScore"] = 18.10825693800046,
		["Star"] = "★",
	}, -- [471]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "松宝宝-范达尔鹿盔",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "猎人",
		["PVPScore"] = 29.39040421729041,
		["Star"] = "★☆",
	}, -- [472]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "君儿-拉贾克斯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "圣骑士",
		["PVPScore"] = 53.90093859282435,
		["Star"] = "★★★",
	}, -- [473]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "萨满试玩-埃加洛尔",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "圣骑士",
		["PVPScore"] = 9.682398612286699,
		["Star"] = "☆",
	}, -- [474]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "暗夜精灵",
		["NameServer"] = "无聊看热闹-塞拉摩",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "战士",
		["PVPScore"] = 0.5840253239428803,
		["Star"] = "☆",
	}, -- [475]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "Skyzero-祖阿曼",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "圣骑士",
		["PVPScore"] = 57.31008085003097,
		["Star"] = "★★★☆",
	}, -- [476]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "子若安然-暗影之月",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "猎人",
		["PVPScore"] = 60.44273244926227,
		["Star"] = "★★★★",
	}, -- [477]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Ulrica-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 0,
		["Star"] = "?",
	}, -- [478]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "凌风漫舞-金色平原",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "法师",
		["PVPScore"] = 48.33686338934204,
		["Star"] = "★★☆",
	}, -- [479]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "暗夜精灵",
		["NameServer"] = "表妹-法拉希姆",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "牧师",
		["PVPScore"] = 10.30933885074767,
		["Star"] = "★",
	}, -- [480]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "晓丶天-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "牧师",
		["PVPScore"] = 22.05482552032191,
		["Star"] = "★☆",
	}, -- [481]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "含嫣-亚雷戈斯",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "猎人",
		["PVPScore"] = 0.290568411470186,
		["Star"] = "☆",
	}, -- [482]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "德莱尼",
		["NameServer"] = "你平你先说吧-狂热之刃",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "法师",
		["PVPScore"] = 0,
		["Star"] = "?",
	}, -- [483]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "张清飏-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "武僧",
		["PVPScore"] = 0,
		["Star"] = "?",
	}, -- [484]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "牛头人",
		["NameServer"] = "我爱吃嫩草-主宰之剑",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Class"] = "战士",
		["PVPScore"] = 0,
		["Star"] = "?",
	}, -- [485]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "黑风牙-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "潜行者",
		["PVPScore"] = 5.314544685004198,
		["Star"] = "☆",
	}, -- [486]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "护舒宝-白骨荒野",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★",
		["PVPScore"] = 15.4391060966663,
		["Class"] = "潜行者",
	}, -- [487]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "油腻的师兄-伊森利恩",
		["Faction"] = "部落",
		["FactionGroup"] = "Horde",
		["Star"] = "★☆",
		["PVPScore"] = 20.91719097722887,
		["Class"] = "德鲁伊",
	}, -- [488]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "兽人",
		["NameServer"] = "Ddjtndibj-安苏",
		["Faction"] = "部落",
		["Star"] = "★",
		["Class"] = "术士",
		["PVPScore"] = 14.38793316671522,
		["FactionGroup"] = "Horde",
	}, -- [489]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "猎奇高手-主宰之剑",
		["Faction"] = "联盟",
		["FactionGroup"] = "Alliance",
		["Class"] = "猎人",
		["PVPScore"] = 20.85476510013846,
		["Star"] = "★☆",
	}, -- [490]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "牛头人",
		["NameServer"] = "老年战-幽暗沼泽",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★",
		["PVPScore"] = 13.52971141163561,
		["FactionGroup"] = "Horde",
	}, -- [491]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "暗夜精灵",
		["NameServer"] = "圣一战-斩魔者",
		["Faction"] = "联盟",
		["Class"] = "战士",
		["Star"] = "★★☆",
		["PVPScore"] = 48.16795648932686,
		["FactionGroup"] = "Alliance",
	}, -- [492]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "天蝎月影-埃加洛尔",
		["Faction"] = "部落",
		["Class"] = "猎人",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [493]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "独上九天-罗宁",
		["Faction"] = "联盟",
		["Class"] = "恶魔猎手",
		["Star"] = "★☆",
		["PVPScore"] = 20.55134446837121,
		["FactionGroup"] = "Alliance",
	}, -- [494]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "芮伊丷-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "德鲁伊",
		["Star"] = "☆",
		["PVPScore"] = 8.08439880934586,
		["FactionGroup"] = "Horde",
	}, -- [495]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "裤裆里有图腾-安苏",
		["Faction"] = "部落",
		["Class"] = "萨满祭司",
		["Star"] = "★★",
		["PVPScore"] = 30.05355327048419,
		["FactionGroup"] = "Horde",
	}, -- [496]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "月小仙儿-冰霜之刃",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★☆",
		["PVPScore"] = 25.39557969657145,
		["FactionGroup"] = "Horde",
	}, -- [497]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "重生特种兵-安苏",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "☆",
		["PVPScore"] = 0.001,
		["FactionGroup"] = "Horde",
	}, -- [498]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "亚沙之泪-无尽之海",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★★☆",
		["PVPScore"] = 49.06484163240846,
		["FactionGroup"] = "Horde",
	}, -- [499]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "囍一鷄-安苏",
		["Faction"] = "部落",
		["Class"] = "战士",
		["Star"] = "★☆",
		["PVPScore"] = 22.22529739440911,
		["FactionGroup"] = "Horde",
	}, -- [500]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "阿呱-冰霜之刃",
		["Faction"] = "部落",
		["Class"] = "恶魔猎手",
		["Star"] = "☆",
		["PVPScore"] = 6.033564412638828,
		["FactionGroup"] = "Horde",
	}, -- [501]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "巨魔",
		["NameServer"] = "Tmainsisau-无尽之海",
		["Faction"] = "部落",
		["Class"] = "牧师",
		["Star"] = "★",
		["PVPScore"] = 15.01143739165015,
		["FactionGroup"] = "Horde",
	}, -- [502]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "巨魔",
		["NameServer"] = "牛排吖丷-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "德鲁伊",
		["Star"] = "★★★☆",
		["PVPScore"] = 55.23754766928121,
		["FactionGroup"] = "Horde",
	}, -- [503]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "風清露寒-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "术士",
		["Star"] = "★★★",
		["PVPScore"] = 53.77884099058453,
		["FactionGroup"] = "Horde",
	}, -- [504]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "Jying-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "猎人",
		["Star"] = "★",
		["PVPScore"] = 15.49979727066435,
		["FactionGroup"] = "Horde",
	}, -- [505]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "虚空精灵",
		["NameServer"] = "希女王安牧-安苏",
		["Faction"] = "联盟",
		["Class"] = "牧师",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [506]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "古加尔-燃烧之刃",
		["Faction"] = "联盟",
		["Class"] = "圣骑士",
		["Star"] = "★",
		["PVPScore"] = 16.4623626461385,
		["FactionGroup"] = "Alliance",
	}, -- [507]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "暗夜精灵",
		["NameServer"] = "灬穆湿灬-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "牧师",
		["Star"] = "★☆",
		["PVPScore"] = 28.82504968074434,
		["FactionGroup"] = "Alliance",
	}, -- [508]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "牛头人",
		["NameServer"] = "求莫名堂哦-安苏",
		["Faction"] = "部落",
		["Class"] = "德鲁伊",
		["Star"] = "★★",
		["PVPScore"] = 34.36574129796748,
		["FactionGroup"] = "Horde",
	}, -- [509]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "血精灵",
		["NameServer"] = "浮生-耐普图隆",
		["Faction"] = "部落",
		["Class"] = "死亡骑士",
		["Star"] = "★★☆",
		["PVPScore"] = 46.88843910808757,
		["FactionGroup"] = "Horde",
	}, -- [510]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "熊猫人",
		["NameServer"] = "噬血葬爱-黑铁",
		["Faction"] = "部落",
		["Class"] = "潜行者",
		["Star"] = "★☆",
		["PVPScore"] = 27.10900322713823,
		["FactionGroup"] = "Horde",
	}, -- [511]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "亡灵",
		["NameServer"] = "王四哥-贫瘠之地",
		["Faction"] = "部落",
		["Class"] = "武僧",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [512]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "熊猫人",
		["NameServer"] = "丶秋某人-主宰之剑",
		["Faction"] = "联盟",
		["Class"] = "牧师",
		["Star"] = "☆",
		["PVPScore"] = 0.0002,
		["FactionGroup"] = "Alliance",
	}, -- [513]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "阿萌姬-铜龙军团",
		["Faction"] = "部落",
		["Class"] = "猎人",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [514]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "想妳已成習慣-熔火之心",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "☆",
		["PVPScore"] = 0.1366384167441037,
		["FactionGroup"] = "Horde",
	}, -- [515]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "虚空精灵",
		["NameServer"] = "有种你驱散呀-伊森德雷",
		["Faction"] = "联盟",
		["Class"] = "术士",
		["Star"] = "☆",
		["PVPScore"] = 0.2463623416095256,
		["FactionGroup"] = "Alliance",
	}, -- [516]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "猫尾草-熔火之心",
		["Faction"] = "部落",
		["Class"] = "圣骑士",
		["Star"] = "★★☆",
		["PVPScore"] = 43.22957824790797,
		["FactionGroup"] = "Horde",
	}, -- [517]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "Shamy-血色十字军",
		["Faction"] = "部落",
		["Class"] = "萨满祭司",
		["Star"] = "★★☆",
		["PVPScore"] = 40.68139671285302,
		["FactionGroup"] = "Horde",
	}, -- [518]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "墨銘-影之哀伤",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★★★★",
		["PVPScore"] = 60.46383356679637,
		["FactionGroup"] = "Horde",
	}, -- [519]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "至高岭牛头人",
		["NameServer"] = "小皮卡-凤凰之神",
		["Faction"] = "部落",
		["Class"] = "萨满祭司",
		["Star"] = "☆",
		["PVPScore"] = 3.771775603095129,
		["FactionGroup"] = "Horde",
	}, -- [520]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "血精灵",
		["NameServer"] = "Fionas-伊森利恩",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "?",
		["PVPScore"] = 0,
		["FactionGroup"] = "Horde",
	}, -- [521]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "巨魔",
		["NameServer"] = "我欲乘风起-无尽之海",
		["Faction"] = "部落",
		["Class"] = "法师",
		["Star"] = "★★★★☆",
		["PVPScore"] = 66.28591977796133,
		["FactionGroup"] = "Horde",
	}, -- [522]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "Kshadow-凤凰之神",
		["Faction"] = "联盟",
		["Class"] = "恶魔猎手",
		["Star"] = "★☆",
		["PVPScore"] = 20.25727093950169,
		["FactionGroup"] = "Alliance",
	}, -- [523]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "黑铁矮人",
		["NameServer"] = "未知目标-埃加洛尔",
		["Faction"] = "联盟",
		["Class"] = "潜行者",
		["Star"] = "★★",
		["PVPScore"] = 30.22862899112376,
		["FactionGroup"] = "Alliance",
	}, -- [524]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "矮人",
		["NameServer"] = "Pikaball-末日行者",
		["Faction"] = "联盟",
		["Class"] = "萨满祭司",
		["Star"] = "☆",
		["PVPScore"] = 9.74653978301768,
		["FactionGroup"] = "Alliance",
	}, -- [525]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "讄讄-末日行者",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "牧师",
		["PVPScore"] = 3.566814814814813,
		["FactionGroup"] = "Alliance",
	}, -- [526]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "雷纳德-羽月",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 27.13744761297377,
		["FactionGroup"] = "Alliance",
	}, -- [527]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "侏儒",
		["NameServer"] = "杀戮乄死神-安苏",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 20.85476892908038,
		["FactionGroup"] = "Alliance",
	}, -- [528]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "光铸德莱尼",
		["NameServer"] = "塞雷娅丶赎光-安苏",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "圣骑士",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [529]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "光铸德莱尼",
		["NameServer"] = "圣光曝衣斩-末日行者",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 0.0002,
		["FactionGroup"] = "Alliance",
	}, -- [530]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "杀戮乄大狂风-塞拉摩",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 19.20515197994084,
		["FactionGroup"] = "Alliance",
	}, -- [531]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "三千醉-瑞文戴尔",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "法师",
		["PVPScore"] = 12.28384213212001,
		["FactionGroup"] = "Alliance",
	}, -- [532]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "无脑判罪-安苏",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "战士",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [533]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "漂泊的小鸟-伊萨里奥斯",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0.5112592592592592,
		["FactionGroup"] = "Alliance",
	}, -- [534]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "丨恶魔再临丨-安苏",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 5.254170719466954,
		["FactionGroup"] = "Alliance",
	}, -- [535]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "夜辉-白银之手",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "圣骑士",
		["PVPScore"] = 10.92208152092106,
		["FactionGroup"] = "Alliance",
	}, -- [536]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "虚空精灵",
		["NameServer"] = "桃之-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "武僧",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [537]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "渔港之星-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "法师",
		["PVPScore"] = 35.61088114047438,
		["FactionGroup"] = "Alliance",
	}, -- [538]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "黑铁矮人",
		["NameServer"] = "龙阳狂少-达文格尔",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "圣骑士",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [539]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "乐柚-罗宁",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "法师",
		["PVPScore"] = 19.11754359735685,
		["FactionGroup"] = "Alliance",
	}, -- [540]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "侏儒",
		["NameServer"] = "卧蚕欧巴-白银之手",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "法师",
		["PVPScore"] = 9.07363878902019,
		["FactionGroup"] = "Alliance",
	}, -- [541]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "Horusu-鬼雾峰",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "法师",
		["PVPScore"] = 38.4912969035127,
		["FactionGroup"] = "Alliance",
	}, -- [542]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "黑铁矮人",
		["NameServer"] = "門襟被撑爆-安苏",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "圣骑士",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [543]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "亡灵",
		["NameServer"] = "Sansy-影之哀伤",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "潜行者",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [544]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "买菜洗菜烧菜-安苏",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 6.284292671825215,
		["FactionGroup"] = "Alliance",
	}, -- [545]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "机械侏儒",
		["NameServer"] = "尸十四-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 48.4259491319683,
		["FactionGroup"] = "Alliance",
	}, -- [546]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "寂寞无情剑-安苏",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "战士",
		["PVPScore"] = 32.98762103392292,
		["FactionGroup"] = "Alliance",
	}, -- [547]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "廾咕咕-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0.07633964463140128,
		["FactionGroup"] = "Alliance",
	}, -- [548]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "一衰任醉生-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "法师",
		["PVPScore"] = 7.384289227882978,
		["FactionGroup"] = "Alliance",
	}, -- [549]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "水茽椛-死亡之翼",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 44.87095080838247,
		["FactionGroup"] = "Alliance",
	}, -- [550]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "牛头人",
		["NameServer"] = "丨牧師-死亡之翼",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "牧师",
		["PVPScore"] = 29.71356033456632,
		["FactionGroup"] = "Alliance",
	}, -- [551]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "牛头人",
		["NameServer"] = "Furryou-布兰卡德",
		["Faction"] = "联盟",
		["Star"] = "★★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 61.16277775808118,
		["FactionGroup"] = "Alliance",
	}, -- [552]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "Eularz-布兰卡德",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 43.82891122739977,
		["FactionGroup"] = "Alliance",
	}, -- [553]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "亡灵",
		["NameServer"] = "把人丨活了-幽暗沼泽",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "牧师",
		["PVPScore"] = 11.94616912330716,
		["FactionGroup"] = "Alliance",
	}, -- [554]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "地精",
		["NameServer"] = "浪哥格-死亡之翼",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 45.19151943470267,
		["FactionGroup"] = "Alliance",
	}, -- [555]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "壮叔叔来了-大地之怒",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 19.55623662482587,
		["FactionGroup"] = "Alliance",
	}, -- [556]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "侏儒",
		["NameServer"] = "枉凝眉-织亡者",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "战士",
		["PVPScore"] = 49.60072059615327,
		["FactionGroup"] = "Alliance",
	}, -- [557]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "兽人",
		["NameServer"] = "战歌灬卤蛋-布兰卡德",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "战士",
		["PVPScore"] = 38.02554219851715,
		["FactionGroup"] = "Alliance",
	}, -- [558]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "污纯纯-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 5.028050590511459,
		["FactionGroup"] = "Alliance",
	}, -- [559]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "雨下的忧郁-末日行者",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 7.739651709128158,
		["FactionGroup"] = "Alliance",
	}, -- [560]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "烈风渊噬-罗宁",
		["Faction"] = "联盟",
		["Star"] = "★★★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 58.65707038322788,
		["FactionGroup"] = "Alliance",
	}, -- [561]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "偷鸡摸狗-破碎岭",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "潜行者",
		["PVPScore"] = 0.4157077735311699,
		["FactionGroup"] = "Alliance",
	}, -- [562]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "波罗密多-库尔提拉斯",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 46.03252588503349,
		["FactionGroup"] = "Alliance",
	}, -- [563]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "虚空精灵",
		["NameServer"] = "梦醒丶泪殇-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "术士",
		["PVPScore"] = 0.0002,
		["FactionGroup"] = "Alliance",
	}, -- [564]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "亡灵",
		["NameServer"] = "Ennyin-埃加洛尔",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "术士",
		["PVPScore"] = 79.15447820948839,
		["FactionGroup"] = "Horde",
	}, -- [565]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "速风-阿克蒙德",
		["Faction"] = "联盟",
		["Star"] = "★★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 59.9509626918738,
		["FactionGroup"] = "Alliance",
	}, -- [566]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "人帅输出低丶-安苏",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "法师",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [567]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "开心宝贝-守护之剑",
		["Faction"] = "联盟",
		["Star"] = "★★★★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 66.27820902296396,
		["FactionGroup"] = "Alliance",
	}, -- [568]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "狼人",
		["NameServer"] = "洒家爱撩妹-安苏",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "潜行者",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [569]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "芒果百香果-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [570]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "矮人",
		["NameServer"] = "啥鸡毛都违规-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "牧师",
		["PVPScore"] = 44.06296693912694,
		["FactionGroup"] = "Alliance",
	}, -- [571]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "黑铁矮人",
		["NameServer"] = "千年酿-安苏",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "武僧",
		["PVPScore"] = 0.07460870248285768,
		["FactionGroup"] = "Alliance",
	}, -- [572]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "虚空精灵",
		["NameServer"] = "Willsmith-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 42.53478623299193,
		["FactionGroup"] = "Alliance",
	}, -- [573]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "湫月白-伊森利恩",
		["Faction"] = "部落",
		["Star"] = "★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 52.54465292538343,
		["FactionGroup"] = "Horde",
	}, -- [574]
	{
		["ClassFileName"] = "WARLOCK",
		["Race"] = "侏儒",
		["NameServer"] = "星辰的术爷-末日行者",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "术士",
		["PVPScore"] = 16.94155798105827,
		["FactionGroup"] = "Alliance",
	}, -- [575]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "侏儒",
		["NameServer"] = "以待天倾-诺兹多姆",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "猎人",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [576]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "暗夜精灵",
		["NameServer"] = "月冷千山-羽月",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "牧师",
		["PVPScore"] = 25.91800283996276,
		["FactionGroup"] = "Alliance",
	}, -- [577]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "两面三刀-达纳斯",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 41.04222726353368,
		["FactionGroup"] = "Alliance",
	}, -- [578]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "丨嘻哈灬餃子-破碎岭",
		["Faction"] = "联盟",
		["Star"] = "★★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 54.80412194166605,
		["FactionGroup"] = "Alliance",
	}, -- [579]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "奈何忘川-末日行者",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "法师",
		["PVPScore"] = 14.72903654391881,
		["FactionGroup"] = "Alliance",
	}, -- [580]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "行者无惧-末日行者",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [581]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "人类",
		["NameServer"] = "尐轶-末日行者",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "圣骑士",
		["PVPScore"] = 44.71411397173868,
		["FactionGroup"] = "Alliance",
	}, -- [582]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "潇萧暮雨-暗影议会",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "牧师",
		["PVPScore"] = 5.322163850921074,
		["FactionGroup"] = "Alliance",
	}, -- [583]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "虚空精灵",
		["NameServer"] = "幻想-奥拉基尔",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "猎人",
		["PVPScore"] = 40.21095879068968,
		["FactionGroup"] = "Alliance",
	}, -- [584]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "兽人",
		["NameServer"] = "Carona-埃德萨拉",
		["Faction"] = "部落",
		["Star"] = "★★★☆",
		["Class"] = "潜行者",
		["PVPScore"] = 58.97406306225351,
		["FactionGroup"] = "Horde",
	}, -- [585]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "凌灬空-安苏",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "法师",
		["PVPScore"] = 26.7716641802246,
		["FactionGroup"] = "Alliance",
	}, -- [586]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "Justrelax-末日行者",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "猎人",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [587]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "人类",
		["NameServer"] = "嗜血狂戰-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "★★★",
		["Class"] = "潜行者",
		["PVPScore"] = 53.88411240622897,
		["FactionGroup"] = "Alliance",
	}, -- [588]
	{
		["ClassFileName"] = "PALADIN",
		["Race"] = "血精灵",
		["NameServer"] = "大白猫-阿纳克洛斯",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "圣骑士",
		["PVPScore"] = 37.65018237771793,
		["FactionGroup"] = "Horde",
	}, -- [589]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "赞达拉巨魔",
		["NameServer"] = "丿刁儿啷噹-冰霜之刃",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "战士",
		["PVPScore"] = 39.11626345660324,
		["FactionGroup"] = "Horde",
	}, -- [590]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "丶可乐加冰丷-格瑞姆巴托",
		["Faction"] = "部落",
		["Star"] = "★★★★★",
		["Class"] = "猎人",
		["PVPScore"] = 72.10036812657785,
		["FactionGroup"] = "Horde",
	}, -- [591]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "兽人",
		["NameServer"] = "部落壶哥-血色十字军",
		["Faction"] = "部落",
		["Star"] = "★★☆",
		["Class"] = "猎人",
		["PVPScore"] = 41.18771640907745,
		["FactionGroup"] = "Horde",
	}, -- [592]
	{
		["ClassFileName"] = "DEATHKNIGHT",
		["Race"] = "暗夜精灵",
		["NameServer"] = "東邪暮雨-罗宁",
		["Faction"] = "联盟",
		["Star"] = "★★★☆",
		["Class"] = "死亡骑士",
		["PVPScore"] = 55.34689204734972,
		["FactionGroup"] = "Alliance",
	}, -- [593]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "人类",
		["NameServer"] = "諸訷黄昏-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "战士",
		["PVPScore"] = 36.43658385989382,
		["FactionGroup"] = "Alliance",
	}, -- [594]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "虚空精灵",
		["NameServer"] = "竹内夏希-风暴之怒",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "武僧",
		["PVPScore"] = 10.76585255670844,
		["FactionGroup"] = "Alliance",
	}, -- [595]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "阿特密斯罗斯-回音山",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "猎人",
		["PVPScore"] = 43.28781550551719,
		["FactionGroup"] = "Alliance",
	}, -- [596]
	{
		["ClassFileName"] = "MONK",
		["Race"] = "熊猫人",
		["NameServer"] = "音至-安苏",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "武僧",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [597]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "暗夜精灵",
		["NameServer"] = "温柔的雨-白银之手",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 33.13177907830546,
		["FactionGroup"] = "Alliance",
	}, -- [598]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "自由之筝-国王之谷",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 31.7696499568272,
		["FactionGroup"] = "Alliance",
	}, -- [599]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "雀神怪鸟-罗宁",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "德鲁伊",
		["PVPScore"] = 15.90159208224236,
		["FactionGroup"] = "Alliance",
	}, -- [600]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "部落克星-阿拉索",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "猎人",
		["PVPScore"] = 48.71712431214155,
		["FactionGroup"] = "Alliance",
	}, -- [601]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "暗夜精灵",
		["NameServer"] = "选择迩丶深爱-黑铁",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "潜行者",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [602]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "真不缺德-奥拉基尔",
		["Faction"] = "联盟",
		["Star"] = "★★☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 40.82941437109727,
		["FactionGroup"] = "Alliance",
	}, -- [603]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "兽人",
		["NameServer"] = "幽暗森林-燃烧之刃",
		["Faction"] = "部落",
		["Star"] = "★★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 31.45930598707145,
		["FactionGroup"] = "Horde",
	}, -- [604]
	{
		["ClassFileName"] = "SHAMAN",
		["Race"] = "库尔提拉斯人",
		["NameServer"] = "破浪者卢娜-白银之手",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "萨满祭司",
		["PVPScore"] = 31.79189095320102,
		["FactionGroup"] = "Alliance",
	}, -- [605]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "明日花琦罗-白银之手",
		["Faction"] = "联盟",
		["Star"] = "★★★★★",
		["Class"] = "法师",
		["PVPScore"] = 73.68604372089892,
		["FactionGroup"] = "Alliance",
	}, -- [606]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "狼人",
		["NameServer"] = "德古拉伯爵壹-天谴之门",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "猎人",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [607]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "血精灵",
		["NameServer"] = "葵雏籽-死亡之翼",
		["Faction"] = "部落",
		["Star"] = "☆",
		["Class"] = "牧师",
		["PVPScore"] = 1.138639185335293,
		["FactionGroup"] = "Horde",
	}, -- [608]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "虚空精灵",
		["NameServer"] = "魔铸-主宰之剑",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "法师",
		["PVPScore"] = 18.53526497550572,
		["FactionGroup"] = "Alliance",
	}, -- [609]
	{
		["ClassFileName"] = "MAGE",
		["Race"] = "人类",
		["NameServer"] = "神說要有愛-末日行者",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "法师",
		["PVPScore"] = 0.4148720397077419,
		["FactionGroup"] = "Alliance",
	}, -- [610]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "狼人",
		["NameServer"] = "白色山猫卡娜-金色平原",
		["Faction"] = "联盟",
		["Star"] = "?",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0,
		["FactionGroup"] = "Alliance",
	}, -- [611]
	{
		["ClassFileName"] = "PRIEST",
		["Race"] = "人类",
		["NameServer"] = "洛莉丝丶星痕-金色平原",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "牧师",
		["PVPScore"] = 18.48548436333633,
		["FactionGroup"] = "Alliance",
	}, -- [612]
	{
		["ClassFileName"] = "HUNTER",
		["Race"] = "人类",
		["NameServer"] = "温蕾莎风行者-库德兰",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "猎人",
		["PVPScore"] = 0.0004,
		["FactionGroup"] = "Alliance",
	}, -- [613]
	{
		["ClassFileName"] = "DEMONHUNTER",
		["Race"] = "血精灵",
		["NameServer"] = "芒果丶丶-阿比迪斯",
		["Faction"] = "联盟",
		["Star"] = "★",
		["Class"] = "恶魔猎手",
		["PVPScore"] = 17.4430417412078,
		["FactionGroup"] = "Alliance",
	}, -- [614]
	{
		["ClassFileName"] = "WARRIOR",
		["Race"] = "巨魔",
		["NameServer"] = "老马不难骑丶-伊森利恩",
		["Faction"] = "联盟",
		["Star"] = "★☆",
		["Class"] = "战士",
		["PVPScore"] = 20.37507070544217,
		["FactionGroup"] = "Alliance",
	}, -- [615]
	{
		["ClassFileName"] = "ROGUE",
		["Race"] = "虚空精灵",
		["NameServer"] = "约瑟丶芬妮-阿古斯",
		["Faction"] = "联盟",
		["Star"] = "★★",
		["Class"] = "潜行者",
		["PVPScore"] = 37.73551970098498,
		["FactionGroup"] = "Alliance",
	}, -- [616]
	{
		["ClassFileName"] = "DRUID",
		["Race"] = "暗夜精灵",
		["NameServer"] = "笑雨清风-末日行者",
		["Faction"] = "联盟",
		["Star"] = "☆",
		["Class"] = "德鲁伊",
		["PVPScore"] = 0.4157077735311699,
		["FactionGroup"] = "Alliance",
	}, -- [617]
}
PVPScoreCacheDate = 1615806104
