
sArena3DB = {
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["Ennyin - 索瑞森"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["Ennyin - 埃加洛尔"] = "ENNYIN",
		["Rainylone - 末日行者"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["layoutSettings"] = {
				["BlizzArena"] = {
					["dr"] = {
						["posX"] = -69,
					},
					["scale"] = 1.6,
					["posY"] = 45,
					["posX"] = 335,
				},
				["Xaryu"] = {
					["dr"] = {
						["posY"] = 21.3,
						["posX"] = -92.3,
					},
					["posY"] = 144.5,
					["spacing"] = 23,
					["castBar"] = {
						["scale"] = 1.5,
						["posY"] = -5.3,
						["posX"] = -101.6,
					},
					["specIcon"] = {
						["posY"] = 9.5,
						["posX"] = -20.2,
					},
					["posX"] = 355,
					["trinket"] = {
						["posY"] = -0.9,
						["posX"] = 99,
					},
				},
			},
			["currentLayout"] = "Xaryu",
		},
		["ENNYIN"] = {
			["layoutSettings"] = {
				["BlizzArena"] = {
					["dr"] = {
						["posX"] = -69,
					},
					["posY"] = 45,
					["scale"] = 1.6,
					["posX"] = 335,
				},
				["Xaryu"] = {
					["dr"] = {
						["posY"] = 21.3,
						["posX"] = -92.3,
					},
					["posY"] = 129,
					["scale"] = 1.4,
					["trinket"] = {
						["posY"] = -0.9,
						["posX"] = 99,
					},
					["castBar"] = {
						["scale"] = 1.5,
						["posY"] = -5.3,
						["posX"] = -101.6,
					},
					["spacing"] = 23,
					["posX"] = 262,
					["specIcon"] = {
						["posY"] = 9.5,
						["posX"] = -20.2,
					},
				},
			},
			["currentLayout"] = "Xaryu",
		},
	},
}
