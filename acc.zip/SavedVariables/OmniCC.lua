
OmniCCDB = {
	["global"] = {
		["addonVersion"] = "9.0.5",
		["dbVersion"] = 5,
	},
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "默认",
		["Rainylone - 末日行者"] = "默认",
		["Ennyin - 索瑞森"] = "默认",
		["Madeep - 冰风岗"] = "默认",
		["Ennyin - 埃加洛尔"] = "默认",
	},
	["profiles"] = {
		["默认"] = {
			["rules"] = {
				{
					["patterns"] = {
						"LossOfControl", -- [1]
						"TotemFrame", -- [2]
					},
					["id"] = "Ignore",
					["priority"] = 1,
					["theme"] = "Ignore",
				}, -- [1]
				{
					["id"] = "t",
					["priority"] = 2,
					["theme"] = "t",
				}, -- [2]
				{
					["patterns"] = {
						"PlaterMainAuraIcon", -- [1]
						"PlaterSecondaryAuraIcon", -- [2]
						"ExtraIconRowIcon", -- [3]
					},
					["id"] = "Plater Nameplates Rule",
					["priority"] = 3,
					["theme"] = "Plater Nameplates Theme",
				}, -- [3]
			},
			["themes"] = {
				["Plater Nameplates Theme"] = {
					["textStyles"] = {
						["seconds"] = {
						},
						["soon"] = {
						},
						["minutes"] = {
						},
					},
				},
				["t"] = {
					["textStyles"] = {
						["soon"] = {
							["scale"] = 1.350000023841858,
						},
						["seconds"] = {
						},
						["minutes"] = {
						},
						["hours"] = {
							["scale"] = 1,
						},
						["charging"] = {
							["r"] = 1,
							["scale"] = 1,
							["g"] = 0.98,
							["b"] = 0.4,
						},
					},
					["fontSize"] = 27,
					["tenthsDuration"] = 0.300000011920929,
					["fontOutline"] = "THICKOUTLINE",
					["minSize"] = 0.52,
					["spiralOpacity"] = 1.00999997742474,
					["minEffectDuration"] = 2.799999952316284,
					["fontFace"] = "Fonts\\ARKai_C.TTF",
					["minDuration"] = 3.200000047683716,
				},
				["默认"] = {
					["textStyles"] = {
						["soon"] = {
							["scale"] = 1.350000023841858,
						},
						["seconds"] = {
						},
						["minutes"] = {
						},
						["hours"] = {
							["scale"] = 1,
						},
						["charging"] = {
							["r"] = 1,
							["scale"] = 1,
							["g"] = 0.98,
							["b"] = 0.4,
						},
					},
					["fontFace"] = "Fonts\\ARKai_C.TTF",
					["minDuration"] = 3,
					["fontOutline"] = "THICKOUTLINE",
					["effect"] = "shine",
					["spiralOpacity"] = 1.00999997742474,
					["minEffectDuration"] = 2.400000095367432,
					["fontSize"] = 16,
				},
				["Ignore"] = {
					["textStyles"] = {
						["seconds"] = {
						},
						["soon"] = {
						},
						["minutes"] = {
						},
						["charging"] = {
							["r"] = 1,
							["scale"] = 0.65,
							["g"] = 0.98,
							["b"] = 0.4,
						},
					},
					["fontFace"] = "Fonts\\bHEI01B.TTF",
					["minDuration"] = 3,
					["enableText"] = false,
					["spiralOpacity"] = 1,
					["fontSize"] = 27,
				},
			},
		},
	},
}
OmniCC4Config = {
	["engine"] = "AniUpdater",
	["version"] = "8.2.5",
	["groupSettings"] = {
		["t"] = {
			["enabled"] = true,
			["fontFace"] = "Fonts\\ARKai_C.TTF",
			["styles"] = {
				["seconds"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 1,
					["b"] = 0.1,
				},
				["soon"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1.350000023841858,
					["g"] = 0.1,
					["b"] = 0.1,
				},
				["minutes"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 1,
					["b"] = 1,
				},
				["hours"] = {
					["a"] = 1,
					["r"] = 0.7,
					["scale"] = 1,
					["g"] = 0.7,
					["b"] = 0.7,
				},
				["charging"] = {
					["a"] = 0.8,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 0.98,
					["b"] = 0.4,
				},
				["controlled"] = {
					["scale"] = 1.5,
				},
			},
			["effect"] = "pulse",
			["fontSize"] = 27,
			["minEffectDuration"] = 2.799999952316284,
			["minSize"] = 0.52,
			["spiralOpacity"] = 1.00999997742474,
			["minDuration"] = 3.200000047683716,
			["xOff"] = 0,
			["tenthsDuration"] = 0.300000011920929,
			["fontOutline"] = "THICKOUTLINE",
			["anchor"] = "CENTER",
			["mmSSDuration"] = 0,
			["scaleText"] = true,
			["yOff"] = 0,
		},
		["base"] = {
			["enabled"] = true,
			["styles"] = {
				["minutes"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 1,
					["b"] = 1,
				},
				["seconds"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 1,
					["b"] = 0.1,
				},
				["soon"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1.350000023841858,
					["g"] = 0.1,
					["b"] = 0.1,
				},
				["hours"] = {
					["a"] = 1,
					["r"] = 0.7,
					["scale"] = 1,
					["g"] = 0.7,
					["b"] = 0.7,
				},
				["charging"] = {
					["a"] = 0.8,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 0.98,
					["b"] = 0.4,
				},
				["controlled"] = {
					["scale"] = 1.5,
				},
			},
			["minDuration"] = 3,
			["effect"] = "shine",
			["yOff"] = 0,
			["mmSSDuration"] = 0,
			["anchor"] = "CENTER",
			["spiralOpacity"] = 1.00999997742474,
			["scaleText"] = true,
			["xOff"] = 0,
			["tenthsDuration"] = 0,
			["fontOutline"] = "THICKOUTLINE",
			["minSize"] = 0.5,
			["minEffectDuration"] = 2.400000095367432,
			["fontFace"] = "Fonts\\ARKai_C.TTF",
			["fontSize"] = 16,
		},
		["Ignore"] = {
			["enabled"] = false,
			["styles"] = {
				["soon"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1.5,
					["g"] = 0.1,
					["b"] = 0.1,
				},
				["minutes"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 1,
					["b"] = 1,
				},
				["seconds"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 1,
					["b"] = 0.1,
				},
				["hours"] = {
					["a"] = 1,
					["r"] = 0.7,
					["scale"] = 0.75,
					["g"] = 0.7,
					["b"] = 0.7,
				},
				["charging"] = {
					["a"] = 0.8,
					["r"] = 1,
					["scale"] = 0.65,
					["g"] = 0.98,
					["b"] = 0.4,
				},
				["controlled"] = {
				},
			},
			["fontSize"] = 27,
			["effect"] = "pulse",
			["fontFace"] = "Fonts\\bHEI01B.TTF",
			["minEffectDuration"] = 30,
			["minSize"] = 0.5,
			["spiralOpacity"] = 1,
			["minDuration"] = 3,
			["xOff"] = 0,
			["tenthsDuration"] = 0,
			["fontOutline"] = "OUTLINE",
			["anchor"] = "CENTER",
			["mmSSDuration"] = 0,
			["yOff"] = 0,
			["scaleText"] = true,
		},
	},
	["groups"] = {
		{
			["id"] = "Ignore",
			["rules"] = {
				"LossOfControl", -- [1]
				"TotemFrame", -- [2]
			},
			["enabled"] = true,
		}, -- [1]
		{
			["id"] = "t",
			["rules"] = {
			},
			["enabled"] = true,
		}, -- [2]
	},
}
