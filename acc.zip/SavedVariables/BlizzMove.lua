
BlizzMoveDB = {
	["points"] = {
	},
	["savePosStrategy"] = "session",
}
