
BlizzMoveDB = {
	["savePosStrategy"] = "session",
	["points"] = {
	},
}
