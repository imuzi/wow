
BeanCounterDB = {
	["索瑞森"] = {
		["Ennyin"] = {
			["vendorsell"] = {
			},
			["postedBids"] = {
			},
			["postedAuctions"] = {
			},
			["completedBidsBuyoutsNeutral"] = {
			},
			["vendorbuy"] = {
			},
			["failedAuctions"] = {
			},
			["failedBidsNeutral"] = {
			},
			["failedBids"] = {
			},
			["completedAuctions"] = {
			},
			["failedAuctionsNeutral"] = {
			},
			["completedAuctionsNeutral"] = {
			},
			["completedBidsBuyouts"] = {
			},
		},
	},
}
BeanCounterDBSettings = {
	["configator.left"] = 368.0001220703125,
	["configator.top"] = 705.0000610351562,
	["util.beancounter.ButtonuseDateCheck"] = false,
	["索瑞森"] = {
		["Ennyin"] = {
			["tasks.sortArray"] = 1581297921,
			["version"] = 3.04,
			["faction"] = "Horde",
			["tasks.compactDB"] = 1581297921,
			["wealth"] = 454066639,
			["tasks.prunePostedDB"] = 1581297921,
			["mailbox"] = {
			},
		},
	},
}
BeanCounterDBNames = {
}
BeanCounterAccountDB = nil
BeanCounterMailPatch = nil
