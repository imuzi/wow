
AucAdvancedConfig = {
}
AucAdvancedData = {
	["Stats"] = {
	},
}
AucAdvancedServers = nil
