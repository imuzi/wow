
nRange_Data = {
	["y"] = -34.0000190734863,
	["x"] = -169.000091552734,
	["active"] = false,
	["Anchor"] = "CENTER",
	["showicon"] = true,
	["communication"] = false,
}
