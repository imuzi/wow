
Bagnon_Sets = {
	["tackleColor"] = {
	},
	["leatherColor"] = {
	},
	["engineerColor"] = {
	},
	["herbColor"] = {
	},
	["inscribeColor"] = {
	},
	["soulColor"] = {
	},
	["quiverColor"] = {
	},
	["global"] = {
		["inventory"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["point"] = "TOPRIGHT",
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["y"] = -70.4443359375,
			["x"] = -458.889404296875,
			["borderColor"] = {
			},
			["bagBreak"] = false,
		},
		["vault"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["borderColor"] = {
			},
		},
		["guild"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["borderColor"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["hiddenBags"] = {
			},
		},
		["bank"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["borderColor"] = {
			},
		},
	},
	["reagentColor"] = {
	},
	["gemColor"] = {
	},
	["enchantColor"] = {
	},
	["glowAlpha"] = 1,
	["emptySlots"] = true,
	["keyColor"] = {
	},
	["normalColor"] = {
	},
	["profiles"] = {
		["Ennyin - 埃加洛尔"] = {
			["vault"] = {
				["y"] = 248.9999694824219,
				["rules"] = {
					"all", -- [1]
					"all/normal", -- [2]
					"all/trade", -- [3]
					"all/reagent", -- [4]
					"all/keys", -- [5]
					"all/quiver", -- [6]
					"equip", -- [7]
					"equip/armor", -- [8]
					"equip/weapon", -- [9]
					"equip/trinket", -- [10]
					"use", -- [11]
					"use/consume", -- [12]
					"use/enhance", -- [13]
					"trade", -- [14]
					"trade/goods", -- [15]
					"trade/gem", -- [16]
					"trade/glyph", -- [17]
					"trade/recipe", -- [18]
					"quest", -- [19]
					"misc", -- [20]
				},
				["point"] = "BOTTOMLEFT",
				["hiddenBags"] = {
				},
				["color"] = {
				},
				["borderColor"] = {
				},
				["hiddenRules"] = {
				},
				["x"] = 95.00000762939453,
			},
			["inventory"] = {
				["rules"] = {
					"all", -- [1]
					"all/normal", -- [2]
					"all/trade", -- [3]
					"all/reagent", -- [4]
					"all/keys", -- [5]
					"all/quiver", -- [6]
					"equip", -- [7]
					"equip/armor", -- [8]
					"equip/weapon", -- [9]
					"equip/trinket", -- [10]
					"use", -- [11]
					"use/consume", -- [12]
					"use/enhance", -- [13]
					"trade", -- [14]
					"trade/goods", -- [15]
					"trade/gem", -- [16]
					"trade/glyph", -- [17]
					"trade/recipe", -- [18]
					"quest", -- [19]
					"misc", -- [20]
				},
				["point"] = "BOTTOMRIGHT",
				["hiddenBags"] = {
					false, -- [1]
					false, -- [2]
					false, -- [3]
					false, -- [4]
					[0] = true,
				},
				["color"] = {
				},
				["hiddenRules"] = {
				},
				["y"] = 87.27784729003906,
				["x"] = -282.890869140625,
				["reverseBags"] = false,
				["borderColor"] = {
				},
				["reverseSlots"] = false,
				["showBags"] = true,
				["bagBreak"] = true,
				["money"] = true,
			},
			["guild"] = {
				["rules"] = {
					"all", -- [1]
					"all/normal", -- [2]
					"all/trade", -- [3]
					"all/reagent", -- [4]
					"all/keys", -- [5]
					"all/quiver", -- [6]
					"equip", -- [7]
					"equip/armor", -- [8]
					"equip/weapon", -- [9]
					"equip/trinket", -- [10]
					"use", -- [11]
					"use/consume", -- [12]
					"use/enhance", -- [13]
					"trade", -- [14]
					"trade/goods", -- [15]
					"trade/gem", -- [16]
					"trade/glyph", -- [17]
					"trade/recipe", -- [18]
					"quest", -- [19]
					"misc", -- [20]
				},
				["borderColor"] = {
				},
				["color"] = {
				},
				["hiddenRules"] = {
				},
				["hiddenBags"] = {
				},
			},
			["bank"] = {
				["rules"] = {
					"all", -- [1]
					"all/normal", -- [2]
					"all/trade", -- [3]
					"all/reagent", -- [4]
					"all/keys", -- [5]
					"all/quiver", -- [6]
					"equip", -- [7]
					"equip/armor", -- [8]
					"equip/weapon", -- [9]
					"equip/trinket", -- [10]
					"use", -- [11]
					"use/consume", -- [12]
					"use/enhance", -- [13]
					"trade", -- [14]
					"trade/goods", -- [15]
					"trade/gem", -- [16]
					"trade/glyph", -- [17]
					"trade/recipe", -- [18]
					"quest", -- [19]
					"misc", -- [20]
				},
				["point"] = "BOTTOMLEFT",
				["hiddenBags"] = {
				},
				["color"] = {
				},
				["hiddenRules"] = {
				},
				["y"] = -189.0000762939453,
				["x"] = 295.0000610351563,
				["borderColor"] = {
				},
				["showBags"] = true,
			},
		},
	},
	["mineColor"] = {
	},
	["glowNew"] = true,
	["version"] = "9.0.4",
	["displayGems"] = true,
	["glowPoor"] = true,
	["colorSlots"] = true,
	["fridgeColor"] = {
	},
	["displayPlayer"] = true,
}
