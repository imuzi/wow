
CursorTrail_Config = {
	["Profiles"] = {
	},
}
