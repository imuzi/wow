
GUIConfigAll = {
	["索瑞森"] = {
		["別雨"] = false,
		["木诺子其"] = false,
	},
}
GUIConfigSettings = {
	["nameplate"] = {
		["track_auras"] = true,
		["show_castbar_name"] = true,
		["health_value"] = true,
	},
	["general"] = {
		["uiscale"] = 1,
	},
	["enemycooldown"] = {
		["show_inpvp"] = true,
		["show_always"] = true,
	},
	["combattext"] = {
		["blizz_head_numbers"] = true,
		["enable"] = false,
	},
	["tooltip"] = {
		["unit_role"] = true,
		["health_value"] = true,
	},
	["chat"] = {
		["chat_bar"] = true,
		["tabs_mouseover"] = true,
		["height"] = 180,
		["time_color"] = {
			"1.00", -- [1]
			"1.00", -- [2]
			"0.00", -- [3]
			"1.00", -- [4]
		},
		["chat_bar_mouseover"] = true,
	},
	["unitframe"] = {
		["plugins_diminishing"] = true,
		["enable"] = false,
		["castbar_icon"] = true,
		["portrait_enable"] = true,
	},
	["automation"] = {
		["tab_binder"] = true,
	},
	["pulsecooldown"] = {
		["enable"] = true,
	},
	["actionbar"] = {
		["enable"] = false,
	},
}
