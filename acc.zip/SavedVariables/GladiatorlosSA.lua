
GladiatorlosSADB = {
	["profileKeys"] = {
		["Sotu - 燃烧之刃"] = "Default",
		["天然野 - 达文格尔"] = "Default",
		["绑不住的风 - 燃烧之刃"] = "Default",
		["Nuc - 阿拉希"] = "Default",
		["额为我 - 战歌"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["Ennyin - 索瑞森"] = "Default",
		["幽笠巫 - 熊猫酒仙"] = "Default",
		["Ennyin - 提瑞斯法"] = "Default",
		["木诺子其 - 索瑞森"] = "Default",
		["Lure - 达文格尔"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
