
NameplateCCnTrinketSettings = {
	["profileKeys"] = {
		["Ennyin - 索瑞森"] = "Default",
		["云雨別 - 索瑞森"] = "Default",
		["Ennyin - 埃加洛尔"] = "ENNYIN",
		["借你流年 - 燃烧之刃"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["你诺 - 索瑞森"] = "Default",
		["Rainylone - 末日行者"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["別雨 - 索瑞森"] = "Default",
		["海雅 - 索瑞森"] = "Default",
	},
	["profiles"] = {
		["WARLOCK"] = {
			["Group"] = {
				["silence"] = false,
				["root"] = false,
				["disarm"] = false,
			},
			["pSetting"] = {
				["pEnable"] = false,
				["pyOfs"] = -38,
				["pxOfs"] = 80,
			},
			["Func"] = {
				["Interrupt"] = false,
			},
			["gSetting"] = {
				["LeftxOfs"] = 19,
				["RightxOfs"] = -18,
				["FrameSize"] = 23,
				["TargetAlpha"] = 0.73,
				["OtherAlpha"] = 0.59,
				["OtherScale"] = 0.65,
				["yOfs"] = 6,
			},
		},
		["Default"] = {
			["gSetting"] = {
				["FrameSize"] = 30,
			},
		},
		["ENNYIN"] = {
			["pSetting"] = {
				["pEnable"] = false,
				["pxOfs"] = 80,
				["pyOfs"] = -38,
			},
			["gSetting"] = {
				["LeftxOfs"] = 19,
				["RightxOfs"] = -7,
				["TargetAlpha"] = 0.73,
				["OtherAlpha"] = 0.59,
				["FrameSize"] = 18,
				["OtherScale"] = 0.65,
			},
			["Group"] = {
				["incapacitate"] = false,
				["disarm"] = false,
				["disorient"] = false,
				["stun"] = false,
				["silence"] = false,
				["root"] = false,
			},
			["Func"] = {
				["Interrupt"] = false,
			},
		},
	},
}
