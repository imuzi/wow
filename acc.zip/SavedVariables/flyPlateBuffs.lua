
flyPlateBuffsDB = {
	["version"] = 2,
	["profileKeys"] = {
		["Ennyin - 索瑞森"] = "Default",
		["云雨別 - 索瑞森"] = "Default",
		["Ennyin - 埃加洛尔"] = "Default",
		["借你流年 - 燃烧之刃"] = "Default",
		["绑住了风 - 索瑞森"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["你诺 - 索瑞森"] = "Default",
		["海雅 - 索瑞森"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["別雨 - 索瑞森"] = "Default",
		["Rainylone - 末日行者"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["sortMode"] = {
				[1.5] = false,
			},
			["yOffset"] = 23,
			["durationPosition"] = 2,
			["colorizeBorder"] = false,
			["showStdCooldown"] = false,
			["showDebuffs"] = 4,
			["font"] = "MSBT ARKai_C",
			["showBuffs"] = 2,
			["Spells"] = {
				["统御魔典"] = {
					["show"] = 5,
					["name"] = "统御魔典",
					["scale"] = 1,
					["durationSize"] = 10,
					["stackSize"] = 10,
				},
			},
			["baseWidth"] = 27,
			["durationSize"] = 13,
			["baseHeight"] = 18,
		},
	},
}
