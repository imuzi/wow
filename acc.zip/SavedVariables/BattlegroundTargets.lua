
BattlegroundTargets_Options = {
	["Enemy"] = {
		["ButtonRangeDisplay"] = {
			[40] = 7,
			[10] = 1,
			[15] = 1,
		},
		["ButtonSortBy"] = {
			[40] = 1,
			[10] = 2,
			[15] = 1,
		},
		["ButtonFocusPosition"] = {
			[40] = 55,
			[10] = 65,
			[15] = 65,
		},
		["ButtonRangeToggle"] = {
			[40] = false,
			[10] = true,
			[15] = true,
		},
		["ButtonShowFTargetCount"] = false,
		["ButtonAssistToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["LayoutTH"] = {
			[40] = 24,
			[10] = 18,
			[15] = 18,
		},
		["ButtonFlagPosition"] = {
			[40] = 100,
			[10] = 30,
			[15] = 55,
		},
		["ButtonSpecToggle"] = {
			[40] = false,
			[10] = true,
			[15] = true,
		},
		["ButtonHealthTextToggle"] = {
			[40] = false,
			[10] = false,
			[15] = true,
		},
		["ButtonAssistPosition"] = {
			[40] = 70,
			[10] = 70,
			[15] = 100,
		},
		["ButtonTargetPosition"] = {
			[40] = 85,
			[10] = 100,
			[15] = 70,
		},
		["LayoutSpace"] = {
			[40] = 0,
			[10] = 0,
			[15] = 0,
		},
		["SummaryScale"] = {
			[40] = 0.5,
			[10] = 0.6,
			[15] = 0.6,
		},
		["SummaryToggle"] = {
			[40] = false,
			[10] = true,
			[15] = false,
		},
		["ButtonToTPosition"] = {
			[40] = 9,
			[10] = 8,
			[15] = 8,
		},
		["ButtonHealthBarToggle"] = {
			[40] = false,
			[10] = true,
			[15] = true,
		},
		["ButtonToTToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonSortDetail"] = {
			[40] = 3,
			[10] = 3,
			[15] = 3,
		},
		["ButtonAssistScale"] = {
			[40] = 1,
			[10] = 1.2,
			[15] = 1.2,
		},
		["EnableBracket"] = {
			[40] = false,
			[10] = true,
			[15] = true,
		},
		["ButtonHeight"] = {
			[40] = 16,
			[10] = 19,
			[15] = 18,
		},
		["ButtonTargetToggle"] = {
			[40] = true,
			[10] = true,
			[15] = true,
		},
		["ButtonScale"] = {
			[40] = 1,
			[10] = 1,
			[15] = 1,
		},
		["ButtonETargetCountToggle"] = {
			[40] = false,
			[10] = true,
			[15] = true,
		},
		["ButtonFontNameSize"] = {
			[40] = 10,
			[10] = 11,
			[15] = 10,
		},
		["ButtonToTScale"] = {
			[40] = 0.6,
			[10] = 0.8,
			[15] = 0.8,
		},
		["ButtonFTargetCountToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonClassToggle"] = {
			[40] = false,
			[10] = true,
			[15] = true,
		},
		["ButtonFontNumberStyle"] = {
			[40] = 1,
			[10] = 1,
			[15] = 1,
		},
		["ButtonFlagToggle"] = {
			[40] = false,
			[10] = true,
			[15] = true,
		},
		["ButtonFocusToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonLeaderToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonPvPTrinketToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonTargetScale"] = {
			[40] = 1,
			[10] = 1.5,
			[15] = 1.5,
		},
		["ButtonRoleToggle"] = {
			[40] = true,
			[10] = true,
			[15] = true,
		},
		["ButtonWidth"] = {
			[40] = 100,
			[10] = 165,
			[15] = 150,
		},
		["ButtonFontNumberSize"] = {
			[40] = 10,
			[10] = 11,
			[15] = 10,
		},
		["ButtonFlagScale"] = {
			[40] = 1,
			[10] = 1.6,
			[15] = 1.2,
		},
		["SummaryPos"] = {
			[40] = 1,
			[10] = 1,
			[15] = 1,
		},
		["ButtonRealmToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonFontNameStyle"] = {
			[40] = 10,
			[10] = 10,
			[15] = 10,
		},
		["ButtonFocusScale"] = {
			[40] = 1,
			[10] = 1,
			[15] = 1,
		},
	},
	["MinimapButton"] = true,
	["version"] = 27,
	["FramePosition"] = {
		["EnemyMainFrame40"] = {
			["y"] = 174.499633789063,
			["x"] = -211,
			["point"] = "RIGHT",
			["s"] = 1,
		},
		["OptionsFrame"] = {
			["y"] = -12.4999656677246,
			["x"] = 65.9999694824219,
			["point"] = "BOTTOMLEFT",
			["s"] = 1,
		},
		["EnemyMainFrame10"] = {
			["y"] = 184.499694824219,
			["x"] = -225.999877929688,
			["point"] = "RIGHT",
			["s"] = 1,
		},
		["EnemyMainFrame15"] = {
			["y"] = 174.499633789063,
			["x"] = -211,
			["point"] = "RIGHT",
			["s"] = 1,
		},
	},
	["MinimapButtonPos"] = -148.298562563501,
	["TransliterationToggle"] = false,
	["Friend"] = {
		["ButtonRangeDisplay"] = {
			[40] = 7,
			[10] = 1,
			[15] = 1,
		},
		["ButtonFTargetCountToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonToTScale"] = {
			[40] = 0.6,
			[10] = 0.8,
			[15] = 0.8,
		},
		["ButtonRangeToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonAssistToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["LayoutTH"] = {
			[40] = 24,
			[10] = 18,
			[15] = 18,
		},
		["ButtonFlagPosition"] = {
			[40] = 100,
			[10] = 60,
			[15] = 60,
		},
		["ButtonSpecToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonHealthTextToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonLeaderToggle"] = {
			[40] = true,
			[10] = true,
			[15] = true,
		},
		["ButtonTargetPosition"] = {
			[40] = 85,
			[10] = 100,
			[15] = 100,
		},
		["LayoutSpace"] = {
			[40] = 0,
			[10] = 0,
			[15] = 0,
		},
		["SummaryScale"] = {
			[40] = 0.5,
			[10] = 0.6,
			[15] = 0.6,
		},
		["SummaryToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonToTPosition"] = {
			[40] = 9,
			[10] = 8,
			[15] = 8,
		},
		["ButtonHealthBarToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonToTToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonSortDetail"] = {
			[40] = 3,
			[10] = 3,
			[15] = 3,
		},
		["ButtonAssistScale"] = {
			[40] = 1,
			[10] = 1.2,
			[15] = 1.2,
		},
		["EnableBracket"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonHeight"] = {
			[40] = 16,
			[10] = 20,
			[15] = 20,
		},
		["ButtonTargetToggle"] = {
			[40] = true,
			[10] = true,
			[15] = true,
		},
		["ButtonRoleToggle"] = {
			[40] = true,
			[10] = true,
			[15] = true,
		},
		["ButtonETargetCountToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonFontNameSize"] = {
			[40] = 10,
			[10] = 12,
			[15] = 12,
		},
		["ButtonWidth"] = {
			[40] = 100,
			[10] = 175,
			[15] = 175,
		},
		["ButtonScale"] = {
			[40] = 1,
			[10] = 1,
			[15] = 1,
		},
		["ButtonClassToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonFontNumberStyle"] = {
			[40] = 1,
			[10] = 1,
			[15] = 1,
		},
		["ButtonFlagToggle"] = {
			[40] = false,
			[10] = true,
			[15] = true,
		},
		["ButtonFontNumberSize"] = {
			[40] = 10,
			[10] = 10,
			[15] = 10,
		},
		["SummaryPos"] = {
			[40] = 1,
			[10] = 1,
			[15] = 1,
		},
		["ButtonPvPTrinketToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonSortBy"] = {
			[40] = 1,
			[10] = 1,
			[15] = 1,
		},
		["ButtonRealmToggle"] = {
			[40] = false,
			[10] = true,
			[15] = true,
		},
		["ButtonAssistPosition"] = {
			[40] = 70,
			[10] = 100,
			[15] = 100,
		},
		["ButtonFocusPosition"] = {
			[40] = 55,
			[10] = 70,
			[15] = 70,
		},
		["ButtonFlagScale"] = {
			[40] = 1,
			[10] = 1.2,
			[15] = 1.2,
		},
		["ButtonFocusToggle"] = {
			[40] = false,
			[10] = false,
			[15] = false,
		},
		["ButtonTargetScale"] = {
			[40] = 1,
			[10] = 1.5,
			[15] = 1.5,
		},
		["ButtonFontNameStyle"] = {
			[40] = 10,
			[10] = 10,
			[15] = 10,
		},
		["ButtonFocusScale"] = {
			[40] = 1,
			[10] = 1,
			[15] = 1,
		},
	},
	["FirstRun"] = true,
}
