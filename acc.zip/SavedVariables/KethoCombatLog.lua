
KethoCombatLogDB = {
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["Ennyin - 埃加洛尔"] = "Default",
		["Rainylone - 末日行者"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["LocalDispel"] = false,
			["IconSize"] = 14,
			["message"] = {
				["CrowdControl"] = "<SPELL><DEST>by<SRC>",
				["Interrupt"] = "<SPELL><XSPELL><DEST>by<SRC>",
				["Juke"] = "<SRC> juked <SPELL> on <DEST> ",
			},
			["LocalCrowdControl"] = true,
			["SpellFilterSelf"] = false,
			["LocalJuke"] = true,
			["LocalDeath"] = false,
			["FilterMonsters"] = false,
			["LocalTaunt"] = false,
			["ChatWindow"] = 1,
			["FilterPets"] = true,
			["sink20ScrollArea"] = "通告信息",
		},
	},
}
