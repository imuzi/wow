
mQuestWatcherDB = {
	["profileKeys"] = {
		["绑住了风 - 索瑞森"] = "Default",
		["Esserbella - 索瑞森"] = "Default",
		["你诺 - 索瑞森"] = "Default",
		["木诺子其 - 索瑞森"] = "Default",
		["別雨 - 索瑞森"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["Point"] = "RIGHT",
			["x"] = -102,
			["Width"] = 259,
			["y"] = 0,
			["RelPoint"] = "CENTER",
			["Height"] = 800,
		},
	},
}
