
SimpleComboPointsDB = nil
