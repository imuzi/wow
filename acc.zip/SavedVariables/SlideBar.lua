
SlideBarConfig = {
	["enabled"] = true,
}
