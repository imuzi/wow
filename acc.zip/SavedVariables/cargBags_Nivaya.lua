
cBnivCfg = {
	["CompressEmpty"] = true,
	["SortBags"] = true,
	["scale"] = 0.8,
	["BankBlack"] = false,
	["Unlocked"] = true,
	["Junk"] = true,
	["CoolStuff"] = false,
	["NewItems"] = true,
	["TradeGoods"] = true,
	["ItemSets"] = true,
	["Armor"] = true,
	["SortBank"] = true,
	["FilterBank"] = true,
	["BankCustomBags"] = false,
}
cB_CustomBags = {
}
cBniv_CatInfo = {
}
