
AucAdvancedStatSimpleData = nil
