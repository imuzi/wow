
ButsuDB = {
	["fontSizeTitle"] = 14,
	["frameScale"] = 0.95,
	["framePosition"] = "TOPLEFTUIParent726419",
}
