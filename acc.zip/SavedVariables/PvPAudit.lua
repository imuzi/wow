
PvPAuditPlayerCache = {
	["Ennyin"] = {
		["localeIndependentClass"] = "WARLOCK",
		["cachedAt"] = 1573060038,
		["5v5"] = {
			["highest"] = "2989",
			["cr"] = 0,
		},
		["2v2"] = {
			["highest"] = "2225",
			["cr"] = 0,
		},
		["achievements"] = {
			["Arena Master"] = true,
		},
		["RBG"] = {
			["highest"] = "2400+",
			["cr"] = 2389,
		},
		["name"] = "Ennyin",
		["3v3"] = {
			["highest"] = "2938",
			["cr"] = 0,
		},
		["realm"] = "",
	},
}
PvPAuditArenaHistory = {
	["Ennyin-索瑞森"] = {
		["players"] = {
			["3v3"] = {
			},
			["2v2"] = {
			},
		},
		["comps"] = {
			["3v3"] = {
			},
			["2v2"] = {
			},
		},
		["opposingComps"] = {
			["3v3"] = {
			},
			["2v2"] = {
			},
		},
		["maps"] = {
			["3v3"] = {
			},
			["2v2"] = {
			},
		},
	},
}
