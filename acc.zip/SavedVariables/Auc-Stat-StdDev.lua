
AucAdvancedStatStdDevData = nil
