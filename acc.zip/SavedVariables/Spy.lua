
SpyDB = {
	["kosData"] = {
		["冰风岗"] = {
			["Horde"] = {
				["Madeep"] = {
				},
			},
		},
		["埃加洛尔"] = {
			["Horde"] = {
				["Ennyin"] = {
				},
			},
		},
		["末日行者"] = {
			["Alliance"] = {
				["Rainylone"] = {
				},
			},
		},
		["燃烧之刃"] = {
			["Horde"] = {
				["借你流年"] = {
				},
			},
		},
		["索瑞森"] = {
			["Horde"] = {
				["Ennyin"] = {
				},
			},
		},
	},
	["removeKOSData"] = {
		["冰风岗"] = {
			["Horde"] = {
			},
		},
		["埃加洛尔"] = {
			["Horde"] = {
			},
		},
		["末日行者"] = {
			["Alliance"] = {
			},
		},
		["燃烧之刃"] = {
			["Horde"] = {
			},
		},
		["索瑞森"] = {
			["Horde"] = {
			},
		},
	},
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "借你流年 - 燃烧之刃",
		["Rainylone - 末日行者"] = "Rainylone - 末日行者",
		["Ennyin - 索瑞森"] = "Ennyin - 索瑞森",
		["Madeep - 冰风岗"] = "Madeep - 冰风岗",
		["Ennyin - 埃加洛尔"] = "Ennyin - 埃加洛尔",
	},
	["profiles"] = {
		["借你流年 - 燃烧之刃"] = {
			["AppendUnitNameCheck"] = true,
			["MainWindow"] = {
				["Position"] = {
					["y"] = 167.9870910644531,
					["x"] = 1157.193969726563,
					["w"] = 160.0000305175781,
					["h"] = 35,
				},
			},
			["Colors"] = {
				["Alert"] = {
					["Stealth Text"] = {
						["a"] = 1,
					},
					["Name Text"] = {
						["a"] = 1,
					},
				},
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitKoSCheck"] = true,
			["EnabledInArenas"] = false,
			["EnabledInBattlegrounds"] = false,
		},
		["Rainylone - 末日行者"] = {
			["AppendUnitNameCheck"] = true,
			["MainWindow"] = {
				["Position"] = {
					["y"] = 166.2853698730469,
					["x"] = 163.0856781005859,
					["w"] = 159.9999847412109,
					["h"] = 34.99999237060547,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitKoSCheck"] = true,
		},
		["Ennyin - 索瑞森"] = {
			["AppendUnitNameCheck"] = true,
			["MainWindow"] = {
				["Position"] = {
					["y"] = 226.9999847412109,
					["x"] = 1084.000244140625,
					["w"] = 159.9999694824219,
					["h"] = 82.99998474121094,
				},
			},
			["Colors"] = {
				["Alert"] = {
					["Stealth Text"] = {
						["a"] = 1,
					},
					["Name Text"] = {
						["a"] = 1,
					},
				},
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitKoSCheck"] = true,
			["EnabledInArenas"] = false,
			["EnabledInBattlegrounds"] = false,
		},
		["Madeep - 冰风岗"] = {
			["AppendUnitNameCheck"] = true,
			["MainWindow"] = {
				["Position"] = {
					["y"] = 259.0852966308594,
					["x"] = 323.0856628417969,
					["w"] = 159.9999694824219,
					["h"] = 35.00000762939453,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitKoSCheck"] = true,
			["EnabledInArenas"] = false,
			["EnabledInBattlegrounds"] = false,
		},
		["Ennyin - 埃加洛尔"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = 187.3336181640625,
					["x"] = 1698.666870117188,
					["w"] = 142.0000305175781,
					["h"] = 179.0000152587891,
				},
			},
			["PurgeData"] = "OneDay",
			["ShareData"] = true,
			["Colors"] = {
				["Alert"] = {
					["Stealth Text"] = {
						["a"] = 1,
					},
					["Name Text"] = {
						["a"] = 1,
					},
					["KOS Text"] = {
						["a"] = 1,
					},
				},
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["ResizeSpyLimit"] = 10,
			["PurgeWinLossData"] = true,
			["MinimapDetection"] = true,
			["AppendUnitNameCheck"] = true,
			["MainWindowVis"] = false,
			["PurgeKoS"] = true,
			["EnableSound"] = false,
			["AppendUnitKoSCheck"] = true,
			["HideSpy"] = true,
		},
	},
}
