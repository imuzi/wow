
jpcbDB = {
	["profileKeys"] = {
		["Ennyin - 埃加洛尔"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
