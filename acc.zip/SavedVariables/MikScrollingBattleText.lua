
MSBTProfiles_SavedVars = {
	["profiles"] = {
		["Default"] = {
			["stickyCritsDisabled"] = true,
			["critFontName"] = "聊天",
			["enableBlizzardDamage"] = true,
			["hideSkills"] = true,
			["shortenNumbers"] = true,
			["textShadowingDisabled"] = true,
			["creationVersion"] = "5.7.149",
			["enableBlizzardHealing"] = true,
			["hideFullOverheals"] = true,
			["events"] = {
				["OUTGOING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["INCOMING_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ITEM_BUFF"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_IMMUNE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_PARRY"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_EVADE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DOT_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_HEAL_CRIT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ALT_POWER_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_MISS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["OUTGOING_HEAL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_HOT_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_EVADE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF_STACK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CHI_FULL"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_PARRY"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_HONOR_GAIN"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_HEAL"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_MISS"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_HEAL_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_AC_FULL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_POWER_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_DODGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_EVADE"] = {
					["disabled"] = true,
				},
				["INCOMING_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_MONSTER_EMOTE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_COMBAT_LEAVE"] = {
					["message"] = "离开战斗",
					["fontSize"] = 26,
					["colorB"] = 0.607843137254902,
					["colorR"] = 0.623529411764706,
				},
				["NOTIFICATION_ITEM_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ENEMY_BUFF"] = {
					["disabled"] = true,
				},
				["OUTGOING_PARRY"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_HOLY_POWER_FULL"] = {
					["disabled"] = true,
				},
				["INCOMING_DODGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CP_GAIN"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DAMAGE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_INTERRUPT"] = {
					["scrollArea"] = "Outgoing",
				},
				["NOTIFICATION_REP_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CHI_CHANGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_HOT_CRIT"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_FADE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_PET_COOLDOWN"] = {
					["message"] = "pet %e ready!",
				},
				["NOTIFICATION_SKILL_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["OUTGOING_EVADE"] = {
					["disabled"] = true,
				},
				["INCOMING_BLOCK"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_HOT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DODGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CP_FULL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_IMMUNE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_AC_CHANGE"] = {
					["disabled"] = true,
				},
				["INCOMING_IMMUNE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_COMBAT_ENTER"] = {
					["message"] = "进入战斗",
					["colorB"] = 0.196078431372549,
					["colorG"] = 0.188235294117647,
					["fontSize"] = 23,
				},
				["NOTIFICATION_PC_KILLING_BLOW"] = {
					["colorB"] = 0.0901960784313726,
					["fontSize"] = 33,
					["colorG"] = 0.0666666666666667,
					["colorR"] = 1,
				},
				["NOTIFICATION_ALT_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DOT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_REP_LOSS"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DODGE"] = {
					["disabled"] = true,
				},
				["INCOMING_MISS"] = {
					["disabled"] = true,
				},
				["OUTGOING_DAMAGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ITEM_COOLDOWN"] = {
					["message"] = " %e ready!",
				},
				["INCOMING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_STACK"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_INTERRUPT"] = {
					["message"] = "interrupted! (%s)",
				},
				["NOTIFICATION_HOLY_POWER_CHANGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_HOT"] = {
					["disabled"] = true,
				},
				["OUTGOING_BLOCK"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_COOLDOWN"] = {
					["message"] = "%e ready!",
				},
				["NOTIFICATION_EXTRA_ATTACK"] = {
					["disabled"] = true,
				},
				["OUTGOING_DEFLECT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_ABSORB"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF"] = {
					["disabled"] = true,
				},
				["INCOMING_PARRY"] = {
					["disabled"] = true,
				},
			},
			["soundsDisabled"] = true,
			["scrollAreas"] = {
				["Incoming"] = {
					["direction"] = "Up",
					["offsetX"] = -551,
					["behavior"] = "MSBT_NORMAL",
					["offsetY"] = 8,
					["animationStyle"] = "Straight",
					["scrollHeight"] = 235,
				},
				["Outgoing"] = {
					["direction"] = "Up",
					["stickyBehavior"] = "Normal",
					["animationSpeed"] = 80,
					["animationStyle"] = "Straight",
					["scrollHeight"] = 65,
					["offsetX"] = 34,
					["behavior"] = "MSBT_NORMAL",
					["iconAlign"] = "Left",
					["offsetY"] = -76,
					["textAlignIndex"] = 2,
					["stickyTextAlignIndex"] = 2,
				},
				["Static"] = {
					["iconAlign"] = "Right",
					["offsetY"] = -133,
					["offsetX"] = -545,
				},
				["Custom1"] = {
					["direction"] = "Left",
					["normalOutlineIndex"] = 3,
					["stickyBehavior"] = "Jiggle",
					["scrollHeight"] = 50,
					["offsetX"] = 40,
					["normalFontAlpha"] = 100,
					["critFontName"] = "聊天",
					["critOutlineIndex"] = 3,
					["animationSpeed"] = 80,
					["critFontAlpha"] = 100,
					["stickyDirection"] = "Up",
					["critFontSize"] = 38,
					["scrollWidth"] = 60,
					["name"] = "KethoCombatLog",
					["normalFontName"] = "MSBT Talisman",
					["behavior"] = "GrowUp",
					["offsetY"] = 148,
					["animationStyle"] = "Horizontal",
					["normalFontSize"] = 26,
				},
				["Notification"] = {
					["direction"] = "Up",
					["normalOutlineIndex"] = 3,
					["stickyBehavior"] = "Normal",
					["stickyDirection"] = "Up",
					["scrollHeight"] = 50,
					["offsetX"] = -81,
					["animationSpeed"] = 80,
					["scrollWidth"] = 80,
					["offsetY"] = 261,
					["normalFontName"] = "聊天",
					["normalFontSize"] = 19,
				},
			},
			["normalFontName"] = "聊天",
			["hideNames"] = true,
			["triggers"] = {
				["Custom2"] = {
					["message"] = "interrupted!",
					["colorR"] = 0.4901960784313725,
					["colorG"] = 0.9882352941176471,
					["colorB"] = 0.2862745098039216,
					["mainEvents"] = "SPELL_INTERRUPT{sourceAffiliation;;eq;;1}",
					["fontSize"] = 26,
				},
			},
		},
	},
}
MSBT_SavedMedia = {
	["fonts"] = {
	},
	["sounds"] = {
	},
}
