
NRunDB_Global = {
	["textureName"] = "Details Vidro",
	["nameFont"] = {
		["alpha"] = 0,
	},
	["timeFont"] = {
		["alpha"] = 0.5,
	},
	["anchors"] = {
		["main"] = {
			["y"] = 200.0012512207031,
			["x"] = -299.4259033203125,
			["point"] = "RIGHT",
			["to"] = "RIGHT",
		},
		["secondary"] = {
			["y"] = -104.5435180664063,
			["x"] = 213.9425354003906,
			["to"] = "LEFT",
			["point"] = "LEFT",
		},
	},
	["cooldownsEnabled"] = false,
	["growth"] = "down",
	["width"] = 80,
	["stackFont"] = {
		["alpha"] = 0,
	},
	["nameplates"] = false,
	["charspec"] = {
	},
	["height"] = 14,
}
NugRunningConfigCustom = {
	["GLOBAL"] = {
		["spells"] = {
			[80353] = {
				["disabled"] = true,
			},
			[297108] = {
				["disabled"] = true,
			},
			[298357] = {
				["disabled"] = true,
			},
			[256740] = {
				["disabled"] = true,
			},
			[295838] = {
				["disabled"] = true,
			},
			[2825] = {
				["disabled"] = true,
			},
			[230935] = {
				["disabled"] = true,
			},
			[299624] = {
				["disabled"] = true,
			},
			[296072] = {
				["disabled"] = true,
			},
			[32182] = {
				["disabled"] = true,
			},
			[264667] = {
				["disabled"] = true,
			},
		},
	},
	["WARLOCK"] = {
		["event_timers"] = {
			[111897] = {
				["disabled"] = true,
			},
			[212619] = {
				["disabled"] = true,
			},
			[119910] = {
				["disabled"] = true,
			},
			[19647] = {
				["disabled"] = true,
			},
			[132409] = {
				["disabled"] = true,
			},
			[111859] = {
				["disabled"] = true,
			},
			[111895] = {
				["disabled"] = true,
			},
			[60478] = {
				["disabled"] = true,
			},
			[221703] = {
				["disabled"] = true,
			},
			[111896] = {
				["disabled"] = true,
			},
			[111898] = {
				["disabled"] = true,
			},
		},
		["spells"] = {
			[104773] = {
				["disabled"] = true,
			},
			[157736] = {
				["nameplates"] = false,
				["ghost"] = 0,
			},
			[221715] = {
				["disabled"] = true,
			},
			[117828] = {
				["disabled"] = true,
				["nameplates"] = true,
			},
			[118699] = {
				["disabled"] = true,
			},
			[80240] = {
				["shine"] = true,
				["shinerefresh"] = true,
				["ghost"] = 0,
			},
			[113858] = {
				["disabled"] = true,
			},
			[111400] = {
				["disabled"] = true,
			},
			[108416] = {
				["disabled"] = true,
			},
			[113860] = {
				["disabled"] = true,
			},
		},
		["cooldowns"] = {
			[17962] = {
				["disabled"] = true,
			},
			[205180] = {
				["disabled"] = true,
			},
			[264119] = {
				["disabled"] = true,
			},
			[196447] = {
				["disabled"] = true,
			},
			[104316] = {
				["disabled"] = true,
			},
			[264106] = {
				["disabled"] = true,
			},
			[264057] = {
				["disabled"] = true,
			},
		},
	},
	["MAGE"] = {
	},
}
