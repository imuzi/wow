
ErrorFilterDB = {
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "Default",
		["Rainylone - 末日行者"] = "Default",
		["Ennyin - 索瑞森"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["Ennyin - 埃加洛尔"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
