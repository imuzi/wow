
SwatterData = {
	["enabled"] = true,
	["warning"] = true,
	["combat"] = false,
	["errors"] = {
		{
			["message"] = "Interface\\AddOns\\AdiBags\\modules\\Junk.lua:246: attempt to call method 'HookScript' (a nil value)",
			["count"] = 1,
			["addons"] = "  Swatter, v8.2.6511 (SwimmingSeadragon)\n  ACP, v3.5.7 \n  AdiBags, vv1.9.18\n  Scrap, v8.3.0\n  BlizRuntimeLib_zhCN v8.3.0.80300 <none>\n  (ck=86)\n",
			["locals"] = "addonName = \"AdiBags\"\naddon = <table> {\n AcquireItemButton = <function> defined @Interface\\AddOns\\AdiBags\\widgets\\ItemButton.lua:155\n modules = <table> {\n }\n UpdateFilters = <function> defined @Interface\\AddOns\\AdiBags\\core\\Filters.lua:83\n SecureHook = <function> defined @Interface\\AddOns\\AdiBags\\libs\\AceHook-3.0\\AceHook-3.0.lua:336\n GetInteractingWindow = <function> defined @Interface\\AddOns\\AdiBags\\core\\Core.lua:451\n ConfigChanged = <function> defined @Interface\\AddOns\\AdiBags\\core\\Core.lua:371\n GetSlotId = <function> defined @Interface\\AddOns\\AdiBags\\core\\Utility.lua:57\n Filter = <function> defined @Interface\\AddOns\\AdiBags\\core\\Filters.lua:144\n IsEnabled = <function> defined @Interface\\AddOns\\AdiBags\\libs\\AceAddon-3.0\\AceAddon-3.0.lua:451\n Reconfigure = <function> defined @Interface\\AddOns\\AdiBags\\core\\Core.lua:183\n SetupTooltip = <function> defined @Interface\\AddOns\\AdiBags\\core\\Utility.lua:114\n RegisterMessage = <function> defined @Interface\\AddOns\\Scrap\\libs\\CallbackHandler-1.0\\CallbackHandler-1.0.lua:90\n UnregisterMessage = <function> defined @Interface\\AddOns\\Scrap\\libs\\CallbackHandler-1.0\\CallbackHandler-1.0.lua:153\n hooks = <table> {\n }\n GetDistinctItemID = <function> defined @Interface\\AddOns\\AdiBags\\core\\Utility.lua:188\n CreateFont = <function> defined @Interface\\AddOns\\AdiBags\\core\\Fonts.lua:122\n filterProto = <table> {\n }\n OpenOptions = <function> defined @Interface\\AddOns\\AdiBags\\core\\Core.lua:289\n SetEnabledState = <function> defined @Interface\\AddOns\\AdiBags\\libs\\AceAddon-3.0\\AceAddon-3.0.lua:424\n Hook = <function> defined @Interface\\AddOns\\AdiBags\\libs\\AceHook-3.0\\AceHook-3.0.lua:274\n IterateBags = <function> defined @Interface\\AddOns\\AdiBags\\core\\Bags.lua:183\n OnEnable = <function> defined @Interface\\AddOns\\AdiBags\\core\\Core.lua:115\n HookBagFrameCreation = <function> defined @Interface\\AddOns\\AdiBags\\core\\Bags.lua:305\n NewBag = <function> defined @Interface\\AddOns\\AdiBags\\core\\Bags.lua:150\n GetClass = <function> defined @Interface\\AddOns\\AdiBags\\core\\OO.lua:129\n RegisterFilter = <function> defined @Interface\\AddOns\\AdiBags\\core\\Filters.lua:120\n BACKDROP = <table> {\n }\n OnInitialize = <function> defined =[C]:-1\n NewModule = <function> defined @Interface\\AddOns\\AdiBags\\libs\\AceAddon-3.0\\AceAddon-3.0.lua:235\n InitializeFilters = <function> defined @Interface\\AddOns\\AdiBags\\core\\Filters.lua:64\n IterateFilters = <function> defined @Interface\\AddOns\\AdiBags\\core\\Filters.lua:116\n ReagentBankUpdated = <function> defined @Interface\\AddOns\\AdiBags\\core\\Core.lua:362\n CreateBagSlotPanel = <function> defined @Interface\\AddOns\\AdiBags\\widgets\\BagSlots.lua:437\n TOP_PADDING = 32\n hookedBags = <table> {\n }\n OpenBag = <function> defined @Interface\\AddOns\\AdiBags\\core\\Hooks.lua:137\n ToggleAllBags = <function> defined @Interface\\AddOns\\AdiBags\\core\\Hooks.lua:86\n OnProfileChanged = <function> defined @Interface\\AddOns\\AdiBags\\core\\Core.lua:191\n GetName = <function> defined @Interface\\AddOns\\AdiBags\\libs\\AceAddon-3.0\\AceAddon-3.0.lua:279\n name = \"AdiBags\"\n OpenBackpack = <function> defined @Interface\\AddOns\\AdiBags\\core\\Hooks.lua:168\n LayoutBags = <function> defined @Interface\\AddOns\\AdiBags\\core\\Layout.lua:101\n Disable = <function> defined @Interface\\AddOns\\AdiBags\\libs\\AceAddon-3.0\\AceAddon-3.0.lua:314\n SetGlobalLock = <function> defined @Interface\\AddOns\\AdiBags\\core\\Core.lua:419\n Unhook = <function> defined @Interface\\AddOns\\AdiBags\\libs\\AceHook-3.0\\AceHook-3.0.lua:418\n Print = <function> defined @Interface\\AddOns\\AdiBags\\libs\\AceConsole-3.0\\AceConsole-3.0.lua:54\n OpenAllBags = <function> defined @Interface\\AddOns\\AdiBags\\core\\Hooks.lua:109\n L = <table> {\n }\n safecall = <function> defined @Interface\\AddOns\\AdiBags\\core\\Utility.lua:81\n Debug = <function> defined @Interface\\AddOns\\AdiBags\\core\\Core.lua:61\n CreateAnchorWidget = <function> defined @Interface\\AddOns\\AdiBags\\widgets\\AnchorWidget.lua:37\n ITEM_SIZE = 37\n DEFAULT_SETTINGS = <table> {\n }\n CreateBagAnchorWidget = <function> defined @Interface\\AddOns\\AdiBags\\widgets\\AnchorWidget.lua:218\n FAMILY_ICONS = <table> {\n }\n UnregisterEvent = <function> defined @Interface",
			["timestamp"] = "2020-02-08 13:26:24",
			["context"] = "Global",
			["stack"] = "[string \"@Interface\\AddOns\\AdiBags\\modules\\Junk.lua\"]:246: in main chunk\n",
		}, -- [1]
		{
			["message"] = "Interface\\AddOns\\Auc-Advanced\\CoreConst.lua:229: attempt to call global 'GetAuctionItemSubClasses' (a nil value)",
			["count"] = 1,
			["addons"] = "  Swatter, v8.2.6511 (SwimmingSeadragon)\n  ACP, v3.5.7 \n  AdiBags, vv1.9.18\n  AdvancedInterfaceOptions, v1.3.4\n  AucAdvanced, v8.2.6471 (SwimmingSeadragon)\n  Scrap, v8.3.0\n  SlideBar, v8.2.6509 (SwimmingSeadragon)\n  Stubby, v8.2.6510 (SwimmingSeadragon)\n  BlizRuntimeLib_zhCN v8.3.0.80300 <none>\n  (ck=128)\n",
			["locals"] = "lib = <table> {\n ENCHANT = 26\n LASTENTRY = 27\n IEQUIP = 5\n MAXSKILLLEVEL = 800\n AMHIGH = 19\n AC_ClassNameList = <table> {\n }\n FACTOR = 25\n MINBID = 15\n FLAG_UNSEEN = 2\n AucMinTimes = <table> {\n }\n FLAG = 21\n FLAG_DIRTY = 64\n CompactRealm = \"索瑞森\"\n ALEVEL_MAX = 5\n EquipEncode = <table> {\n }\n PlayerName = \"Ennyin\"\n MAXITEMLEVEL = 1100\n ITEMID = 23\n PlayerRealm = \"索瑞森\"\n AC_SubClassIDLists = <table> {\n }\n DEP2 = 10\n ISUB = 4\n ALEVEL_HI = 4\n ScanPosLabels = <table> {\n }\n ULEVEL = 14\n BUYOUT = 17\n MAXUSERLEVEL = 120\n AC_ClassIDList = <table> {\n }\n ALEVEL_MED = 3\n ITYPE = 3\n ALEVEL_LOW = 2\n AucTimes = <table> {\n }\n ALEVEL_MIN = 1\n NAME = 9\n FLAG_EXPIRED = 128\n CURBID = 18\n MAXBIDPRICE = 99999999999\n COUNT = 11\n SEED = 27\n SUFFIX = 24\n AC_SubClassNameLists = <table> {\n }\n CANUSE = 13\n SELLER = 20\n LINK = 1\n ILEVEL = 2\n FLAG_FILTER = 4\n TIME = 8\n TLEFT = 7\n BONUSES = 22\n AucMaxTimes = <table> {\n }\n QUALITY = 12\n SUBCLASSID = 4\n ALEVEL_OFF = 0\n MININC = 16\n PRICE = 6\n CLASSID = 3\n}\n(for generator) = <function> defined =[C]:-1\n(for state) = <table> {\n 1 = 2\n 2 = 4\n 3 = 1\n 4 = 3\n 5 = 8\n 6 = 0\n 7 = 16\n 8 = 7\n 9 = 9\n 10 = 17\n 11 = 12\n 12 = 15\n}\n(for control) = 1\nindex = 1\nclassID = 2\n(*temporary) = <table> {\n}\n(*temporary) = nil\n(*temporary) = 2\n(*temporary) = \"attempt to call global 'GetAuctionItemSubClasses' (a nil value)\"\n",
			["timestamp"] = "2020-02-08 13:26:24",
			["context"] = "Global",
			["stack"] = "[string \"@Interface\\AddOns\\Auc-Advanced\\CoreConst.lua\"]:229: in main chunk\n",
		}, -- [2]
		{
			["message"] = "Interface\\AddOns\\Auc-Advanced\\CorePost.lua:1413: Attempt to register unknown event \"NEW_AUCTION_UPDATE\"",
			["count"] = 1,
			["addons"] = "  Swatter, v8.2.6511 (SwimmingSeadragon)\n  ACP, v3.5.7 \n  AdiBags, vv1.9.18\n  AdvancedInterfaceOptions, v1.3.4\n  AucAdvanced, v8.2.6471 (SwimmingSeadragon)\n  Scrap, v8.3.0\n  SlideBar, v8.2.6509 (SwimmingSeadragon)\n  Stubby, v8.2.6510 (SwimmingSeadragon)\n  BlizRuntimeLib_zhCN v8.3.0.80300 <none>\n  (ck=128)\n",
			["locals"] = "(*temporary) = <unnamed> {\n 0 = <userdata>\n}\n(*temporary) = \"NEW_AUCTION_UPDATE\"\n",
			["timestamp"] = "2020-02-08 13:26:24",
			["context"] = "Global",
			["stack"] = "[string \"=[C]\"]: in function `RegisterEvent'\n[string \"@Interface\\AddOns\\Auc-Advanced\\CorePost.lua\"]:1413: in main chunk\n",
		}, -- [3]
		{
			["message"] = "Interface\\AddOns\\Auctionator\\AuctionatorFilters.lua:70: attempt to call global 'GetAuctionItemSubClasses' (a nil value)",
			["count"] = 1,
			["addons"] = "  Swatter, v8.2.6511 (SwimmingSeadragon)\n  ACP, v3.5.7 \n  AdiBags, vv1.9.18\n  AdvancedInterfaceOptions, v1.3.4\n  AucAdvanced, v8.2.6471 (SwimmingSeadragon)\n  AucFilterBasic, v8.2.6497 (SwimmingSeadragon)\n  AucStatHistogram, v8.2.6499 (SwimmingSeadragon)\n  AucStatiLevel, v8.2.6503 (SwimmingSeadragon)\n  AucStatPurchased, v8.2.6500 (SwimmingSeadragon)\n  AucStatSimple, v8.2.6501 (SwimmingSeadragon)\n  AucStatStdDev, v8.2.6502 (SwimmingSeadragon)\n  AucUtilFixAH, v8.2.6504 (SwimmingSeadragon)\n  Auctionator, v8.2.0\n  Scrap, v8.3.0\n  SlideBar, v8.2.6509 (SwimmingSeadragon)\n  Stubby, v8.2.6510 (SwimmingSeadragon)\n  BlizRuntimeLib_zhCN v8.3.0.80300 <none>\n  (ck=28d)\n",
			["locals"] = "classID = 2\nparentName = \"武器\"\nparentKey = \"武器\"\n(*temporary) = <table> {\n}\n(*temporary) = nil\n(*temporary) = 2\n(*temporary) = \"attempt to call global 'GetAuctionItemSubClasses' (a nil value)\"\n",
			["timestamp"] = "2020-02-08 13:26:24",
			["context"] = "Global",
			["stack"] = "[string \"@Interface\\AddOns\\Auctionator\\AuctionatorFilters.lua\"]:70: in function `GenerateSubClasses'\n[string \"@Interface\\AddOns\\Auctionator\\AuctionatorFilters.lua\"]:98: in main chunk\n",
		}, -- [4]
		{
			["message"] = "Interface\\AddOns\\Auctionator\\Auctionator.lua:146: Attempt to register unknown event \"AUCTION_ITEM_LIST_UPDATE\"",
			["count"] = 1,
			["addons"] = "  Swatter, v8.2.6511 (SwimmingSeadragon)\n  ACP, v3.5.7 \n  AdiBags, vv1.9.18\n  AdvancedInterfaceOptions, v1.3.4\n  AucAdvanced, v8.2.6471 (SwimmingSeadragon)\n  AucFilterBasic, v8.2.6497 (SwimmingSeadragon)\n  AucStatHistogram, v8.2.6499 (SwimmingSeadragon)\n  AucStatiLevel, v8.2.6503 (SwimmingSeadragon)\n  AucStatPurchased, v8.2.6500 (SwimmingSeadragon)\n  AucStatSimple, v8.2.6501 (SwimmingSeadragon)\n  AucStatStdDev, v8.2.6502 (SwimmingSeadragon)\n  AucUtilFixAH, v8.2.6504 (SwimmingSeadragon)\n  Auctionator, v8.2.0\n  Scrap, v8.3.0\n  SlideBar, v8.2.6509 (SwimmingSeadragon)\n  Stubby, v8.2.6510 (SwimmingSeadragon)\n  BlizRuntimeLib_zhCN v8.3.0.80300 <none>\n  (ck=28d)\n",
			["locals"] = "(*temporary) = Atr_core {\n 0 = <userdata>\n}\n(*temporary) = \"AUCTION_ITEM_LIST_UPDATE\"\n",
			["timestamp"] = "2020-02-08 13:26:24",
			["context"] = "Global",
			["stack"] = "[string \"=[C]\"]: in function `RegisterEvent'\n[string \"@Interface\\AddOns\\Auctionator\\Auctionator.lua\"]:146: in function `Atr_RegisterEvents'\n[string \"*:OnLoad\"]:1: in function <[string \"*:OnLoad\"]:1>\n",
		}, -- [5]
		{
			["message"] = "Interface\\AddOns\\Auctionator\\AuctionatorHints.lua:505: hooksecurefunc(): SetAuctionItem is not a function",
			["count"] = 1,
			["addons"] = "  Swatter, v8.2.6511 (SwimmingSeadragon)\n  ACP, v3.5.7 \n  AdiBags, vv1.9.18\n  AdvancedInterfaceOptions, v1.3.4\n  AucAdvanced, v8.2.6471 (SwimmingSeadragon)\n  AucFilterBasic, v8.2.6497 (SwimmingSeadragon)\n  AucStatHistogram, v8.2.6499 (SwimmingSeadragon)\n  AucStatiLevel, v8.2.6503 (SwimmingSeadragon)\n  AucStatPurchased, v8.2.6500 (SwimmingSeadragon)\n  AucStatSimple, v8.2.6501 (SwimmingSeadragon)\n  AucStatStdDev, v8.2.6502 (SwimmingSeadragon)\n  AucUtilFixAH, v8.2.6504 (SwimmingSeadragon)\n  Auctionator, v8.2.0\n  Scrap, v8.3.0\n  SlideBar, v8.2.6509 (SwimmingSeadragon)\n  Stubby, v8.2.6510 (SwimmingSeadragon)\n  BlizRuntimeLib_zhCN v8.3.0.80300 <none>\n  (ck=28d)\n",
			["locals"] = "",
			["timestamp"] = "2020-02-08 13:26:24",
			["context"] = "Global",
			["stack"] = "[string \"=[C]\"]: in function `hooksecurefunc'\n[string \"@Interface\\AddOns\\Auctionator\\AuctionatorHints.lua\"]:505: in main chunk\n",
		}, -- [6]
	},
	["autoshow"] = true,
}
