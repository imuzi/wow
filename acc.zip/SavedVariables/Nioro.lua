
NIORO_VARS = {
	["COMPACT_UNIT_FRAME"] = false,
	["COMPACT_FRAME"] = {
		["pet"] = {
			[0] = nil --[[ skipped userdata ]],
			["debuffFrames"] = {
				{
					[0] = nil --[[ skipped userdata ]],
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["border"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [1]
				{
					[0] = nil --[[ skipped userdata ]],
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["border"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [2]
				{
					[0] = nil --[[ skipped userdata ]],
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["border"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [3]
			},
			["maxDispelDebuffs"] = 0,
			["inUse"] = false,
			["inVehicle"] = false,
			["background"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["powerBar"] = {
				[0] = nil --[[ skipped userdata ]],
				["background"] = {
					[0] = nil --[[ skipped userdata ]],
				},
			},
			["healthBar"] = {
				[0] = nil --[[ skipped userdata ]],
				["b"] = 0,
				["background"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["g"] = 1,
				["r"] = 0,
			},
			["overAbsorbGlow"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["horizTopBorder"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["vertRightBorder"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["myHealPrediction"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["aggroHighlight"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["myHealAbsorbRightShadow"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["overHealAbsorbGlow"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["newUnit"] = true,
			["selectionHighlight"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["myHealAbsorbLeftShadow"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["totalAbsorbOverlay"] = {
				[0] = nil --[[ skipped userdata ]],
				["tileSize"] = 32,
			},
			["unitExists"] = false,
			["unusedFunc"] = nil --[[ skipped inline function ]],
			["updateAllEvent"] = "GROUP_ROSTER_UPDATE",
			["statusText"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["horizDivider"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["applyFunc"] = nil --[[ skipped inline function ]],
			["roleIcon"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["menu"] = nil --[[ skipped inline function ]],
			["optionTable"] = {
				["fadeOutOfRange"] = true,
				["displayHealPrediction"] = true,
				["displayAggroHighlight"] = true,
				["displayName"] = true,
				["displaySelectionHighlight"] = true,
			},
			["otherHealPrediction"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["dispelDebuffFrames"] = {
				{
					[0] = nil --[[ skipped userdata ]],
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [1]
				{
					[0] = nil --[[ skipped userdata ]],
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [2]
				{
					[0] = nil --[[ skipped userdata ]],
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [3]
			},
			["buffFrames"] = {
				{
					[0] = nil --[[ skipped userdata ]],
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [1]
				{
					[0] = nil --[[ skipped userdata ]],
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [2]
				{
					[0] = nil --[[ skipped userdata ]],
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [3]
			},
			["maxDebuffs"] = 0,
			["centerStatusIcon"] = {
				[0] = nil --[[ skipped userdata ]],
				["border"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["texture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
			},
			["dropDown"] = {
				[0] = nil --[[ skipped userdata ]],
				["Right"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["Left"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["displayMode"] = "MENU",
				["initialize"] = nil --[[ skipped inline function ]],
				["Button"] = {
					["NormalTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["OnLeave"] = nil --[[ skipped inline function ]],
					["HighlightTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["HandlesGlobalMouseEvent"] = nil --[[ skipped inline function ]],
					["PushedTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["DisabledTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["OnMouseDown"] = nil --[[ skipped inline function ]],
					[0] = nil --[[ skipped userdata ]],
					["OnEnter"] = nil --[[ skipped inline function ]],
					["OnLoad_Intrinsic"] = nil --[[ skipped inline function ]],
				},
				["Icon"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["Middle"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["Text"] = {
					[0] = nil --[[ skipped userdata ]],
				},
			},
			["myHealAbsorb"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["maxBuffs"] = 0,
			["vertLeftBorder"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["horizBottomBorder"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["name"] = {
				[0] = nil --[[ skipped userdata ]],
				["nioro_size"] = 15,
			},
			["readyCheckIcon"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["totalAbsorb"] = {
				[0] = nil --[[ skipped userdata ]],
				["overlay"] = {
					[0] = nil --[[ skipped userdata ]],
					["tileSize"] = 32,
				},
			},
		},
		["player"] = {
			[0] = nil --[[ skipped userdata ]],
			["debuffFrames"] = {
				{
					[0] = nil --[[ skipped userdata ]],
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["maxHeight"] = 11,
					["baseSize"] = 11,
					["border"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [1]
				{
					[0] = nil --[[ skipped userdata ]],
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["maxHeight"] = 11,
					["baseSize"] = 11,
					["border"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [2]
				{
					[0] = nil --[[ skipped userdata ]],
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["maxHeight"] = 11,
					["baseSize"] = 11,
					["border"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [3]
				{
					[0] = nil --[[ skipped userdata ]],
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["maxHeight"] = 11,
					["baseSize"] = 11,
					["border"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
						["noCooldownCount"] = false,
					},
				}, -- [4]
				{
					[0] = nil --[[ skipped userdata ]],
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["maxHeight"] = 11,
					["baseSize"] = 11,
					["border"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
						["noCooldownCount"] = false,
					},
				}, -- [5]
			},
			["BigDebuffs"] = {
				{
					[0] = nil --[[ skipped userdata ]],
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["maxHeight"] = 11,
					["baseSize"] = 11,
					["border"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
						["noCooldownCount"] = false,
					},
				}, -- [1]
				{
					[0] = nil --[[ skipped userdata ]],
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["maxHeight"] = 11,
					["baseSize"] = 11,
					["border"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
						["noCooldownCount"] = false,
					},
				}, -- [2]
			},
			["maxDispelDebuffs"] = 3,
			["inVehicle"] = false,
			["background"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["powerBar"] = {
				[0] = nil --[[ skipped userdata ]],
				["background"] = {
					[0] = nil --[[ skipped userdata ]],
				},
			},
			["hasDispelPoison"] = false,
			["healthBar"] = {
				[0] = nil --[[ skipped userdata ]],
				["b"] = 0.9294097423553467,
				["background"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["g"] = 0.5294106006622314,
				["r"] = 0.5294106006622314,
			},
			["overAbsorbGlow"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["horizTopBorder"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["vertRightBorder"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["myHealPrediction"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["aggroHighlight"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["myHealAbsorbRightShadow"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["overHealAbsorbGlow"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["newUnit"] = true,
			["updateAllEvent"] = "GROUP_ROSTER_UPDATE",
			["selectionHighlight"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["hasDispelDisease"] = false,
			["hasDispelMagic"] = false,
			["myHealAbsorbLeftShadow"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["totalAbsorbOverlay"] = {
				[0] = nil --[[ skipped userdata ]],
				["tileSize"] = 32,
			},
			["unit"] = "player",
			["unitExists"] = true,
			["hasDispelCurse"] = false,
			["statusText"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["horizDivider"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["displayedUnit"] = "player",
			["roleIcon"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["menu"] = nil --[[ skipped inline function ]],
			["optionTable"] = {
				["displayDebuffs"] = true,
				["displayAggroHighlight"] = true,
				["useClassColors"] = true,
				["displayRaidRoleIcon"] = true,
				["displayStatusText"] = true,
				["displayIncomingSummon"] = true,
				["fadeOutOfRange"] = true,
				["allowClassColorsForNPCs"] = true,
				["displayHealPrediction"] = true,
				["displayBuffs"] = true,
				["displayOnlyDispellableDebuffs"] = false,
				["displaySelectionHighlight"] = true,
				["displayInOtherPhase"] = true,
				["displayInOtherGroup"] = true,
				["displayIncomingResurrect"] = true,
				["healthText"] = "none",
				["displayRoleIcon"] = true,
				["displayNonBossDebuffs"] = true,
				["displayDispelDebuffs"] = true,
				["displayName"] = true,
			},
			["otherHealPrediction"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["dispelDebuffFrames"] = {
				{
					[0] = nil --[[ skipped userdata ]],
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [1]
				{
					[0] = nil --[[ skipped userdata ]],
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [2]
				{
					[0] = nil --[[ skipped userdata ]],
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [3]
			},
			["buffFrames"] = {
				{
					[0] = nil --[[ skipped userdata ]],
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
						["_occ_kind"] = "default",
						["_occ_start"] = 1725356.899,
						["_occ_duration"] = 600,
						["_occ_settings"] = {
							["textStyles"] = {
								["soon"] = {
									["scale"] = 1.350000023841858,
								},
								["seconds"] = {
								},
								["minutes"] = {
								},
								["hours"] = {
									["scale"] = 1,
								},
								["charging"] = {
									["r"] = 1,
									["scale"] = 1,
									["g"] = 0.98,
									["b"] = 0.4,
								},
							},
							["fontFace"] = "Fonts\\ARKai_C.TTF",
							["minDuration"] = 3,
							["fontOutline"] = "THICKOUTLINE",
							["effect"] = "shine",
							["spiralOpacity"] = 1.00999997742474,
							["minEffectDuration"] = 2.400000095367432,
							["fontSize"] = 16,
						},
						["_occ_priority"] = 1,
						["_occ_show"] = true,
						["_occ_draw_swipe"] = true,
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [1]
				{
					[0] = nil --[[ skipped userdata ]],
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [2]
				{
					[0] = nil --[[ skipped userdata ]],
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [3]
				{
					[0] = nil --[[ skipped userdata ]],
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [4]
				{
					[0] = nil --[[ skipped userdata ]],
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [5]
				{
					[0] = nil --[[ skipped userdata ]],
					["cooldown"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["icon"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["count"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				}, -- [6]
			},
			["maxDebuffs"] = 3,
			["centerStatusIcon"] = {
				[0] = nil --[[ skipped userdata ]],
				["border"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["texture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
			},
			["dropDown"] = {
				[0] = nil --[[ skipped userdata ]],
				["Right"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["Left"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["displayMode"] = "MENU",
				["initialize"] = nil --[[ skipped inline function ]],
				["Button"] = {
					["NormalTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["OnLeave"] = nil --[[ skipped inline function ]],
					["HighlightTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["HandlesGlobalMouseEvent"] = nil --[[ skipped inline function ]],
					["PushedTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["DisabledTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["OnMouseDown"] = nil --[[ skipped inline function ]],
					[0] = nil --[[ skipped userdata ]],
					["OnEnter"] = nil --[[ skipped inline function ]],
					["OnLoad_Intrinsic"] = nil --[[ skipped inline function ]],
				},
				["Icon"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["Middle"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["Text"] = {
					[0] = nil --[[ skipped userdata ]],
				},
			},
			["myHealAbsorb"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["maxBuffs"] = 3,
			["vertLeftBorder"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["horizBottomBorder"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["name"] = {
				[0] = nil --[[ skipped userdata ]],
				["nioro_size"] = 15,
			},
			["readyCheckIcon"] = {
				[0] = nil --[[ skipped userdata ]],
			},
			["totalAbsorb"] = {
				[0] = nil --[[ skipped userdata ]],
				["overlay"] = {
					[0] = nil --[[ skipped userdata ]],
					["tileSize"] = 32,
				},
			},
		},
	},
}
