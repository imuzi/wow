
bcmDB = {
	["lines"] = {
		["ChatFrame1"] = 1000,
	},
	["playerLBrack"] = "[",
	["v"] = 1,
	["BCM_AutoLog"] = true,
	["stampformat"] = "[%I:%M:%S]",
	["stampcolor"] = "|cff777777",
	["replacements"] = {
		"[GEN]", -- [1]
		"[T]", -- [2]
		"[WD]", -- [3]
		"[LD]", -- [4]
		"[LFG]", -- [5]
		"[GR]", -- [6]
		"[BG]", -- [7]
		"[BGL]", -- [8]
		"[G]", -- [9]
		"[P]", -- [10]
		"[PL]", -- [11]
		"[PL]", -- [12]
		"[O]", -- [13]
		"[R]", -- [14]
		"[RL]", -- [15]
		"[RW]", -- [16]
		"[%1]", -- [17]
	},
	["playerRBrack"] = "]",
	["sticky"] = {
		["EMOTE"] = 1,
		["YELL"] = 1,
	},
	["BCM_PlayerNames"] = true,
	["playerSeparator"] = ":",
}
