
LPSTAT = {
	["沙怒"] = {
		["Eofol"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 2,
		},
	},
	["达文格尔"] = {
		["Lure"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 2300197,
		},
		["Oow"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 0,
		},
	},
	["冰风岗"] = {
		["Ifey"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 0,
		},
		["失重"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 2199198,
		},
	},
	["熊猫酒仙"] = {
		["幽笠巫"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 1003493,
		},
		["Wenderpai"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 0,
		},
	},
	["伊森利恩"] = {
		["Whsi"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 0,
		},
		["Wonderain"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 908,
		},
		["闰汐"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 143241,
		},
	},
	["索瑞森"] = {
		["你诺"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 115305,
		},
		["绑住了风"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 13032151,
		},
		["孤涯"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 17,
		},
		["Rinaly"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 15,
		},
		["撕雨"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 0,
		},
		["Haiya"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 0,
		},
		["木诺子其"] = {
			["AutoSell"] = true,
			["AutoRepair"] = true,
			["Gold"] = 100625044,
		},
		["海雅"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 2991368,
		},
		["画雨"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 452677,
		},
		["云雨別"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 11044444,
		},
		["別雨"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 27955785,
		},
		["Esserbella"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 370010,
		},
	},
	["达尔坎"] = {
		["嘿嘿牛"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 80,
		},
	},
	["夏维安"] = {
		["Boneshoc"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 0,
		},
		["Elytolpain"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 20082864,
		},
		["Ylno"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 1185,
		},
		["Rainylone"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 50,
		},
	},
	["恶魔之翼"] = {
		["浮雲"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 281131,
		},
		["香水般的温柔"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 4424,
		},
		["那片云的味道"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 1979724,
		},
	},
	["JunkIgnore"] = {
	},
	["黑铁"] = {
		["Revp"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 0,
		},
	},
	["无尽之海"] = {
		["失重"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 0,
		},
	},
	["鬼雾峰"] = {
		["我过年好"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 0,
		},
	},
	["燃烧之刃"] = {
		["Sotu"] = {
			["AutoSell"] = true,
			["AutoRepair"] = false,
			["Gold"] = 0,
		},
	},
}
