
AucAdvancedStat_iLevelData = nil
