
AS_Sound = nil
AS_Focus = nil
