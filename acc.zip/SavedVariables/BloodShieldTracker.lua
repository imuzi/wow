
BloodShieldTrackerDB = nil
