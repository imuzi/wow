
BigDebuffsDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Ennyin - 索瑞森"] = "Default",
		["云雨別 - 索瑞森"] = "Default",
		["Ennyin - 埃加洛尔"] = "ENNYIN",
		["借你流年 - 燃烧之刃"] = "Default",
		["绑住了风 - 索瑞森"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["你诺 - 索瑞森"] = "Default",
		["海雅 - 索瑞森"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["別雨 - 索瑞森"] = "Default",
		["Rainylone - 末日行者"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["nameplates"] = {
				["y"] = -1,
				["x"] = -29,
				["size"] = 30,
			},
			["spells"] = {
				[20707] = {
					["nameplates"] = 0,
					["unitFrames"] = 0,
				},
			},
			["raidFrames"] = {
				["anchor"] = "RIGHT",
				["warning"] = 72,
				["increaseBuffs"] = true,
				["enabled"] = false,
			},
			["unitFrames"] = {
				["player"] = {
					["anchor"] = "manual",
					["position"] = {
						"CENTER", -- [1]
						nil, -- [2]
						"CENTER", -- [3]
						46.64357376098633, -- [4]
						21.84201431274414, -- [5]
					},
					["size"] = 68,
				},
				["pet"] = {
					["anchor"] = "manual",
					["position"] = {
						"CENTER", -- [1]
						nil, -- [2]
						"CENTER", -- [3]
						-21.60633087158203, -- [4]
						166.0785675048828, -- [5]
					},
				},
				["arena1"] = {
				},
			},
		},
		["ENNYIN"] = {
			["raidFrames"] = {
				["cc"] = 90,
				["interrupts"] = 100,
				["anchor"] = "RIGHT",
				["increaseBuffs"] = true,
				["warning"] = 100,
				["dispellable"] = {
					["cc"] = 87,
				},
			},
			["nameplates"] = {
				["size"] = 24,
				["y"] = 5,
				["x"] = -29,
			},
			["spells"] = {
				[20707] = {
					["nameplates"] = 0,
					["unitFrames"] = 0,
				},
			},
			["unitFrames"] = {
				["arena1"] = {
				},
				["pet"] = {
					["anchor"] = "manual",
					["position"] = {
						"CENTER", -- [1]
						nil, -- [2]
						"CENTER", -- [3]
						-49.16184234619141, -- [4]
						165.1896362304688, -- [5]
					},
				},
				["player"] = {
					["anchor"] = "manual",
					["position"] = {
						"CENTER", -- [1]
						nil, -- [2]
						"CENTER", -- [3]
						45.75465774536133, -- [4]
						12.06425285339356, -- [5]
					},
					["size"] = 51,
				},
			},
		},
	},
}
