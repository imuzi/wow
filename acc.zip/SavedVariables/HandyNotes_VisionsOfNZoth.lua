
HandyNotes_VisionsOfNZothDB = {
	["profileKeys"] = {
		["Madeep - 冰风岗"] = "Default",
		["Ennyin - 索瑞森"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
