
combusettingstable = {
	["combuignitereport"] = true,
	["combutrack"] = true,
	["combuflamestrike"] = true,
	["combuffb"] = false,
	["combureport"] = true,
	["bgcolorcombustion"] = {
		0, -- [1]
		0.7, -- [2]
		0, -- [3]
		0.5, -- [4]
	},
	["bgcolorimpact"] = {
		1, -- [1]
		0.82, -- [2]
		0, -- [3]
		0.5, -- [4]
	},
	["tileSize"] = 16,
	["textcolorvalid"] = {
		0, -- [1]
		1, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["language"] = "Default",
	["insets"] = 5,
	["combuimpact"] = true,
	["tile"] = true,
	["combuignitedelta"] = 0,
	["combusoundname"] = "CombustionHelper Volcano",
	["edgecolornormal"] = {
		0.67, -- [1]
		0.67, -- [2]
		0.67, -- [3]
		1, -- [4]
	},
	["combufadeinspeed"] = 2,
	["combulbup"] = true,
	["combuautohide"] = 1,
	["combufontname"] = "Friz Quadrata TT",
	["combuafterfade"] = 15,
	["combubarwidth"] = 24,
	["barcolorwarning"] = {
		1, -- [1]
		0, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["combubeforefade"] = 15,
	["combufadeoutspeed"] = 2,
	["combubartimers"] = false,
	["combureportmunching"] = true,
	["textcolornormal"] = {
		1, -- [1]
		1, -- [2]
		1, -- [3]
		1, -- [4]
	},
	["comburefreshmode"] = true,
	["textcolorwarning"] = {
		1, -- [1]
		0, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["barcolornormal"] = {
		0, -- [1]
		0.5, -- [2]
		0.8, -- [3]
		1, -- [4]
	},
	["combuscale"] = 1.360000014305115,
	["combureportvalue"] = 0,
	["combufadealpha"] = 0,
	["combulbtarget"] = true,
	["edgeFile"] = "Blizzard Tooltip",
	["combucrit"] = true,
	["bgcolornormal"] = {
		0.25, -- [1]
		0.25, -- [2]
		0.25, -- [3]
		1, -- [4]
	},
	["edgeSize"] = 16,
	["combulbdown"] = false,
	["combureportthreshold"] = false,
	["buttontexturevalid"] = "InterfaceAddOnsCombustionHelperImagesCombustionon",
	["bgFile"] = "Blizzard Tooltip",
	["combuignitepredict"] = true,
	["combutimervalue"] = 2,
	["combulbright"] = false,
	["combubafterfade"] = 15,
	["combulock"] = false,
	["combureportpyro"] = true,
	["buttontexturewarning"] = "InterfaceAddOnsCombustionHelperImagesCombustionoff",
	["combutexturename"] = "CombuBar",
	["combulbleft"] = false,
	["combuwaitfade"] = 86,
	["combuchat"] = true,
	["thresholdalert"] = true,
	["combulbtracker"] = true,
}
