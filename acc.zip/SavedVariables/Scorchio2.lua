
Scorchio2DB = {
	["profiles"] = {
		["Default"] = {
		},
	},
	["profileKeys"] = {
		["別雨 - 索瑞森"] = "Default",
	},
	["dbversion"] = 2,
}
