
EA_Config = {
	["ShowFlash"] = false,
	["ShowTimer"] = true,
	["AlertSound"] = 568154,
	["ChangeTimer"] = false,
	["DoAlertSound"] = true,
	["Debug"] = false,
	["AlertSoundText"] = "Shay's Bell",
	["VersionText"] = "8.2.5",
	["DoDoom"] = true,
	["Version"] = 825,
	["ShowStacks"] = true,
	["ShowFrame"] = true,
	["ShowName"] = true,
	["AllowESC"] = false,
	["ShowSpellInfo"] = false,
}
EA_Position = {
	["xOffset"] = 0,
	["xLoc"] = -346.6847229003906,
	["LockFrame"] = false,
	["relativePoint"] = "RIGHT",
	["Anchor"] = "RIGHT",
	["yLoc"] = -210.2859649658203,
	["IconSize"] = 60,
	["yOffset"] = 0,
}
EA_Items = {
	["DEATHKNIGHT"] = {
		[81340] = true,
		[51124] = true,
		[59052] = true,
		[81141] = true,
		[101568] = false,
	},
	["WARRIOR"] = {
		[32216] = true,
		[202573] = true,
		[206316] = true,
		[122510] = true,
		[184362] = false,
		[202574] = true,
		[60503] = true,
		[215570] = true,
		[52437] = true,
	},
	["PALADIN"] = {
		[267611] = true,
		[281178] = false,
		[223819] = true,
		[197561] = false,
		[54149] = true,
		[85416] = true,
	},
	["MAGE"] = {
		[48107] = true,
		[190446] = true,
		[48108] = true,
	},
	["PRIEST"] = {
		[124430] = true,
	},
	["HUNTER"] = {
		[260395] = true,
		[185791] = true,
		[259285] = true,
		[190931] = true,
		[269576] = true,
		[194594] = true,
		[268552] = true,
	},
	["WARLOCK"] = {
		[117828] = true,
		[88448] = true,
		[17941] = true,
	},
	["DEMONHUNTER"] = {
	},
	["ROGUE"] = {
		[199600] = false,
		[193357] = false,
		[193358] = false,
		[195627] = true,
		[199603] = false,
		[193359] = false,
	},
	["DRUID"] = {
		[16870] = true,
		[93622] = true,
		[213680] = true,
		[213708] = true,
		[69369] = true,
		[93400] = true,
		[114108] = true,
	},
	["MONK"] = {
		[116768] = true,
	},
	["SHAMAN"] = {
		[215785] = true,
		[201846] = true,
		[77762] = true,
	},
}
EA_AltItems = {
	["DEATHKNIGHT"] = {
		[63560] = true,
	},
	["WARRIOR"] = {
		[5308] = true,
		[85288] = true,
		[6572] = true,
		[23922] = true,
		[167105] = true,
		[184367] = true,
	},
	["PALADIN"] = {
		[24275] = true,
		[184575] = true,
		[31935] = true,
	},
	["MAGE"] = {
	},
	["PRIEST"] = {
		[32379] = true,
	},
	["HUNTER"] = {
	},
	["WARLOCK"] = {
		[17877] = true,
	},
	["DEMONHUNTER"] = {
	},
	["ROGUE"] = {
	},
	["DRUID"] = {
	},
	["MONK"] = {
	},
	["SHAMAN"] = {
		[8042] = true,
	},
}
EA_StackingItems = {
	["DEATHKNIGHT"] = {
	},
	["WARRIOR"] = {
		[131116] = true,
		[206333] = true,
		[85739] = true,
	},
	["PALADIN"] = {
		[271581] = true,
		[114250] = true,
		[269571] = false,
		[85247] = true,
	},
	["MAGE"] = {
		[79683] = true,
		[44544] = true,
		[36032] = true,
	},
	["PRIEST"] = {
		[114255] = true,
		[87160] = true,
		[199412] = true,
	},
	["HUNTER"] = {
		[260242] = true,
		[260286] = true,
		[201081] = true,
		[259388] = true,
		[193534] = true,
	},
	["WARLOCK"] = {
		[80240] = true,
		[138556] = true,
	},
	["DEMONHUNTER"] = {
	},
	["ROGUE"] = {
		[193538] = true,
		[64385] = true,
	},
	["DRUID"] = {
		[114302] = true,
		[64385] = true,
	},
	["MONK"] = {
		[196745] = true,
		[128939] = true,
	},
	["SHAMAN"] = {
		[53390] = true,
		[89631] = true,
	},
}
EA_StackingItemsCounts = {
	["DEATHKNIGHT"] = {
	},
	["WARRIOR"] = {
		[131116] = 1,
		[206333] = 3,
		[85739] = 3,
	},
	["PALADIN"] = {
		[271581] = 4,
		[114250] = 4,
		[269571] = 1,
		[85247] = 3,
	},
	["MAGE"] = {
		[79683] = 1,
		[44544] = 1,
		[36032] = 4,
	},
	["PRIEST"] = {
		[114255] = 1,
		[87160] = 1,
		[199412] = 90,
	},
	["HUNTER"] = {
		[260242] = 1,
		[260286] = 1,
		[201081] = 1,
		[259388] = 1,
		[193534] = 1,
	},
	["WARLOCK"] = {
		[80240] = 1,
		[138556] = 4,
	},
	["DEMONHUNTER"] = {
	},
	["ROGUE"] = {
		[193538] = 1,
		[64385] = 5,
	},
	["DRUID"] = {
		[114302] = 85,
		[64385] = 5,
	},
	["MONK"] = {
		[196745] = 4,
		[128939] = 15,
	},
	["SHAMAN"] = {
		[53390] = 1,
		[89631] = 90,
	},
}
EA_CustomItems = {
	["DEATHKNIGHT"] = {
	},
	["WARRIOR"] = {
	},
	["PALADIN"] = {
	},
	["MAGE"] = {
	},
	["PRIEST"] = {
	},
	["HUNTER"] = {
	},
	["WARLOCK"] = {
	},
	["DEMONHUNTER"] = {
	},
	["ROGUE"] = {
	},
	["DRUID"] = {
	},
	["MONK"] = {
	},
	["SHAMAN"] = {
	},
}
