
RangeDisplayDB3 = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Haiya - 索瑞森"] = "Default",
		["Whsi - 伊森利恩"] = "Default",
		["云雨別 - 索瑞森"] = "Default",
		["Ennysoul - 索瑞森"] = "Default",
		["Boneshoc - 夏维安"] = "Default",
		["额为我 - 战歌"] = "Default",
		["那片云的味道 - 恶魔之翼"] = "Default",
		["幽笠巫 - 熊猫酒仙"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["Lure - 达文格尔"] = "Default",
		["Sotu - 燃烧之刃"] = "Default",
		["Ennyin - 索瑞森"] = "Default",
		["Rinaly - 索瑞森"] = "Default",
		["Oow - 达文格尔"] = "Default",
		["Nuc - 阿拉希"] = "Default",
		["Rainylone - 夏维安"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["木诺子其 - 索瑞森"] = "Default",
		["Eofol - 沙怒"] = "Default",
		["Revp - 黑铁"] = "Default",
		["撕雨 - 索瑞森"] = "Default",
		["Ifey - 冰风岗"] = "Default",
		["嘿嘿牛 - 达尔坎"] = "Default",
		["Wonderain - 伊森利恩"] = "Default",
		["香水般的温柔 - 恶魔之翼"] = "Default",
		["Ennyin - 埃加洛尔"] = "ENNYIN",
		["失重 - 无尽之海"] = "Default",
		["Ylno - 夏维安"] = "Default",
		["Esserbella - 索瑞森"] = "Default",
		["你诺 - 索瑞森"] = "Default",
		["Ennyin - 提瑞斯法"] = "Default",
		["孤涯 - 索瑞森"] = "Default",
		["绑住了风 - 恶魔之翼"] = "Default",
		["借你流年 - 燃烧之刃"] = "Default",
		["失重 - 冰风岗"] = "Default",
		["闰汐 - 伊森利恩"] = "Default",
		["海雅 - 索瑞森"] = "Default",
		["绑住了风 - 索瑞森"] = "Default",
		["Wenderpai - 熊猫酒仙"] = "Default",
		["我过年好 - 鬼雾峰"] = "Default",
		["Elytolpain - 夏维安"] = "Default",
		["画雨 - 索瑞森"] = "Default",
		["別雨 - 索瑞森"] = "Default",
		["Rainylone - 末日行者"] = "Default",
	},
	["profiles"] = {
		["ENNYIN"] = {
			["locked"] = true,
			["units"] = {
				["pet"] = {
				},
				["playertarget"] = {
					["fontSize"] = 14,
					["point"] = "BOTTOM",
					["font"] = "MSBT ARKai_C",
					["enemyOnly"] = true,
					["warnEnemyOnly"] = false,
					["overLimitDisplay"] = true,
					["y"] = 198.6170196533203,
					["x"] = 195.4805145263672,
					["relPoint"] = "BOTTOM",
					["crSection"] = {
						["warnSound"] = false,
						["warnSoundName"] = "Fel Nova",
						["range"] = 8,
					},
				},
				["focus"] = {
					["x"] = -283.6144409179688,
					["fontSize"] = 18,
					["point"] = "TOP",
					["fontOutline"] = "OUTLINE",
					["frameHeight"] = 45,
					["overLimitDisplay"] = true,
					["checkVisible"] = false,
					["y"] = -199.2456970214844,
					["relPoint"] = "TOP",
					["strata"] = "HIGH",
					["font"] = "MSBT ARKai_C",
					["frameWidth"] = 132,
				},
				["arena2"] = {
				},
				["mouseover"] = {
					["fontOutline"] = "THICKOUTLINE",
					["y"] = -0.9423214197158813,
					["x"] = 45.46783447265625,
					["fontSize"] = 23,
					["enemyOnly"] = true,
					["checkVisible"] = false,
				},
				["arena5"] = {
				},
				["arena4"] = {
				},
			},
		},
		["WARLOCK"] = {
			["units"] = {
				["arena2"] = {
				},
				["focus"] = {
				},
				["arena5"] = {
				},
				["pet"] = {
				},
				["arena4"] = {
				},
			},
		},
		["Default"] = {
			["locked"] = true,
			["units"] = {
				["arena2"] = {
				},
				["playertarget"] = {
					["fontSize"] = 19,
					["point"] = "BOTTOM",
					["overLimitDisplay"] = true,
					["y"] = 198.6170196533203,
					["font"] = "MSBT ARKai_C",
					["warnEnemyOnly"] = false,
					["x"] = 195.4805145263672,
					["enemyOnly"] = true,
					["relPoint"] = "BOTTOM",
					["crSection"] = {
						["warnSound"] = false,
						["warnSoundName"] = "Fel Nova",
						["range"] = 8,
					},
				},
				["focus"] = {
					["fontSize"] = 18,
					["point"] = "TOP",
					["overLimitDisplay"] = true,
					["checkVisible"] = false,
					["y"] = -199.2456970214844,
					["font"] = "MSBT ARKai_C",
					["frameHeight"] = 45,
					["fontOutline"] = "OUTLINE",
					["relPoint"] = "TOP",
					["strata"] = "HIGH",
					["frameWidth"] = 132,
					["x"] = -283.6144409179688,
				},
				["pet"] = {
				},
				["mouseover"] = {
					["y"] = 31.05770874023438,
					["x"] = 29.46792793273926,
					["enemyOnly"] = true,
				},
				["arena5"] = {
				},
				["arena4"] = {
				},
			},
		},
		["Ennyin - 索瑞森"] = {
			["units"] = {
				["arena2"] = {
				},
				["focus"] = {
				},
				["arena5"] = {
				},
				["pet"] = {
				},
				["arena4"] = {
				},
			},
		},
	},
}
