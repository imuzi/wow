
DraenorTreasuresDB = {
	["profileKeys"] = {
		["Esserbella - 索瑞森"] = "Default",
		["Ennyin - 索瑞森"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
