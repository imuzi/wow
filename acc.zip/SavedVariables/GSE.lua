
GSEOptions = {
	["HideLoginMessage"] = false,
	["use1"] = false,
	["KEYWORD"] = "|cff88bbdd",
	["Updated801"] = true,
	["use2"] = false,
	["STANDARDFUNCS"] = "|cff55ddcc",
	["showGSEUsers"] = false,
	["UnfoundSpellIDs"] = {
	},
	["saveAllMacrosLocal"] = true,
	["COMMENT"] = "|cff55cc55",
	["use14"] = false,
	["use11"] = false,
	["NUMBER"] = "|cffffaa00",
	["EQUALS"] = "|cffccddee",
	["autoCreateMacroStubsClass"] = true,
	["sendDebugOutputToChatWindow"] = false,
	["Update2305"] = true,
	["use12"] = false,
	["debug"] = false,
	["use6"] = false,
	["CONCAT"] = "|cffcc7777",
	["CommandColour"] = "|cFF00FF00",
	["UNKNOWN"] = "|cffff6666",
	["DisabledSequences"] = {
	},
	["AddInPacks"] = {
		["Samples"] = {
			["Version"] = "2.5.11",
			["Name"] = "Samples",
			["SequenceNames"] = {
				"Assorted Sample Macros", -- [1]
			},
		},
	},
	["AuthorColour"] = "|cFF00D1FF",
	["autoCreateMacroStubsGlobal"] = false,
	["PromptSample"] = true,
	["clearUIErrors"] = false,
	["sendDebugOutputToDebugOutput"] = false,
	["hideSoundErrors"] = false,
	["ErroneousSpellID"] = {
	},
	["useTranslator"] = false,
	["STRING"] = "|cff888888",
	["requireTarget"] = false,
	["INDENT"] = "|cffccaa88",
	["Update2411"] = true,
	["TitleColour"] = "|cFFFF0000",
	["hideUIErrors"] = false,
	["initialised"] = true,
	["Update2415"] = true,
	["DebugModules"] = {
		["Translator"] = false,
		["GUI"] = false,
		["Storage"] = false,
		["Editor"] = false,
		["API"] = false,
		["Versions"] = false,
		["Viewer"] = false,
		["Transmission"] = false,
	},
	["resetOOC"] = true,
	["MacroResetModifiers"] = {
		["Alt"] = false,
		["LeftControl"] = false,
		["LeftButton"] = false,
		["LeftAlt"] = false,
		["RightAlt"] = false,
		["RightButton"] = false,
		["Button4"] = false,
		["Button5"] = false,
		["MiddleButton"] = false,
		["RightControl"] = false,
		["Control"] = false,
		["Shift"] = false,
		["LeftShift"] = false,
		["AnyMod"] = false,
		["RightShift"] = false,
	},
	["filterList"] = {
		["Spec"] = true,
		["Class"] = true,
		["Global"] = true,
		["All"] = false,
	},
	["EmphasisColour"] = "|cFFFFFF00",
	["UseVerboseExportFormat"] = false,
	["WOWSHORTCUTS"] = "|cffddaaff",
	["RealtimeParse"] = false,
	["deleteOrphansOnLogout"] = false,
	["Update2410"] = true,
	["UnfoundSpells"] = {
		["Corruption"] = true,
		["Power Siphon"] = true,
		["Hand of Gul'dan"] = true,
		["Soul Strike"] = true,
		["Unstable Affliction"] = true,
		["Summon Demonic Tyrant"] = true,
		["Agony"] = true,
		["Channel Demonfire"] = true,
		["卡洛斯的著名帽子"] = true,
		["Phantom Singularity"] = true,
		["ShadowBolt"] = true,
		["Call Dreadstalkers"] = true,
		["Demonbolt"] = true,
	},
	["overflowPersonalMacros"] = false,
	["DebugPrintModConditionsOnKeyPress"] = false,
	["showMiniMap"] = {
		["hide"] = false,
	},
	["ActiveSequenceVersions"] = {
	},
	["DefaultDisabledMacroIcon"] = "Interface\\Icons\\INV_MISC_BOOK_08",
	["use13"] = false,
	["NormalColour"] = "|cFFFFFFFF",
	["CreateGlobalButtons"] = false,
	["showGSEoocqueue"] = true,
	["setDefaultIconQuestionMark"] = true,
	["UseWLMExportFormat"] = true,
	["DefaultImportAction"] = "MERGE",
}
GSELibrary = {
	[0] = {
	},
	[9] = {
		["DESTRO"] = {
			["Talents"] = "1,1,1,2,3,1,1",
			["Heroic"] = 1,
			["ManualIntervention"] = false,
			["Dungeon"] = 1,
			["Party"] = 1,
			["Raid"] = 1,
			["Timewalking"] = 1,
			["PVP"] = 1,
			["GSEVersion"] = "2405",
			["EnforceCompatability"] = true,
			["MacroVersions"] = {
				{
					"/castsequence [nochanneling] 348, 29722, 29722, 29722", -- [1]
					"/cast [nochanneling] 104773", -- [2]
					["KeyRelease"] = {
						"/cast [nochanneling] 17962", -- [1]
						"/cast [nochanneling] 113858", -- [2]
					},
					["LoopLimit"] = "1",
					["PostMacro"] = {
					},
					["Trinket2"] = true,
					["Trinket1"] = true,
					["KeyPress"] = {
						"/targetenemy [noharm][dead]", -- [1]
						"/cast [mod:shift,nochanneling,@cursor] 152108", -- [2]
						"/cast [mod:alt,nochanneling] 116858", -- [3]
						"/cast [mod:ctrl,nochanneling,@cursor] 1122", -- [4]
					},
					["PreMacro"] = {
						"/cast [nochanneling] 17962", -- [1]
						"/cast [nochanneling] 113858", -- [2]
					},
					["StepFunction"] = "Sequential",
				}, -- [1]
			},
			["Default"] = 1,
			["MythicPlus"] = 1,
			["SpecID"] = 267,
			["Arena"] = 1,
			["Mythic"] = 1,
			["Author"] = "Affloid@Frostmourne",
		},
		["SAM_DEMO"] = {
			["Talents"] = "1111311",
			["Default"] = 1,
			["MacroVersions"] = {
				{
					"/cast Soul Strike", -- [1]
					"/cast Call Dreadstalkers", -- [2]
					"/cast 29722", -- [3]
					"/cast Hand of Gul'dan", -- [4]
					"/cast Hand of Gul'dan", -- [5]
					"/cast Power Siphon", -- [6]
					["KeyRelease"] = {
					},
					["StepFunction"] = "Sequential",
					["Combat"] = true,
					["PostMacro"] = {
					},
					["PreMacro"] = {
					},
					["KeyPress"] = {
						"/cast [mod:shift] Demonbolt", -- [1]
						"/cast [mod:ctrl] Summon Demonic Tyrant", -- [2]
						"/petattack [exists]", -- [3]
					},
				}, -- [1]
			},
			["Author"] = "Cymiric",
			["SpecID"] = 266,
			["ManualIntervention"] = false,
		},
		["SAM_AFFLOCK"] = {
			["Default"] = 1,
			["Talents"] = "3111113",
			["Help"] = "Affliction - Talents are 3111113",
			["SpecID"] = 265,
			["MacroVersions"] = {
				{
					"/castsequence [nochanneling] reset=target/10  Agony, Corruption", -- [1]
					"/cast [combat,nochanneling] Unstable Affliction", -- [2]
					"/cast ShadowBolt", -- [3]
					["PostMacro"] = {
					},
					["StepFunction"] = "Sequential",
					["KeyPress"] = {
					},
					["PreMacro"] = {
					},
					["KeyRelease"] = {
						"/cast [combat,nochanneling] Phantom Singularity", -- [1]
					},
				}, -- [1]
			},
			["Author"] = "Cacey@The Venture Co",
			["Icon"] = "",
			["ManualIntervention"] = false,
		},
		["NEW_SEQUENCE"] = {
			["Talents"] = "1113223",
			["Default"] = 1,
			["Author"] = "Ennyin@索瑞森",
			["SpecID"] = 267,
			["MacroVersions"] = {
				{
					"/castsequence [@cursor] 1122, 296208, 5740, 5740", -- [1]
					"/cast 296208", -- [2]
					["LoopLimit"] = "",
					["PostMacro"] = {
					},
					["KeyPress"] = {
					},
					["StepFunction"] = "Priority",
					["PreMacro"] = {
					},
					["KeyRelease"] = {
					},
				}, -- [1]
			},
			["ManualIntervention"] = true,
		},
		["献祭大灾变"] = {
			["Talents"] = "1123223",
			["Default"] = 1,
			["Author"] = "Ennyin@索瑞森",
			["SpecID"] = 267,
			["MacroVersions"] = {
				{
					"/cast 152108", -- [1]
					"/cast [@mouseover,harm,exists] 348; 348", -- [2]
					["PostMacro"] = {
					},
					["StepFunction"] = "Sequential",
					["KeyRelease"] = {
					},
					["PreMacro"] = {
						"/clearfocus [@focus,noharm]", -- [1]
						"/focus [@focus,noexists]", -- [2]
						"/clearfocus [@focus,dead]", -- [3]
						"/cancelAura 卡洛斯的著名帽子", -- [4]
						"/PETATTACK [@focus,exists];petattack [@mouseover,exists];petattack [@target]", -- [5]
					},
					["KeyPress"] = {
					},
				}, -- [1]
			},
			["ManualIntervention"] = true,
		},
		["SAM_DESTRO"] = {
			["Talents"] = "2212122",
			["Default"] = 1,
			["Author"] = "Cymiryc",
			["SpecID"] = 267,
			["MacroVersions"] = {
				{
					"/cast [nochanneling] 29722", -- [1]
					"/cast [nochanneling] 29722", -- [2]
					"/cast [nochanneling] 17962", -- [3]
					"/cast [nochanneling] 29722", -- [4]
					"/cast [nochanneling] Channel Demonfire", -- [5]
					["LoopLimit"] = "1",
					["Combat"] = true,
					["StepFunction"] = "Sequential",
					["KeyPress"] = {
						"/cast [mod:shift] 116858", -- [1]
						"/cast [mod:ctrl,@cursor] 5740", -- [2]
					},
					["PostMacro"] = {
					},
					["PreMacro"] = {
						"/castsequence [nochanneling] reset=target  348", -- [1]
					},
					["KeyRelease"] = {
					},
				}, -- [1]
			},
			["ManualIntervention"] = true,
		},
	},
	[8] = {
		["SAM_FROST"] = {
			["Default"] = 1,
			["Talents"] = "2311121",
			["Help"] = "Don't know what i am doing",
			["SpecID"] = 64,
			["Author"] = "Cymiric",
			["MacroVersions"] = {
				{
					"/cast 84714", -- [1]
					"/cast 12472", -- [2]
					"/cast Ebonbolt", -- [3]
					"/cast 116", -- [4]
					["Combat"] = true,
					["StepFunction"] = "Priority",
					["KeyPress"] = {
						"/targetenemy [noharm][dead]", -- [1]
						"/cast [mod:shift] 44614", -- [2]
						"/cast [mod:ctrl] 30455", -- [3]
					},
					["PostMacro"] = {
					},
					["PreMacro"] = {
					},
					["KeyRelease"] = {
					},
				}, -- [1]
			},
			["Icon"] = "",
			["ManualIntervention"] = false,
		},
		["NEW_SEQUENCE"] = {
			["Talents"] = "3211333",
			["Default"] = 1,
			["Author"] = "Madeep@冰风岗",
			["SpecID"] = 63,
			["MacroVersions"] = {
				{
					"/cast 108853", -- [1]
					"/cast 108853", -- [2]
					"/cast 11366", -- [3]
					"/cast 108853", -- [4]
					"/cast 108853", -- [5]
					"/cast 11366", -- [6]
					["PostMacro"] = {
					},
					["KeyPress"] = {
					},
					["PreMacro"] = {
					},
					["StepFunciton"] = "Sequential",
					["KeyRelease"] = {
					},
				}, -- [1]
			},
			["ManualIntervention"] = false,
		},
		["SAM_ARCANE"] = {
			["Talents"] = "3313113",
			["Default"] = 1,
			["MacroVersions"] = {
				{
					"/cast 30451", -- [1]
					"/cast 30451", -- [2]
					"/cast 30451", -- [3]
					"/cast 30451", -- [4]
					"/cast 44425", -- [5]
					"/cast 153626", -- [6]
					"/cast 157980", -- [7]
					["Combat"] = true,
					["KeyPress"] = {
						"/cast [mod:shift] 5143", -- [1]
					},
					["PostMacro"] = {
					},
					["StepFunction"] = "Sequential",
					["PreMacro"] = {
					},
					["KeyRelease"] = {
					},
				}, -- [1]
			},
			["Author"] = "Cymiric",
			["SpecID"] = 62,
			["ManualIntervention"] = false,
		},
	},
}
