
g_auctionHouseSortsBySearchContext = {
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [2]
	}, -- [1]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [2]
	}, -- [2]
	{
		{
			["reverseSort"] = true,
			["sortOrder"] = 2,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [2]
	}, -- [3]
	{
		{
			["reverseSort"] = true,
			["sortOrder"] = 2,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [2]
	}, -- [4]
	{
		{
			["reverseSort"] = true,
			["sortOrder"] = 2,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [2]
	}, -- [5]
	{
		{
			["reverseSort"] = true,
			["sortOrder"] = 2,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [2]
	}, -- [6]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [2]
	}, -- [7]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [2]
	}, -- [8]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [2]
	}, -- [9]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [2]
	}, -- [10]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [2]
	}, -- [11]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [2]
	}, -- [12]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [2]
	}, -- [13]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 4,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 3,
		}, -- [2]
	}, -- [14]
	{
	}, -- [15]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 4,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 3,
		}, -- [2]
	}, -- [16]
	{
	}, -- [17]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 4,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 3,
		}, -- [2]
	}, -- [18]
	{
	}, -- [19]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 4,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 3,
		}, -- [2]
	}, -- [20]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [2]
	}, -- [21]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [2]
	}, -- [22]
	{
		{
			["reverseSort"] = false,
			["sortOrder"] = 1,
		}, -- [1]
		{
			["reverseSort"] = false,
			["sortOrder"] = 0,
		}, -- [2]
	}, -- [23]
	["auctionHouseSortVersion"] = 2,
}
