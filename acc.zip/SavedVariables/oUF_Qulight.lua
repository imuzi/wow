
QulightData = nil
