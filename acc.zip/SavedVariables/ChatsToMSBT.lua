
C2MSBT_Settings = {
	["ChanList"] = {
	},
	["CustomOutput"] = {
		["Whispers"] = true,
		["Enable"] = true,
		["BGs"] = true,
		["Party"] = true,
		["Guild"] = true,
		["Say"] = true,
		["Yell"] = true,
		["Raid"] = true,
		["Emotes"] = true,
		["Chats"] = true,
	},
	["CustomOutputFrame"] = {
		["Whispers"] = "KethoCombatLog",
		["BGs"] = "KethoCombatLog",
		["Party"] = "KethoCombatLog",
		["Yell"] = "KethoCombatLog",
		["Say"] = "KethoCombatLog",
		["Guild"] = "KethoCombatLog",
		["Raid"] = "KethoCombatLog",
		["Emotes"] = "KethoCombatLog",
		["Chats"] = "KethoCombatLog",
	},
}
