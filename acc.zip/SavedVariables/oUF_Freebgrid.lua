
oUF_FreebgridDB = {
	["powercolor"] = {
		["a"] = 1,
		["r"] = 1,
		["g"] = 1,
		["b"] = 1,
	},
	["powerclass"] = true,
	["solo"] = true,
	["growth"] = "UP",
	["cluster"] = {
		["enabled"] = false,
		["textcolor"] = {
			["a"] = 1,
			["b"] = 0.6,
			["g"] = 0.9,
			["r"] = 0,
		},
		["perc"] = 90,
		["freq"] = 250,
		["range"] = 30,
	},
	["gradient"] = {
		["a"] = 1,
		["r"] = 1,
		["g"] = 0,
		["b"] = 0,
	},
	["powerbgcolor"] = {
		["a"] = 1,
		["r"] = 0.33,
		["g"] = 0.33,
		["b"] = 0.33,
	},
	["scale"] = 0.8,
	["fontsize"] = 13,
	["fontPath"] = "Fonts\\bHEI01B.ttf",
	["definecolors"] = true,
	["powerbar"] = true,
	["powerbarsize"] = 0.1,
	["spacing"] = 3,
	["height"] = 22,
	["hpcolor"] = {
		["a"] = 1,
		["r"] = 0.1,
		["g"] = 0.1,
		["b"] = 0.1,
	},
	["horizontal"] = true,
	["porientation"] = "HORIZONTAL",
	["otherhealcolor"] = {
		["a"] = 0.4,
		["r"] = 0,
		["g"] = 1,
		["b"] = 0,
	},
	["font"] = "聊天",
	["width"] = 53,
	["myhealcolor"] = {
		["a"] = 0.4,
		["r"] = 0,
		["g"] = 1,
		["b"] = 0.5,
	},
	["orientation"] = "HORIZONTAL",
	["hpbgcolor"] = {
		["a"] = 1,
		["r"] = 0.33,
		["g"] = 0.33,
		["b"] = 0.33,
	},
}
Freebgridomf2 = {
	["__INITIAL"] = {
		["Freebgrid"] = {
			["oUF_FreebgridRaidFrame"] = "LEFTUIParent80",
			["oUF_FreebgridPetFrame"] = "LEFTUIParent2490",
			["oUF_FreebgridMTFrame"] = "TOPLEFTUIParent8-59",
		},
	},
	["Freebgrid"] = {
		["oUF_FreebgridRaidFrame"] = "LEFTUIParent3-28",
		["oUF_FreebgridPetFrame"] = "LEFTUIParent28-55",
		["oUF_FreebgridMTFrame"] = "LEFTUIParent144",
	},
}
