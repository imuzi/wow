
ThreatPlatesDB = {
	["char"] = {
		["Ennyin - 埃加洛尔"] = {
			["spec"] = {
				[3] = false,
			},
			["welcome"] = true,
		},
		["借你流年 - 燃烧之刃"] = {
			["welcome"] = true,
			["spec"] = {
				[3] = false,
			},
		},
	},
	["profileKeys"] = {
		["Ennyin - 埃加洛尔"] = "Default",
		["借你流年 - 燃烧之刃"] = "Default",
	},
	["global"] = {
		["DefaultsVersion"] = "CLASSIC",
		["version"] = "9.2.4",
	},
	["profiles"] = {
		["Default"] = {
			["uniqueSettings"] = {
				nil, -- [1]
				{
				}, -- [2]
				{
				}, -- [3]
				{
				}, -- [4]
				{
				}, -- [5]
				{
				}, -- [6]
				{
				}, -- [7]
				{
				}, -- [8]
				{
				}, -- [9]
				{
				}, -- [10]
				{
				}, -- [11]
				{
				}, -- [12]
				{
				}, -- [13]
				{
				}, -- [14]
				nil, -- [15]
				{
				}, -- [16]
				{
				}, -- [17]
				nil, -- [18]
				nil, -- [19]
				{
				}, -- [20]
				{
				}, -- [21]
				nil, -- [22]
				nil, -- [23]
				{
				}, -- [24]
				{
				}, -- [25]
				nil, -- [26]
				{
				}, -- [27]
				{
				}, -- [28]
				{
				}, -- [29]
				nil, -- [30]
				nil, -- [31]
				{
				}, -- [32]
			},
			["cache"] = {
			},
			["settings"] = {
				["healthbar"] = {
					["width"] = 121,
					["texture"] = "Details Flat",
				},
				["healthborder"] = {
					["show"] = false,
					["texture"] = "TP_Border_Thin",
				},
				["frame"] = {
					["height"] = 62.99999999999999,
					["width"] = 177.6,
				},
			},
		},
	},
}
