
BattleGroundEnemiesDB = {
	["profileKeys"] = {
		["Ennyin - 索瑞森"] = "Default",
		["云雨別 - 索瑞森"] = "Default",
		["Ennyin - 埃加洛尔"] = "Default",
		["借你流年 - 燃烧之刃"] = "Default",
		["绑住了风 - 索瑞森"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["你诺 - 索瑞森"] = "Default",
		["海雅 - 索瑞森"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["別雨 - 索瑞森"] = "Default",
		["Rainylone - 末日行者"] = "Default",
	},
	["profiles"] = {
		["simpleColumn"] = {
		},
		["WARLOCK"] = {
			["DisableArenaFrames"] = true,
		},
		["Default"] = {
			["Enemies"] = {
				["40"] = {
					["Position_Y"] = 763.733375670945,
					["BarColumns"] = 2,
					["Trinket_Enabled"] = false,
					["BarHorizontalSpacing"] = 8,
					["Framescale"] = 1.15,
					["BarWidth"] = 79,
					["Position_X"] = 999.6393150090007,
					["Racial_Enabled"] = false,
					["BarHeight"] = 16,
					["Spec_Width"] = 23,
				},
				["RangeIndicator_Everything"] = true,
				["RangeIndicator_Alpha"] = 0.15,
				["ShowRealmnames"] = false,
				["15"] = {
					["NumericTargetindicator_Fontsize"] = 33,
					["DrTracking_Container_RelativeTo"] = "Racial",
					["Position_Y"] = 678.399961280822,
					["Auras_Debuffs_Size"] = 33,
					["PowerBar_Background"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0.6599999964237213, -- [4]
					},
					["DrTrackingFiltering_Filterlist"] = {
						["disorient"] = true,
					},
					["PowerBar_Texture"] = "MaUI 15",
					["DrTracking_Container_BasicPoint"] = "LEFT",
					["BarWidth"] = 98,
					["HealthBar_Texture"] = "MaUI 15",
					["Spec_Width"] = 21,
					["Position_X"] = 934.0810686063924,
					["Racial_Enabled"] = false,
					["PowerBar_Enabled"] = true,
					["PowerBar_Height"] = 3,
					["BarHeight"] = 33,
					["DrTracking_GrowDirection"] = "rightwards",
					["Auras_Debuffs_Container_RelativeTo"] = "Spec",
					["DrTrackingFiltering_Enabled"] = true,
					["Auras_Debuffs_Container_OffsetX"] = 0,
				},
			},
			["Allies"] = {
				["40"] = {
					["Position_Y"] = 445.0057840224617,
					["Position_X"] = 54.99416176115483,
					["BarHeight"] = 73,
					["Enabled"] = false,
				},
				["RangeIndicator_Everything"] = true,
				["Enabled"] = false,
				["RangeIndicator_Alpha"] = 0,
				["15"] = {
					["Position_Y"] = 741.2713896812929,
					["BarVerticalSpacing"] = 0,
					["Framescale"] = 0.4,
					["BarWidth"] = 91,
					["Spec_Width"] = 31,
					["Position_X"] = 1009.162711818455,
					["DrTracking_Enabled"] = false,
					["Racial_Enabled"] = false,
					["PowerBar_Enabled"] = true,
					["PowerBar_Height"] = 8,
					["BarHeight"] = 34,
				},
				["RightButtonType"] = "Custom",
			},
		},
		["Ennyin - 索瑞森"] = {
			["DisableArenaFrames"] = true,
		},
	},
}
