
MADB = {
	["noMMMW"] = false,
	["characters"] = {
	},
	["alwaysShowNudger"] = false,
	["frameListRows"] = 18,
	["profiles"] = {
		["default"] = {
			["name"] = "default",
			["frames"] = {
				["PlayerPowerBarAltMover"] = {
					["orgPos"] = {
						"BOTTOM", -- [1]
						"UIParent", -- [2]
						"BOTTOM", -- [3]
						0, -- [4]
						155, -- [5]
					},
					["name"] = "PlayerPowerBarAltMover",
					["pos"] = {
						"BOTTOM", -- [1]
						"UIParent", -- [2]
						"BOTTOM", -- [3]
						3.555511474609375, -- [4]
						222.7774810791016, -- [5]
					},
				},
				["TargetDebuffsMover"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"TargetFrameBuffs", -- [2]
						"BOTTOMLEFT", -- [3]
						0, -- [4]
						-6, -- [5]
					},
					["name"] = "TargetDebuffsMover",
					["pos"] = {
						"TOPLEFT", -- [1]
						"TargetFrameBuffs", -- [2]
						"BOTTOMLEFT", -- [3]
						0, -- [4]
						-5.99993896484375, -- [5]
					},
				},
				["PlayerAttackIcon"] = {
					["hidden"] = true,
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						40, -- [4]
						-48.99999618530273, -- [5]
					},
					["name"] = "PlayerAttackIcon",
					["pos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						609.2494506835938, -- [4]
						-797.761613937821, -- [5]
					},
				},
				["PlayerLeaderIcon"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						nil, -- [2]
						"TOPLEFT", -- [3]
						40, -- [4]
						-11.99999904632568, -- [5]
					},
					["name"] = "PlayerLeaderIcon",
					["pos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						622.999755859375, -- [4]
						-738.4443054199219, -- [5]
					},
				},
				["TargetFramePowerBarAltMover"] = {
					["orgPos"] = {
						"LEFT", -- [1]
						"TargetFrame", -- [2]
						"RIGHT", -- [3]
						-25, -- [4]
						5, -- [5]
					},
					["name"] = "TargetFramePowerBarAltMover",
					["pos"] = {
						"LEFT", -- [1]
						"TargetFrame", -- [2]
						"RIGHT", -- [3]
						-25.0001220703125, -- [4]
						5, -- [5]
					},
				},
				["PlayerStatusTexture"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						nil, -- [2]
						"TOPLEFT", -- [3]
						34.99999618530273, -- [4]
						-7.999999523162842, -- [5]
					},
					["name"] = "PlayerStatusTexture",
					["pos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						595.958984375, -- [4]
						-727.4055043186804, -- [5]
					},
				},
				["TargetFrameToT"] = {
					["orgPos"] = {
						"BOTTOMRIGHT", -- [1]
						"TargetFrame", -- [2]
						"BOTTOMRIGHT", -- [3]
						-34.99999618530273, -- [4]
						-10, -- [5]
					},
					["name"] = "TargetFrameToT",
					["pos"] = {
						"BOTTOMRIGHT", -- [1]
						"TargetFrame", -- [2]
						"BOTTOMRIGHT", -- [3]
						22.88916015625, -- [4]
						72.22201538085938, -- [5]
					},
				},
				["QueueStatusMinimapButton"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"MinimapBackdrop", -- [2]
						"TOPLEFT", -- [3]
						22, -- [4]
						-100, -- [5]
					},
					["name"] = "QueueStatusMinimapButton",
					["pos"] = {
						"CENTER", -- [1]
						"Minimap", -- [2]
						"CENTER", -- [3]
						-74.0118408203125, -- [4]
						-77.72415161132812, -- [5]
					},
				},
				["FocusFrame"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						250, -- [4]
						-240, -- [5]
					},
					["name"] = "FocusFrame",
					["scale"] = 0.8749554753303528,
					["orgScale"] = 1,
					["pos"] = {
						"TOP", -- [1]
						"UIParent", -- [2]
						"TOP", -- [3]
						-368.0189825902252, -- [4]
						-185.152088897784, -- [5]
					},
				},
				["PlayerStatusGlow"] = {
					["disabled"] = true,
					["name"] = "PlayerStatusGlow",
					["pos"] = {
						"TOPLEFT", -- [1]
						"PlayerRestIcon", -- [2]
						"TOPLEFT", -- [3]
						-6.75048828125, -- [4]
						-6.750457763671875, -- [5]
					},
				},
				["AchievementFrame"] = {
					["UIPanelWindows"] = {
						["xoffset"] = 80,
						["whileDead"] = 1,
						["pushable"] = 0,
						["area"] = "doublewide",
					},
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						0, -- [4]
						-103.9999923706055, -- [5]
					},
					["name"] = "AchievementFrame",
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						0, -- [4]
						356.0000915527344, -- [5]
					},
				},
				["Boss3TargetFrame"] = {
					["clampToScreen"] = true,
					["name"] = "Boss3TargetFrame",
					["orgClampToScreen"] = true,
					["scale"] = 1.243675112724304,
					["orgScale"] = 0.75,
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"Boss2TargetFrame", -- [2]
						"BOTTOMLEFT", -- [3]
						0, -- [4]
						-30, -- [5]
					},
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						861.4943237304688, -- [4]
						500.1671142578125, -- [5]
					},
				},
				["PVPUIFrame"] = {
					["UIPanelWindows"] = {
						["whileDead"] = 1,
						["width"] = 563,
						["pushable"] = 0,
						["area"] = "left",
					},
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"PVEFrame", -- [2]
						"TOPLEFT", -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "PVPUIFrame",
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						16.00000762939453, -- [4]
						416.0001525878906, -- [5]
					},
				},
				["UIWidgetTopCenterContainerFrame"] = {
					["orgPos"] = {
						"TOP", -- [1]
						"UIParent", -- [2]
						"TOP", -- [3]
						0, -- [4]
						-15, -- [5]
					},
					["name"] = "UIWidgetTopCenterContainerFrame",
					["scale"] = 0.9648529887199402,
					["orgScale"] = 1,
					["pos"] = {
						"TOP", -- [1]
						"UIParent", -- [2]
						"TOP", -- [3]
						-669.1626951960786, -- [4]
						6.87017415564797, -- [5]
					},
				},
				["PrestigeLevelUpBanner"] = {
					["orgPos"] = {
						"TOP", -- [1]
						"UIParent", -- [2]
						"TOP", -- [3]
						0, -- [4]
						-269.9999694824219, -- [5]
					},
					["name"] = "PrestigeLevelUpBanner",
					["pos"] = {
						"TOP", -- [1]
						"UIParent", -- [2]
						"TOP", -- [3]
						403.3830688476592, -- [4]
						40.1260955810576, -- [5]
					},
				},
				["PetFrame"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"PlayerFrame", -- [2]
						"TOPLEFT", -- [3]
						60, -- [4]
						-89.99999237060547, -- [5]
					},
					["name"] = "PetFrame",
					["orgScale"] = 1,
					["scale"] = 1.039999961853027,
					["orgAlpha"] = 1,
					["alpha"] = 0.9799999594688416,
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						552.23486328125, -- [4]
						177.6921691894531, -- [5]
					},
				},
				["TalkingHeadFrame"] = {
					["orgPos"] = {
						"CENTER", -- [1]
						"DominosFrametalk", -- [2]
						"CENTER", -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "TalkingHeadFrame",
					["pos"] = {
						"BOTTOM", -- [1]
						"UIParent", -- [2]
						"BOTTOM", -- [3]
						-9.1552734375e-05, -- [4]
						96, -- [5]
					},
				},
				["Boss1TargetFramePowerBarAlt"] = {
					["orgPos"] = {
						"RIGHT", -- [1]
						"Boss1TargetFrame", -- [2]
						"LEFT", -- [3]
						0, -- [4]
						5, -- [5]
					},
					["name"] = "Boss1TargetFramePowerBarAlt",
					["pos"] = {
						"RIGHT", -- [1]
						"Boss1TargetFrame", -- [2]
						"LEFT", -- [3]
						0, -- [4]
						0, -- [5]
					},
				},
				["PlayerFrame"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						-18.99999809265137, -- [4]
						-3.999999761581421, -- [5]
					},
					["name"] = "PlayerFrame",
					["scale"] = 0.825794517993927,
					["orgScale"] = 1,
					["pos"] = {
						"CENTER", -- [1]
						"UIParent", -- [2]
						"CENTER", -- [3]
						-189.33, -- [4]
						-386.33, -- [5]
					},
				},
				["Boss2TargetFramePowerBarAlt"] = {
					["orgPos"] = {
						"RIGHT", -- [1]
						"Boss2TargetFrame", -- [2]
						"LEFT", -- [3]
						0, -- [4]
						5, -- [5]
					},
					["name"] = "Boss2TargetFramePowerBarAlt",
					["pos"] = {
						"RIGHT", -- [1]
						"Boss2TargetFrame", -- [2]
						"LEFT", -- [3]
						0, -- [4]
						0, -- [5]
					},
				},
				["ObjectiveTrackerFrameMover"] = {
					["orgPos"] = {
						"TOPRIGHT", -- [1]
						"MinimapCluster", -- [2]
						"BOTTOMRIGHT", -- [3]
						-10, -- [4]
						0, -- [5]
					},
					["name"] = "ObjectiveTrackerFrameMover",
					["pos"] = {
						"TOPRIGHT", -- [1]
						"MinimapCluster", -- [2]
						"BOTTOMRIGHT", -- [3]
						-0.0003662109375, -- [4]
						32.92578125, -- [5]
					},
				},
				["QuestFrame"] = {
					["orgPos"] = {
						"TOP", -- [1]
						"UIParent", -- [2]
						"TOP", -- [3]
						0, -- [4]
						-135, -- [5]
					},
					["name"] = "QuestFrame",
					["UIPanelWindows"] = {
						["pushable"] = 0,
						["area"] = "left",
					},
					["orgFrameStrata"] = "MEDIUM",
					["frameStrata"] = "FULLSCREEN_DIALOG",
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						449.3714294433594, -- [4]
						442.0573425292969, -- [5]
					},
				},
				["RaidBossEmoteFrame"] = {
					["orgPos"] = {
						"TOP", -- [1]
						"RaidWarningFrame", -- [2]
						"BOTTOM", -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "RaidBossEmoteFrame",
					["pos"] = {
						"TOP", -- [1]
						"RaidWarningFrame", -- [2]
						"BOTTOM", -- [3]
						0, -- [4]
						0, -- [5]
					},
				},
				["AchievementAlertFrame2"] = {
					["name"] = "AchievementAlertFrame2",
					["pos"] = {
						"BOTTOM", -- [1]
						"UIParent", -- [2]
						"BOTTOM", -- [3]
						-3.0517578125e-05, -- [4]
						128.0000152587891, -- [5]
					},
				},
				["PlayerAttackGlow"] = {
					["disabled"] = true,
					["name"] = "PlayerAttackGlow",
					["pos"] = {
						"TOPLEFT", -- [1]
						"PlayerStatusGlow", -- [2]
						"TOPLEFT", -- [3]
						-5.75054931640625, -- [4]
						-5.75054931640625, -- [5]
					},
				},
				["PlayerRestGlow"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"PlayerStatusGlow", -- [2]
						"TOPLEFT", -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "PlayerRestGlow",
					["pos"] = {
						"TOPLEFT", -- [1]
						"PlayerStatusGlow", -- [2]
						"TOPLEFT", -- [3]
						129.8069458007813, -- [4]
						-189.8853912353516, -- [5]
					},
				},
				["PetDebuffsMover"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"PetFrame", -- [2]
						"TOPLEFT", -- [3]
						48, -- [4]
						-42, -- [5]
					},
					["name"] = "PetDebuffsMover",
					["pos"] = {
						"TOPLEFT", -- [1]
						"PetFrame", -- [2]
						"TOPLEFT", -- [3]
						48, -- [4]
						-41.99998474121094, -- [5]
					},
				},
				["ObjectiveTrackerBonusBannerFrame"] = {
					["orgPos"] = {
						"TOP", -- [1]
						"UIParent", -- [2]
						"TOP", -- [3]
						0, -- [4]
						-170, -- [5]
					},
					["name"] = "ObjectiveTrackerBonusBannerFrame",
					["pos"] = {
						"TOP", -- [1]
						"UIParent", -- [2]
						"TOP", -- [3]
						-6.103515625e-05, -- [4]
						-170, -- [5]
					},
				},
				["PetActionButtonsMover"] = {
					["scale"] = 0.8749555945396423,
					["disabled"] = true,
					["name"] = "PetActionButtonsMover",
				},
				["PlayerPVPIcon"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						nil, -- [2]
						"TOPLEFT", -- [3]
						17.99999809265137, -- [4]
						-20, -- [5]
					},
					["name"] = "PlayerPVPIcon",
					["pos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						532.6666870117188, -- [4]
						-91.3331298828125, -- [5]
					},
				},
				["PlayerRestIcon"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						nil, -- [2]
						"TOPLEFT", -- [3]
						39, -- [4]
						-50, -- [5]
					},
					["name"] = "PlayerRestIcon",
					["pos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						754.7202758789062, -- [4]
						-963.6511097874304, -- [5]
					},
				},
				["TargetFrame"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						250, -- [4]
						-3.999999761581421, -- [5]
					},
					["name"] = "TargetFrame",
					["scale"] = 0.8257912993431091,
					["orgScale"] = 1,
					["pos"] = {
						"CENTER", -- [1]
						"UIParent", -- [2]
						"CENTER", -- [3]
						189.3093050621513, -- [4]
						-386.33, -- [5]
					},
				},
				["Boss1TargetFrame"] = {
					["orgPos"] = {
						"TOPRIGHT", -- [1]
						"UIParent", -- [2]
						"TOPRIGHT", -- [3]
						54.99999618530273, -- [4]
						-236, -- [5]
					},
					["orgAlpha"] = 1,
					["orgClampToScreen"] = true,
					["scale"] = 1.243675112724304,
					["alpha"] = 1,
					["clampToScreen"] = true,
					["name"] = "Boss1TargetFrame",
					["orgScale"] = 0.75,
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						856.3262329101562, -- [4]
						671.90576171875, -- [5]
					},
				},
				["Boss2TargetFrame"] = {
					["clampToScreen"] = true,
					["name"] = "Boss2TargetFrame",
					["orgClampToScreen"] = true,
					["scale"] = 1.268258213996887,
					["orgScale"] = 0.75,
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"Boss1TargetFrame", -- [2]
						"BOTTOMLEFT", -- [3]
						0, -- [4]
						-30, -- [5]
					},
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						839.748291015625, -- [4]
						573.4993896484375, -- [5]
					},
				},
				["ComboPointPlayerFrame"] = {
					["orgPos"] = {
						"TOP", -- [1]
						"PlayerFrame", -- [2]
						"BOTTOM", -- [3]
						50, -- [4]
						37.99999618530273, -- [5]
					},
					["name"] = "ComboPointPlayerFrame",
					["pos"] = {
						"TOP", -- [1]
						"PlayerFrame", -- [2]
						"BOTTOM", -- [3]
						50.00006103515625, -- [4]
						39.00006103515625, -- [5]
					},
				},
				["PartyMemberFrame1"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"CompactRaidFrameManager", -- [2]
						"TOPRIGHT", -- [3]
						0, -- [4]
						-20, -- [5]
					},
					["name"] = "PartyMemberFrame1",
					["pos"] = {
						"TOPLEFT", -- [1]
						"CompactRaidFrameManager", -- [2]
						"TOPRIGHT", -- [3]
						0, -- [4]
						-20, -- [5]
					},
				},
				["TargetFrameNumericalThreat"] = {
					["orgPos"] = {
						"BOTTOM", -- [1]
						"TargetFrame", -- [2]
						"TOP", -- [3]
						-50, -- [4]
						-22, -- [5]
					},
					["name"] = "TargetFrameNumericalThreat",
					["pos"] = {
						"BOTTOM", -- [1]
						"TargetFrame", -- [2]
						"TOP", -- [3]
						49.55577087402344, -- [4]
						-25.55548095703125, -- [5]
					},
				},
				["PlayerHitIndicator"] = {
					["orgPos"] = {
						"CENTER", -- [1]
						nil, -- [2]
						"TOPLEFT", -- [3]
						73, -- [4]
						-41.99999618530273, -- [5]
					},
					["name"] = "PlayerHitIndicator",
					["pos"] = {
						"CENTER", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						653.8942565917969, -- [4]
						-754.5493641819617, -- [5]
					},
				},
				["ObjectiveTrackerFrameScaleMover"] = {
					["orgPos"] = {
						"TOPRIGHT", -- [1]
						"MinimapCluster", -- [2]
						"BOTTOMRIGHT", -- [3]
						-10, -- [4]
						0, -- [5]
					},
					["orgAlpha"] = 1,
					["orgScale"] = 1,
					["scale"] = 0.8399999737739563,
					["name"] = "ObjectiveTrackerFrameScaleMover",
					["alpha"] = 0.9560848474502563,
					["pos"] = {
						"TOPRIGHT", -- [1]
						"MinimapCluster", -- [2]
						"BOTTOMRIGHT", -- [3]
						0.0001515960081412894, -- [4]
						8.740068257955945e-05, -- [5]
					},
				},
				["Boss3TargetFramePowerBarAlt"] = {
					["orgPos"] = {
						"RIGHT", -- [1]
						"Boss3TargetFrame", -- [2]
						"LEFT", -- [3]
						0, -- [4]
						5, -- [5]
					},
					["name"] = "Boss3TargetFramePowerBarAlt",
					["pos"] = {
						"RIGHT", -- [1]
						"Boss3TargetFrame", -- [2]
						"LEFT", -- [3]
						0, -- [4]
						0, -- [5]
					},
				},
				["AchievementAlertFrame1"] = {
					["name"] = "AchievementAlertFrame1",
					["pos"] = {
						"BOTTOM", -- [1]
						"UIParent", -- [2]
						"BOTTOM", -- [3]
						-3.0517578125e-05, -- [4]
						128.0000152587891, -- [5]
					},
				},
				["QueueStatusFrame"] = {
					["orgPos"] = {
						"TOPRIGHT", -- [1]
						"QueueStatusMinimapButton", -- [2]
						"TOPLEFT", -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "QueueStatusFrame",
					["pos"] = {
						"TOPRIGHT", -- [1]
						"QueueStatusMinimapButton", -- [2]
						"TOPLEFT", -- [3]
						-0.0001220703125, -- [4]
						0, -- [5]
					},
				},
				["UIWidgetBelowMinimapContainerFrame"] = {
					["orgPos"] = {
						"TOPRIGHT", -- [1]
						"MinimapCluster", -- [2]
						"BOTTOMRIGHT", -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "UIWidgetBelowMinimapContainerFrame",
					["pos"] = {
						"TOPRIGHT", -- [1]
						"MinimapCluster", -- [2]
						"BOTTOMRIGHT", -- [3]
						-400, -- [4]
						0, -- [5]
					},
				},
				["TargetFrameTextureFramePVPIcon"] = {
					["orgPos"] = {
						"TOPRIGHT", -- [1]
						"TargetFrameTextureFrame", -- [2]
						"TOPRIGHT", -- [3]
						2.999999761581421, -- [4]
						-20, -- [5]
					},
					["orgAlpha"] = 1,
					["name"] = "TargetFrameTextureFramePVPIcon",
					["alpha"] = 0,
					["pos"] = {
						"TOPRIGHT", -- [1]
						"TargetFrameTextureFrame", -- [2]
						"TOPRIGHT", -- [3]
						-695.6667890548707, -- [4]
						105.3335571289063, -- [5]
					},
				},
				["PlayerAttackBackground"] = {
					["disabled"] = true,
					["name"] = "PlayerAttackBackground",
					["pos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						614.6244506835938, -- [4]
						-765.8192616428992, -- [5]
					},
				},
				["LossOfControlFrame"] = {
					["orgPos"] = {
						"CENTER", -- [1]
						"UIParent", -- [2]
						"CENTER", -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "LossOfControlFrame",
					["pos"] = {
						"CENTER", -- [1]
						"UIParent", -- [2]
						"CENTER", -- [3]
						-9.1552734375e-05, -- [4]
						6.103515625e-05, -- [5]
					},
				},
				["QuestLogPopupDetailFrame"] = {
					["UIPanelWindows"] = {
						["whileDead"] = 1,
						["pushable"] = 0,
						["area"] = "left",
					},
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"UIParent", -- [2]
						"TOPLEFT", -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "QuestLogPopupDetailFrame",
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						558.2223510742188, -- [4]
						457.77783203125, -- [5]
					},
				},
				["SpellActivationOverlayFrame"] = {
					["orgPos"] = {
						"CENTER", -- [1]
						"UIParent", -- [2]
						"CENTER", -- [3]
						0, -- [4]
						0, -- [5]
					},
					["name"] = "SpellActivationOverlayFrame",
					["pos"] = {
						"CENTER", -- [1]
						"UIParent", -- [2]
						"CENTER", -- [3]
						-3.0517578125e-05, -- [4]
						1.52587890625e-05, -- [5]
					},
				},
				["PlayerFrameGroupIndicator"] = {
					["orgPos"] = {
						"BOTTOMLEFT", -- [1]
						"PlayerFrame", -- [2]
						"TOPLEFT", -- [3]
						96.99999237060547, -- [4]
						-20, -- [5]
					},
					["name"] = "PlayerFrameGroupIndicator",
					["scale"] = 0.9840187907561491,
					["orgScale"] = 1,
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"PlayerFrame", -- [2]
						"TOPLEFT", -- [3]
						-32.09634132380938, -- [4]
						-53.88152166525151, -- [5]
					},
				},
				["PlayerTalentFrame"] = {
					["name"] = "PlayerTalentFrame",
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						16.00000381469727, -- [4]
						376, -- [5]
					},
				},
				["PartyMemberFrame1PetFrame"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"PartyMemberFrame1", -- [2]
						"TOPLEFT", -- [3]
						23, -- [4]
						-26.99999809265137, -- [5]
					},
					["name"] = "PartyMemberFrame1PetFrame",
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						40.9999885559082, -- [4]
						747.0000610351562, -- [5]
					},
				},
				["PlayerFrameAlternateManaBar"] = {
					["orgPos"] = {
						"BOTTOMLEFT", -- [1]
						"PlayerFrame", -- [2]
						"BOTTOMLEFT", -- [3]
						114, -- [4]
						23, -- [5]
					},
					["name"] = "PlayerFrameAlternateManaBar",
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"PlayerFrame", -- [2]
						"BOTTOMLEFT", -- [3]
						115.0302124023438, -- [4]
						23.11886596679688, -- [5]
					},
				},
				["TargetBuffsMover"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"TargetFrame", -- [2]
						"BOTTOMLEFT", -- [3]
						5, -- [4]
						32, -- [5]
					},
					["name"] = "TargetBuffsMover",
					["pos"] = {
						"TOPLEFT", -- [1]
						"TargetFrame", -- [2]
						"BOTTOMLEFT", -- [3]
						5.000030517578125, -- [4]
						32.00006103515625, -- [5]
					},
				},
				["PartyMember1DebuffsMover"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"PartyMemberFrame1", -- [2]
						"TOPLEFT", -- [3]
						48, -- [4]
						-32, -- [5]
					},
					["name"] = "PartyMember1DebuffsMover",
					["pos"] = {
						"TOPLEFT", -- [1]
						"PartyMemberFrame1", -- [2]
						"TOPLEFT", -- [3]
						47.9999885559082, -- [4]
						-32.00006103515625, -- [5]
					},
				},
				["TargetFrameSpellBar"] = {
					["orgPos"] = {
						"TOPLEFT", -- [1]
						"TargetFrame", -- [2]
						"BOTTOMLEFT", -- [3]
						25, -- [4]
						6.999999523162842, -- [5]
					},
					["name"] = "TargetFrameSpellBar",
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						500.3331298828125, -- [4]
						637.0001220703125, -- [5]
					},
				},
				["WarlockPowerFrame"] = {
					["orgPos"] = {
						"TOP", -- [1]
						"PlayerFrame", -- [2]
						"BOTTOM", -- [3]
						50, -- [4]
						34, -- [5]
					},
					["name"] = "WarlockPowerFrame",
					["scale"] = 0.9399999976158142,
					["orgScale"] = 1,
					["pos"] = {
						"TOP", -- [1]
						"PlayerFrame", -- [2]
						"BOTTOM", -- [3]
						53.69999694824219, -- [4]
						39.42999267578125, -- [5]
					},
				},
			},
		},
	},
	["closeGUIOnEscape"] = false,
	["noBags"] = false,
	["playSound"] = false,
	["tooltips"] = true,
}
