
Postal3DB = {
	["profileKeys"] = {
		["Ifey - 冰风岗"] = "Ifey - 冰风岗",
		["嘿嘿牛 - 达尔坎"] = "嘿嘿牛 - 达尔坎",
		["云雨別 - 索瑞森"] = "云雨別 - 索瑞森",
		["失重 - 无尽之海"] = "失重 - 无尽之海",
		["Ylno - 夏维安"] = "Ylno - 夏维安",
		["Esserbella - 索瑞森"] = "Esserbella - 索瑞森",
		["你诺 - 索瑞森"] = "你诺 - 索瑞森",
		["幽笠巫 - 熊猫酒仙"] = "幽笠巫 - 熊猫酒仙",
		["Lure - 达文格尔"] = "Lure - 达文格尔",
		["失重 - 冰风岗"] = "失重 - 冰风岗",
		["Rinaly - 索瑞森"] = "Rinaly - 索瑞森",
		["海雅 - 索瑞森"] = "海雅 - 索瑞森",
		["Eofol - 沙怒"] = "Eofol - 沙怒",
		["Rainylone - 夏维安"] = "Rainylone - 夏维安",
		["浮雲 - 恶魔之翼"] = "浮雲 - 恶魔之翼",
		["绑住了风 - 索瑞森"] = "绑住了风 - 索瑞森",
		["木诺子其 - 索瑞森"] = "木诺子其 - 索瑞森",
		["画雨 - 索瑞森"] = "画雨 - 索瑞森",
		["別雨 - 索瑞森"] = "別雨 - 索瑞森",
		["Elytolpain - 夏维安"] = "Elytolpain - 夏维安",
	},
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"Elytolpain|夏维安|Alliance|21|ROGUE", -- [1]
				"Eofol|沙怒|Horde|1|WARRIOR", -- [2]
				"Esserbella|索瑞森|Alliance|65|WARRIOR", -- [3]
				"Ifey|冰风岗|Alliance|1|PALADIN", -- [4]
				"Lure|达文格尔|Horde|26|WARRIOR", -- [5]
				"Rainylone|夏维安|Alliance|2|ROGUE", -- [6]
				"Rinaly|索瑞森|Alliance|1|ROGUE", -- [7]
				"Ylno|夏维安|Alliance|3|ROGUE", -- [8]
				"云雨別|索瑞森|Alliance|85|DRUID", -- [9]
				"你诺|索瑞森|Horde|60|DEATHKNIGHT", -- [10]
				"別雨|索瑞森|Horde|86|MAGE", -- [11]
				"嘿嘿牛|达尔坎|Horde|6|HUNTER", -- [12]
				"失重|冰风岗|Horde|64|WARRIOR", -- [13]
				"失重|无尽之海|Horde|1|WARRIOR", -- [14]
				"幽笠巫|熊猫酒仙|Horde|10|WARLOCK", -- [15]
				"木诺子其|索瑞森|Horde|90|WARLOCK", -- [16]
				"浮雲|恶魔之翼|Horde|72|MAGE", -- [17]
				"海雅|索瑞森|Horde|58|HUNTER", -- [18]
				"画雨|索瑞森|Horde|22|DRUID", -- [19]
				"绑住了风|索瑞森|Horde|85|PRIEST", -- [20]
			},
		},
	},
	["profiles"] = {
		["Ifey - 冰风岗"] = {
		},
		["嘿嘿牛 - 达尔坎"] = {
		},
		["云雨別 - 索瑞森"] = {
			["BlackBook"] = {
				["recent"] = {
					"海雅|索瑞森|Alliance", -- [1]
				},
			},
		},
		["失重 - 无尽之海"] = {
		},
		["Ylno - 夏维安"] = {
		},
		["Esserbella - 索瑞森"] = {
			["BlackBook"] = {
				["recent"] = {
					"云雨別|索瑞森|Alliance", -- [1]
					"云雨别|索瑞森|Alliance", -- [2]
					"你诺|索瑞森|Alliance", -- [3]
				},
			},
		},
		["你诺 - 索瑞森"] = {
		},
		["幽笠巫 - 熊猫酒仙"] = {
		},
		["Lure - 达文格尔"] = {
		},
		["失重 - 冰风岗"] = {
		},
		["Rinaly - 索瑞森"] = {
		},
		["海雅 - 索瑞森"] = {
		},
		["Eofol - 沙怒"] = {
		},
		["Rainylone - 夏维安"] = {
		},
		["浮雲 - 恶魔之翼"] = {
		},
		["绑住了风 - 索瑞森"] = {
			["BlackBook"] = {
				["recent"] = {
					"云雨別|索瑞森|Horde", -- [1]
					"木诺子其|索瑞森|Horde", -- [2]
				},
			},
		},
		["木诺子其 - 索瑞森"] = {
			["BlackBook"] = {
				["recent"] = {
					"海雅|索瑞森|Horde", -- [1]
					"云雨別|索瑞森|Horde", -- [2]
					"那一杖的风情|索瑞森|Horde", -- [3]
					"绑住了风|索瑞森|Horde", -- [4]
					"別雨|索瑞森|Horde", -- [5]
				},
			},
		},
		["画雨 - 索瑞森"] = {
			["BlackBook"] = {
				["recent"] = {
					"云雨別|索瑞森|Horde", -- [1]
				},
			},
		},
		["別雨 - 索瑞森"] = {
			["BlackBook"] = {
				["recent"] = {
					"绑住了风|索瑞森|Horde", -- [1]
					"木诺子其|索瑞森|Horde", -- [2]
					"画雨|索瑞森|Horde", -- [3]
				},
			},
		},
		["Elytolpain - 夏维安"] = {
		},
	},
}
