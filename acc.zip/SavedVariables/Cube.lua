
CubeSave = {
	["LogLevel"] = 3,
	["CodeList"] = {
		{
			["name"] = "snippet",
			["code"] = "",
		}, -- [1]
	},
}
