
SavedOptions = {
	["RaidLayout"] = "DPS",
}
SavedStats = {
	["JunkIgnore"] = {
	},
	["索瑞森"] = {
		["別雨"] = {
			["ExpMode"] = "played",
			["AutoSell"] = true,
			["AutoGuildRepair"] = true,
			["Gold"] = 80318318,
			["AutoRepair"] = true,
			["Played"] = 648472,
		},
		["木诺子其"] = {
			["ExpMode"] = "played",
			["AutoSell"] = true,
			["AutoGuildRepair"] = true,
			["Gold"] = 26379229,
			["AutoRepair"] = true,
			["Played"] = 20712773,
		},
	},
}
SavedAddonProfiles = {
	["OLDwithouS"] = {
		"ACP", -- [1]
		"BattlegroundTargets", -- [2]
		"Capping", -- [3]
		"DebuffFilter", -- [4]
		"ExtraCD", -- [5]
		"GladiusEx", -- [6]
		"InterruptBar", -- [7]
		"LibSharedMedia-3.0", -- [8]
		"LoseControl", -- [9]
		"OmniCC", -- [10]
		"PlateBuffs", -- [11]
		"PVPScore", -- [12]
		"PVPSound", -- [13]
		"Quartz", -- [14]
		"RangeDisplay", -- [15]
		"RETabBinder", -- [16]
		"SeeCD", -- [17]
		"SexyCooldown", -- [18]
		"ShestakUI", -- [19]
		"ShestakUI_Config", -- [20]
		"ShestakUI_Filger", -- [21]
		"SpellFlashCore", -- [22]
		"Vial", -- [23]
		"SpellFlash", -- [24]
		"dct", -- [25]
		"dct_damage", -- [26]
		"dct_options", -- [27]
	},
	["wowwiths"] = {
		"ACP", -- [1]
		"BattlegroundTargets", -- [2]
		"Capping", -- [3]
		"DebuffFilter", -- [4]
		"ExtraCD", -- [5]
		"GladiusEx", -- [6]
		"InterruptBar", -- [7]
		"LibSharedMedia-3.0", -- [8]
		"LoseControl", -- [9]
		"OmniCC", -- [10]
		"PlateBuffs", -- [11]
		"PVPScore", -- [12]
		"PVPSound", -- [13]
		"Quartz", -- [14]
		"RangeDisplay", -- [15]
		"RETabBinder", -- [16]
		"SeeCD", -- [17]
		"SexyCooldown", -- [18]
		"ShestakUI", -- [19]
		"ShestakUI_Config", -- [20]
		"ShestakUI_Filger", -- [21]
		"SpellFlashCore", -- [22]
		"Vial", -- [23]
		"SpellFlash", -- [24]
		"dct", -- [25]
		"dct_damage", -- [26]
		"dct_options", -- [27]
	},
	["LESSwitS"] = {
		"PVPScore", -- [1]
		"PVPSound", -- [2]
		"Quartz", -- [3]
		"RangeDisplay", -- [4]
		"ShestakUI", -- [5]
		"ShestakUI_Config", -- [6]
		"ShestakUI_Filger", -- [7]
		"dct", -- [8]
		"dct_damage", -- [9]
		"dct_options", -- [10]
	},
}
SavedBindings = nil
SavedCurrency = nil
