
ShieldTrackerDB = {
	["profileKeys"] = {
		["Ennyin - 埃加洛尔"] = "ENNYIN",
	},
	["profiles"] = {
		["ENNYIN"] = {
			["minimap"] = {
				["hide"] = false,
			},
			["bars"] = {
				["player"] = {
					["border"] = false,
					["timeRemaining"] = "LEFT",
					["texture"] = "Blizzard Raid Bar",
					["enabled"] = true,
					["font_thickoutline"] = false,
					["font_size"] = 12,
					["width"] = 50,
					["y"] = -325.5988006591797,
					["x"] = -87.679931640625,
					["height"] = 11,
					["tracking"] = {
						["Ice Barrier"] = true,
						["Dark Pact"] = true,
						["Blazing Barrier"] = true,
						["Soul Leech"] = true,
						["Prismatic Barrier"] = true,
					},
				},
				["TAR"] = {
					["border"] = false,
					["unit"] = "target",
					["timeRemaining"] = "RIGHT",
					["enabled"] = true,
					["tracked"] = "All",
					["width"] = 50,
					["y"] = -326.2777709960938,
					["x"] = 142.2223510742188,
					["height"] = 11,
				},
			},
		},
	},
}
