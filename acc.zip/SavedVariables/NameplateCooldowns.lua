
NameplateCooldownsAceDB = {
	["profileKeys"] = {
		["Ennyin - 索瑞森"] = "借你流年 - 燃烧之刃",
		["云雨別 - 索瑞森"] = "云雨別 - 索瑞森",
		["Ennyin - 埃加洛尔"] = "ENNYIN",
		["借你流年 - 燃烧之刃"] = "借你流年 - 燃烧之刃",
		["绑住了风 - 索瑞森"] = "绑住了风 - 索瑞森",
		["浮雲 - 恶魔之翼"] = "浮雲 - 恶魔之翼",
		["你诺 - 索瑞森"] = "你诺 - 索瑞森",
		["別雨 - 索瑞森"] = "別雨 - 索瑞森",
		["Madeep - 冰风岗"] = "借你流年 - 燃烧之刃",
		["海雅 - 索瑞森"] = "海雅 - 索瑞森",
		["Rainylone - 末日行者"] = "Rainylone - 末日行者",
	},
	["profiles"] = {
		["Default"] = {
		},
		["Ennyin - 索瑞森"] = {
			["DBVersion"] = 8,
			["IconSortMode"] = "interrupt-trinket-other",
			["Font"] = "伤害数字",
			["IconSize"] = 25,
			["SpellCDs"] = {
				["窒息"] = {
					["enabled"] = true,
					["refSpellID"] = 108194,
					["spellIDs"] = {
						[108194] = true,
					},
					["cooldown"] = 45,
					["texture"] = 538558,
				},
				["法术反制"] = {
					["enabled"] = true,
					["refSpellID"] = 2139,
					["spellIDs"] = {
						[2139] = true,
					},
					["cooldown"] = 24,
					["texture"] = 135856,
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["glow"] = 4000000000,
					["refSpellID"] = 42292,
					["spellIDs"] = {
						[42292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 100,
					["spellIDs"] = {
						[100] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132337,
				},
			},
			["IconYOffset"] = 27,
			["ShowCooldownsOnCurrentTargetOnly"] = true,
		},
		["海雅 - 索瑞森"] = {
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["refSpellID"] = 31230,
					["spellIDs"] = {
						[31230] = true,
					},
					["cooldown"] = 360,
					["texture"] = 132285,
				},
				["法术反制"] = {
					["enabled"] = true,
					["refSpellID"] = 2139,
					["spellIDs"] = {
						[2139] = true,
					},
					["cooldown"] = 24,
					["texture"] = 135856,
				},
				["天灾契约"] = {
					["enabled"] = true,
					["refSpellID"] = 48743,
					["spellIDs"] = {
						[48743] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136146,
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["refSpellID"] = 204437,
					["spellIDs"] = {
						[204437] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1385911,
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["refSpellID"] = 132578,
					["spellIDs"] = {
						[132578] = true,
					},
					["cooldown"] = 180,
					["texture"] = 608951,
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 206572,
					["spellIDs"] = {
						[206572] = true,
					},
					["cooldown"] = 20,
					["texture"] = 1380676,
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 215769,
					["spellIDs"] = {
						[215769] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132864,
				},
				["震荡波"] = {
					["enabled"] = true,
					["refSpellID"] = 46968,
					["spellIDs"] = {
						[46968] = true,
					},
					["cooldown"] = 40,
					["texture"] = 236312,
				},
				["谈判"] = {
					["enabled"] = true,
					["refSpellID"] = 199743,
					["spellIDs"] = {
						[199743] = true,
					},
					["cooldown"] = 20,
					["texture"] = 236448,
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 195710,
					["spellIDs"] = {
						[195710] = true,
					},
					["cooldown"] = 180,
					["texture"] = 338784,
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["refSpellID"] = 207167,
					["spellIDs"] = {
						[207167] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135836,
				},
				["超级新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157980,
					["spellIDs"] = {
						[157980] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033912,
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["refSpellID"] = 206650,
					["spellIDs"] = {
						[206650] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380366,
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["refSpellID"] = 48792,
					["spellIDs"] = {
						[48792] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237525,
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["refSpellID"] = 102558,
					["spellIDs"] = {
						[102558] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["死亡之握"] = {
					["enabled"] = true,
					["refSpellID"] = 49576,
					["spellIDs"] = {
						[49576] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237532,
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 853,
					["spellIDs"] = {
						[853] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135963,
				},
				["狂暴"] = {
					["enabled"] = true,
					["refSpellID"] = 26297,
					["spellIDs"] = {
						[26297] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135727,
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["refSpellID"] = 116849,
					["spellIDs"] = {
						[116849] = true,
					},
					["cooldown"] = 90,
					["texture"] = 627485,
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["refSpellID"] = 198817,
					["spellIDs"] = {
						[198817] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1380678,
				},
				["嗜血"] = {
					["enabled"] = true,
					["refSpellID"] = 2825,
					["spellIDs"] = {
						[2825] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136012,
				},
				["墓石"] = {
					["enabled"] = true,
					["refSpellID"] = 219809,
					["spellIDs"] = {
						[219809] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132151,
				},
				["电能图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 192058,
					["spellIDs"] = {
						[192058] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136013,
				},
				["影舞步"] = {
					["enabled"] = true,
					["refSpellID"] = 51690,
					["spellIDs"] = {
						[51690] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236277,
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["refSpellID"] = 108359,
					["spellIDs"] = {
						[108359] = true,
					},
					["cooldown"] = 120,
					["texture"] = 537516,
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["refSpellID"] = 102342,
					["spellIDs"] = {
						[102342] = true,
					},
					["cooldown"] = 90,
					["texture"] = 572025,
				},
				["亡者大军"] = {
					["enabled"] = true,
					["refSpellID"] = 42650,
					["spellIDs"] = {
						[42650] = true,
					},
					["cooldown"] = 600,
					["texture"] = 237511,
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["refSpellID"] = 198529,
					["spellIDs"] = {
						[198529] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133787,
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["refSpellID"] = 51052,
					["spellIDs"] = {
						[51052] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237510,
				},
				["消散"] = {
					["enabled"] = true,
					["refSpellID"] = 47585,
					["spellIDs"] = {
						[47585] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237563,
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["refSpellID"] = 122,
					["spellIDs"] = {
						[122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135848,
				},
				["轮回之触"] = {
					["enabled"] = true,
					["refSpellID"] = 115080,
					["spellIDs"] = {
						[115080] = true,
					},
					["cooldown"] = 60,
					["texture"] = 606552,
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["refSpellID"] = 48707,
					["spellIDs"] = {
						[48707] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136120,
				},
				["火焰石"] = {
					["enabled"] = true,
					["refSpellID"] = 212284,
					["spellIDs"] = {
						[212284] = true,
					},
					["cooldown"] = 45,
					["texture"] = 134085,
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["refSpellID"] = 196884,
					["spellIDs"] = {
						[196884] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1027879,
				},
				["鲁莽"] = {
					["enabled"] = true,
					["refSpellID"] = 1719,
					["spellIDs"] = {
						[1719] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458972,
				},
				["游侠之网"] = {
					["enabled"] = true,
					["refSpellID"] = 200108,
					["spellIDs"] = {
						[200108] = true,
					},
					["cooldown"] = 60,
					["texture"] = 134325,
				},
				["虚空联结"] = {
					["enabled"] = true,
					["refSpellID"] = 207810,
					["spellIDs"] = {
						[207810] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1450144,
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 5217,
					["spellIDs"] = {
						[5217] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132242,
				},
				["风剪"] = {
					["enabled"] = true,
					["refSpellID"] = 57994,
					["spellIDs"] = {
						[57994] = true,
					},
					["cooldown"] = 12,
					["texture"] = 136018,
				},
				["灭战者"] = {
					["enabled"] = true,
					["refSpellID"] = 262161,
					["spellIDs"] = {
						[262161] = true,
					},
					["cooldown"] = 45,
					["texture"] = 2065633,
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["refSpellID"] = 49028,
					["spellIDs"] = {
						[49028] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135277,
				},
				["石像形态"] = {
					["enabled"] = true,
					["refSpellID"] = 20594,
					["spellIDs"] = {
						[20594] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136225,
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["refSpellID"] = 201318,
					["spellIDs"] = {
						[201318] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1616072,
				},
				["压制"] = {
					["enabled"] = true,
					["refSpellID"] = 187707,
					["spellIDs"] = {
						[187707] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1376045,
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 110959,
					["spellIDs"] = {
						[110959] = true,
					},
					["cooldown"] = 75,
					["texture"] = 575584,
				},
				["剑在人在"] = {
					["enabled"] = true,
					["refSpellID"] = 118038,
					["spellIDs"] = {
						[118038] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132336,
				},
				["自利"] = {
					["enabled"] = true,
					["refSpellID"] = 59752,
					["spellIDs"] = {
						[59752] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136129,
				},
				["反击图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204331,
					["spellIDs"] = {
						[204331] = true,
					},
					["cooldown"] = 45,
					["texture"] = 511726,
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 207684,
					["spellIDs"] = {
						[207684] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418287,
				},
				["阵风"] = {
					["enabled"] = true,
					["refSpellID"] = 192063,
					["spellIDs"] = {
						[192063] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1029585,
				},
				["混乱新星"] = {
					["enabled"] = true,
					["refSpellID"] = 179057,
					["spellIDs"] = {
						[179057] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135795,
				},
				["切喉手"] = {
					["enabled"] = true,
					["refSpellID"] = 116705,
					["spellIDs"] = {
						[116705] = true,
					},
					["cooldown"] = 15,
					["texture"] = 608940,
				},
				["法术封锁"] = {
					["enabled"] = true,
					["refSpellID"] = 19647,
					["spellIDs"] = {
						[19647] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136174,
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["refSpellID"] = 115781,
					["spellIDs"] = {
						[115781] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136028,
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["refSpellID"] = 80483,
					["spellIDs"] = {
						[80483] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136222,
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["refSpellID"] = 11426,
					["spellIDs"] = {
						[11426] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135988,
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 204150,
					["spellIDs"] = {
						[204150] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135909,
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 89751,
					["spellIDs"] = {
						[89751] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236303,
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 6789,
					["spellIDs"] = {
						[6789] = true,
					},
					["cooldown"] = 45,
					["texture"] = 607853,
				},
				["生存本能"] = {
					["enabled"] = true,
					["refSpellID"] = 61336,
					["spellIDs"] = {
						[61336] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236169,
				},
				["闪避"] = {
					["enabled"] = true,
					["refSpellID"] = 5277,
					["spellIDs"] = {
						[5277] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136205,
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["refSpellID"] = 64843,
					["spellIDs"] = {
						[64843] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237540,
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["refSpellID"] = 201078,
					["spellIDs"] = {
						[201078] = true,
					},
					["cooldown"] = 120,
					["texture"] = 254647,
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186265,
					["spellIDs"] = {
						[186265] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132199,
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 31884,
					["spellIDs"] = {
						[31884] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135875,
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 91802,
					["spellIDs"] = {
						[91802] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237569,
				},
				["燃烧"] = {
					["enabled"] = true,
					["refSpellID"] = 190319,
					["spellIDs"] = {
						[190319] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135824,
				},
				["唤醒"] = {
					["enabled"] = true,
					["refSpellID"] = 12051,
					["spellIDs"] = {
						[12051] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136075,
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["refSpellID"] = 206491,
					["spellIDs"] = {
						[206491] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236299,
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["refSpellID"] = 42292,
					["spellIDs"] = {
						[42292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 200851,
					["spellIDs"] = {
						[200851] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1129695,
				},
				["法术反射"] = {
					["enabled"] = true,
					["refSpellID"] = 23920,
					["spellIDs"] = {
						[23920] = true,
					},
					["cooldown"] = 25,
					["texture"] = 132361,
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 123904,
					["spellIDs"] = {
						[123904] = true,
					},
					["cooldown"] = 180,
					["texture"] = 620832,
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["refSpellID"] = 45438,
					["spellIDs"] = {
						[45438] = true,
					},
					["cooldown"] = 240,
					["texture"] = 135841,
				},
				["时光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 198111,
					["spellIDs"] = {
						[198111] = true,
					},
					["cooldown"] = 45,
					["texture"] = 610472,
				},
				["脚踢"] = {
					["enabled"] = true,
					["refSpellID"] = 1766,
					["spellIDs"] = {
						[1766] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132219,
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 18499,
					["spellIDs"] = {
						[18499] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136009,
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202137,
					["spellIDs"] = {
						[202137] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418288,
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["refSpellID"] = 198664,
					["spellIDs"] = {
						[198664] = true,
					},
					["cooldown"] = 180,
					["texture"] = 877514,
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["refSpellID"] = 194223,
					["spellIDs"] = {
						[194223] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136060,
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 98008,
					["spellIDs"] = {
						[98008] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237586,
				},
				["拳击"] = {
					["enabled"] = true,
					["refSpellID"] = 6552,
					["spellIDs"] = {
						[6552] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132938,
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["refSpellID"] = 211881,
					["spellIDs"] = {
						[211881] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1118739,
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 51485,
					["spellIDs"] = {
						[51485] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136100,
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["refSpellID"] = 59543,
					["spellIDs"] = {
						[59543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135923,
				},
				["宁静"] = {
					["enabled"] = true,
					["refSpellID"] = 740,
					["spellIDs"] = {
						[740] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136107,
				},
				["急奔"] = {
					["enabled"] = true,
					["refSpellID"] = 1850,
					["spellIDs"] = {
						[1850] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132120,
				},
				["缴械"] = {
					["enabled"] = true,
					["refSpellID"] = 236077,
					["spellIDs"] = {
						[236077] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132343,
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 212295,
					["spellIDs"] = {
						[212295] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135796,
				},
				["自然之力"] = {
					["enabled"] = true,
					["refSpellID"] = 205636,
					["spellIDs"] = {
						[205636] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132129,
				},
				["根基图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204336,
					["spellIDs"] = {
						[204336] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136039,
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["refSpellID"] = 209749,
					["spellIDs"] = {
						[209749] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538516,
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["refSpellID"] = 184364,
					["spellIDs"] = {
						[184364] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132345,
				},
				["保护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1022,
					["spellIDs"] = {
						[1022] = true,
					},
					["cooldown"] = 135,
					["texture"] = 135964,
				},
				["血之镜像"] = {
					["enabled"] = true,
					["refSpellID"] = 206977,
					["spellIDs"] = {
						[206977] = true,
					},
					["cooldown"] = 120,
					["texture"] = 134084,
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 196932,
					["spellIDs"] = {
						[196932] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136232,
				},
				["平心之环"] = {
					["enabled"] = true,
					["refSpellID"] = 116844,
					["spellIDs"] = {
						[116844] = true,
					},
					["cooldown"] = 45,
					["texture"] = 839107,
				},
				["虚空转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108968,
					["spellIDs"] = {
						[108968] = true,
					},
					["cooldown"] = 300,
					["texture"] = 537079,
				},
				["急速冷却"] = {
					["enabled"] = true,
					["refSpellID"] = 235219,
					["spellIDs"] = {
						[235219] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135865,
				},
				["光环掌握"] = {
					["enabled"] = true,
					["refSpellID"] = 31821,
					["spellIDs"] = {
						[31821] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135872,
				},
				["火箭跳"] = {
					["enabled"] = true,
					["refSpellID"] = 69070,
					["spellIDs"] = {
						[69070] = true,
					},
					["cooldown"] = 120,
					["texture"] = 370769,
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["refSpellID"] = 19386,
					["spellIDs"] = {
						[19386] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135125,
				},
				["伪装"] = {
					["enabled"] = true,
					["refSpellID"] = 199483,
					["spellIDs"] = {
						[199483] = true,
					},
					["cooldown"] = 60,
					["texture"] = 461113,
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186289,
					["spellIDs"] = {
						[186289] = true,
					},
					["cooldown"] = 120,
					["texture"] = 612363,
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["refSpellID"] = 63560,
					["spellIDs"] = {
						[63560] = true,
					},
					["cooldown"] = 60,
					["texture"] = 342913,
				},
				["抓钩"] = {
					["enabled"] = true,
					["refSpellID"] = 195457,
					["spellIDs"] = {
						[195457] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1373906,
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["refSpellID"] = 205369,
					["spellIDs"] = {
						[205369] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136173,
				},
				["圣佑术"] = {
					["enabled"] = true,
					["refSpellID"] = 498,
					["spellIDs"] = {
						[498] = true,
					},
					["cooldown"] = 60,
					["texture"] = 524353,
				},
				["禁锢"] = {
					["enabled"] = true,
					["refSpellID"] = 221527,
					["spellIDs"] = {
						[221527] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380368,
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["refSpellID"] = 207349,
					["spellIDs"] = {
						[207349] = true,
					},
					["cooldown"] = 120,
					["texture"] = 298674,
				},
				["责难"] = {
					["enabled"] = true,
					["refSpellID"] = 96231,
					["spellIDs"] = {
						[96231] = true,
					},
					["cooldown"] = 15,
					["texture"] = 523893,
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 202246,
					["spellIDs"] = {
						[202246] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1408833,
				},
				["冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 100,
					["spellIDs"] = {
						[100] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132337,
				},
				["意气风发"] = {
					["enabled"] = true,
					["refSpellID"] = 109304,
					["spellIDs"] = {
						[109304] = true,
					},
					["cooldown"] = 120,
					["texture"] = 461117,
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 205629,
					["spellIDs"] = {
						[205629] = true,
					},
					["cooldown"] = 30,
					["texture"] = 134294,
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 207736,
					["spellIDs"] = {
						[207736] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1020341,
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["refSpellID"] = 119381,
					["spellIDs"] = {
						[119381] = true,
					},
					["cooldown"] = 60,
					["texture"] = 642414,
				},
				["圣盾术"] = {
					["enabled"] = true,
					["refSpellID"] = 642,
					["spellIDs"] = {
						[642] = true,
					},
					["cooldown"] = 240,
					["texture"] = 524354,
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["refSpellID"] = 7744,
					["spellIDs"] = {
						[7744] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136187,
				},
				["虚空行走"] = {
					["enabled"] = true,
					["refSpellID"] = 196555,
					["spellIDs"] = {
						[196555] = true,
					},
					["cooldown"] = 120,
					["texture"] = 463284,
				},
				["战旗"] = {
					["enabled"] = true,
					["refSpellID"] = 236320,
					["spellIDs"] = {
						[236320] = true,
					},
					["cooldown"] = 90,
					["texture"] = 603532,
				},
				["还击"] = {
					["enabled"] = true,
					["refSpellID"] = 199754,
					["spellIDs"] = {
						[199754] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132269,
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 227847,
					["spellIDs"] = {
						[227847] = true,
					},
					["cooldown"] = 60,
					["texture"] = 236303,
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186257,
					["spellIDs"] = {
						[186257] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132242,
				},
				["甘霖"] = {
					["enabled"] = true,
					["refSpellID"] = 108238,
					["spellIDs"] = {
						[108238] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136059,
				},
				["决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 236273,
					["spellIDs"] = {
						[236273] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1455893,
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202138,
					["spellIDs"] = {
						[202138] = true,
					},
					["cooldown"] = 54,
					["texture"] = 1418286,
				},
				["百发百中"] = {
					["enabled"] = true,
					["refSpellID"] = 193526,
					["spellIDs"] = {
						[193526] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132329,
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["refSpellID"] = 31224,
					["spellIDs"] = {
						[31224] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136177,
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["refSpellID"] = 205191,
					["spellIDs"] = {
						[205191] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135986,
				},
				["群体反射"] = {
					["enabled"] = true,
					["refSpellID"] = 213915,
					["spellIDs"] = {
						[213915] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132358,
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["refSpellID"] = 53271,
					["spellIDs"] = {
						[53271] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236189,
				},
				["从天而降"] = {
					["enabled"] = true,
					["refSpellID"] = 206803,
					["spellIDs"] = {
						[206803] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380371,
				},
				["驱散射击"] = {
					["enabled"] = true,
					["refSpellID"] = 213691,
					["spellIDs"] = {
						[213691] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132153,
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 108280,
					["spellIDs"] = {
						[108280] = true,
					},
					["cooldown"] = 180,
					["texture"] = 538569,
				},
				["能量灌注"] = {
					["enabled"] = true,
					["refSpellID"] = 10060,
					["spellIDs"] = {
						[10060] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135939,
				},
				["窒息"] = {
					["enabled"] = true,
					["refSpellID"] = 47476,
					["spellIDs"] = {
						[47476] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["卸除武装"] = {
					["enabled"] = true,
					["refSpellID"] = 207777,
					["spellIDs"] = {
						[207777] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236272,
				},
				["升腾"] = {
					["enabled"] = true,
					["refSpellID"] = 114050,
					["spellIDs"] = {
						[114050] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135791,
				},
				["拦截"] = {
					["enabled"] = true,
					["refSpellID"] = 198304,
					["spellIDs"] = {
						[198304] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132365,
				},
				["闪现术"] = {
					["enabled"] = true,
					["refSpellID"] = 1953,
					["spellIDs"] = {
						[1953] = true,
					},
					["cooldown"] = 15,
					["texture"] = 135736,
				},
				["树皮术"] = {
					["enabled"] = true,
					["refSpellID"] = 22812,
					["spellIDs"] = {
						[22812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136097,
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["refSpellID"] = 5484,
					["spellIDs"] = {
						[5484] = true,
					},
					["cooldown"] = 40,
					["texture"] = 607852,
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["refSpellID"] = 89766,
					["spellIDs"] = {
						[89766] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236316,
				},
				["反转魔法"] = {
					["enabled"] = true,
					["refSpellID"] = 205604,
					["spellIDs"] = {
						[205604] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380372,
				},
				["火焰之息"] = {
					["enabled"] = true,
					["refSpellID"] = 115181,
					["spellIDs"] = {
						[115181] = true,
					},
					["cooldown"] = 15,
					["texture"] = 615339,
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["refSpellID"] = 216113,
					["spellIDs"] = {
						[216113] = true,
					},
					["cooldown"] = 45,
					["texture"] = 977169,
				},
				["疾跑"] = {
					["enabled"] = true,
					["refSpellID"] = 2983,
					["spellIDs"] = {
						[2983] = true,
					},
					["cooldown"] = 51,
					["texture"] = 132307,
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["refSpellID"] = 12292,
					["spellIDs"] = {
						[12292] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236304,
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["refSpellID"] = 64044,
					["spellIDs"] = {
						[64044] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237568,
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["refSpellID"] = 33891,
					["spellIDs"] = {
						[33891] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236157,
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["refSpellID"] = 115176,
					["spellIDs"] = {
						[115176] = true,
					},
					["cooldown"] = 150,
					["texture"] = 642417,
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["refSpellID"] = 121471,
					["spellIDs"] = {
						[121471] = true,
					},
					["cooldown"] = 180,
					["texture"] = 376022,
				},
				["冲动"] = {
					["enabled"] = true,
					["refSpellID"] = 13750,
					["spellIDs"] = {
						[13750] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136206,
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["refSpellID"] = 8122,
					["spellIDs"] = {
						[8122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136184,
				},
				["躯不坏"] = {
					["enabled"] = true,
					["refSpellID"] = 122278,
					["spellIDs"] = {
						[122278] = true,
					},
					["cooldown"] = 120,
					["texture"] = 620827,
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 208683,
					["spellIDs"] = {
						[208683] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["暗影步"] = {
					["enabled"] = true,
					["refSpellID"] = 36554,
					["spellIDs"] = {
						[36554] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132303,
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["refSpellID"] = 213602,
					["spellIDs"] = {
						[213602] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135994,
				},
				["凿击"] = {
					["enabled"] = true,
					["refSpellID"] = 1776,
					["spellIDs"] = {
						[1776] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132155,
				},
				["逃命专家"] = {
					["enabled"] = true,
					["refSpellID"] = 20589,
					["spellIDs"] = {
						[20589] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132309,
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["refSpellID"] = 191427,
					["spellIDs"] = {
						[191427] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1247262,
				},
				["圣疗术"] = {
					["enabled"] = true,
					["refSpellID"] = 633,
					["spellIDs"] = {
						[633] = true,
					},
					["cooldown"] = 600,
					["texture"] = 135928,
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 210256,
					["spellIDs"] = {
						[210256] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135911,
				},
				["自由祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1044,
					["spellIDs"] = {
						[1044] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135968,
				},
				["散魔功"] = {
					["enabled"] = true,
					["refSpellID"] = 122783,
					["spellIDs"] = {
						[122783] = true,
					},
					["cooldown"] = 90,
					["texture"] = 775460,
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["refSpellID"] = 212459,
					["spellIDs"] = {
						[212459] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1113433,
				},
				["闪光力场"] = {
					["enabled"] = true,
					["refSpellID"] = 204263,
					["spellIDs"] = {
						[204263] = true,
					},
					["cooldown"] = 45,
					["texture"] = 571554,
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["refSpellID"] = 102560,
					["spellIDs"] = {
						[102560] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 204018,
					["spellIDs"] = {
						[204018] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135880,
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["refSpellID"] = 5211,
					["spellIDs"] = {
						[5211] = true,
					},
					["cooldown"] = 50,
					["texture"] = 132114,
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157997,
					["spellIDs"] = {
						[157997] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033909,
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["refSpellID"] = 119996,
					["spellIDs"] = {
						[119996] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237585,
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["refSpellID"] = 47528,
					["spellIDs"] = {
						[47528] = true,
					},
					["cooldown"] = 15,
					["texture"] = 237527,
				},
				["业报之触"] = {
					["enabled"] = true,
					["refSpellID"] = 122470,
					["spellIDs"] = {
						[122470] = true,
					},
					["cooldown"] = 90,
					["texture"] = 651728,
				},
				["盾墙"] = {
					["enabled"] = true,
					["refSpellID"] = 871,
					["spellIDs"] = {
						[871] = true,
					},
					["cooldown"] = 240,
					["texture"] = 132362,
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["refSpellID"] = 68992,
					["spellIDs"] = {
						[68992] = true,
					},
					["cooldown"] = 120,
					["texture"] = 366937,
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["refSpellID"] = 190784,
					["spellIDs"] = {
						[190784] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1360759,
				},
				["龙息术"] = {
					["enabled"] = true,
					["refSpellID"] = 31661,
					["spellIDs"] = {
						[31661] = true,
					},
					["cooldown"] = 20,
					["texture"] = 134153,
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["refSpellID"] = 212182,
					["spellIDs"] = {
						[212182] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458733,
				},
				["沉默"] = {
					["enabled"] = true,
					["refSpellID"] = 15487,
					["spellIDs"] = {
						[15487] = true,
					},
					["cooldown"] = 45,
					["texture"] = 458230,
				},
				["巨人打击"] = {
					["enabled"] = true,
					["refSpellID"] = 167105,
					["spellIDs"] = {
						[167105] = true,
					},
					["cooldown"] = 45,
					["texture"] = 464973,
				},
				["元素宗师"] = {
					["enabled"] = true,
					["refSpellID"] = 16166,
					["spellIDs"] = {
						[16166] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136027,
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["refSpellID"] = 51271,
					["spellIDs"] = {
						[51271] = true,
					},
					["cooldown"] = 60,
					["texture"] = 458718,
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 51490,
					["spellIDs"] = {
						[51490] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237589,
				},
				["血魔之握"] = {
					["enabled"] = true,
					["refSpellID"] = 108199,
					["spellIDs"] = {
						[108199] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538767,
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["refSpellID"] = 49206,
					["spellIDs"] = {
						[49206] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458967,
				},
				["风火雷电"] = {
					["enabled"] = true,
					["refSpellID"] = 137639,
					["spellIDs"] = {
						[137639] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136038,
				},
				["星界转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108271,
					["spellIDs"] = {
						[108271] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538565,
				},
				["还魂术"] = {
					["enabled"] = true,
					["refSpellID"] = 115310,
					["spellIDs"] = {
						[115310] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1020466,
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["refSpellID"] = 31687,
					["spellIDs"] = {
						[31687] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135862,
				},
				["宿敌"] = {
					["enabled"] = true,
					["refSpellID"] = 79140,
					["spellIDs"] = {
						[79140] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458726,
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["refSpellID"] = 202370,
					["spellIDs"] = {
						[202370] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1381297,
				},
				["斗转星移"] = {
					["enabled"] = true,
					["refSpellID"] = 202162,
					["spellIDs"] = {
						[202162] = true,
					},
					["cooldown"] = 45,
					["texture"] = 620829,
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 86659,
					["spellIDs"] = {
						[86659] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135919,
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 6544,
					["spellIDs"] = {
						[6544] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236171,
				},
				["反制射击"] = {
					["enabled"] = true,
					["refSpellID"] = 147362,
					["spellIDs"] = {
						[147362] = true,
					},
					["cooldown"] = 24,
					["texture"] = 249170,
				},
				["灵体形态"] = {
					["enabled"] = true,
					["refSpellID"] = 210918,
					["spellIDs"] = {
						[210918] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237572,
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 73325,
					["spellIDs"] = {
						[73325] = true,
					},
					["cooldown"] = 45,
					["texture"] = 463835,
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["refSpellID"] = 102793,
					["spellIDs"] = {
						[102793] = true,
					},
					["cooldown"] = 60,
					["texture"] = 571588,
				},
				["英勇"] = {
					["enabled"] = true,
					["refSpellID"] = 32182,
					["spellIDs"] = {
						[32182] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132313,
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["refSpellID"] = 108416,
					["spellIDs"] = {
						[108416] = true,
					},
					["cooldown"] = 60,
					["texture"] = 538538,
				},
				["束缚射击"] = {
					["enabled"] = true,
					["refSpellID"] = 109248,
					["spellIDs"] = {
						[109248] = true,
					},
					["cooldown"] = 45,
					["texture"] = 462650,
				},
				["守护之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 47788,
					["spellIDs"] = {
						[47788] = true,
					},
					["cooldown"] = 60,
					["texture"] = 237542,
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["refSpellID"] = 48020,
					["spellIDs"] = {
						[48020] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237560,
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["refSpellID"] = 105809,
					["spellIDs"] = {
						[105809] = true,
					},
					["cooldown"] = 90,
					["texture"] = 571555,
				},
				["割碎"] = {
					["enabled"] = true,
					["refSpellID"] = 22570,
					["spellIDs"] = {
						[22570] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132134,
				},
				["摧心魔"] = {
					["enabled"] = true,
					["refSpellID"] = 123040,
					["spellIDs"] = {
						[123040] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["refSpellID"] = 102543,
					["spellIDs"] = {
						[102543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["refSpellID"] = 12472,
					["spellIDs"] = {
						[12472] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135838,
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["refSpellID"] = 209789,
					["spellIDs"] = {
						[209789] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1033903,
				},
				["隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 66,
					["spellIDs"] = {
						[66] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132220,
				},
				["幻影打击"] = {
					["enabled"] = true,
					["refSpellID"] = 196718,
					["spellIDs"] = {
						[196718] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1305154,
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["refSpellID"] = 207319,
					["spellIDs"] = {
						[207319] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1531513,
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["refSpellID"] = 31850,
					["spellIDs"] = {
						[31850] = true,
					},
					["cooldown"] = 110,
					["texture"] = 135870,
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["refSpellID"] = 108201,
					["spellIDs"] = {
						[108201] = true,
					},
					["cooldown"] = 120,
					["texture"] = 538768,
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["refSpellID"] = 33206,
					["spellIDs"] = {
						[33206] = true,
					},
					["cooldown"] = 210,
					["texture"] = 135936,
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["refSpellID"] = 201325,
					["spellIDs"] = {
						[201325] = true,
					},
					["cooldown"] = 180,
					["texture"] = 642417,
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["refSpellID"] = 188501,
					["spellIDs"] = {
						[188501] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1247266,
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["refSpellID"] = 216331,
					["spellIDs"] = {
						[216331] = true,
					},
					["cooldown"] = 60,
					["texture"] = 589117,
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["refSpellID"] = 198898,
					["spellIDs"] = {
						[198898] = true,
					},
					["cooldown"] = 15,
					["texture"] = 332402,
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["refSpellID"] = 19236,
					["spellIDs"] = {
						[19236] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237550,
				},
				["奥术强化"] = {
					["enabled"] = true,
					["refSpellID"] = 12042,
					["spellIDs"] = {
						[12042] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136048,
				},
				["致盲"] = {
					["enabled"] = true,
					["refSpellID"] = 2094,
					["spellIDs"] = {
						[2094] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136175,
				},
				["闪回"] = {
					["enabled"] = true,
					["refSpellID"] = 195676,
					["spellIDs"] = {
						[195676] = true,
					},
					["cooldown"] = 24,
					["texture"] = 132171,
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["refSpellID"] = 228049,
					["spellIDs"] = {
						[228049] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135919,
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["refSpellID"] = 79206,
					["spellIDs"] = {
						[79206] = true,
					},
					["cooldown"] = 60,
					["texture"] = 451170,
				},
				["牺牲"] = {
					["enabled"] = true,
					["refSpellID"] = 7812,
					["spellIDs"] = {
						[7812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136190,
				},
				["正中眉心"] = {
					["enabled"] = true,
					["refSpellID"] = 199804,
					["spellIDs"] = {
						[199804] = true,
					},
					["cooldown"] = 20,
					["texture"] = 135610,
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["refSpellID"] = 187650,
					["spellIDs"] = {
						[187650] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135834,
				},
				["台风"] = {
					["enabled"] = true,
					["refSpellID"] = 132469,
					["spellIDs"] = {
						[132469] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236170,
				},
				["肾击"] = {
					["enabled"] = true,
					["refSpellID"] = 408,
					["spellIDs"] = {
						[408] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132298,
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["refSpellID"] = 84714,
					["spellIDs"] = {
						[84714] = true,
					},
					["cooldown"] = 60,
					["texture"] = 629077,
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["refSpellID"] = 69041,
					["spellIDs"] = {
						[69041] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133032,
				},
				["日光术"] = {
					["enabled"] = true,
					["refSpellID"] = 78675,
					["spellIDs"] = {
						[78675] = true,
					},
					["cooldown"] = 30,
					["texture"] = 252188,
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["refSpellID"] = 77606,
					["spellIDs"] = {
						[77606] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135888,
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["refSpellID"] = 208253,
					["spellIDs"] = {
						[208253] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1115592,
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 30283,
					["spellIDs"] = {
						[30283] = true,
					},
					["cooldown"] = 30,
					["texture"] = 607865,
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 102359,
					["spellIDs"] = {
						[102359] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538515,
				},
				["真言术：障"] = {
					["enabled"] = true,
					["refSpellID"] = 62618,
					["spellIDs"] = {
						[62618] = true,
					},
					["cooldown"] = 120,
					["texture"] = 253400,
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["refSpellID"] = 106839,
					["spellIDs"] = {
						[106839] = true,
					},
					["cooldown"] = 15,
					["texture"] = 236946,
				},
				["瓦解"] = {
					["enabled"] = true,
					["refSpellID"] = 183752,
					["spellIDs"] = {
						[183752] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1305153,
				},
				["战争践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 11876,
					["spellIDs"] = {
						[11876] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132091,
				},
				["妖术"] = {
					["enabled"] = true,
					["refSpellID"] = 51514,
					["spellIDs"] = {
						[51514] = true,
					},
					["cooldown"] = 10,
					["texture"] = 237579,
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["refSpellID"] = 205630,
					["spellIDs"] = {
						[205630] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380367,
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["refSpellID"] = 152173,
					["spellIDs"] = {
						[152173] = true,
					},
					["cooldown"] = 90,
					["texture"] = 988197,
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 107570,
					["spellIDs"] = {
						[107570] = true,
					},
					["cooldown"] = 30,
					["texture"] = 613535,
				},
				["疾影"] = {
					["enabled"] = true,
					["refSpellID"] = 198589,
					["spellIDs"] = {
						[198589] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1305150,
				},
				["不灭决心"] = {
					["enabled"] = true,
					["refSpellID"] = 104773,
					["spellIDs"] = {
						[104773] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136150,
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 6940,
					["spellIDs"] = {
						[6940] = true,
					},
					["cooldown"] = 75,
					["texture"] = 135966,
				},
				["逃脱"] = {
					["enabled"] = true,
					["refSpellID"] = 781,
					["spellIDs"] = {
						[781] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132294,
				},
				["胁迫"] = {
					["enabled"] = true,
					["refSpellID"] = 19577,
					["spellIDs"] = {
						[19577] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132111,
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["refSpellID"] = 88625,
					["spellIDs"] = {
						[88625] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135886,
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["refSpellID"] = 51533,
					["spellIDs"] = {
						[51533] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237577,
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["refSpellID"] = 115078,
					["spellIDs"] = {
						[115078] = true,
					},
					["cooldown"] = 15,
					["texture"] = 629534,
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["refSpellID"] = 5246,
					["spellIDs"] = {
						[5246] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132154,
				},
				["天神下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 107574,
					["spellIDs"] = {
						[107574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 613534,
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["refSpellID"] = 205691,
					["spellIDs"] = {
						[205691] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1412204,
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["refSpellID"] = 186387,
					["spellIDs"] = {
						[186387] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1376038,
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["refSpellID"] = 19574,
					["spellIDs"] = {
						[19574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132127,
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["refSpellID"] = 12975,
					["spellIDs"] = {
						[12975] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135871,
				},
				["消失"] = {
					["enabled"] = true,
					["refSpellID"] = 1856,
					["spellIDs"] = {
						[1856] = true,
					},
					["cooldown"] = 75,
					["texture"] = 132331,
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 207399,
					["spellIDs"] = {
						[207399] = true,
					},
					["cooldown"] = 300,
					["texture"] = 136080,
				},
				["影遁"] = {
					["enabled"] = true,
					["refSpellID"] = 58984,
					["spellIDs"] = {
						[58984] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132089,
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["refSpellID"] = 1122,
					["spellIDs"] = {
						[1122] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136219,
				},
				["复生"] = {
					["enabled"] = true,
					["refSpellID"] = 20484,
					["spellIDs"] = {
						[20484] = true,
					},
					["cooldown"] = 600,
					["texture"] = 136080,
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["refSpellID"] = 33697,
					["spellIDs"] = {
						[33697] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135726,
				},
			},
			["DBVersion"] = 8,
		},
		["云雨別 - 索瑞森"] = {
			["DBVersion"] = 8,
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["refSpellID"] = 31230,
					["spellIDs"] = {
						[31230] = true,
					},
					["cooldown"] = 360,
					["texture"] = 132285,
				},
				["法术反制"] = {
					["enabled"] = true,
					["refSpellID"] = 2139,
					["spellIDs"] = {
						[2139] = true,
					},
					["cooldown"] = 24,
					["texture"] = 135856,
				},
				["天灾契约"] = {
					["enabled"] = true,
					["refSpellID"] = 48743,
					["spellIDs"] = {
						[48743] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136146,
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["refSpellID"] = 204437,
					["spellIDs"] = {
						[204437] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1385911,
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["refSpellID"] = 132578,
					["spellIDs"] = {
						[132578] = true,
					},
					["cooldown"] = 180,
					["texture"] = 608951,
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 206572,
					["spellIDs"] = {
						[206572] = true,
					},
					["cooldown"] = 20,
					["texture"] = 1380676,
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 215769,
					["spellIDs"] = {
						[215769] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132864,
				},
				["震荡波"] = {
					["enabled"] = true,
					["refSpellID"] = 46968,
					["spellIDs"] = {
						[46968] = true,
					},
					["cooldown"] = 40,
					["texture"] = 236312,
				},
				["谈判"] = {
					["enabled"] = true,
					["refSpellID"] = 199743,
					["spellIDs"] = {
						[199743] = true,
					},
					["cooldown"] = 20,
					["texture"] = 236448,
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 195710,
					["spellIDs"] = {
						[195710] = true,
					},
					["cooldown"] = 180,
					["texture"] = 338784,
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["refSpellID"] = 207167,
					["spellIDs"] = {
						[207167] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135836,
				},
				["超级新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157980,
					["spellIDs"] = {
						[157980] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033912,
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["refSpellID"] = 206650,
					["spellIDs"] = {
						[206650] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380366,
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["refSpellID"] = 48792,
					["spellIDs"] = {
						[48792] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237525,
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["refSpellID"] = 102558,
					["spellIDs"] = {
						[102558] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["死亡之握"] = {
					["enabled"] = true,
					["refSpellID"] = 49576,
					["spellIDs"] = {
						[49576] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237532,
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 853,
					["spellIDs"] = {
						[853] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135963,
				},
				["狂暴"] = {
					["enabled"] = true,
					["refSpellID"] = 26297,
					["spellIDs"] = {
						[26297] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135727,
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["refSpellID"] = 116849,
					["spellIDs"] = {
						[116849] = true,
					},
					["cooldown"] = 90,
					["texture"] = 627485,
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["refSpellID"] = 198817,
					["spellIDs"] = {
						[198817] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1380678,
				},
				["嗜血"] = {
					["enabled"] = true,
					["refSpellID"] = 2825,
					["spellIDs"] = {
						[2825] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136012,
				},
				["墓石"] = {
					["enabled"] = true,
					["refSpellID"] = 219809,
					["spellIDs"] = {
						[219809] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132151,
				},
				["电能图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 192058,
					["spellIDs"] = {
						[192058] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136013,
				},
				["影舞步"] = {
					["enabled"] = true,
					["refSpellID"] = 51690,
					["spellIDs"] = {
						[51690] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236277,
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["refSpellID"] = 108359,
					["spellIDs"] = {
						[108359] = true,
					},
					["cooldown"] = 120,
					["texture"] = 537516,
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["refSpellID"] = 102342,
					["spellIDs"] = {
						[102342] = true,
					},
					["cooldown"] = 90,
					["texture"] = 572025,
				},
				["亡者大军"] = {
					["enabled"] = true,
					["refSpellID"] = 42650,
					["spellIDs"] = {
						[42650] = true,
					},
					["cooldown"] = 600,
					["texture"] = 237511,
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["refSpellID"] = 198529,
					["spellIDs"] = {
						[198529] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133787,
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["refSpellID"] = 51052,
					["spellIDs"] = {
						[51052] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237510,
				},
				["消散"] = {
					["enabled"] = true,
					["refSpellID"] = 47585,
					["spellIDs"] = {
						[47585] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237563,
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["refSpellID"] = 122,
					["spellIDs"] = {
						[122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135848,
				},
				["轮回之触"] = {
					["enabled"] = true,
					["refSpellID"] = 115080,
					["spellIDs"] = {
						[115080] = true,
					},
					["cooldown"] = 60,
					["texture"] = 606552,
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["refSpellID"] = 48707,
					["spellIDs"] = {
						[48707] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136120,
				},
				["火焰石"] = {
					["enabled"] = true,
					["refSpellID"] = 212284,
					["spellIDs"] = {
						[212284] = true,
					},
					["cooldown"] = 45,
					["texture"] = 134085,
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["refSpellID"] = 196884,
					["spellIDs"] = {
						[196884] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1027879,
				},
				["鲁莽"] = {
					["enabled"] = true,
					["refSpellID"] = 1719,
					["spellIDs"] = {
						[1719] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458972,
				},
				["游侠之网"] = {
					["enabled"] = true,
					["refSpellID"] = 200108,
					["spellIDs"] = {
						[200108] = true,
					},
					["cooldown"] = 60,
					["texture"] = 134325,
				},
				["虚空联结"] = {
					["enabled"] = true,
					["refSpellID"] = 207810,
					["spellIDs"] = {
						[207810] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1450144,
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 5217,
					["spellIDs"] = {
						[5217] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132242,
				},
				["风剪"] = {
					["enabled"] = true,
					["refSpellID"] = 57994,
					["spellIDs"] = {
						[57994] = true,
					},
					["cooldown"] = 12,
					["texture"] = 136018,
				},
				["灭战者"] = {
					["enabled"] = true,
					["refSpellID"] = 262161,
					["spellIDs"] = {
						[262161] = true,
					},
					["cooldown"] = 45,
					["texture"] = 2065633,
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["refSpellID"] = 49028,
					["spellIDs"] = {
						[49028] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135277,
				},
				["石像形态"] = {
					["enabled"] = true,
					["refSpellID"] = 20594,
					["spellIDs"] = {
						[20594] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136225,
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["refSpellID"] = 201318,
					["spellIDs"] = {
						[201318] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1616072,
				},
				["压制"] = {
					["enabled"] = true,
					["refSpellID"] = 187707,
					["spellIDs"] = {
						[187707] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1376045,
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 110959,
					["spellIDs"] = {
						[110959] = true,
					},
					["cooldown"] = 75,
					["texture"] = 575584,
				},
				["剑在人在"] = {
					["enabled"] = true,
					["refSpellID"] = 118038,
					["spellIDs"] = {
						[118038] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132336,
				},
				["自利"] = {
					["enabled"] = true,
					["refSpellID"] = 59752,
					["spellIDs"] = {
						[59752] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136129,
				},
				["反击图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204331,
					["spellIDs"] = {
						[204331] = true,
					},
					["cooldown"] = 45,
					["texture"] = 511726,
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 207684,
					["spellIDs"] = {
						[207684] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418287,
				},
				["阵风"] = {
					["enabled"] = true,
					["refSpellID"] = 192063,
					["spellIDs"] = {
						[192063] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1029585,
				},
				["混乱新星"] = {
					["enabled"] = true,
					["refSpellID"] = 179057,
					["spellIDs"] = {
						[179057] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135795,
				},
				["切喉手"] = {
					["enabled"] = true,
					["refSpellID"] = 116705,
					["spellIDs"] = {
						[116705] = true,
					},
					["cooldown"] = 15,
					["texture"] = 608940,
				},
				["法术封锁"] = {
					["enabled"] = true,
					["refSpellID"] = 19647,
					["spellIDs"] = {
						[19647] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136174,
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["refSpellID"] = 115781,
					["spellIDs"] = {
						[115781] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136028,
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["refSpellID"] = 80483,
					["spellIDs"] = {
						[80483] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136222,
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["refSpellID"] = 11426,
					["spellIDs"] = {
						[11426] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135988,
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 204150,
					["spellIDs"] = {
						[204150] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135909,
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 89751,
					["spellIDs"] = {
						[89751] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236303,
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 6789,
					["spellIDs"] = {
						[6789] = true,
					},
					["cooldown"] = 45,
					["texture"] = 607853,
				},
				["生存本能"] = {
					["enabled"] = true,
					["refSpellID"] = 61336,
					["spellIDs"] = {
						[61336] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236169,
				},
				["闪避"] = {
					["enabled"] = true,
					["refSpellID"] = 5277,
					["spellIDs"] = {
						[5277] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136205,
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["refSpellID"] = 64843,
					["spellIDs"] = {
						[64843] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237540,
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["refSpellID"] = 201078,
					["spellIDs"] = {
						[201078] = true,
					},
					["cooldown"] = 120,
					["texture"] = 254647,
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186265,
					["spellIDs"] = {
						[186265] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132199,
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 31884,
					["spellIDs"] = {
						[31884] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135875,
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 91802,
					["spellIDs"] = {
						[91802] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237569,
				},
				["燃烧"] = {
					["enabled"] = true,
					["refSpellID"] = 190319,
					["spellIDs"] = {
						[190319] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135824,
				},
				["唤醒"] = {
					["enabled"] = true,
					["refSpellID"] = 12051,
					["spellIDs"] = {
						[12051] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136075,
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["refSpellID"] = 206491,
					["spellIDs"] = {
						[206491] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236299,
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["refSpellID"] = 42292,
					["spellIDs"] = {
						[42292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 200851,
					["spellIDs"] = {
						[200851] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1129695,
				},
				["法术反射"] = {
					["enabled"] = true,
					["refSpellID"] = 23920,
					["spellIDs"] = {
						[23920] = true,
					},
					["cooldown"] = 25,
					["texture"] = 132361,
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 123904,
					["spellIDs"] = {
						[123904] = true,
					},
					["cooldown"] = 180,
					["texture"] = 620832,
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["refSpellID"] = 45438,
					["spellIDs"] = {
						[45438] = true,
					},
					["cooldown"] = 240,
					["texture"] = 135841,
				},
				["时光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 198111,
					["spellIDs"] = {
						[198111] = true,
					},
					["cooldown"] = 45,
					["texture"] = 610472,
				},
				["脚踢"] = {
					["enabled"] = true,
					["refSpellID"] = 1766,
					["spellIDs"] = {
						[1766] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132219,
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 18499,
					["spellIDs"] = {
						[18499] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136009,
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202137,
					["spellIDs"] = {
						[202137] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418288,
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["refSpellID"] = 198664,
					["spellIDs"] = {
						[198664] = true,
					},
					["cooldown"] = 180,
					["texture"] = 877514,
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["refSpellID"] = 194223,
					["spellIDs"] = {
						[194223] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136060,
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 98008,
					["spellIDs"] = {
						[98008] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237586,
				},
				["拳击"] = {
					["enabled"] = true,
					["refSpellID"] = 6552,
					["spellIDs"] = {
						[6552] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132938,
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["refSpellID"] = 211881,
					["spellIDs"] = {
						[211881] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1118739,
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 51485,
					["spellIDs"] = {
						[51485] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136100,
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["refSpellID"] = 59543,
					["spellIDs"] = {
						[59543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135923,
				},
				["宁静"] = {
					["enabled"] = true,
					["refSpellID"] = 740,
					["spellIDs"] = {
						[740] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136107,
				},
				["急奔"] = {
					["enabled"] = true,
					["refSpellID"] = 1850,
					["spellIDs"] = {
						[1850] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132120,
				},
				["缴械"] = {
					["enabled"] = true,
					["refSpellID"] = 236077,
					["spellIDs"] = {
						[236077] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132343,
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 212295,
					["spellIDs"] = {
						[212295] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135796,
				},
				["自然之力"] = {
					["enabled"] = true,
					["refSpellID"] = 205636,
					["spellIDs"] = {
						[205636] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132129,
				},
				["根基图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204336,
					["spellIDs"] = {
						[204336] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136039,
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["refSpellID"] = 209749,
					["spellIDs"] = {
						[209749] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538516,
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["refSpellID"] = 184364,
					["spellIDs"] = {
						[184364] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132345,
				},
				["保护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1022,
					["spellIDs"] = {
						[1022] = true,
					},
					["cooldown"] = 135,
					["texture"] = 135964,
				},
				["血之镜像"] = {
					["enabled"] = true,
					["refSpellID"] = 206977,
					["spellIDs"] = {
						[206977] = true,
					},
					["cooldown"] = 120,
					["texture"] = 134084,
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 196932,
					["spellIDs"] = {
						[196932] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136232,
				},
				["平心之环"] = {
					["enabled"] = true,
					["refSpellID"] = 116844,
					["spellIDs"] = {
						[116844] = true,
					},
					["cooldown"] = 45,
					["texture"] = 839107,
				},
				["虚空转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108968,
					["spellIDs"] = {
						[108968] = true,
					},
					["cooldown"] = 300,
					["texture"] = 537079,
				},
				["急速冷却"] = {
					["enabled"] = true,
					["refSpellID"] = 235219,
					["spellIDs"] = {
						[235219] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135865,
				},
				["光环掌握"] = {
					["enabled"] = true,
					["refSpellID"] = 31821,
					["spellIDs"] = {
						[31821] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135872,
				},
				["火箭跳"] = {
					["enabled"] = true,
					["refSpellID"] = 69070,
					["spellIDs"] = {
						[69070] = true,
					},
					["cooldown"] = 120,
					["texture"] = 370769,
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["refSpellID"] = 19386,
					["spellIDs"] = {
						[19386] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135125,
				},
				["伪装"] = {
					["enabled"] = true,
					["refSpellID"] = 199483,
					["spellIDs"] = {
						[199483] = true,
					},
					["cooldown"] = 60,
					["texture"] = 461113,
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186289,
					["spellIDs"] = {
						[186289] = true,
					},
					["cooldown"] = 120,
					["texture"] = 612363,
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["refSpellID"] = 63560,
					["spellIDs"] = {
						[63560] = true,
					},
					["cooldown"] = 60,
					["texture"] = 342913,
				},
				["抓钩"] = {
					["enabled"] = true,
					["refSpellID"] = 195457,
					["spellIDs"] = {
						[195457] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1373906,
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["refSpellID"] = 205369,
					["spellIDs"] = {
						[205369] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136173,
				},
				["圣佑术"] = {
					["enabled"] = true,
					["refSpellID"] = 498,
					["spellIDs"] = {
						[498] = true,
					},
					["cooldown"] = 60,
					["texture"] = 524353,
				},
				["禁锢"] = {
					["enabled"] = true,
					["refSpellID"] = 221527,
					["spellIDs"] = {
						[221527] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380368,
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["refSpellID"] = 207349,
					["spellIDs"] = {
						[207349] = true,
					},
					["cooldown"] = 120,
					["texture"] = 298674,
				},
				["责难"] = {
					["enabled"] = true,
					["refSpellID"] = 96231,
					["spellIDs"] = {
						[96231] = true,
					},
					["cooldown"] = 15,
					["texture"] = 523893,
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 202246,
					["spellIDs"] = {
						[202246] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1408833,
				},
				["冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 100,
					["spellIDs"] = {
						[100] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132337,
				},
				["意气风发"] = {
					["enabled"] = true,
					["refSpellID"] = 109304,
					["spellIDs"] = {
						[109304] = true,
					},
					["cooldown"] = 120,
					["texture"] = 461117,
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 205629,
					["spellIDs"] = {
						[205629] = true,
					},
					["cooldown"] = 30,
					["texture"] = 134294,
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 207736,
					["spellIDs"] = {
						[207736] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1020341,
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["refSpellID"] = 119381,
					["spellIDs"] = {
						[119381] = true,
					},
					["cooldown"] = 60,
					["texture"] = 642414,
				},
				["圣盾术"] = {
					["enabled"] = true,
					["refSpellID"] = 642,
					["spellIDs"] = {
						[642] = true,
					},
					["cooldown"] = 240,
					["texture"] = 524354,
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["refSpellID"] = 7744,
					["spellIDs"] = {
						[7744] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136187,
				},
				["虚空行走"] = {
					["enabled"] = true,
					["refSpellID"] = 196555,
					["spellIDs"] = {
						[196555] = true,
					},
					["cooldown"] = 120,
					["texture"] = 463284,
				},
				["战旗"] = {
					["enabled"] = true,
					["refSpellID"] = 236320,
					["spellIDs"] = {
						[236320] = true,
					},
					["cooldown"] = 90,
					["texture"] = 603532,
				},
				["还击"] = {
					["enabled"] = true,
					["refSpellID"] = 199754,
					["spellIDs"] = {
						[199754] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132269,
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 227847,
					["spellIDs"] = {
						[227847] = true,
					},
					["cooldown"] = 60,
					["texture"] = 236303,
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186257,
					["spellIDs"] = {
						[186257] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132242,
				},
				["甘霖"] = {
					["enabled"] = true,
					["refSpellID"] = 108238,
					["spellIDs"] = {
						[108238] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136059,
				},
				["决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 236273,
					["spellIDs"] = {
						[236273] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1455893,
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202138,
					["spellIDs"] = {
						[202138] = true,
					},
					["cooldown"] = 54,
					["texture"] = 1418286,
				},
				["百发百中"] = {
					["enabled"] = true,
					["refSpellID"] = 193526,
					["spellIDs"] = {
						[193526] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132329,
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["refSpellID"] = 31224,
					["spellIDs"] = {
						[31224] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136177,
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["refSpellID"] = 205191,
					["spellIDs"] = {
						[205191] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135986,
				},
				["群体反射"] = {
					["enabled"] = true,
					["refSpellID"] = 213915,
					["spellIDs"] = {
						[213915] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132358,
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["refSpellID"] = 53271,
					["spellIDs"] = {
						[53271] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236189,
				},
				["从天而降"] = {
					["enabled"] = true,
					["refSpellID"] = 206803,
					["spellIDs"] = {
						[206803] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380371,
				},
				["驱散射击"] = {
					["enabled"] = true,
					["refSpellID"] = 213691,
					["spellIDs"] = {
						[213691] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132153,
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 108280,
					["spellIDs"] = {
						[108280] = true,
					},
					["cooldown"] = 180,
					["texture"] = 538569,
				},
				["能量灌注"] = {
					["enabled"] = true,
					["refSpellID"] = 10060,
					["spellIDs"] = {
						[10060] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135939,
				},
				["窒息"] = {
					["enabled"] = true,
					["refSpellID"] = 47476,
					["spellIDs"] = {
						[47476] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["卸除武装"] = {
					["enabled"] = true,
					["refSpellID"] = 207777,
					["spellIDs"] = {
						[207777] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236272,
				},
				["升腾"] = {
					["enabled"] = true,
					["refSpellID"] = 114050,
					["spellIDs"] = {
						[114050] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135791,
				},
				["拦截"] = {
					["enabled"] = true,
					["refSpellID"] = 198304,
					["spellIDs"] = {
						[198304] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132365,
				},
				["闪现术"] = {
					["enabled"] = true,
					["refSpellID"] = 1953,
					["spellIDs"] = {
						[1953] = true,
					},
					["cooldown"] = 15,
					["texture"] = 135736,
				},
				["树皮术"] = {
					["enabled"] = true,
					["refSpellID"] = 22812,
					["spellIDs"] = {
						[22812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136097,
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["refSpellID"] = 5484,
					["spellIDs"] = {
						[5484] = true,
					},
					["cooldown"] = 40,
					["texture"] = 607852,
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["refSpellID"] = 89766,
					["spellIDs"] = {
						[89766] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236316,
				},
				["反转魔法"] = {
					["enabled"] = true,
					["refSpellID"] = 205604,
					["spellIDs"] = {
						[205604] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380372,
				},
				["火焰之息"] = {
					["enabled"] = true,
					["refSpellID"] = 115181,
					["spellIDs"] = {
						[115181] = true,
					},
					["cooldown"] = 15,
					["texture"] = 615339,
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["refSpellID"] = 216113,
					["spellIDs"] = {
						[216113] = true,
					},
					["cooldown"] = 45,
					["texture"] = 977169,
				},
				["疾跑"] = {
					["enabled"] = true,
					["refSpellID"] = 2983,
					["spellIDs"] = {
						[2983] = true,
					},
					["cooldown"] = 51,
					["texture"] = 132307,
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["refSpellID"] = 12292,
					["spellIDs"] = {
						[12292] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236304,
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["refSpellID"] = 64044,
					["spellIDs"] = {
						[64044] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237568,
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["refSpellID"] = 33891,
					["spellIDs"] = {
						[33891] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236157,
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["refSpellID"] = 115176,
					["spellIDs"] = {
						[115176] = true,
					},
					["cooldown"] = 150,
					["texture"] = 642417,
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["refSpellID"] = 121471,
					["spellIDs"] = {
						[121471] = true,
					},
					["cooldown"] = 180,
					["texture"] = 376022,
				},
				["冲动"] = {
					["enabled"] = true,
					["refSpellID"] = 13750,
					["spellIDs"] = {
						[13750] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136206,
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["refSpellID"] = 8122,
					["spellIDs"] = {
						[8122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136184,
				},
				["躯不坏"] = {
					["enabled"] = true,
					["refSpellID"] = 122278,
					["spellIDs"] = {
						[122278] = true,
					},
					["cooldown"] = 120,
					["texture"] = 620827,
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 208683,
					["spellIDs"] = {
						[208683] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["暗影步"] = {
					["enabled"] = true,
					["refSpellID"] = 36554,
					["spellIDs"] = {
						[36554] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132303,
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["refSpellID"] = 213602,
					["spellIDs"] = {
						[213602] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135994,
				},
				["凿击"] = {
					["enabled"] = true,
					["refSpellID"] = 1776,
					["spellIDs"] = {
						[1776] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132155,
				},
				["逃命专家"] = {
					["enabled"] = true,
					["refSpellID"] = 20589,
					["spellIDs"] = {
						[20589] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132309,
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["refSpellID"] = 191427,
					["spellIDs"] = {
						[191427] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1247262,
				},
				["圣疗术"] = {
					["enabled"] = true,
					["refSpellID"] = 633,
					["spellIDs"] = {
						[633] = true,
					},
					["cooldown"] = 600,
					["texture"] = 135928,
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 210256,
					["spellIDs"] = {
						[210256] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135911,
				},
				["自由祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1044,
					["spellIDs"] = {
						[1044] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135968,
				},
				["散魔功"] = {
					["enabled"] = true,
					["refSpellID"] = 122783,
					["spellIDs"] = {
						[122783] = true,
					},
					["cooldown"] = 90,
					["texture"] = 775460,
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["refSpellID"] = 212459,
					["spellIDs"] = {
						[212459] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1113433,
				},
				["闪光力场"] = {
					["enabled"] = true,
					["refSpellID"] = 204263,
					["spellIDs"] = {
						[204263] = true,
					},
					["cooldown"] = 45,
					["texture"] = 571554,
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["refSpellID"] = 102560,
					["spellIDs"] = {
						[102560] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 204018,
					["spellIDs"] = {
						[204018] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135880,
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["refSpellID"] = 5211,
					["spellIDs"] = {
						[5211] = true,
					},
					["cooldown"] = 50,
					["texture"] = 132114,
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157997,
					["spellIDs"] = {
						[157997] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033909,
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["refSpellID"] = 119996,
					["spellIDs"] = {
						[119996] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237585,
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["refSpellID"] = 47528,
					["spellIDs"] = {
						[47528] = true,
					},
					["cooldown"] = 15,
					["texture"] = 237527,
				},
				["业报之触"] = {
					["enabled"] = true,
					["refSpellID"] = 122470,
					["spellIDs"] = {
						[122470] = true,
					},
					["cooldown"] = 90,
					["texture"] = 651728,
				},
				["盾墙"] = {
					["enabled"] = true,
					["refSpellID"] = 871,
					["spellIDs"] = {
						[871] = true,
					},
					["cooldown"] = 240,
					["texture"] = 132362,
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["refSpellID"] = 68992,
					["spellIDs"] = {
						[68992] = true,
					},
					["cooldown"] = 120,
					["texture"] = 366937,
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["refSpellID"] = 190784,
					["spellIDs"] = {
						[190784] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1360759,
				},
				["龙息术"] = {
					["enabled"] = true,
					["refSpellID"] = 31661,
					["spellIDs"] = {
						[31661] = true,
					},
					["cooldown"] = 20,
					["texture"] = 134153,
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["refSpellID"] = 212182,
					["spellIDs"] = {
						[212182] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458733,
				},
				["沉默"] = {
					["enabled"] = true,
					["refSpellID"] = 15487,
					["spellIDs"] = {
						[15487] = true,
					},
					["cooldown"] = 45,
					["texture"] = 458230,
				},
				["巨人打击"] = {
					["enabled"] = true,
					["refSpellID"] = 167105,
					["spellIDs"] = {
						[167105] = true,
					},
					["cooldown"] = 45,
					["texture"] = 464973,
				},
				["元素宗师"] = {
					["enabled"] = true,
					["refSpellID"] = 16166,
					["spellIDs"] = {
						[16166] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136027,
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["refSpellID"] = 51271,
					["spellIDs"] = {
						[51271] = true,
					},
					["cooldown"] = 60,
					["texture"] = 458718,
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 51490,
					["spellIDs"] = {
						[51490] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237589,
				},
				["血魔之握"] = {
					["enabled"] = true,
					["refSpellID"] = 108199,
					["spellIDs"] = {
						[108199] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538767,
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["refSpellID"] = 49206,
					["spellIDs"] = {
						[49206] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458967,
				},
				["风火雷电"] = {
					["enabled"] = true,
					["refSpellID"] = 137639,
					["spellIDs"] = {
						[137639] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136038,
				},
				["星界转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108271,
					["spellIDs"] = {
						[108271] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538565,
				},
				["还魂术"] = {
					["enabled"] = true,
					["refSpellID"] = 115310,
					["spellIDs"] = {
						[115310] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1020466,
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["refSpellID"] = 31687,
					["spellIDs"] = {
						[31687] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135862,
				},
				["宿敌"] = {
					["enabled"] = true,
					["refSpellID"] = 79140,
					["spellIDs"] = {
						[79140] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458726,
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["refSpellID"] = 202370,
					["spellIDs"] = {
						[202370] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1381297,
				},
				["斗转星移"] = {
					["enabled"] = true,
					["refSpellID"] = 202162,
					["spellIDs"] = {
						[202162] = true,
					},
					["cooldown"] = 45,
					["texture"] = 620829,
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 86659,
					["spellIDs"] = {
						[86659] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135919,
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 6544,
					["spellIDs"] = {
						[6544] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236171,
				},
				["反制射击"] = {
					["enabled"] = true,
					["refSpellID"] = 147362,
					["spellIDs"] = {
						[147362] = true,
					},
					["cooldown"] = 24,
					["texture"] = 249170,
				},
				["灵体形态"] = {
					["enabled"] = true,
					["refSpellID"] = 210918,
					["spellIDs"] = {
						[210918] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237572,
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 73325,
					["spellIDs"] = {
						[73325] = true,
					},
					["cooldown"] = 45,
					["texture"] = 463835,
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["refSpellID"] = 102793,
					["spellIDs"] = {
						[102793] = true,
					},
					["cooldown"] = 60,
					["texture"] = 571588,
				},
				["英勇"] = {
					["enabled"] = true,
					["refSpellID"] = 32182,
					["spellIDs"] = {
						[32182] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132313,
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["refSpellID"] = 108416,
					["spellIDs"] = {
						[108416] = true,
					},
					["cooldown"] = 60,
					["texture"] = 538538,
				},
				["束缚射击"] = {
					["enabled"] = true,
					["refSpellID"] = 109248,
					["spellIDs"] = {
						[109248] = true,
					},
					["cooldown"] = 45,
					["texture"] = 462650,
				},
				["守护之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 47788,
					["spellIDs"] = {
						[47788] = true,
					},
					["cooldown"] = 60,
					["texture"] = 237542,
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["refSpellID"] = 48020,
					["spellIDs"] = {
						[48020] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237560,
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["refSpellID"] = 105809,
					["spellIDs"] = {
						[105809] = true,
					},
					["cooldown"] = 90,
					["texture"] = 571555,
				},
				["割碎"] = {
					["enabled"] = true,
					["refSpellID"] = 22570,
					["spellIDs"] = {
						[22570] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132134,
				},
				["摧心魔"] = {
					["enabled"] = true,
					["refSpellID"] = 123040,
					["spellIDs"] = {
						[123040] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["refSpellID"] = 102543,
					["spellIDs"] = {
						[102543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["refSpellID"] = 12472,
					["spellIDs"] = {
						[12472] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135838,
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["refSpellID"] = 209789,
					["spellIDs"] = {
						[209789] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1033903,
				},
				["隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 66,
					["spellIDs"] = {
						[66] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132220,
				},
				["幻影打击"] = {
					["enabled"] = true,
					["refSpellID"] = 196718,
					["spellIDs"] = {
						[196718] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1305154,
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["refSpellID"] = 207319,
					["spellIDs"] = {
						[207319] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1531513,
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["refSpellID"] = 201325,
					["spellIDs"] = {
						[201325] = true,
					},
					["cooldown"] = 180,
					["texture"] = 642417,
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["refSpellID"] = 188501,
					["spellIDs"] = {
						[188501] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1247266,
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["refSpellID"] = 216331,
					["spellIDs"] = {
						[216331] = true,
					},
					["cooldown"] = 60,
					["texture"] = 589117,
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["refSpellID"] = 77606,
					["spellIDs"] = {
						[77606] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135888,
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["refSpellID"] = 69041,
					["spellIDs"] = {
						[69041] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133032,
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["refSpellID"] = 33206,
					["spellIDs"] = {
						[33206] = true,
					},
					["cooldown"] = 210,
					["texture"] = 135936,
				},
				["肾击"] = {
					["enabled"] = true,
					["refSpellID"] = 408,
					["spellIDs"] = {
						[408] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132298,
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["refSpellID"] = 198898,
					["spellIDs"] = {
						[198898] = true,
					},
					["cooldown"] = 15,
					["texture"] = 332402,
				},
				["奥术强化"] = {
					["enabled"] = true,
					["refSpellID"] = 12042,
					["spellIDs"] = {
						[12042] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136048,
				},
				["致盲"] = {
					["enabled"] = true,
					["refSpellID"] = 2094,
					["spellIDs"] = {
						[2094] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136175,
				},
				["闪回"] = {
					["enabled"] = true,
					["refSpellID"] = 195676,
					["spellIDs"] = {
						[195676] = true,
					},
					["cooldown"] = 24,
					["texture"] = 132171,
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["refSpellID"] = 228049,
					["spellIDs"] = {
						[228049] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135919,
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["refSpellID"] = 79206,
					["spellIDs"] = {
						[79206] = true,
					},
					["cooldown"] = 60,
					["texture"] = 451170,
				},
				["牺牲"] = {
					["enabled"] = true,
					["refSpellID"] = 7812,
					["spellIDs"] = {
						[7812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136190,
				},
				["正中眉心"] = {
					["enabled"] = true,
					["refSpellID"] = 199804,
					["spellIDs"] = {
						[199804] = true,
					},
					["cooldown"] = 20,
					["texture"] = 135610,
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["refSpellID"] = 187650,
					["spellIDs"] = {
						[187650] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135834,
				},
				["台风"] = {
					["enabled"] = true,
					["refSpellID"] = 132469,
					["spellIDs"] = {
						[132469] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236170,
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["refSpellID"] = 19236,
					["spellIDs"] = {
						[19236] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237550,
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["refSpellID"] = 84714,
					["spellIDs"] = {
						[84714] = true,
					},
					["cooldown"] = 60,
					["texture"] = 629077,
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["refSpellID"] = 108201,
					["spellIDs"] = {
						[108201] = true,
					},
					["cooldown"] = 120,
					["texture"] = 538768,
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["refSpellID"] = 31850,
					["spellIDs"] = {
						[31850] = true,
					},
					["cooldown"] = 110,
					["texture"] = 135870,
				},
				["日光术"] = {
					["enabled"] = true,
					["refSpellID"] = 78675,
					["spellIDs"] = {
						[78675] = true,
					},
					["cooldown"] = 30,
					["texture"] = 252188,
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["refSpellID"] = 208253,
					["spellIDs"] = {
						[208253] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1115592,
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 30283,
					["spellIDs"] = {
						[30283] = true,
					},
					["cooldown"] = 30,
					["texture"] = 607865,
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 102359,
					["spellIDs"] = {
						[102359] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538515,
				},
				["真言术：障"] = {
					["enabled"] = true,
					["refSpellID"] = 62618,
					["spellIDs"] = {
						[62618] = true,
					},
					["cooldown"] = 120,
					["texture"] = 253400,
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["refSpellID"] = 106839,
					["spellIDs"] = {
						[106839] = true,
					},
					["cooldown"] = 15,
					["texture"] = 236946,
				},
				["瓦解"] = {
					["enabled"] = true,
					["refSpellID"] = 183752,
					["spellIDs"] = {
						[183752] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1305153,
				},
				["战争践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 11876,
					["spellIDs"] = {
						[11876] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132091,
				},
				["妖术"] = {
					["enabled"] = true,
					["refSpellID"] = 51514,
					["spellIDs"] = {
						[51514] = true,
					},
					["cooldown"] = 10,
					["texture"] = 237579,
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["refSpellID"] = 205630,
					["spellIDs"] = {
						[205630] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380367,
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["refSpellID"] = 152173,
					["spellIDs"] = {
						[152173] = true,
					},
					["cooldown"] = 90,
					["texture"] = 988197,
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 107570,
					["spellIDs"] = {
						[107570] = true,
					},
					["cooldown"] = 30,
					["texture"] = 613535,
				},
				["疾影"] = {
					["enabled"] = true,
					["refSpellID"] = 198589,
					["spellIDs"] = {
						[198589] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1305150,
				},
				["不灭决心"] = {
					["enabled"] = true,
					["refSpellID"] = 104773,
					["spellIDs"] = {
						[104773] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136150,
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 6940,
					["spellIDs"] = {
						[6940] = true,
					},
					["cooldown"] = 75,
					["texture"] = 135966,
				},
				["逃脱"] = {
					["enabled"] = true,
					["refSpellID"] = 781,
					["spellIDs"] = {
						[781] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132294,
				},
				["胁迫"] = {
					["enabled"] = true,
					["refSpellID"] = 19577,
					["spellIDs"] = {
						[19577] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132111,
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["refSpellID"] = 88625,
					["spellIDs"] = {
						[88625] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135886,
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["refSpellID"] = 51533,
					["spellIDs"] = {
						[51533] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237577,
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["refSpellID"] = 115078,
					["spellIDs"] = {
						[115078] = true,
					},
					["cooldown"] = 15,
					["texture"] = 629534,
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["refSpellID"] = 5246,
					["spellIDs"] = {
						[5246] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132154,
				},
				["天神下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 107574,
					["spellIDs"] = {
						[107574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 613534,
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["refSpellID"] = 205691,
					["spellIDs"] = {
						[205691] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1412204,
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["refSpellID"] = 186387,
					["spellIDs"] = {
						[186387] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1376038,
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["refSpellID"] = 19574,
					["spellIDs"] = {
						[19574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132127,
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["refSpellID"] = 12975,
					["spellIDs"] = {
						[12975] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135871,
				},
				["消失"] = {
					["enabled"] = true,
					["refSpellID"] = 1856,
					["spellIDs"] = {
						[1856] = true,
					},
					["cooldown"] = 75,
					["texture"] = 132331,
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 207399,
					["spellIDs"] = {
						[207399] = true,
					},
					["cooldown"] = 300,
					["texture"] = 136080,
				},
				["影遁"] = {
					["enabled"] = true,
					["refSpellID"] = 58984,
					["spellIDs"] = {
						[58984] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132089,
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["refSpellID"] = 1122,
					["spellIDs"] = {
						[1122] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136219,
				},
				["复生"] = {
					["enabled"] = true,
					["refSpellID"] = 20484,
					["spellIDs"] = {
						[20484] = true,
					},
					["cooldown"] = 600,
					["texture"] = 136080,
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["refSpellID"] = 33697,
					["spellIDs"] = {
						[33697] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135726,
				},
			},
		},
		["Ennyin - 埃加洛尔"] = {
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["refSpellID"] = 31230,
					["spellIDs"] = {
						[31230] = true,
					},
					["cooldown"] = 360,
					["texture"] = 132285,
				},
				["法术反制"] = {
					["enabled"] = true,
					["refSpellID"] = 2139,
					["spellIDs"] = {
						[2139] = true,
					},
					["cooldown"] = 24,
					["texture"] = 135856,
				},
				["天灾契约"] = {
					["enabled"] = true,
					["refSpellID"] = 48743,
					["spellIDs"] = {
						[48743] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136146,
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["refSpellID"] = 204437,
					["spellIDs"] = {
						[204437] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1385911,
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["refSpellID"] = 132578,
					["spellIDs"] = {
						[132578] = true,
					},
					["cooldown"] = 180,
					["texture"] = 608951,
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 206572,
					["spellIDs"] = {
						[206572] = true,
					},
					["cooldown"] = 20,
					["texture"] = 1380676,
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 215769,
					["spellIDs"] = {
						[215769] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132864,
				},
				["震荡波"] = {
					["enabled"] = true,
					["refSpellID"] = 46968,
					["spellIDs"] = {
						[46968] = true,
					},
					["cooldown"] = 40,
					["texture"] = 236312,
				},
				["谈判"] = {
					["enabled"] = true,
					["refSpellID"] = 199743,
					["spellIDs"] = {
						[199743] = true,
					},
					["cooldown"] = 20,
					["texture"] = 236448,
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 195710,
					["spellIDs"] = {
						[195710] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1322720,
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["refSpellID"] = 207167,
					["spellIDs"] = {
						[207167] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135836,
				},
				["超级新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157980,
					["spellIDs"] = {
						[157980] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033912,
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["refSpellID"] = 206650,
					["spellIDs"] = {
						[206650] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380366,
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["refSpellID"] = 48792,
					["spellIDs"] = {
						[48792] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237525,
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["refSpellID"] = 102558,
					["spellIDs"] = {
						[102558] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["死亡之握"] = {
					["enabled"] = true,
					["refSpellID"] = 49576,
					["spellIDs"] = {
						[49576] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237532,
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 853,
					["spellIDs"] = {
						[853] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135963,
				},
				["狂暴"] = {
					["enabled"] = true,
					["refSpellID"] = 26297,
					["spellIDs"] = {
						[26297] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135727,
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["refSpellID"] = 116849,
					["spellIDs"] = {
						[116849] = true,
					},
					["cooldown"] = 90,
					["texture"] = 627485,
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["refSpellID"] = 198817,
					["spellIDs"] = {
						[198817] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1380678,
				},
				["嗜血"] = {
					["enabled"] = true,
					["refSpellID"] = 2825,
					["spellIDs"] = {
						[2825] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136012,
				},
				["墓石"] = {
					["enabled"] = true,
					["refSpellID"] = 219809,
					["spellIDs"] = {
						[219809] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132151,
				},
				["电能图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 192058,
					["spellIDs"] = {
						[192058] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136013,
				},
				["影舞步"] = {
					["enabled"] = true,
					["refSpellID"] = 51690,
					["spellIDs"] = {
						[51690] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236277,
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["refSpellID"] = 108359,
					["spellIDs"] = {
						[108359] = true,
					},
					["cooldown"] = 120,
					["texture"] = 537516,
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["refSpellID"] = 102342,
					["spellIDs"] = {
						[102342] = true,
					},
					["cooldown"] = 90,
					["texture"] = 572025,
				},
				["亡者大军"] = {
					["enabled"] = true,
					["refSpellID"] = 42650,
					["spellIDs"] = {
						[42650] = true,
					},
					["cooldown"] = 600,
					["texture"] = 237511,
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["refSpellID"] = 198529,
					["spellIDs"] = {
						[198529] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133787,
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["refSpellID"] = 51052,
					["spellIDs"] = {
						[51052] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237510,
				},
				["消散"] = {
					["enabled"] = true,
					["refSpellID"] = 47585,
					["spellIDs"] = {
						[47585] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237563,
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["refSpellID"] = 122,
					["spellIDs"] = {
						[122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135848,
				},
				["轮回之触"] = {
					["enabled"] = true,
					["refSpellID"] = 115080,
					["spellIDs"] = {
						[115080] = true,
					},
					["cooldown"] = 60,
					["texture"] = 606552,
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["refSpellID"] = 48707,
					["spellIDs"] = {
						[48707] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136120,
				},
				["火焰石"] = {
					["enabled"] = true,
					["refSpellID"] = 212284,
					["spellIDs"] = {
						[212284] = true,
					},
					["cooldown"] = 45,
					["texture"] = 134085,
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["refSpellID"] = 196884,
					["spellIDs"] = {
						[196884] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1027879,
				},
				["鲁莽"] = {
					["enabled"] = true,
					["refSpellID"] = 1719,
					["spellIDs"] = {
						[1719] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458972,
				},
				["游侠之网"] = {
					["enabled"] = true,
					["refSpellID"] = 200108,
					["spellIDs"] = {
						[200108] = true,
					},
					["cooldown"] = 60,
					["texture"] = 134325,
				},
				["虚空联结"] = {
					["enabled"] = true,
					["refSpellID"] = 207810,
					["spellIDs"] = {
						[207810] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1450144,
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 5217,
					["spellIDs"] = {
						[5217] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132242,
				},
				["风剪"] = {
					["enabled"] = true,
					["refSpellID"] = 57994,
					["spellIDs"] = {
						[57994] = true,
					},
					["cooldown"] = 12,
					["texture"] = 136018,
				},
				["灭战者"] = {
					["enabled"] = true,
					["refSpellID"] = 262161,
					["spellIDs"] = {
						[262161] = true,
					},
					["cooldown"] = 45,
					["texture"] = 2065633,
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["refSpellID"] = 49028,
					["spellIDs"] = {
						[49028] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135277,
				},
				["石像形态"] = {
					["enabled"] = true,
					["refSpellID"] = 20594,
					["spellIDs"] = {
						[20594] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136225,
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["refSpellID"] = 201318,
					["spellIDs"] = {
						[201318] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1616072,
				},
				["压制"] = {
					["enabled"] = true,
					["refSpellID"] = 187707,
					["spellIDs"] = {
						[187707] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1376045,
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 110959,
					["spellIDs"] = {
						[110959] = true,
					},
					["cooldown"] = 75,
					["texture"] = 575584,
				},
				["剑在人在"] = {
					["enabled"] = true,
					["refSpellID"] = 118038,
					["spellIDs"] = {
						[118038] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132336,
				},
				["自利"] = {
					["enabled"] = true,
					["refSpellID"] = 59752,
					["spellIDs"] = {
						[59752] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136129,
				},
				["反击图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204331,
					["spellIDs"] = {
						[204331] = true,
					},
					["cooldown"] = 45,
					["texture"] = 511726,
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 207684,
					["spellIDs"] = {
						[207684] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418287,
				},
				["阵风"] = {
					["enabled"] = true,
					["refSpellID"] = 192063,
					["spellIDs"] = {
						[192063] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1029585,
				},
				["混乱新星"] = {
					["enabled"] = true,
					["refSpellID"] = 179057,
					["spellIDs"] = {
						[179057] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135795,
				},
				["切喉手"] = {
					["enabled"] = true,
					["refSpellID"] = 116705,
					["spellIDs"] = {
						[116705] = true,
					},
					["cooldown"] = 15,
					["texture"] = 608940,
				},
				["法术封锁"] = {
					["enabled"] = true,
					["refSpellID"] = 19647,
					["spellIDs"] = {
						[19647] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136174,
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["refSpellID"] = 115781,
					["spellIDs"] = {
						[115781] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136028,
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["refSpellID"] = 80483,
					["spellIDs"] = {
						[80483] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136222,
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["refSpellID"] = 11426,
					["spellIDs"] = {
						[11426] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135988,
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 204150,
					["spellIDs"] = {
						[204150] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135909,
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 89751,
					["spellIDs"] = {
						[89751] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236303,
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 6789,
					["spellIDs"] = {
						[6789] = true,
					},
					["cooldown"] = 45,
					["texture"] = 607853,
				},
				["生存本能"] = {
					["enabled"] = true,
					["refSpellID"] = 61336,
					["spellIDs"] = {
						[61336] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236169,
				},
				["闪避"] = {
					["enabled"] = true,
					["refSpellID"] = 5277,
					["spellIDs"] = {
						[5277] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136205,
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["refSpellID"] = 64843,
					["spellIDs"] = {
						[64843] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237540,
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["refSpellID"] = 201078,
					["spellIDs"] = {
						[201078] = true,
					},
					["cooldown"] = 120,
					["texture"] = 254647,
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186265,
					["spellIDs"] = {
						[186265] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132199,
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 31884,
					["spellIDs"] = {
						[31884] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135875,
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 91802,
					["spellIDs"] = {
						[91802] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237569,
				},
				["燃烧"] = {
					["enabled"] = true,
					["refSpellID"] = 190319,
					["spellIDs"] = {
						[190319] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135824,
				},
				["唤醒"] = {
					["enabled"] = true,
					["refSpellID"] = 12051,
					["spellIDs"] = {
						[12051] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136075,
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["refSpellID"] = 206491,
					["spellIDs"] = {
						[206491] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236299,
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["refSpellID"] = 42292,
					["spellIDs"] = {
						[42292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 200851,
					["spellIDs"] = {
						[200851] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1129695,
				},
				["法术反射"] = {
					["enabled"] = true,
					["refSpellID"] = 23920,
					["spellIDs"] = {
						[23920] = true,
					},
					["cooldown"] = 25,
					["texture"] = 132361,
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 123904,
					["spellIDs"] = {
						[123904] = true,
					},
					["cooldown"] = 180,
					["texture"] = 620832,
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["refSpellID"] = 45438,
					["spellIDs"] = {
						[45438] = true,
					},
					["cooldown"] = 240,
					["texture"] = 135841,
				},
				["时光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 198111,
					["spellIDs"] = {
						[198111] = true,
					},
					["cooldown"] = 45,
					["texture"] = 610472,
				},
				["脚踢"] = {
					["enabled"] = true,
					["refSpellID"] = 1766,
					["spellIDs"] = {
						[1766] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132219,
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 18499,
					["spellIDs"] = {
						[18499] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136009,
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202137,
					["spellIDs"] = {
						[202137] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418288,
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["refSpellID"] = 198664,
					["spellIDs"] = {
						[198664] = true,
					},
					["cooldown"] = 180,
					["texture"] = 877514,
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["refSpellID"] = 194223,
					["spellIDs"] = {
						[194223] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136060,
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 98008,
					["spellIDs"] = {
						[98008] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237586,
				},
				["拳击"] = {
					["enabled"] = true,
					["refSpellID"] = 6552,
					["spellIDs"] = {
						[6552] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132938,
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["refSpellID"] = 211881,
					["spellIDs"] = {
						[211881] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1118739,
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 51485,
					["spellIDs"] = {
						[51485] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136100,
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["refSpellID"] = 59543,
					["spellIDs"] = {
						[59543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135923,
				},
				["宁静"] = {
					["enabled"] = true,
					["refSpellID"] = 740,
					["spellIDs"] = {
						[740] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136107,
				},
				["急奔"] = {
					["enabled"] = true,
					["refSpellID"] = 1850,
					["spellIDs"] = {
						[1850] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132120,
				},
				["缴械"] = {
					["enabled"] = true,
					["refSpellID"] = 236077,
					["spellIDs"] = {
						[236077] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132343,
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 212295,
					["spellIDs"] = {
						[212295] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135796,
				},
				["自然之力"] = {
					["enabled"] = true,
					["refSpellID"] = 205636,
					["spellIDs"] = {
						[205636] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132129,
				},
				["根基图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204336,
					["spellIDs"] = {
						[204336] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136039,
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["refSpellID"] = 209749,
					["spellIDs"] = {
						[209749] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538516,
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["refSpellID"] = 184364,
					["spellIDs"] = {
						[184364] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132345,
				},
				["保护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1022,
					["spellIDs"] = {
						[1022] = true,
					},
					["cooldown"] = 135,
					["texture"] = 135964,
				},
				["血之镜像"] = {
					["enabled"] = true,
					["refSpellID"] = 206977,
					["spellIDs"] = {
						[206977] = true,
					},
					["cooldown"] = 120,
					["texture"] = 134084,
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 196932,
					["spellIDs"] = {
						[196932] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136232,
				},
				["平心之环"] = {
					["enabled"] = true,
					["refSpellID"] = 116844,
					["spellIDs"] = {
						[116844] = true,
					},
					["cooldown"] = 45,
					["texture"] = 839107,
				},
				["虚空转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108968,
					["spellIDs"] = {
						[108968] = true,
					},
					["cooldown"] = 300,
					["texture"] = 537079,
				},
				["急速冷却"] = {
					["enabled"] = true,
					["refSpellID"] = 235219,
					["spellIDs"] = {
						[235219] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135865,
				},
				["光环掌握"] = {
					["enabled"] = true,
					["refSpellID"] = 31821,
					["spellIDs"] = {
						[31821] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135872,
				},
				["火箭跳"] = {
					["enabled"] = true,
					["refSpellID"] = 69070,
					["spellIDs"] = {
						[69070] = true,
					},
					["cooldown"] = 120,
					["texture"] = 370769,
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["refSpellID"] = 19386,
					["spellIDs"] = {
						[19386] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135125,
				},
				["伪装"] = {
					["enabled"] = true,
					["refSpellID"] = 199483,
					["spellIDs"] = {
						[199483] = true,
					},
					["cooldown"] = 60,
					["texture"] = 461113,
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186289,
					["spellIDs"] = {
						[186289] = true,
					},
					["cooldown"] = 120,
					["texture"] = 612363,
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["refSpellID"] = 63560,
					["spellIDs"] = {
						[63560] = true,
					},
					["cooldown"] = 60,
					["texture"] = 342913,
				},
				["抓钩"] = {
					["enabled"] = true,
					["refSpellID"] = 195457,
					["spellIDs"] = {
						[195457] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1373906,
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["refSpellID"] = 205369,
					["spellIDs"] = {
						[205369] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136173,
				},
				["圣佑术"] = {
					["enabled"] = true,
					["refSpellID"] = 498,
					["spellIDs"] = {
						[498] = true,
					},
					["cooldown"] = 60,
					["texture"] = 524353,
				},
				["禁锢"] = {
					["enabled"] = true,
					["refSpellID"] = 221527,
					["spellIDs"] = {
						[221527] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380368,
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["refSpellID"] = 207349,
					["spellIDs"] = {
						[207349] = true,
					},
					["cooldown"] = 120,
					["texture"] = 298674,
				},
				["责难"] = {
					["enabled"] = true,
					["refSpellID"] = 96231,
					["spellIDs"] = {
						[96231] = true,
					},
					["cooldown"] = 15,
					["texture"] = 523893,
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 202246,
					["spellIDs"] = {
						[202246] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1408833,
				},
				["冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 100,
					["spellIDs"] = {
						[100] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132337,
				},
				["意气风发"] = {
					["enabled"] = true,
					["refSpellID"] = 109304,
					["spellIDs"] = {
						[109304] = true,
					},
					["cooldown"] = 120,
					["texture"] = 461117,
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 205629,
					["spellIDs"] = {
						[205629] = true,
					},
					["cooldown"] = 30,
					["texture"] = 134294,
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 207736,
					["spellIDs"] = {
						[207736] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1020341,
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["refSpellID"] = 119381,
					["spellIDs"] = {
						[119381] = true,
					},
					["cooldown"] = 60,
					["texture"] = 642414,
				},
				["圣盾术"] = {
					["enabled"] = true,
					["refSpellID"] = 642,
					["spellIDs"] = {
						[642] = true,
					},
					["cooldown"] = 240,
					["texture"] = 524354,
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["refSpellID"] = 7744,
					["spellIDs"] = {
						[7744] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136187,
				},
				["虚空行走"] = {
					["enabled"] = true,
					["refSpellID"] = 196555,
					["spellIDs"] = {
						[196555] = true,
					},
					["cooldown"] = 120,
					["texture"] = 463284,
				},
				["战旗"] = {
					["enabled"] = true,
					["refSpellID"] = 236320,
					["spellIDs"] = {
						[236320] = true,
					},
					["cooldown"] = 90,
					["texture"] = 603532,
				},
				["还击"] = {
					["enabled"] = true,
					["refSpellID"] = 199754,
					["spellIDs"] = {
						[199754] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132269,
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 227847,
					["spellIDs"] = {
						[227847] = true,
					},
					["cooldown"] = 60,
					["texture"] = 236303,
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186257,
					["spellIDs"] = {
						[186257] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132242,
				},
				["甘霖"] = {
					["enabled"] = true,
					["refSpellID"] = 108238,
					["spellIDs"] = {
						[108238] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136059,
				},
				["决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 236273,
					["spellIDs"] = {
						[236273] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1455893,
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202138,
					["spellIDs"] = {
						[202138] = true,
					},
					["cooldown"] = 54,
					["texture"] = 1418286,
				},
				["百发百中"] = {
					["enabled"] = true,
					["refSpellID"] = 193526,
					["spellIDs"] = {
						[193526] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132329,
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["refSpellID"] = 31224,
					["spellIDs"] = {
						[31224] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136177,
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["refSpellID"] = 205191,
					["spellIDs"] = {
						[205191] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135986,
				},
				["群体反射"] = {
					["enabled"] = true,
					["refSpellID"] = 213915,
					["spellIDs"] = {
						[213915] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132358,
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["refSpellID"] = 53271,
					["spellIDs"] = {
						[53271] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236189,
				},
				["从天而降"] = {
					["enabled"] = true,
					["refSpellID"] = 206803,
					["spellIDs"] = {
						[206803] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380371,
				},
				["驱散射击"] = {
					["enabled"] = true,
					["refSpellID"] = 213691,
					["spellIDs"] = {
						[213691] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132153,
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 108280,
					["spellIDs"] = {
						[108280] = true,
					},
					["cooldown"] = 180,
					["texture"] = 538569,
				},
				["能量灌注"] = {
					["enabled"] = true,
					["refSpellID"] = 10060,
					["spellIDs"] = {
						[10060] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135939,
				},
				["窒息"] = {
					["enabled"] = true,
					["refSpellID"] = 47476,
					["spellIDs"] = {
						[47476] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["卸除武装"] = {
					["enabled"] = true,
					["refSpellID"] = 207777,
					["spellIDs"] = {
						[207777] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236272,
				},
				["升腾"] = {
					["enabled"] = true,
					["refSpellID"] = 114050,
					["spellIDs"] = {
						[114050] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135791,
				},
				["拦截"] = {
					["enabled"] = true,
					["refSpellID"] = 198304,
					["spellIDs"] = {
						[198304] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132365,
				},
				["闪现术"] = {
					["enabled"] = true,
					["refSpellID"] = 1953,
					["spellIDs"] = {
						[1953] = true,
					},
					["cooldown"] = 15,
					["texture"] = 135736,
				},
				["树皮术"] = {
					["enabled"] = true,
					["refSpellID"] = 22812,
					["spellIDs"] = {
						[22812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136097,
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["refSpellID"] = 5484,
					["spellIDs"] = {
						[5484] = true,
					},
					["cooldown"] = 40,
					["texture"] = 607852,
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["refSpellID"] = 89766,
					["spellIDs"] = {
						[89766] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236316,
				},
				["反转魔法"] = {
					["enabled"] = true,
					["refSpellID"] = 205604,
					["spellIDs"] = {
						[205604] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380372,
				},
				["火焰之息"] = {
					["enabled"] = true,
					["refSpellID"] = 115181,
					["spellIDs"] = {
						[115181] = true,
					},
					["cooldown"] = 15,
					["texture"] = 615339,
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["refSpellID"] = 216113,
					["spellIDs"] = {
						[216113] = true,
					},
					["cooldown"] = 45,
					["texture"] = 977169,
				},
				["疾跑"] = {
					["enabled"] = true,
					["refSpellID"] = 2983,
					["spellIDs"] = {
						[2983] = true,
					},
					["cooldown"] = 51,
					["texture"] = 132307,
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["refSpellID"] = 12292,
					["spellIDs"] = {
						[12292] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236304,
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["refSpellID"] = 64044,
					["spellIDs"] = {
						[64044] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237568,
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["refSpellID"] = 33891,
					["spellIDs"] = {
						[33891] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236157,
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["refSpellID"] = 115176,
					["spellIDs"] = {
						[115176] = true,
					},
					["cooldown"] = 150,
					["texture"] = 642417,
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["refSpellID"] = 121471,
					["spellIDs"] = {
						[121471] = true,
					},
					["cooldown"] = 180,
					["texture"] = 376022,
				},
				["冲动"] = {
					["enabled"] = true,
					["refSpellID"] = 13750,
					["spellIDs"] = {
						[13750] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136206,
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["refSpellID"] = 8122,
					["spellIDs"] = {
						[8122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136184,
				},
				["躯不坏"] = {
					["enabled"] = true,
					["refSpellID"] = 122278,
					["spellIDs"] = {
						[122278] = true,
					},
					["cooldown"] = 120,
					["texture"] = 620827,
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 208683,
					["spellIDs"] = {
						[208683] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["暗影步"] = {
					["enabled"] = true,
					["refSpellID"] = 36554,
					["spellIDs"] = {
						[36554] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132303,
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["refSpellID"] = 213602,
					["spellIDs"] = {
						[213602] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135994,
				},
				["凿击"] = {
					["enabled"] = true,
					["refSpellID"] = 1776,
					["spellIDs"] = {
						[1776] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132155,
				},
				["逃命专家"] = {
					["enabled"] = true,
					["refSpellID"] = 20589,
					["spellIDs"] = {
						[20589] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132309,
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["refSpellID"] = 191427,
					["spellIDs"] = {
						[191427] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1247262,
				},
				["圣疗术"] = {
					["enabled"] = true,
					["refSpellID"] = 633,
					["spellIDs"] = {
						[633] = true,
					},
					["cooldown"] = 600,
					["texture"] = 135928,
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 210256,
					["spellIDs"] = {
						[210256] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135911,
				},
				["自由祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1044,
					["spellIDs"] = {
						[1044] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135968,
				},
				["散魔功"] = {
					["enabled"] = true,
					["refSpellID"] = 122783,
					["spellIDs"] = {
						[122783] = true,
					},
					["cooldown"] = 90,
					["texture"] = 775460,
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["refSpellID"] = 33697,
					["spellIDs"] = {
						[33697] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135726,
				},
				["复生"] = {
					["enabled"] = true,
					["refSpellID"] = 20484,
					["spellIDs"] = {
						[20484] = true,
					},
					["cooldown"] = 600,
					["texture"] = 136080,
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["refSpellID"] = 102560,
					["spellIDs"] = {
						[102560] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 204018,
					["spellIDs"] = {
						[204018] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135880,
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 207399,
					["spellIDs"] = {
						[207399] = true,
					},
					["cooldown"] = 300,
					["texture"] = 136080,
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157997,
					["spellIDs"] = {
						[157997] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033909,
				},
				["消失"] = {
					["enabled"] = true,
					["refSpellID"] = 1856,
					["spellIDs"] = {
						[1856] = true,
					},
					["cooldown"] = 75,
					["texture"] = 132331,
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["refSpellID"] = 47528,
					["spellIDs"] = {
						[47528] = true,
					},
					["cooldown"] = 15,
					["texture"] = 237527,
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["refSpellID"] = 12975,
					["spellIDs"] = {
						[12975] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135871,
				},
				["盾墙"] = {
					["enabled"] = true,
					["refSpellID"] = 871,
					["spellIDs"] = {
						[871] = true,
					},
					["cooldown"] = 240,
					["texture"] = 132362,
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["refSpellID"] = 19574,
					["spellIDs"] = {
						[19574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132127,
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["refSpellID"] = 186387,
					["spellIDs"] = {
						[186387] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1376038,
				},
				["龙息术"] = {
					["enabled"] = true,
					["refSpellID"] = 31661,
					["spellIDs"] = {
						[31661] = true,
					},
					["cooldown"] = 20,
					["texture"] = 134153,
				},
				["天神下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 107574,
					["spellIDs"] = {
						[107574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 613534,
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["refSpellID"] = 5246,
					["spellIDs"] = {
						[5246] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132154,
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["refSpellID"] = 115078,
					["spellIDs"] = {
						[115078] = true,
					},
					["cooldown"] = 15,
					["texture"] = 629534,
				},
				["元素宗师"] = {
					["enabled"] = true,
					["refSpellID"] = 16166,
					["spellIDs"] = {
						[16166] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136027,
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["refSpellID"] = 51533,
					["spellIDs"] = {
						[51533] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237577,
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 51490,
					["spellIDs"] = {
						[51490] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237589,
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["refSpellID"] = 88625,
					["spellIDs"] = {
						[88625] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135886,
				},
				["胁迫"] = {
					["enabled"] = true,
					["refSpellID"] = 19577,
					["spellIDs"] = {
						[19577] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132111,
				},
				["风火雷电"] = {
					["enabled"] = true,
					["refSpellID"] = 137639,
					["spellIDs"] = {
						[137639] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136038,
				},
				["星界转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108271,
					["spellIDs"] = {
						[108271] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538565,
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 6940,
					["spellIDs"] = {
						[6940] = true,
					},
					["cooldown"] = 75,
					["texture"] = 135966,
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["refSpellID"] = 31687,
					["spellIDs"] = {
						[31687] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135862,
				},
				["宿敌"] = {
					["enabled"] = true,
					["refSpellID"] = 79140,
					["spellIDs"] = {
						[79140] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458726,
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["refSpellID"] = 202370,
					["spellIDs"] = {
						[202370] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1381297,
				},
				["斗转星移"] = {
					["enabled"] = true,
					["refSpellID"] = 202162,
					["spellIDs"] = {
						[202162] = true,
					},
					["cooldown"] = 45,
					["texture"] = 620829,
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 86659,
					["spellIDs"] = {
						[86659] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135919,
				},
				["不灭决心"] = {
					["enabled"] = true,
					["refSpellID"] = 104773,
					["spellIDs"] = {
						[104773] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136150,
				},
				["反制射击"] = {
					["enabled"] = true,
					["refSpellID"] = 147362,
					["spellIDs"] = {
						[147362] = true,
					},
					["cooldown"] = 24,
					["texture"] = 249170,
				},
				["灵体形态"] = {
					["enabled"] = true,
					["refSpellID"] = 210918,
					["spellIDs"] = {
						[210918] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237572,
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 73325,
					["spellIDs"] = {
						[73325] = true,
					},
					["cooldown"] = 45,
					["texture"] = 463835,
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["refSpellID"] = 102793,
					["spellIDs"] = {
						[102793] = true,
					},
					["cooldown"] = 60,
					["texture"] = 571588,
				},
				["英勇"] = {
					["enabled"] = true,
					["refSpellID"] = 32182,
					["spellIDs"] = {
						[32182] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132313,
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["refSpellID"] = 108416,
					["spellIDs"] = {
						[108416] = true,
					},
					["cooldown"] = 60,
					["texture"] = 538538,
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["refSpellID"] = 152173,
					["spellIDs"] = {
						[152173] = true,
					},
					["cooldown"] = 90,
					["texture"] = 988197,
				},
				["守护之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 47788,
					["spellIDs"] = {
						[47788] = true,
					},
					["cooldown"] = 60,
					["texture"] = 237542,
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["refSpellID"] = 48020,
					["spellIDs"] = {
						[48020] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237560,
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["refSpellID"] = 205630,
					["spellIDs"] = {
						[205630] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380367,
				},
				["妖术"] = {
					["enabled"] = true,
					["refSpellID"] = 51514,
					["spellIDs"] = {
						[51514] = true,
					},
					["cooldown"] = 10,
					["texture"] = 237579,
				},
				["摧心魔"] = {
					["enabled"] = true,
					["refSpellID"] = 123040,
					["spellIDs"] = {
						[123040] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["瓦解"] = {
					["enabled"] = true,
					["refSpellID"] = 183752,
					["spellIDs"] = {
						[183752] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1305153,
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["refSpellID"] = 12472,
					["spellIDs"] = {
						[12472] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135838,
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["refSpellID"] = 209789,
					["spellIDs"] = {
						[209789] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1033903,
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 102359,
					["spellIDs"] = {
						[102359] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538515,
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 30283,
					["spellIDs"] = {
						[30283] = true,
					},
					["cooldown"] = 30,
					["texture"] = 607865,
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["refSpellID"] = 207319,
					["spellIDs"] = {
						[207319] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1531513,
				},
				["日光术"] = {
					["enabled"] = true,
					["refSpellID"] = 78675,
					["spellIDs"] = {
						[78675] = true,
					},
					["cooldown"] = 30,
					["texture"] = 252188,
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["refSpellID"] = 31850,
					["spellIDs"] = {
						[31850] = true,
					},
					["cooldown"] = 110,
					["texture"] = 135870,
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["refSpellID"] = 188501,
					["spellIDs"] = {
						[188501] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1247266,
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["refSpellID"] = 201325,
					["spellIDs"] = {
						[201325] = true,
					},
					["cooldown"] = 180,
					["texture"] = 642417,
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["refSpellID"] = 69041,
					["spellIDs"] = {
						[69041] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133032,
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["refSpellID"] = 216331,
					["spellIDs"] = {
						[216331] = true,
					},
					["cooldown"] = 60,
					["texture"] = 589117,
				},
				["肾击"] = {
					["enabled"] = true,
					["refSpellID"] = 408,
					["spellIDs"] = {
						[408] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132298,
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["refSpellID"] = 198898,
					["spellIDs"] = {
						[198898] = true,
					},
					["cooldown"] = 15,
					["texture"] = 332402,
				},
				["奥术强化"] = {
					["enabled"] = true,
					["refSpellID"] = 12042,
					["spellIDs"] = {
						[12042] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136048,
				},
				["致盲"] = {
					["enabled"] = true,
					["refSpellID"] = 2094,
					["spellIDs"] = {
						[2094] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136175,
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["refSpellID"] = 187650,
					["spellIDs"] = {
						[187650] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135834,
				},
				["正中眉心"] = {
					["enabled"] = true,
					["refSpellID"] = 199804,
					["spellIDs"] = {
						[199804] = true,
					},
					["cooldown"] = 20,
					["texture"] = 135610,
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["refSpellID"] = 79206,
					["spellIDs"] = {
						[79206] = true,
					},
					["cooldown"] = 60,
					["texture"] = 451170,
				},
				["牺牲"] = {
					["enabled"] = true,
					["refSpellID"] = 7812,
					["spellIDs"] = {
						[7812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136190,
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["refSpellID"] = 228049,
					["spellIDs"] = {
						[228049] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135919,
				},
				["闪回"] = {
					["enabled"] = true,
					["refSpellID"] = 195676,
					["spellIDs"] = {
						[195676] = true,
					},
					["cooldown"] = 24,
					["texture"] = 132171,
				},
				["台风"] = {
					["enabled"] = true,
					["refSpellID"] = 132469,
					["spellIDs"] = {
						[132469] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236170,
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["refSpellID"] = 19236,
					["spellIDs"] = {
						[19236] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237550,
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["refSpellID"] = 84714,
					["spellIDs"] = {
						[84714] = true,
					},
					["cooldown"] = 60,
					["texture"] = 629077,
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["refSpellID"] = 33206,
					["spellIDs"] = {
						[33206] = true,
					},
					["cooldown"] = 210,
					["texture"] = 135936,
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["refSpellID"] = 108201,
					["spellIDs"] = {
						[108201] = true,
					},
					["cooldown"] = 120,
					["texture"] = 538768,
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["refSpellID"] = 77606,
					["spellIDs"] = {
						[77606] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135888,
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["refSpellID"] = 208253,
					["spellIDs"] = {
						[208253] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1115592,
				},
				["幻影打击"] = {
					["enabled"] = true,
					["refSpellID"] = 196718,
					["spellIDs"] = {
						[196718] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1305154,
				},
				["隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 66,
					["spellIDs"] = {
						[66] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132220,
				},
				["真言术：障"] = {
					["enabled"] = true,
					["refSpellID"] = 62618,
					["spellIDs"] = {
						[62618] = true,
					},
					["cooldown"] = 120,
					["texture"] = 253400,
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["refSpellID"] = 106839,
					["spellIDs"] = {
						[106839] = true,
					},
					["cooldown"] = 15,
					["texture"] = 236946,
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["refSpellID"] = 102543,
					["spellIDs"] = {
						[102543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["战争践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 11876,
					["spellIDs"] = {
						[11876] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132091,
				},
				["割碎"] = {
					["enabled"] = true,
					["refSpellID"] = 22570,
					["spellIDs"] = {
						[22570] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132134,
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["refSpellID"] = 105809,
					["spellIDs"] = {
						[105809] = true,
					},
					["cooldown"] = 90,
					["texture"] = 571555,
				},
				["束缚射击"] = {
					["enabled"] = true,
					["refSpellID"] = 109248,
					["spellIDs"] = {
						[109248] = true,
					},
					["cooldown"] = 45,
					["texture"] = 462650,
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 107570,
					["spellIDs"] = {
						[107570] = true,
					},
					["cooldown"] = 30,
					["texture"] = 613535,
				},
				["疾影"] = {
					["enabled"] = true,
					["refSpellID"] = 198589,
					["spellIDs"] = {
						[198589] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1305150,
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 6544,
					["spellIDs"] = {
						[6544] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236171,
				},
				["还魂术"] = {
					["enabled"] = true,
					["refSpellID"] = 115310,
					["spellIDs"] = {
						[115310] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1020466,
				},
				["逃脱"] = {
					["enabled"] = true,
					["refSpellID"] = 781,
					["spellIDs"] = {
						[781] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132294,
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["refSpellID"] = 49206,
					["spellIDs"] = {
						[49206] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458967,
				},
				["血魔之握"] = {
					["enabled"] = true,
					["refSpellID"] = 108199,
					["spellIDs"] = {
						[108199] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538767,
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["refSpellID"] = 51271,
					["spellIDs"] = {
						[51271] = true,
					},
					["cooldown"] = 60,
					["texture"] = 458718,
				},
				["巨人打击"] = {
					["enabled"] = true,
					["refSpellID"] = 167105,
					["spellIDs"] = {
						[167105] = true,
					},
					["cooldown"] = 45,
					["texture"] = 464973,
				},
				["沉默"] = {
					["enabled"] = true,
					["refSpellID"] = 15487,
					["spellIDs"] = {
						[15487] = true,
					},
					["cooldown"] = 45,
					["texture"] = 458230,
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["refSpellID"] = 212182,
					["spellIDs"] = {
						[212182] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458733,
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["refSpellID"] = 205691,
					["spellIDs"] = {
						[205691] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1412204,
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["refSpellID"] = 190784,
					["spellIDs"] = {
						[190784] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1360759,
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["refSpellID"] = 68992,
					["spellIDs"] = {
						[68992] = true,
					},
					["cooldown"] = 120,
					["texture"] = 366937,
				},
				["业报之触"] = {
					["enabled"] = true,
					["refSpellID"] = 122470,
					["spellIDs"] = {
						[122470] = true,
					},
					["cooldown"] = 90,
					["texture"] = 651728,
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["refSpellID"] = 119996,
					["spellIDs"] = {
						[119996] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237585,
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["refSpellID"] = 5211,
					["spellIDs"] = {
						[5211] = true,
					},
					["cooldown"] = 50,
					["texture"] = 132114,
				},
				["影遁"] = {
					["enabled"] = true,
					["refSpellID"] = 58984,
					["spellIDs"] = {
						[58984] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132089,
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["refSpellID"] = 1122,
					["spellIDs"] = {
						[1122] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136219,
				},
				["闪光力场"] = {
					["enabled"] = true,
					["refSpellID"] = 204263,
					["spellIDs"] = {
						[204263] = true,
					},
					["cooldown"] = 45,
					["texture"] = 571554,
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["refSpellID"] = 212459,
					["spellIDs"] = {
						[212459] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1113433,
				},
			},
			["DBVersion"] = 8,
		},
		["浮雲 - 恶魔之翼"] = {
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["refSpellID"] = 31230,
					["spellIDs"] = {
						[31230] = true,
					},
					["cooldown"] = 360,
					["texture"] = 132285,
				},
				["法术反制"] = {
					["enabled"] = true,
					["refSpellID"] = 2139,
					["spellIDs"] = {
						[2139] = true,
					},
					["cooldown"] = 24,
					["texture"] = 135856,
				},
				["天灾契约"] = {
					["enabled"] = true,
					["refSpellID"] = 48743,
					["spellIDs"] = {
						[48743] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136146,
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["refSpellID"] = 204437,
					["spellIDs"] = {
						[204437] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1385911,
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["refSpellID"] = 132578,
					["spellIDs"] = {
						[132578] = true,
					},
					["cooldown"] = 180,
					["texture"] = 608951,
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 206572,
					["spellIDs"] = {
						[206572] = true,
					},
					["cooldown"] = 20,
					["texture"] = 1380676,
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 215769,
					["spellIDs"] = {
						[215769] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132864,
				},
				["震荡波"] = {
					["enabled"] = true,
					["refSpellID"] = 46968,
					["spellIDs"] = {
						[46968] = true,
					},
					["cooldown"] = 40,
					["texture"] = 236312,
				},
				["谈判"] = {
					["enabled"] = true,
					["refSpellID"] = 199743,
					["spellIDs"] = {
						[199743] = true,
					},
					["cooldown"] = 20,
					["texture"] = 236448,
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 195710,
					["spellIDs"] = {
						[195710] = true,
					},
					["cooldown"] = 180,
					["texture"] = 338784,
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["refSpellID"] = 207167,
					["spellIDs"] = {
						[207167] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135836,
				},
				["超级新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157980,
					["spellIDs"] = {
						[157980] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033912,
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["refSpellID"] = 206650,
					["spellIDs"] = {
						[206650] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380366,
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["refSpellID"] = 48792,
					["spellIDs"] = {
						[48792] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237525,
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["refSpellID"] = 102558,
					["spellIDs"] = {
						[102558] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["死亡之握"] = {
					["enabled"] = true,
					["refSpellID"] = 49576,
					["spellIDs"] = {
						[49576] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237532,
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 853,
					["spellIDs"] = {
						[853] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135963,
				},
				["狂暴"] = {
					["enabled"] = true,
					["refSpellID"] = 26297,
					["spellIDs"] = {
						[26297] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135727,
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["refSpellID"] = 116849,
					["spellIDs"] = {
						[116849] = true,
					},
					["cooldown"] = 90,
					["texture"] = 627485,
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["refSpellID"] = 198817,
					["spellIDs"] = {
						[198817] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1380678,
				},
				["嗜血"] = {
					["enabled"] = true,
					["refSpellID"] = 2825,
					["spellIDs"] = {
						[2825] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136012,
				},
				["墓石"] = {
					["enabled"] = true,
					["refSpellID"] = 219809,
					["spellIDs"] = {
						[219809] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132151,
				},
				["电能图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 192058,
					["spellIDs"] = {
						[192058] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136013,
				},
				["影舞步"] = {
					["enabled"] = true,
					["refSpellID"] = 51690,
					["spellIDs"] = {
						[51690] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236277,
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["refSpellID"] = 108359,
					["spellIDs"] = {
						[108359] = true,
					},
					["cooldown"] = 120,
					["texture"] = 537516,
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["refSpellID"] = 102342,
					["spellIDs"] = {
						[102342] = true,
					},
					["cooldown"] = 90,
					["texture"] = 572025,
				},
				["亡者大军"] = {
					["enabled"] = true,
					["refSpellID"] = 42650,
					["spellIDs"] = {
						[42650] = true,
					},
					["cooldown"] = 600,
					["texture"] = 237511,
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["refSpellID"] = 198529,
					["spellIDs"] = {
						[198529] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133787,
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["refSpellID"] = 51052,
					["spellIDs"] = {
						[51052] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237510,
				},
				["消散"] = {
					["enabled"] = true,
					["refSpellID"] = 47585,
					["spellIDs"] = {
						[47585] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237563,
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["refSpellID"] = 122,
					["spellIDs"] = {
						[122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135848,
				},
				["轮回之触"] = {
					["enabled"] = true,
					["refSpellID"] = 115080,
					["spellIDs"] = {
						[115080] = true,
					},
					["cooldown"] = 60,
					["texture"] = 606552,
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["refSpellID"] = 48707,
					["spellIDs"] = {
						[48707] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136120,
				},
				["火焰石"] = {
					["enabled"] = true,
					["refSpellID"] = 212284,
					["spellIDs"] = {
						[212284] = true,
					},
					["cooldown"] = 45,
					["texture"] = 134085,
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["refSpellID"] = 196884,
					["spellIDs"] = {
						[196884] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1027879,
				},
				["鲁莽"] = {
					["enabled"] = true,
					["refSpellID"] = 1719,
					["spellIDs"] = {
						[1719] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458972,
				},
				["游侠之网"] = {
					["enabled"] = true,
					["refSpellID"] = 200108,
					["spellIDs"] = {
						[200108] = true,
					},
					["cooldown"] = 60,
					["texture"] = 134325,
				},
				["虚空联结"] = {
					["enabled"] = true,
					["refSpellID"] = 207810,
					["spellIDs"] = {
						[207810] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1450144,
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 5217,
					["spellIDs"] = {
						[5217] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132242,
				},
				["风剪"] = {
					["enabled"] = true,
					["refSpellID"] = 57994,
					["spellIDs"] = {
						[57994] = true,
					},
					["cooldown"] = 12,
					["texture"] = 136018,
				},
				["灭战者"] = {
					["enabled"] = true,
					["refSpellID"] = 262161,
					["spellIDs"] = {
						[262161] = true,
					},
					["cooldown"] = 45,
					["texture"] = 2065633,
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["refSpellID"] = 49028,
					["spellIDs"] = {
						[49028] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135277,
				},
				["石像形态"] = {
					["enabled"] = true,
					["refSpellID"] = 20594,
					["spellIDs"] = {
						[20594] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136225,
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["refSpellID"] = 201318,
					["spellIDs"] = {
						[201318] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1616072,
				},
				["压制"] = {
					["enabled"] = true,
					["refSpellID"] = 187707,
					["spellIDs"] = {
						[187707] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1376045,
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 110959,
					["spellIDs"] = {
						[110959] = true,
					},
					["cooldown"] = 75,
					["texture"] = 575584,
				},
				["剑在人在"] = {
					["enabled"] = true,
					["refSpellID"] = 118038,
					["spellIDs"] = {
						[118038] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132336,
				},
				["自利"] = {
					["enabled"] = true,
					["refSpellID"] = 59752,
					["spellIDs"] = {
						[59752] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136129,
				},
				["反击图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204331,
					["spellIDs"] = {
						[204331] = true,
					},
					["cooldown"] = 45,
					["texture"] = 511726,
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 207684,
					["spellIDs"] = {
						[207684] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418287,
				},
				["阵风"] = {
					["enabled"] = true,
					["refSpellID"] = 192063,
					["spellIDs"] = {
						[192063] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1029585,
				},
				["混乱新星"] = {
					["enabled"] = true,
					["refSpellID"] = 179057,
					["spellIDs"] = {
						[179057] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135795,
				},
				["切喉手"] = {
					["enabled"] = true,
					["refSpellID"] = 116705,
					["spellIDs"] = {
						[116705] = true,
					},
					["cooldown"] = 15,
					["texture"] = 608940,
				},
				["法术封锁"] = {
					["enabled"] = true,
					["refSpellID"] = 19647,
					["spellIDs"] = {
						[19647] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136174,
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["refSpellID"] = 115781,
					["spellIDs"] = {
						[115781] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136028,
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["refSpellID"] = 80483,
					["spellIDs"] = {
						[80483] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136222,
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["refSpellID"] = 11426,
					["spellIDs"] = {
						[11426] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135988,
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 204150,
					["spellIDs"] = {
						[204150] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135909,
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 89751,
					["spellIDs"] = {
						[89751] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236303,
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 6789,
					["spellIDs"] = {
						[6789] = true,
					},
					["cooldown"] = 45,
					["texture"] = 607853,
				},
				["生存本能"] = {
					["enabled"] = true,
					["refSpellID"] = 61336,
					["spellIDs"] = {
						[61336] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236169,
				},
				["闪避"] = {
					["enabled"] = true,
					["refSpellID"] = 5277,
					["spellIDs"] = {
						[5277] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136205,
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["refSpellID"] = 64843,
					["spellIDs"] = {
						[64843] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237540,
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["refSpellID"] = 201078,
					["spellIDs"] = {
						[201078] = true,
					},
					["cooldown"] = 120,
					["texture"] = 254647,
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186265,
					["spellIDs"] = {
						[186265] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132199,
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 31884,
					["spellIDs"] = {
						[31884] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135875,
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 91802,
					["spellIDs"] = {
						[91802] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237569,
				},
				["燃烧"] = {
					["enabled"] = true,
					["refSpellID"] = 190319,
					["spellIDs"] = {
						[190319] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135824,
				},
				["唤醒"] = {
					["enabled"] = true,
					["refSpellID"] = 12051,
					["spellIDs"] = {
						[12051] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136075,
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["refSpellID"] = 206491,
					["spellIDs"] = {
						[206491] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236299,
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["refSpellID"] = 42292,
					["spellIDs"] = {
						[42292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 200851,
					["spellIDs"] = {
						[200851] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1129695,
				},
				["法术反射"] = {
					["enabled"] = true,
					["refSpellID"] = 23920,
					["spellIDs"] = {
						[23920] = true,
					},
					["cooldown"] = 25,
					["texture"] = 132361,
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 123904,
					["spellIDs"] = {
						[123904] = true,
					},
					["cooldown"] = 180,
					["texture"] = 620832,
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["refSpellID"] = 45438,
					["spellIDs"] = {
						[45438] = true,
					},
					["cooldown"] = 240,
					["texture"] = 135841,
				},
				["时光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 198111,
					["spellIDs"] = {
						[198111] = true,
					},
					["cooldown"] = 45,
					["texture"] = 610472,
				},
				["脚踢"] = {
					["enabled"] = true,
					["refSpellID"] = 1766,
					["spellIDs"] = {
						[1766] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132219,
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 18499,
					["spellIDs"] = {
						[18499] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136009,
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202137,
					["spellIDs"] = {
						[202137] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418288,
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["refSpellID"] = 198664,
					["spellIDs"] = {
						[198664] = true,
					},
					["cooldown"] = 180,
					["texture"] = 877514,
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["refSpellID"] = 194223,
					["spellIDs"] = {
						[194223] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136060,
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 98008,
					["spellIDs"] = {
						[98008] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237586,
				},
				["拳击"] = {
					["enabled"] = true,
					["refSpellID"] = 6552,
					["spellIDs"] = {
						[6552] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132938,
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["refSpellID"] = 211881,
					["spellIDs"] = {
						[211881] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1118739,
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 51485,
					["spellIDs"] = {
						[51485] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136100,
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["refSpellID"] = 59543,
					["spellIDs"] = {
						[59543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135923,
				},
				["宁静"] = {
					["enabled"] = true,
					["refSpellID"] = 740,
					["spellIDs"] = {
						[740] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136107,
				},
				["急奔"] = {
					["enabled"] = true,
					["refSpellID"] = 1850,
					["spellIDs"] = {
						[1850] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132120,
				},
				["缴械"] = {
					["enabled"] = true,
					["refSpellID"] = 236077,
					["spellIDs"] = {
						[236077] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132343,
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 212295,
					["spellIDs"] = {
						[212295] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135796,
				},
				["自然之力"] = {
					["enabled"] = true,
					["refSpellID"] = 205636,
					["spellIDs"] = {
						[205636] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132129,
				},
				["根基图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204336,
					["spellIDs"] = {
						[204336] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136039,
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["refSpellID"] = 209749,
					["spellIDs"] = {
						[209749] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538516,
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["refSpellID"] = 184364,
					["spellIDs"] = {
						[184364] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132345,
				},
				["保护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1022,
					["spellIDs"] = {
						[1022] = true,
					},
					["cooldown"] = 135,
					["texture"] = 135964,
				},
				["血之镜像"] = {
					["enabled"] = true,
					["refSpellID"] = 206977,
					["spellIDs"] = {
						[206977] = true,
					},
					["cooldown"] = 120,
					["texture"] = 134084,
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 196932,
					["spellIDs"] = {
						[196932] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136232,
				},
				["平心之环"] = {
					["enabled"] = true,
					["refSpellID"] = 116844,
					["spellIDs"] = {
						[116844] = true,
					},
					["cooldown"] = 45,
					["texture"] = 839107,
				},
				["虚空转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108968,
					["spellIDs"] = {
						[108968] = true,
					},
					["cooldown"] = 300,
					["texture"] = 537079,
				},
				["急速冷却"] = {
					["enabled"] = true,
					["refSpellID"] = 235219,
					["spellIDs"] = {
						[235219] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135865,
				},
				["光环掌握"] = {
					["enabled"] = true,
					["refSpellID"] = 31821,
					["spellIDs"] = {
						[31821] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135872,
				},
				["火箭跳"] = {
					["enabled"] = true,
					["refSpellID"] = 69070,
					["spellIDs"] = {
						[69070] = true,
					},
					["cooldown"] = 120,
					["texture"] = 370769,
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["refSpellID"] = 19386,
					["spellIDs"] = {
						[19386] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135125,
				},
				["伪装"] = {
					["enabled"] = true,
					["refSpellID"] = 199483,
					["spellIDs"] = {
						[199483] = true,
					},
					["cooldown"] = 60,
					["texture"] = 461113,
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186289,
					["spellIDs"] = {
						[186289] = true,
					},
					["cooldown"] = 120,
					["texture"] = 612363,
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["refSpellID"] = 63560,
					["spellIDs"] = {
						[63560] = true,
					},
					["cooldown"] = 60,
					["texture"] = 342913,
				},
				["抓钩"] = {
					["enabled"] = true,
					["refSpellID"] = 195457,
					["spellIDs"] = {
						[195457] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1373906,
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["refSpellID"] = 205369,
					["spellIDs"] = {
						[205369] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136173,
				},
				["圣佑术"] = {
					["enabled"] = true,
					["refSpellID"] = 498,
					["spellIDs"] = {
						[498] = true,
					},
					["cooldown"] = 60,
					["texture"] = 524353,
				},
				["禁锢"] = {
					["enabled"] = true,
					["refSpellID"] = 221527,
					["spellIDs"] = {
						[221527] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380368,
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["refSpellID"] = 207349,
					["spellIDs"] = {
						[207349] = true,
					},
					["cooldown"] = 120,
					["texture"] = 298674,
				},
				["责难"] = {
					["enabled"] = true,
					["refSpellID"] = 96231,
					["spellIDs"] = {
						[96231] = true,
					},
					["cooldown"] = 15,
					["texture"] = 523893,
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 202246,
					["spellIDs"] = {
						[202246] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1408833,
				},
				["冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 100,
					["spellIDs"] = {
						[100] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132337,
				},
				["意气风发"] = {
					["enabled"] = true,
					["refSpellID"] = 109304,
					["spellIDs"] = {
						[109304] = true,
					},
					["cooldown"] = 120,
					["texture"] = 461117,
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 205629,
					["spellIDs"] = {
						[205629] = true,
					},
					["cooldown"] = 30,
					["texture"] = 134294,
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 207736,
					["spellIDs"] = {
						[207736] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1020341,
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["refSpellID"] = 119381,
					["spellIDs"] = {
						[119381] = true,
					},
					["cooldown"] = 60,
					["texture"] = 642414,
				},
				["圣盾术"] = {
					["enabled"] = true,
					["refSpellID"] = 642,
					["spellIDs"] = {
						[642] = true,
					},
					["cooldown"] = 240,
					["texture"] = 524354,
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["refSpellID"] = 7744,
					["spellIDs"] = {
						[7744] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136187,
				},
				["虚空行走"] = {
					["enabled"] = true,
					["refSpellID"] = 196555,
					["spellIDs"] = {
						[196555] = true,
					},
					["cooldown"] = 120,
					["texture"] = 463284,
				},
				["战旗"] = {
					["enabled"] = true,
					["refSpellID"] = 236320,
					["spellIDs"] = {
						[236320] = true,
					},
					["cooldown"] = 90,
					["texture"] = 603532,
				},
				["还击"] = {
					["enabled"] = true,
					["refSpellID"] = 199754,
					["spellIDs"] = {
						[199754] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132269,
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 227847,
					["spellIDs"] = {
						[227847] = true,
					},
					["cooldown"] = 60,
					["texture"] = 236303,
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186257,
					["spellIDs"] = {
						[186257] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132242,
				},
				["甘霖"] = {
					["enabled"] = true,
					["refSpellID"] = 108238,
					["spellIDs"] = {
						[108238] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136059,
				},
				["决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 236273,
					["spellIDs"] = {
						[236273] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1455893,
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202138,
					["spellIDs"] = {
						[202138] = true,
					},
					["cooldown"] = 54,
					["texture"] = 1418286,
				},
				["百发百中"] = {
					["enabled"] = true,
					["refSpellID"] = 193526,
					["spellIDs"] = {
						[193526] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132329,
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["refSpellID"] = 31224,
					["spellIDs"] = {
						[31224] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136177,
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["refSpellID"] = 205191,
					["spellIDs"] = {
						[205191] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135986,
				},
				["群体反射"] = {
					["enabled"] = true,
					["refSpellID"] = 213915,
					["spellIDs"] = {
						[213915] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132358,
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["refSpellID"] = 53271,
					["spellIDs"] = {
						[53271] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236189,
				},
				["从天而降"] = {
					["enabled"] = true,
					["refSpellID"] = 206803,
					["spellIDs"] = {
						[206803] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380371,
				},
				["驱散射击"] = {
					["enabled"] = true,
					["refSpellID"] = 213691,
					["spellIDs"] = {
						[213691] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132153,
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 108280,
					["spellIDs"] = {
						[108280] = true,
					},
					["cooldown"] = 180,
					["texture"] = 538569,
				},
				["能量灌注"] = {
					["enabled"] = true,
					["refSpellID"] = 10060,
					["spellIDs"] = {
						[10060] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135939,
				},
				["窒息"] = {
					["enabled"] = true,
					["refSpellID"] = 47476,
					["spellIDs"] = {
						[47476] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136214,
				},
				["卸除武装"] = {
					["enabled"] = true,
					["refSpellID"] = 207777,
					["spellIDs"] = {
						[207777] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236272,
				},
				["升腾"] = {
					["enabled"] = true,
					["refSpellID"] = 114050,
					["spellIDs"] = {
						[114050] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135791,
				},
				["拦截"] = {
					["enabled"] = true,
					["refSpellID"] = 198304,
					["spellIDs"] = {
						[198304] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132365,
				},
				["闪现术"] = {
					["enabled"] = true,
					["refSpellID"] = 1953,
					["spellIDs"] = {
						[1953] = true,
					},
					["cooldown"] = 15,
					["texture"] = 135736,
				},
				["树皮术"] = {
					["enabled"] = true,
					["refSpellID"] = 22812,
					["spellIDs"] = {
						[22812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136097,
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["refSpellID"] = 5484,
					["spellIDs"] = {
						[5484] = true,
					},
					["cooldown"] = 40,
					["texture"] = 607852,
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["refSpellID"] = 89766,
					["spellIDs"] = {
						[89766] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236316,
				},
				["反转魔法"] = {
					["enabled"] = true,
					["refSpellID"] = 205604,
					["spellIDs"] = {
						[205604] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380372,
				},
				["火焰之息"] = {
					["enabled"] = true,
					["refSpellID"] = 115181,
					["spellIDs"] = {
						[115181] = true,
					},
					["cooldown"] = 15,
					["texture"] = 615339,
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["refSpellID"] = 216113,
					["spellIDs"] = {
						[216113] = true,
					},
					["cooldown"] = 45,
					["texture"] = 977169,
				},
				["疾跑"] = {
					["enabled"] = true,
					["refSpellID"] = 2983,
					["spellIDs"] = {
						[2983] = true,
					},
					["cooldown"] = 51,
					["texture"] = 132307,
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["refSpellID"] = 12292,
					["spellIDs"] = {
						[12292] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236304,
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["refSpellID"] = 64044,
					["spellIDs"] = {
						[64044] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237568,
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["refSpellID"] = 33891,
					["spellIDs"] = {
						[33891] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236157,
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["refSpellID"] = 115176,
					["spellIDs"] = {
						[115176] = true,
					},
					["cooldown"] = 150,
					["texture"] = 642417,
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["refSpellID"] = 121471,
					["spellIDs"] = {
						[121471] = true,
					},
					["cooldown"] = 180,
					["texture"] = 376022,
				},
				["冲动"] = {
					["enabled"] = true,
					["refSpellID"] = 13750,
					["spellIDs"] = {
						[13750] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136206,
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["refSpellID"] = 8122,
					["spellIDs"] = {
						[8122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136184,
				},
				["躯不坏"] = {
					["enabled"] = true,
					["refSpellID"] = 122278,
					["spellIDs"] = {
						[122278] = true,
					},
					["cooldown"] = 120,
					["texture"] = 620827,
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 208683,
					["spellIDs"] = {
						[208683] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["暗影步"] = {
					["enabled"] = true,
					["refSpellID"] = 36554,
					["spellIDs"] = {
						[36554] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132303,
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["refSpellID"] = 213602,
					["spellIDs"] = {
						[213602] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135994,
				},
				["凿击"] = {
					["enabled"] = true,
					["refSpellID"] = 1776,
					["spellIDs"] = {
						[1776] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132155,
				},
				["逃命专家"] = {
					["enabled"] = true,
					["refSpellID"] = 20589,
					["spellIDs"] = {
						[20589] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132309,
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["refSpellID"] = 191427,
					["spellIDs"] = {
						[191427] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1247262,
				},
				["圣疗术"] = {
					["enabled"] = true,
					["refSpellID"] = 633,
					["spellIDs"] = {
						[633] = true,
					},
					["cooldown"] = 600,
					["texture"] = 135928,
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 210256,
					["spellIDs"] = {
						[210256] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135911,
				},
				["自由祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1044,
					["spellIDs"] = {
						[1044] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135968,
				},
				["散魔功"] = {
					["enabled"] = true,
					["refSpellID"] = 122783,
					["spellIDs"] = {
						[122783] = true,
					},
					["cooldown"] = 90,
					["texture"] = 775460,
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["refSpellID"] = 212459,
					["spellIDs"] = {
						[212459] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1113433,
				},
				["闪光力场"] = {
					["enabled"] = true,
					["refSpellID"] = 204263,
					["spellIDs"] = {
						[204263] = true,
					},
					["cooldown"] = 45,
					["texture"] = 571554,
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["refSpellID"] = 102560,
					["spellIDs"] = {
						[102560] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 204018,
					["spellIDs"] = {
						[204018] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135880,
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["refSpellID"] = 5211,
					["spellIDs"] = {
						[5211] = true,
					},
					["cooldown"] = 50,
					["texture"] = 132114,
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157997,
					["spellIDs"] = {
						[157997] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033909,
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["refSpellID"] = 119996,
					["spellIDs"] = {
						[119996] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237585,
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["refSpellID"] = 47528,
					["spellIDs"] = {
						[47528] = true,
					},
					["cooldown"] = 15,
					["texture"] = 237527,
				},
				["业报之触"] = {
					["enabled"] = true,
					["refSpellID"] = 122470,
					["spellIDs"] = {
						[122470] = true,
					},
					["cooldown"] = 90,
					["texture"] = 651728,
				},
				["盾墙"] = {
					["enabled"] = true,
					["refSpellID"] = 871,
					["spellIDs"] = {
						[871] = true,
					},
					["cooldown"] = 240,
					["texture"] = 132362,
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["refSpellID"] = 68992,
					["spellIDs"] = {
						[68992] = true,
					},
					["cooldown"] = 120,
					["texture"] = 366937,
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["refSpellID"] = 190784,
					["spellIDs"] = {
						[190784] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1360759,
				},
				["龙息术"] = {
					["enabled"] = true,
					["refSpellID"] = 31661,
					["spellIDs"] = {
						[31661] = true,
					},
					["cooldown"] = 20,
					["texture"] = 134153,
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["refSpellID"] = 212182,
					["spellIDs"] = {
						[212182] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458733,
				},
				["沉默"] = {
					["enabled"] = true,
					["refSpellID"] = 15487,
					["spellIDs"] = {
						[15487] = true,
					},
					["cooldown"] = 45,
					["texture"] = 458230,
				},
				["巨人打击"] = {
					["enabled"] = true,
					["refSpellID"] = 167105,
					["spellIDs"] = {
						[167105] = true,
					},
					["cooldown"] = 45,
					["texture"] = 464973,
				},
				["元素宗师"] = {
					["enabled"] = true,
					["refSpellID"] = 16166,
					["spellIDs"] = {
						[16166] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136027,
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["refSpellID"] = 51271,
					["spellIDs"] = {
						[51271] = true,
					},
					["cooldown"] = 60,
					["texture"] = 458718,
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 51490,
					["spellIDs"] = {
						[51490] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237589,
				},
				["血魔之握"] = {
					["enabled"] = true,
					["refSpellID"] = 108199,
					["spellIDs"] = {
						[108199] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538767,
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["refSpellID"] = 49206,
					["spellIDs"] = {
						[49206] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458967,
				},
				["风火雷电"] = {
					["enabled"] = true,
					["refSpellID"] = 137639,
					["spellIDs"] = {
						[137639] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136038,
				},
				["星界转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108271,
					["spellIDs"] = {
						[108271] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538565,
				},
				["还魂术"] = {
					["enabled"] = true,
					["refSpellID"] = 115310,
					["spellIDs"] = {
						[115310] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1020466,
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["refSpellID"] = 31687,
					["spellIDs"] = {
						[31687] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135862,
				},
				["宿敌"] = {
					["enabled"] = true,
					["refSpellID"] = 79140,
					["spellIDs"] = {
						[79140] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458726,
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["refSpellID"] = 202370,
					["spellIDs"] = {
						[202370] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1381297,
				},
				["斗转星移"] = {
					["enabled"] = true,
					["refSpellID"] = 202162,
					["spellIDs"] = {
						[202162] = true,
					},
					["cooldown"] = 45,
					["texture"] = 620829,
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 86659,
					["spellIDs"] = {
						[86659] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135919,
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 6544,
					["spellIDs"] = {
						[6544] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236171,
				},
				["反制射击"] = {
					["enabled"] = true,
					["refSpellID"] = 147362,
					["spellIDs"] = {
						[147362] = true,
					},
					["cooldown"] = 24,
					["texture"] = 249170,
				},
				["灵体形态"] = {
					["enabled"] = true,
					["refSpellID"] = 210918,
					["spellIDs"] = {
						[210918] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237572,
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 73325,
					["spellIDs"] = {
						[73325] = true,
					},
					["cooldown"] = 45,
					["texture"] = 463835,
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["refSpellID"] = 102793,
					["spellIDs"] = {
						[102793] = true,
					},
					["cooldown"] = 60,
					["texture"] = 571588,
				},
				["英勇"] = {
					["enabled"] = true,
					["refSpellID"] = 32182,
					["spellIDs"] = {
						[32182] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132313,
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["refSpellID"] = 108416,
					["spellIDs"] = {
						[108416] = true,
					},
					["cooldown"] = 60,
					["texture"] = 538538,
				},
				["束缚射击"] = {
					["enabled"] = true,
					["refSpellID"] = 109248,
					["spellIDs"] = {
						[109248] = true,
					},
					["cooldown"] = 45,
					["texture"] = 462650,
				},
				["守护之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 47788,
					["spellIDs"] = {
						[47788] = true,
					},
					["cooldown"] = 60,
					["texture"] = 237542,
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["refSpellID"] = 48020,
					["spellIDs"] = {
						[48020] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237560,
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["refSpellID"] = 105809,
					["spellIDs"] = {
						[105809] = true,
					},
					["cooldown"] = 90,
					["texture"] = 571555,
				},
				["割碎"] = {
					["enabled"] = true,
					["refSpellID"] = 22570,
					["spellIDs"] = {
						[22570] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132134,
				},
				["摧心魔"] = {
					["enabled"] = true,
					["refSpellID"] = 123040,
					["spellIDs"] = {
						[123040] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["refSpellID"] = 102543,
					["spellIDs"] = {
						[102543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["refSpellID"] = 12472,
					["spellIDs"] = {
						[12472] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135838,
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["refSpellID"] = 209789,
					["spellIDs"] = {
						[209789] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1033903,
				},
				["隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 66,
					["spellIDs"] = {
						[66] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132220,
				},
				["幻影打击"] = {
					["enabled"] = true,
					["refSpellID"] = 196718,
					["spellIDs"] = {
						[196718] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1305154,
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["refSpellID"] = 207319,
					["spellIDs"] = {
						[207319] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1531513,
				},
				["日光术"] = {
					["enabled"] = true,
					["refSpellID"] = 78675,
					["spellIDs"] = {
						[78675] = true,
					},
					["cooldown"] = 30,
					["texture"] = 252188,
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["refSpellID"] = 188501,
					["spellIDs"] = {
						[188501] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1247266,
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["refSpellID"] = 216331,
					["spellIDs"] = {
						[216331] = true,
					},
					["cooldown"] = 60,
					["texture"] = 589117,
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["refSpellID"] = 31850,
					["spellIDs"] = {
						[31850] = true,
					},
					["cooldown"] = 110,
					["texture"] = 135870,
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["refSpellID"] = 69041,
					["spellIDs"] = {
						[69041] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133032,
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["refSpellID"] = 33206,
					["spellIDs"] = {
						[33206] = true,
					},
					["cooldown"] = 210,
					["texture"] = 135936,
				},
				["肾击"] = {
					["enabled"] = true,
					["refSpellID"] = 408,
					["spellIDs"] = {
						[408] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132298,
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["refSpellID"] = 198898,
					["spellIDs"] = {
						[198898] = true,
					},
					["cooldown"] = 15,
					["texture"] = 332402,
				},
				["奥术强化"] = {
					["enabled"] = true,
					["refSpellID"] = 12042,
					["spellIDs"] = {
						[12042] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136048,
				},
				["致盲"] = {
					["enabled"] = true,
					["refSpellID"] = 2094,
					["spellIDs"] = {
						[2094] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136175,
				},
				["闪回"] = {
					["enabled"] = true,
					["refSpellID"] = 195676,
					["spellIDs"] = {
						[195676] = true,
					},
					["cooldown"] = 24,
					["texture"] = 132171,
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["refSpellID"] = 228049,
					["spellIDs"] = {
						[228049] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135919,
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["refSpellID"] = 79206,
					["spellIDs"] = {
						[79206] = true,
					},
					["cooldown"] = 60,
					["texture"] = 451170,
				},
				["牺牲"] = {
					["enabled"] = true,
					["refSpellID"] = 7812,
					["spellIDs"] = {
						[7812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136190,
				},
				["正中眉心"] = {
					["enabled"] = true,
					["refSpellID"] = 199804,
					["spellIDs"] = {
						[199804] = true,
					},
					["cooldown"] = 20,
					["texture"] = 135610,
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["refSpellID"] = 187650,
					["spellIDs"] = {
						[187650] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135834,
				},
				["台风"] = {
					["enabled"] = true,
					["refSpellID"] = 132469,
					["spellIDs"] = {
						[132469] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236170,
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["refSpellID"] = 19236,
					["spellIDs"] = {
						[19236] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237550,
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["refSpellID"] = 84714,
					["spellIDs"] = {
						[84714] = true,
					},
					["cooldown"] = 60,
					["texture"] = 629077,
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["refSpellID"] = 108201,
					["spellIDs"] = {
						[108201] = true,
					},
					["cooldown"] = 120,
					["texture"] = 538768,
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["refSpellID"] = 77606,
					["spellIDs"] = {
						[77606] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135888,
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["refSpellID"] = 201325,
					["spellIDs"] = {
						[201325] = true,
					},
					["cooldown"] = 180,
					["texture"] = 642417,
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["refSpellID"] = 208253,
					["spellIDs"] = {
						[208253] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1115592,
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 30283,
					["spellIDs"] = {
						[30283] = true,
					},
					["cooldown"] = 30,
					["texture"] = 607865,
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 102359,
					["spellIDs"] = {
						[102359] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538515,
				},
				["真言术：障"] = {
					["enabled"] = true,
					["refSpellID"] = 62618,
					["spellIDs"] = {
						[62618] = true,
					},
					["cooldown"] = 120,
					["texture"] = 253400,
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["refSpellID"] = 106839,
					["spellIDs"] = {
						[106839] = true,
					},
					["cooldown"] = 15,
					["texture"] = 236946,
				},
				["瓦解"] = {
					["enabled"] = true,
					["refSpellID"] = 183752,
					["spellIDs"] = {
						[183752] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1305153,
				},
				["战争践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 11876,
					["spellIDs"] = {
						[11876] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132091,
				},
				["妖术"] = {
					["enabled"] = true,
					["refSpellID"] = 51514,
					["spellIDs"] = {
						[51514] = true,
					},
					["cooldown"] = 10,
					["texture"] = 237579,
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["refSpellID"] = 205630,
					["spellIDs"] = {
						[205630] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380367,
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["refSpellID"] = 152173,
					["spellIDs"] = {
						[152173] = true,
					},
					["cooldown"] = 90,
					["texture"] = 988197,
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 107570,
					["spellIDs"] = {
						[107570] = true,
					},
					["cooldown"] = 30,
					["texture"] = 613535,
				},
				["疾影"] = {
					["enabled"] = true,
					["refSpellID"] = 198589,
					["spellIDs"] = {
						[198589] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1305150,
				},
				["不灭决心"] = {
					["enabled"] = true,
					["refSpellID"] = 104773,
					["spellIDs"] = {
						[104773] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136150,
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 6940,
					["spellIDs"] = {
						[6940] = true,
					},
					["cooldown"] = 75,
					["texture"] = 135966,
				},
				["逃脱"] = {
					["enabled"] = true,
					["refSpellID"] = 781,
					["spellIDs"] = {
						[781] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132294,
				},
				["胁迫"] = {
					["enabled"] = true,
					["refSpellID"] = 19577,
					["spellIDs"] = {
						[19577] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132111,
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["refSpellID"] = 88625,
					["spellIDs"] = {
						[88625] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135886,
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["refSpellID"] = 51533,
					["spellIDs"] = {
						[51533] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237577,
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["refSpellID"] = 115078,
					["spellIDs"] = {
						[115078] = true,
					},
					["cooldown"] = 15,
					["texture"] = 629534,
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["refSpellID"] = 5246,
					["spellIDs"] = {
						[5246] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132154,
				},
				["天神下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 107574,
					["spellIDs"] = {
						[107574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 613534,
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["refSpellID"] = 205691,
					["spellIDs"] = {
						[205691] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1412204,
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["refSpellID"] = 186387,
					["spellIDs"] = {
						[186387] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1376038,
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["refSpellID"] = 19574,
					["spellIDs"] = {
						[19574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132127,
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["refSpellID"] = 12975,
					["spellIDs"] = {
						[12975] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135871,
				},
				["消失"] = {
					["enabled"] = true,
					["refSpellID"] = 1856,
					["spellIDs"] = {
						[1856] = true,
					},
					["cooldown"] = 75,
					["texture"] = 132331,
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 207399,
					["spellIDs"] = {
						[207399] = true,
					},
					["cooldown"] = 300,
					["texture"] = 136080,
				},
				["影遁"] = {
					["enabled"] = true,
					["refSpellID"] = 58984,
					["spellIDs"] = {
						[58984] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132089,
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["refSpellID"] = 1122,
					["spellIDs"] = {
						[1122] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136219,
				},
				["复生"] = {
					["enabled"] = true,
					["refSpellID"] = 20484,
					["spellIDs"] = {
						[20484] = true,
					},
					["cooldown"] = 600,
					["texture"] = 136080,
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["refSpellID"] = 33697,
					["spellIDs"] = {
						[33697] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135726,
				},
			},
			["DBVersion"] = 8,
		},
		["借你流年 - 燃烧之刃"] = {
			["DBVersion"] = 9,
			["TimerTextSize"] = 9,
			["IconSize"] = 18,
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["refSpellID"] = 31230,
					["spellIDs"] = {
						[31230] = true,
					},
					["cooldown"] = 360,
					["texture"] = 132285,
				},
				["法术反制"] = {
					["enabled"] = true,
					["refSpellID"] = 2139,
					["spellIDs"] = {
						[2139] = true,
					},
					["cooldown"] = 24,
					["texture"] = 135856,
				},
				["致盲"] = {
					["enabled"] = true,
					["refSpellID"] = 2094,
					["spellIDs"] = {
						[2094] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136175,
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["refSpellID"] = 204437,
					["spellIDs"] = {
						[204437] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1385911,
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["refSpellID"] = 132578,
					["spellIDs"] = {
						[132578] = true,
					},
					["cooldown"] = 180,
					["texture"] = 608951,
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 206572,
					["spellIDs"] = {
						[206572] = true,
					},
					["cooldown"] = 20,
					["texture"] = 1380676,
				},
				["巨人打击"] = {
					["enabled"] = true,
					["refSpellID"] = 167105,
					["spellIDs"] = {
						[167105] = true,
					},
					["cooldown"] = 45,
					["texture"] = 464973,
				},
				["震荡波"] = {
					["enabled"] = true,
					["refSpellID"] = 46968,
					["spellIDs"] = {
						[46968] = true,
					},
					["cooldown"] = 40,
					["texture"] = 236312,
				},
				["谈判"] = {
					["enabled"] = true,
					["refSpellID"] = 199743,
					["spellIDs"] = {
						[199743] = true,
					},
					["cooldown"] = 20,
					["texture"] = 236448,
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 195710,
					["spellIDs"] = {
						[195710] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1322720,
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["refSpellID"] = 207167,
					["spellIDs"] = {
						[207167] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135836,
				},
				["超级新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157980,
					["spellIDs"] = {
						[157980] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033912,
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["refSpellID"] = 206650,
					["spellIDs"] = {
						[206650] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380366,
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["refSpellID"] = 48792,
					["spellIDs"] = {
						[48792] = true,
					},
					["cooldown"] = 135,
					["texture"] = 237525,
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["refSpellID"] = 102558,
					["spellIDs"] = {
						[102558] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["死亡之握"] = {
					["enabled"] = true,
					["refSpellID"] = 49576,
					["spellIDs"] = {
						[49576] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237532,
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 853,
					["spellIDs"] = {
						[853] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135963,
				},
				["狂暴"] = {
					["enabled"] = true,
					["refSpellID"] = 106951,
					["spellIDs"] = {
						[106951] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236149,
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["refSpellID"] = 116849,
					["spellIDs"] = {
						[116849] = true,
					},
					["cooldown"] = 55,
					["texture"] = 627485,
				},
				["还魂术"] = {
					["enabled"] = true,
					["refSpellID"] = 115310,
					["spellIDs"] = {
						[115310] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1020466,
				},
				["嗜血"] = {
					["enabled"] = true,
					["refSpellID"] = 2825,
					["spellIDs"] = {
						[2825] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136012,
				},
				["墓石"] = {
					["enabled"] = true,
					["refSpellID"] = 219809,
					["spellIDs"] = {
						[219809] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132151,
				},
				["牺牲"] = {
					["enabled"] = true,
					["refSpellID"] = 7812,
					["spellIDs"] = {
						[7812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136190,
				},
				["影舞步"] = {
					["enabled"] = true,
					["refSpellID"] = 51690,
					["spellIDs"] = {
						[51690] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236277,
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["refSpellID"] = 108359,
					["spellIDs"] = {
						[108359] = true,
					},
					["cooldown"] = 120,
					["texture"] = 537516,
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["refSpellID"] = 102342,
					["spellIDs"] = {
						[102342] = true,
					},
					["cooldown"] = 30,
					["texture"] = 572025,
				},
				["亡者大军"] = {
					["enabled"] = true,
					["refSpellID"] = 42650,
					["spellIDs"] = {
						[42650] = true,
					},
					["cooldown"] = 240,
					["texture"] = 237511,
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["refSpellID"] = 198529,
					["spellIDs"] = {
						[198529] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133787,
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["refSpellID"] = 51052,
					["spellIDs"] = {
						[51052] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237510,
				},
				["消散"] = {
					["enabled"] = true,
					["refSpellID"] = 47585,
					["spellIDs"] = {
						[47585] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237563,
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["refSpellID"] = 122,
					["spellIDs"] = {
						[122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135848,
				},
				["轮回之触"] = {
					["enabled"] = true,
					["refSpellID"] = 115080,
					["spellIDs"] = {
						[115080] = true,
					},
					["cooldown"] = 120,
					["texture"] = 606552,
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["refSpellID"] = 48707,
					["spellIDs"] = {
						[48707] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136120,
				},
				["火焰石"] = {
					["enabled"] = true,
					["refSpellID"] = 212284,
					["spellIDs"] = {
						[212284] = true,
					},
					["cooldown"] = 25,
					["texture"] = 134085,
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["refSpellID"] = 196884,
					["spellIDs"] = {
						[196884] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1027879,
				},
				["鲁莽"] = {
					["enabled"] = true,
					["refSpellID"] = 1719,
					["spellIDs"] = {
						[1719] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458972,
				},
				["游侠之网"] = {
					["enabled"] = true,
					["refSpellID"] = 200108,
					["spellIDs"] = {
						[200108] = true,
					},
					["cooldown"] = 60,
					["texture"] = 134325,
				},
				["虚空联结"] = {
					["enabled"] = true,
					["refSpellID"] = 207810,
					["spellIDs"] = {
						[207810] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1450144,
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 5217,
					["spellIDs"] = {
						[5217] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132242,
				},
				["风剪"] = {
					["enabled"] = true,
					["refSpellID"] = 57994,
					["spellIDs"] = {
						[57994] = true,
					},
					["cooldown"] = 12,
					["texture"] = 136018,
				},
				["灭战者"] = {
					["enabled"] = true,
					["refSpellID"] = 262161,
					["spellIDs"] = {
						[262161] = true,
					},
					["cooldown"] = 45,
					["texture"] = 2065633,
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["refSpellID"] = 49028,
					["spellIDs"] = {
						[49028] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135277,
				},
				["石像形态"] = {
					["enabled"] = true,
					["refSpellID"] = 20594,
					["spellIDs"] = {
						[20594] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136225,
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["refSpellID"] = 201318,
					["spellIDs"] = {
						[201318] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1616072,
				},
				["压制"] = {
					["enabled"] = true,
					["refSpellID"] = 187707,
					["spellIDs"] = {
						[187707] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1376045,
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 110959,
					["spellIDs"] = {
						[110959] = true,
					},
					["cooldown"] = 75,
					["texture"] = 575584,
				},
				["剑在人在"] = {
					["enabled"] = true,
					["refSpellID"] = 118038,
					["spellIDs"] = {
						[118038] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132336,
				},
				["自利"] = {
					["enabled"] = true,
					["refSpellID"] = 59752,
					["spellIDs"] = {
						[59752] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136129,
				},
				["反击图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204331,
					["spellIDs"] = {
						[204331] = true,
					},
					["cooldown"] = 45,
					["texture"] = 511726,
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 207684,
					["spellIDs"] = {
						[207684] = true,
					},
					["cooldown"] = 50,
					["texture"] = 1418287,
				},
				["阵风"] = {
					["enabled"] = true,
					["refSpellID"] = 192063,
					["spellIDs"] = {
						[192063] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1029585,
				},
				["混乱新星"] = {
					["enabled"] = true,
					["refSpellID"] = 179057,
					["spellIDs"] = {
						[179057] = true,
					},
					["cooldown"] = 40,
					["texture"] = 135795,
				},
				["切喉手"] = {
					["enabled"] = true,
					["refSpellID"] = 116705,
					["spellIDs"] = {
						[116705] = true,
					},
					["cooldown"] = 15,
					["texture"] = 608940,
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["refSpellID"] = 102560,
					["spellIDs"] = {
						[102560] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["refSpellID"] = 115781,
					["spellIDs"] = {
						[115781] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136028,
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["refSpellID"] = 80483,
					["spellIDs"] = {
						[80483] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136222,
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["refSpellID"] = 11426,
					["spellIDs"] = {
						[11426] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135988,
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 204150,
					["spellIDs"] = {
						[204150] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135909,
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 89751,
					["spellIDs"] = {
						[89751] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236303,
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 6789,
					["spellIDs"] = {
						[6789] = true,
					},
					["cooldown"] = 45,
					["texture"] = 607853,
				},
				["生存本能"] = {
					["enabled"] = true,
					["refSpellID"] = 61336,
					["spellIDs"] = {
						[61336] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236169,
				},
				["闪避"] = {
					["enabled"] = true,
					["refSpellID"] = 5277,
					["spellIDs"] = {
						[5277] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136205,
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["refSpellID"] = 190784,
					["spellIDs"] = {
						[190784] = true,
					},
					["cooldown"] = 22,
					["texture"] = 1360759,
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["refSpellID"] = 201078,
					["spellIDs"] = {
						[201078] = true,
					},
					["cooldown"] = 120,
					["texture"] = 254647,
				},
				["天神下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 107574,
					["spellIDs"] = {
						[107574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 613534,
				},
				["消失"] = {
					["enabled"] = true,
					["refSpellID"] = 1856,
					["spellIDs"] = {
						[1856] = true,
					},
					["cooldown"] = 75,
					["texture"] = 132331,
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 91802,
					["spellIDs"] = {
						[91802] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237569,
				},
				["燃烧"] = {
					["enabled"] = true,
					["refSpellID"] = 190319,
					["spellIDs"] = {
						[190319] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135824,
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 207399,
					["spellIDs"] = {
						[207399] = true,
					},
					["cooldown"] = 300,
					["texture"] = 136080,
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["refSpellID"] = 206491,
					["spellIDs"] = {
						[206491] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236299,
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["refSpellID"] = 42292,
					["spellIDs"] = {
						[42292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 200851,
					["spellIDs"] = {
						[200851] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1129695,
				},
				["法术反射"] = {
					["enabled"] = true,
					["refSpellID"] = 216890,
					["spellIDs"] = {
						[216890] = true,
					},
					["cooldown"] = 25,
					["texture"] = 132361,
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 123904,
					["spellIDs"] = {
						[123904] = true,
					},
					["cooldown"] = 120,
					["texture"] = 620832,
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["refSpellID"] = 45438,
					["spellIDs"] = {
						[45438] = true,
					},
					["cooldown"] = 240,
					["texture"] = 135841,
				},
				["时光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 198111,
					["spellIDs"] = {
						[198111] = true,
					},
					["cooldown"] = 45,
					["texture"] = 610472,
				},
				["脚踢"] = {
					["enabled"] = true,
					["refSpellID"] = 1766,
					["spellIDs"] = {
						[1766] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132219,
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["refSpellID"] = 207319,
					["spellIDs"] = {
						[207319] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1531513,
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202137,
					["spellIDs"] = {
						[202137] = true,
					},
					["cooldown"] = 33,
					["texture"] = 1418288,
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["refSpellID"] = 198664,
					["spellIDs"] = {
						[198664] = true,
					},
					["cooldown"] = 180,
					["texture"] = 877514,
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["refSpellID"] = 194223,
					["spellIDs"] = {
						[194223] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136060,
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 98008,
					["spellIDs"] = {
						[98008] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237586,
				},
				["拳击"] = {
					["enabled"] = true,
					["refSpellID"] = 6552,
					["spellIDs"] = {
						[6552] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132938,
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["refSpellID"] = 211881,
					["spellIDs"] = {
						[211881] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1118739,
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["refSpellID"] = 33697,
					["spellIDs"] = {
						[33697] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135726,
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["refSpellID"] = 59543,
					["spellIDs"] = {
						[59543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135923,
				},
				["宁静"] = {
					["enabled"] = true,
					["refSpellID"] = 740,
					["spellIDs"] = {
						[740] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136107,
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["refSpellID"] = 12975,
					["spellIDs"] = {
						[12975] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135871,
				},
				["缴械"] = {
					["enabled"] = true,
					["refSpellID"] = 236077,
					["spellIDs"] = {
						[236077] = true,
					},
					["cooldown"] = 45,
					["texture"] = 132343,
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 212295,
					["spellIDs"] = {
						[212295] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135796,
				},
				["自然之力"] = {
					["enabled"] = true,
					["refSpellID"] = 205636,
					["spellIDs"] = {
						[205636] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132129,
				},
				["根基图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204336,
					["spellIDs"] = {
						[204336] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136039,
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["refSpellID"] = 209789,
					["spellIDs"] = {
						[209789] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1033903,
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["refSpellID"] = 184364,
					["spellIDs"] = {
						[184364] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132345,
				},
				["保护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1022,
					["spellIDs"] = {
						[1022] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135964,
				},
				["血之镜像"] = {
					["enabled"] = true,
					["refSpellID"] = 206977,
					["spellIDs"] = {
						[206977] = true,
					},
					["cooldown"] = 120,
					["texture"] = 134084,
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 196932,
					["spellIDs"] = {
						[196932] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136232,
				},
				["平心之环"] = {
					["enabled"] = true,
					["refSpellID"] = 116844,
					["spellIDs"] = {
						[116844] = true,
					},
					["cooldown"] = 45,
					["texture"] = 839107,
				},
				["虚空转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108968,
					["spellIDs"] = {
						[108968] = true,
					},
					["cooldown"] = 300,
					["texture"] = 537079,
				},
				["急速冷却"] = {
					["enabled"] = true,
					["refSpellID"] = 235219,
					["spellIDs"] = {
						[235219] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135865,
				},
				["光环掌握"] = {
					["enabled"] = true,
					["refSpellID"] = 31821,
					["spellIDs"] = {
						[31821] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135872,
				},
				["火箭跳"] = {
					["enabled"] = true,
					["refSpellID"] = 69070,
					["spellIDs"] = {
						[69070] = true,
					},
					["cooldown"] = 90,
					["texture"] = 370769,
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["refSpellID"] = 19386,
					["spellIDs"] = {
						[19386] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135125,
				},
				["伪装"] = {
					["enabled"] = true,
					["refSpellID"] = 199483,
					["spellIDs"] = {
						[199483] = true,
					},
					["cooldown"] = 60,
					["texture"] = 461113,
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186289,
					["spellIDs"] = {
						[186289] = true,
					},
					["cooldown"] = 120,
					["texture"] = 612363,
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["refSpellID"] = 63560,
					["spellIDs"] = {
						[63560] = true,
					},
					["cooldown"] = 60,
					["texture"] = 342913,
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["refSpellID"] = 119996,
					["spellIDs"] = {
						[119996] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237585,
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["refSpellID"] = 205369,
					["spellIDs"] = {
						[205369] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136173,
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["refSpellID"] = 68992,
					["spellIDs"] = {
						[68992] = true,
					},
					["cooldown"] = 120,
					["texture"] = 366937,
				},
				["龙息术"] = {
					["enabled"] = true,
					["refSpellID"] = 31661,
					["spellIDs"] = {
						[31661] = true,
					},
					["cooldown"] = 20,
					["texture"] = 134153,
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["refSpellID"] = 207349,
					["spellIDs"] = {
						[207349] = true,
					},
					["cooldown"] = 180,
					["texture"] = 298674,
				},
				["责难"] = {
					["enabled"] = true,
					["refSpellID"] = 96231,
					["spellIDs"] = {
						[96231] = true,
					},
					["cooldown"] = 15,
					["texture"] = 523893,
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 202246,
					["spellIDs"] = {
						[202246] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1408833,
				},
				["冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 100,
					["spellIDs"] = {
						[100] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132337,
				},
				["意气风发"] = {
					["enabled"] = true,
					["refSpellID"] = 109304,
					["spellIDs"] = {
						[109304] = true,
					},
					["cooldown"] = 105,
					["texture"] = 461117,
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 205629,
					["spellIDs"] = {
						[205629] = true,
					},
					["cooldown"] = 20,
					["texture"] = 134294,
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 207736,
					["spellIDs"] = {
						[207736] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1020341,
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["refSpellID"] = 119381,
					["spellIDs"] = {
						[119381] = true,
					},
					["cooldown"] = 50,
					["texture"] = 642414,
				},
				["圣盾术"] = {
					["enabled"] = true,
					["refSpellID"] = 642,
					["spellIDs"] = {
						[642] = true,
					},
					["cooldown"] = 210,
					["texture"] = 524354,
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["refSpellID"] = 7744,
					["spellIDs"] = {
						[7744] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136187,
				},
				["虚空行走"] = {
					["enabled"] = true,
					["refSpellID"] = 196555,
					["spellIDs"] = {
						[196555] = true,
					},
					["cooldown"] = 120,
					["texture"] = 463284,
				},
				["战旗"] = {
					["enabled"] = true,
					["refSpellID"] = 236320,
					["spellIDs"] = {
						[236320] = true,
					},
					["cooldown"] = 90,
					["texture"] = 603532,
				},
				["还击"] = {
					["enabled"] = true,
					["refSpellID"] = 199754,
					["spellIDs"] = {
						[199754] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132269,
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 227847,
					["spellIDs"] = {
						[227847] = true,
					},
					["cooldown"] = 60,
					["texture"] = 236303,
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["refSpellID"] = 205630,
					["spellIDs"] = {
						[205630] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380367,
				},
				["闪电奔涌图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 192058,
					["spellIDs"] = {
						[192058] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136013,
				},
				["决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 236273,
					["spellIDs"] = {
						[236273] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1455893,
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202138,
					["spellIDs"] = {
						[202138] = true,
					},
					["cooldown"] = 50,
					["texture"] = 1418286,
				},
				["百发百中"] = {
					["enabled"] = true,
					["refSpellID"] = 193526,
					["spellIDs"] = {
						[193526] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132329,
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["refSpellID"] = 31224,
					["spellIDs"] = {
						[31224] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136177,
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["refSpellID"] = 205191,
					["spellIDs"] = {
						[205191] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135986,
				},
				["群体反射"] = {
					["enabled"] = true,
					["refSpellID"] = 213915,
					["spellIDs"] = {
						[213915] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132358,
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["refSpellID"] = 53271,
					["spellIDs"] = {
						[53271] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236189,
				},
				["从天而降"] = {
					["enabled"] = true,
					["refSpellID"] = 206803,
					["spellIDs"] = {
						[206803] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380371,
				},
				["驱散射击"] = {
					["enabled"] = true,
					["refSpellID"] = 213691,
					["spellIDs"] = {
						[213691] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132153,
				},
				["血魔之握"] = {
					["enabled"] = true,
					["refSpellID"] = 108199,
					["spellIDs"] = {
						[108199] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538767,
				},
				["能量灌注"] = {
					["enabled"] = true,
					["refSpellID"] = 10060,
					["spellIDs"] = {
						[10060] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135939,
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["refSpellID"] = 5211,
					["spellIDs"] = {
						[5211] = true,
					},
					["cooldown"] = 50,
					["texture"] = 132114,
				},
				["卸除武装"] = {
					["enabled"] = true,
					["refSpellID"] = 207777,
					["spellIDs"] = {
						[207777] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236272,
				},
				["升腾"] = {
					["enabled"] = true,
					["refSpellID"] = 114050,
					["spellIDs"] = {
						[114050] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135791,
				},
				["拦截"] = {
					["enabled"] = true,
					["refSpellID"] = 198758,
					["spellIDs"] = {
						[198758] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132365,
				},
				["闪现术"] = {
					["enabled"] = true,
					["refSpellID"] = 1953,
					["spellIDs"] = {
						[1953] = true,
					},
					["cooldown"] = 15,
					["texture"] = 135739,
				},
				["树皮术"] = {
					["enabled"] = true,
					["refSpellID"] = 22812,
					["spellIDs"] = {
						[22812] = true,
					},
					["cooldown"] = 40,
					["texture"] = 136097,
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["refSpellID"] = 5484,
					["spellIDs"] = {
						[5484] = true,
					},
					["cooldown"] = 40,
					["texture"] = 607852,
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["refSpellID"] = 89766,
					["spellIDs"] = {
						[89766] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236316,
				},
				["反转魔法"] = {
					["enabled"] = true,
					["refSpellID"] = 205604,
					["spellIDs"] = {
						[205604] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380372,
				},
				["火焰之息"] = {
					["enabled"] = true,
					["refSpellID"] = 115181,
					["spellIDs"] = {
						[115181] = true,
					},
					["cooldown"] = 15,
					["texture"] = 615339,
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["refSpellID"] = 216113,
					["spellIDs"] = {
						[216113] = true,
					},
					["cooldown"] = 60,
					["texture"] = 977169,
				},
				["疾跑"] = {
					["enabled"] = true,
					["refSpellID"] = 2983,
					["spellIDs"] = {
						[2983] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132307,
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["refSpellID"] = 12292,
					["spellIDs"] = {
						[12292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236304,
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 6940,
					["spellIDs"] = {
						[6940] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135966,
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["refSpellID"] = 33891,
					["spellIDs"] = {
						[33891] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236157,
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["refSpellID"] = 115176,
					["spellIDs"] = {
						[115176] = true,
					},
					["cooldown"] = 100,
					["texture"] = 642417,
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["refSpellID"] = 108416,
					["spellIDs"] = {
						[108416] = true,
					},
					["cooldown"] = 60,
					["texture"] = 538538,
				},
				["冲动"] = {
					["enabled"] = true,
					["refSpellID"] = 13750,
					["spellIDs"] = {
						[13750] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136206,
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["refSpellID"] = 8122,
					["spellIDs"] = {
						[8122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136184,
				},
				["躯不坏"] = {
					["enabled"] = true,
					["refSpellID"] = 122278,
					["spellIDs"] = {
						[122278] = true,
					},
					["cooldown"] = 120,
					["texture"] = 620827,
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 208683,
					["spellIDs"] = {
						[208683] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["暗影步"] = {
					["enabled"] = true,
					["refSpellID"] = 36554,
					["spellIDs"] = {
						[36554] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132303,
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["refSpellID"] = 213602,
					["spellIDs"] = {
						[213602] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135994,
				},
				["正中眉心"] = {
					["enabled"] = true,
					["refSpellID"] = 199804,
					["spellIDs"] = {
						[199804] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135610,
				},
				["逃命专家"] = {
					["enabled"] = true,
					["refSpellID"] = 20589,
					["spellIDs"] = {
						[20589] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132309,
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["refSpellID"] = 187827,
					["spellIDs"] = {
						[187827] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1247263,
				},
				["圣疗术"] = {
					["enabled"] = true,
					["refSpellID"] = 633,
					["spellIDs"] = {
						[633] = true,
					},
					["cooldown"] = 420,
					["texture"] = 135928,
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["refSpellID"] = 19574,
					["spellIDs"] = {
						[19574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132127,
				},
				["自由祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1044,
					["spellIDs"] = {
						[1044] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135968,
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 102359,
					["spellIDs"] = {
						[102359] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538515,
				},
				["散魔功"] = {
					["enabled"] = true,
					["refSpellID"] = 122783,
					["spellIDs"] = {
						[122783] = true,
					},
					["cooldown"] = 90,
					["texture"] = 775460,
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["refSpellID"] = 76577,
					["spellIDs"] = {
						[76577] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458733,
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 18499,
					["spellIDs"] = {
						[18499] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136009,
				},
				["胁迫"] = {
					["enabled"] = true,
					["refSpellID"] = 19577,
					["spellIDs"] = {
						[19577] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132111,
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["refSpellID"] = 105809,
					["spellIDs"] = {
						[105809] = true,
					},
					["cooldown"] = 90,
					["texture"] = 571555,
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["refSpellID"] = 64843,
					["spellIDs"] = {
						[64843] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237540,
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157997,
					["spellIDs"] = {
						[157997] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033909,
				},
				["法术封锁"] = {
					["enabled"] = true,
					["refSpellID"] = 19647,
					["spellIDs"] = {
						[19647] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136174,
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["refSpellID"] = 47528,
					["spellIDs"] = {
						[47528] = true,
					},
					["cooldown"] = 15,
					["texture"] = 237527,
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["refSpellID"] = 115078,
					["spellIDs"] = {
						[115078] = true,
					},
					["cooldown"] = 45,
					["texture"] = 629534,
				},
				["盾墙"] = {
					["enabled"] = true,
					["refSpellID"] = 871,
					["spellIDs"] = {
						[871] = true,
					},
					["cooldown"] = 240,
					["texture"] = 132362,
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["refSpellID"] = 121471,
					["spellIDs"] = {
						[121471] = true,
					},
					["cooldown"] = 180,
					["texture"] = 376022,
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["refSpellID"] = 228049,
					["spellIDs"] = {
						[228049] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135919,
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["refSpellID"] = 49206,
					["spellIDs"] = {
						[49206] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458967,
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["refSpellID"] = 5246,
					["spellIDs"] = {
						[5246] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132154,
				},
				["抓钩"] = {
					["enabled"] = true,
					["refSpellID"] = 195457,
					["spellIDs"] = {
						[195457] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1373906,
				},
				["窒息"] = {
					["enabled"] = true,
					["refSpellID"] = 47476,
					["spellIDs"] = {
						[47476] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["元素宗师"] = {
					["enabled"] = true,
					["refSpellID"] = 16166,
					["spellIDs"] = {
						[16166] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136027,
				},
				["圣佑术"] = {
					["enabled"] = true,
					["refSpellID"] = 498,
					["spellIDs"] = {
						[498] = true,
					},
					["cooldown"] = 30,
					["texture"] = 524353,
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 51490,
					["spellIDs"] = {
						[51490] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237589,
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 31884,
					["spellIDs"] = {
						[31884] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135875,
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 51485,
					["spellIDs"] = {
						[51485] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136100,
				},
				["禁锢"] = {
					["enabled"] = true,
					["refSpellID"] = 221527,
					["spellIDs"] = {
						[221527] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380368,
				},
				["星界转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108271,
					["spellIDs"] = {
						[108271] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538565,
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 6544,
					["spellIDs"] = {
						[6544] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236171,
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["refSpellID"] = 31687,
					["spellIDs"] = {
						[31687] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135862,
				},
				["宿敌"] = {
					["enabled"] = true,
					["refSpellID"] = 79140,
					["spellIDs"] = {
						[79140] = true,
					},
					["cooldown"] = 120,
					["texture"] = 458726,
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["refSpellID"] = 202370,
					["spellIDs"] = {
						[202370] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1381297,
				},
				["斗转星移"] = {
					["enabled"] = true,
					["refSpellID"] = 202162,
					["spellIDs"] = {
						[202162] = true,
					},
					["cooldown"] = 45,
					["texture"] = 620829,
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 86659,
					["spellIDs"] = {
						[86659] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135919,
				},
				["摧心魔"] = {
					["enabled"] = true,
					["refSpellID"] = 123040,
					["spellIDs"] = {
						[123040] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["反制射击"] = {
					["enabled"] = true,
					["refSpellID"] = 147362,
					["spellIDs"] = {
						[147362] = true,
					},
					["cooldown"] = 24,
					["texture"] = 249170,
				},
				["灵体形态"] = {
					["enabled"] = true,
					["refSpellID"] = 210918,
					["spellIDs"] = {
						[210918] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237572,
				},
				["英勇"] = {
					["enabled"] = true,
					["refSpellID"] = 32182,
					["spellIDs"] = {
						[32182] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132313,
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["refSpellID"] = 102793,
					["spellIDs"] = {
						[102793] = true,
					},
					["cooldown"] = 60,
					["texture"] = 571588,
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["refSpellID"] = 187650,
					["spellIDs"] = {
						[187650] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135834,
				},
				["业报之触"] = {
					["enabled"] = true,
					["refSpellID"] = 122470,
					["spellIDs"] = {
						[122470] = true,
					},
					["cooldown"] = 90,
					["texture"] = 651728,
				},
				["束缚射击"] = {
					["enabled"] = true,
					["refSpellID"] = 109248,
					["spellIDs"] = {
						[109248] = true,
					},
					["cooldown"] = 45,
					["texture"] = 462650,
				},
				["守护之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 47788,
					["spellIDs"] = {
						[47788] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237542,
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["refSpellID"] = 48020,
					["spellIDs"] = {
						[48020] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237560,
				},
				["割碎"] = {
					["enabled"] = true,
					["refSpellID"] = 22570,
					["spellIDs"] = {
						[22570] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132134,
				},
				["闪光力场"] = {
					["enabled"] = true,
					["refSpellID"] = 204263,
					["spellIDs"] = {
						[204263] = true,
					},
					["cooldown"] = 45,
					["texture"] = 571554,
				},
				["瓦解"] = {
					["enabled"] = true,
					["refSpellID"] = 183752,
					["spellIDs"] = {
						[183752] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1305153,
				},
				["隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 66,
					["spellIDs"] = {
						[66] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132220,
				},
				["复生"] = {
					["enabled"] = true,
					["refSpellID"] = 20484,
					["spellIDs"] = {
						[20484] = true,
					},
					["cooldown"] = 600,
					["texture"] = 136080,
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 73325,
					["spellIDs"] = {
						[73325] = true,
					},
					["cooldown"] = 45,
					["texture"] = 463835,
				},
				["急奔"] = {
					["enabled"] = true,
					["refSpellID"] = 1850,
					["spellIDs"] = {
						[1850] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132120,
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["refSpellID"] = 209749,
					["spellIDs"] = {
						[209749] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538516,
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["refSpellID"] = 188501,
					["spellIDs"] = {
						[188501] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1247266,
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["refSpellID"] = 201325,
					["spellIDs"] = {
						[201325] = true,
					},
					["cooldown"] = 45,
					["texture"] = 642417,
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["refSpellID"] = 108201,
					["spellIDs"] = {
						[108201] = true,
					},
					["cooldown"] = 60,
					["texture"] = 538768,
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["refSpellID"] = 33206,
					["spellIDs"] = {
						[33206] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135936,
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["refSpellID"] = 77606,
					["spellIDs"] = {
						[77606] = true,
					},
					["cooldown"] = 20,
					["texture"] = 135888,
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["refSpellID"] = 69041,
					["spellIDs"] = {
						[69041] = true,
					},
					["cooldown"] = 90,
					["texture"] = 133032,
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["refSpellID"] = 216331,
					["spellIDs"] = {
						[216331] = true,
					},
					["cooldown"] = 120,
					["texture"] = 589117,
				},
				["肾击"] = {
					["enabled"] = true,
					["refSpellID"] = 408,
					["spellIDs"] = {
						[408] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132298,
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["refSpellID"] = 19236,
					["spellIDs"] = {
						[19236] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237550,
				},
				["奥术强化"] = {
					["enabled"] = true,
					["refSpellID"] = 12042,
					["spellIDs"] = {
						[12042] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136048,
				},
				["风火雷电"] = {
					["enabled"] = true,
					["refSpellID"] = 137639,
					["spellIDs"] = {
						[137639] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136038,
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["refSpellID"] = 12472,
					["spellIDs"] = {
						[12472] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135838,
				},
				["闪回"] = {
					["enabled"] = true,
					["refSpellID"] = 195676,
					["spellIDs"] = {
						[195676] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132171,
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["refSpellID"] = 79206,
					["spellIDs"] = {
						[79206] = true,
					},
					["cooldown"] = 60,
					["texture"] = 451170,
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 204018,
					["spellIDs"] = {
						[204018] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135880,
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186257,
					["spellIDs"] = {
						[186257] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132242,
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["refSpellID"] = 198817,
					["spellIDs"] = {
						[198817] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1380678,
				},
				["台风"] = {
					["enabled"] = true,
					["refSpellID"] = 132469,
					["spellIDs"] = {
						[132469] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236170,
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["refSpellID"] = 198898,
					["spellIDs"] = {
						[198898] = true,
					},
					["cooldown"] = 30,
					["texture"] = 332402,
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["refSpellID"] = 84714,
					["spellIDs"] = {
						[84714] = true,
					},
					["cooldown"] = 60,
					["texture"] = 629077,
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["refSpellID"] = 31850,
					["spellIDs"] = {
						[31850] = true,
					},
					["cooldown"] = 84,
					["texture"] = 135870,
				},
				["日光术"] = {
					["enabled"] = true,
					["refSpellID"] = 78675,
					["spellIDs"] = {
						[78675] = true,
					},
					["cooldown"] = 40,
					["texture"] = 252188,
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["refSpellID"] = 212459,
					["spellIDs"] = {
						[212459] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1113433,
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["refSpellID"] = 208253,
					["spellIDs"] = {
						[208253] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1115592,
				},
				["甘霖"] = {
					["enabled"] = true,
					["refSpellID"] = 108238,
					["spellIDs"] = {
						[108238] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136059,
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["refSpellID"] = 152173,
					["spellIDs"] = {
						[152173] = true,
					},
					["cooldown"] = 90,
					["texture"] = 988197,
				},
				["真言术：障"] = {
					["enabled"] = true,
					["refSpellID"] = 62618,
					["spellIDs"] = {
						[62618] = true,
					},
					["cooldown"] = 90,
					["texture"] = 253400,
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["refSpellID"] = 106839,
					["spellIDs"] = {
						[106839] = true,
					},
					["cooldown"] = 15,
					["texture"] = 236946,
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["refSpellID"] = 102543,
					["spellIDs"] = {
						[102543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["战争践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 11876,
					["spellIDs"] = {
						[11876] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132091,
				},
				["妖术"] = {
					["enabled"] = true,
					["refSpellID"] = 51514,
					["spellIDs"] = {
						[51514] = true,
					},
					["cooldown"] = 10,
					["texture"] = 237579,
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 108280,
					["spellIDs"] = {
						[108280] = true,
					},
					["cooldown"] = 180,
					["texture"] = 538569,
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 215769,
					["spellIDs"] = {
						[215769] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132864,
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 107570,
					["spellIDs"] = {
						[107570] = true,
					},
					["cooldown"] = 30,
					["texture"] = 613535,
				},
				["疾影"] = {
					["enabled"] = true,
					["refSpellID"] = 198589,
					["spellIDs"] = {
						[198589] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1305150,
				},
				["不灭决心"] = {
					["enabled"] = true,
					["refSpellID"] = 104773,
					["spellIDs"] = {
						[104773] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136150,
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["refSpellID"] = 186387,
					["spellIDs"] = {
						[186387] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1376038,
				},
				["逃脱"] = {
					["enabled"] = true,
					["refSpellID"] = 781,
					["spellIDs"] = {
						[781] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132294,
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186265,
					["spellIDs"] = {
						[186265] = true,
					},
					["cooldown"] = 144,
					["texture"] = 132199,
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["refSpellID"] = 64044,
					["spellIDs"] = {
						[64044] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237568,
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["refSpellID"] = 88625,
					["spellIDs"] = {
						[88625] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135886,
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 30283,
					["spellIDs"] = {
						[30283] = true,
					},
					["cooldown"] = 45,
					["texture"] = 607865,
				},
				["沉默"] = {
					["enabled"] = true,
					["refSpellID"] = 15487,
					["spellIDs"] = {
						[15487] = true,
					},
					["cooldown"] = 30,
					["texture"] = 458230,
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["refSpellID"] = 51533,
					["spellIDs"] = {
						[51533] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237577,
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["refSpellID"] = 205691,
					["spellIDs"] = {
						[205691] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1412204,
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["refSpellID"] = 51271,
					["spellIDs"] = {
						[51271] = true,
					},
					["cooldown"] = 45,
					["texture"] = 458718,
				},
				["幻影打击"] = {
					["enabled"] = true,
					["refSpellID"] = 196718,
					["spellIDs"] = {
						[196718] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1305154,
				},
				["凿击"] = {
					["enabled"] = true,
					["refSpellID"] = 1776,
					["spellIDs"] = {
						[1776] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132155,
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 210256,
					["spellIDs"] = {
						[210256] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135911,
				},
				["唤醒"] = {
					["enabled"] = true,
					["refSpellID"] = 12051,
					["spellIDs"] = {
						[12051] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136075,
				},
				["影遁"] = {
					["enabled"] = true,
					["refSpellID"] = 58984,
					["spellIDs"] = {
						[58984] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132089,
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["refSpellID"] = 1122,
					["spellIDs"] = {
						[1122] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136219,
				},
				["天灾契约"] = {
					["enabled"] = true,
					["refSpellID"] = 48743,
					["spellIDs"] = {
						[48743] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136146,
				},
				["电能图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 192058,
					["spellIDs"] = {
						[192058] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136013,
				},
			},
			["IconYOffset"] = -8,
		},
		["绑住了风 - 索瑞森"] = {
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["refSpellID"] = 31230,
					["spellIDs"] = {
						[31230] = true,
					},
					["cooldown"] = 360,
					["texture"] = 132285,
				},
				["法术反制"] = {
					["enabled"] = true,
					["refSpellID"] = 2139,
					["spellIDs"] = {
						[2139] = true,
					},
					["cooldown"] = 24,
					["texture"] = 135856,
				},
				["天灾契约"] = {
					["enabled"] = true,
					["refSpellID"] = 48743,
					["spellIDs"] = {
						[48743] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136146,
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["refSpellID"] = 204437,
					["spellIDs"] = {
						[204437] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1385911,
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["refSpellID"] = 132578,
					["spellIDs"] = {
						[132578] = true,
					},
					["cooldown"] = 180,
					["texture"] = 608951,
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 206572,
					["spellIDs"] = {
						[206572] = true,
					},
					["cooldown"] = 20,
					["texture"] = 1380676,
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 215769,
					["spellIDs"] = {
						[215769] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132864,
				},
				["震荡波"] = {
					["enabled"] = true,
					["refSpellID"] = 46968,
					["spellIDs"] = {
						[46968] = true,
					},
					["cooldown"] = 40,
					["texture"] = 236312,
				},
				["谈判"] = {
					["enabled"] = true,
					["refSpellID"] = 199743,
					["spellIDs"] = {
						[199743] = true,
					},
					["cooldown"] = 20,
					["texture"] = 236448,
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 195710,
					["spellIDs"] = {
						[195710] = true,
					},
					["cooldown"] = 180,
					["texture"] = 338784,
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["refSpellID"] = 207167,
					["spellIDs"] = {
						[207167] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135836,
				},
				["超级新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157980,
					["spellIDs"] = {
						[157980] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033912,
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["refSpellID"] = 206650,
					["spellIDs"] = {
						[206650] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380366,
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["refSpellID"] = 48792,
					["spellIDs"] = {
						[48792] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237525,
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["refSpellID"] = 102558,
					["spellIDs"] = {
						[102558] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["死亡之握"] = {
					["enabled"] = true,
					["refSpellID"] = 49576,
					["spellIDs"] = {
						[49576] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237532,
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 853,
					["spellIDs"] = {
						[853] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135963,
				},
				["狂暴"] = {
					["enabled"] = true,
					["refSpellID"] = 26297,
					["spellIDs"] = {
						[26297] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135727,
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["refSpellID"] = 116849,
					["spellIDs"] = {
						[116849] = true,
					},
					["cooldown"] = 90,
					["texture"] = 627485,
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["refSpellID"] = 198817,
					["spellIDs"] = {
						[198817] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1380678,
				},
				["嗜血"] = {
					["enabled"] = true,
					["refSpellID"] = 2825,
					["spellIDs"] = {
						[2825] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136012,
				},
				["墓石"] = {
					["enabled"] = true,
					["refSpellID"] = 219809,
					["spellIDs"] = {
						[219809] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132151,
				},
				["电能图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 192058,
					["spellIDs"] = {
						[192058] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136013,
				},
				["影舞步"] = {
					["enabled"] = true,
					["refSpellID"] = 51690,
					["spellIDs"] = {
						[51690] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236277,
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["refSpellID"] = 108359,
					["spellIDs"] = {
						[108359] = true,
					},
					["cooldown"] = 120,
					["texture"] = 537516,
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["refSpellID"] = 102342,
					["spellIDs"] = {
						[102342] = true,
					},
					["cooldown"] = 90,
					["texture"] = 572025,
				},
				["亡者大军"] = {
					["enabled"] = true,
					["refSpellID"] = 42650,
					["spellIDs"] = {
						[42650] = true,
					},
					["cooldown"] = 600,
					["texture"] = 237511,
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["refSpellID"] = 198529,
					["spellIDs"] = {
						[198529] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133787,
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["refSpellID"] = 51052,
					["spellIDs"] = {
						[51052] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237510,
				},
				["消散"] = {
					["enabled"] = true,
					["refSpellID"] = 47585,
					["spellIDs"] = {
						[47585] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237563,
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["refSpellID"] = 122,
					["spellIDs"] = {
						[122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135848,
				},
				["轮回之触"] = {
					["enabled"] = true,
					["refSpellID"] = 115080,
					["spellIDs"] = {
						[115080] = true,
					},
					["cooldown"] = 60,
					["texture"] = 606552,
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["refSpellID"] = 48707,
					["spellIDs"] = {
						[48707] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136120,
				},
				["火焰石"] = {
					["enabled"] = true,
					["refSpellID"] = 212284,
					["spellIDs"] = {
						[212284] = true,
					},
					["cooldown"] = 45,
					["texture"] = 134085,
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["refSpellID"] = 196884,
					["spellIDs"] = {
						[196884] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1027879,
				},
				["鲁莽"] = {
					["enabled"] = true,
					["refSpellID"] = 1719,
					["spellIDs"] = {
						[1719] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458972,
				},
				["游侠之网"] = {
					["enabled"] = true,
					["refSpellID"] = 200108,
					["spellIDs"] = {
						[200108] = true,
					},
					["cooldown"] = 60,
					["texture"] = 134325,
				},
				["虚空联结"] = {
					["enabled"] = true,
					["refSpellID"] = 207810,
					["spellIDs"] = {
						[207810] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1450144,
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 5217,
					["spellIDs"] = {
						[5217] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132242,
				},
				["风剪"] = {
					["enabled"] = true,
					["refSpellID"] = 57994,
					["spellIDs"] = {
						[57994] = true,
					},
					["cooldown"] = 12,
					["texture"] = 136018,
				},
				["灭战者"] = {
					["enabled"] = true,
					["refSpellID"] = 262161,
					["spellIDs"] = {
						[262161] = true,
					},
					["cooldown"] = 45,
					["texture"] = 2065633,
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["refSpellID"] = 49028,
					["spellIDs"] = {
						[49028] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135277,
				},
				["石像形态"] = {
					["enabled"] = true,
					["refSpellID"] = 20594,
					["spellIDs"] = {
						[20594] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136225,
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["refSpellID"] = 201318,
					["spellIDs"] = {
						[201318] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1616072,
				},
				["压制"] = {
					["enabled"] = true,
					["refSpellID"] = 187707,
					["spellIDs"] = {
						[187707] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1376045,
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 110959,
					["spellIDs"] = {
						[110959] = true,
					},
					["cooldown"] = 75,
					["texture"] = 575584,
				},
				["剑在人在"] = {
					["enabled"] = true,
					["refSpellID"] = 118038,
					["spellIDs"] = {
						[118038] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132336,
				},
				["自利"] = {
					["enabled"] = true,
					["refSpellID"] = 59752,
					["spellIDs"] = {
						[59752] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136129,
				},
				["反击图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204331,
					["spellIDs"] = {
						[204331] = true,
					},
					["cooldown"] = 45,
					["texture"] = 511726,
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 207684,
					["spellIDs"] = {
						[207684] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418287,
				},
				["阵风"] = {
					["enabled"] = true,
					["refSpellID"] = 192063,
					["spellIDs"] = {
						[192063] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1029585,
				},
				["混乱新星"] = {
					["enabled"] = true,
					["refSpellID"] = 179057,
					["spellIDs"] = {
						[179057] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135795,
				},
				["切喉手"] = {
					["enabled"] = true,
					["refSpellID"] = 116705,
					["spellIDs"] = {
						[116705] = true,
					},
					["cooldown"] = 15,
					["texture"] = 608940,
				},
				["法术封锁"] = {
					["enabled"] = true,
					["refSpellID"] = 19647,
					["spellIDs"] = {
						[19647] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136174,
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["refSpellID"] = 115781,
					["spellIDs"] = {
						[115781] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136028,
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["refSpellID"] = 80483,
					["spellIDs"] = {
						[80483] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136222,
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["refSpellID"] = 11426,
					["spellIDs"] = {
						[11426] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135988,
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 204150,
					["spellIDs"] = {
						[204150] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135909,
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 89751,
					["spellIDs"] = {
						[89751] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236303,
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 6789,
					["spellIDs"] = {
						[6789] = true,
					},
					["cooldown"] = 45,
					["texture"] = 607853,
				},
				["生存本能"] = {
					["enabled"] = true,
					["refSpellID"] = 61336,
					["spellIDs"] = {
						[61336] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236169,
				},
				["闪避"] = {
					["enabled"] = true,
					["refSpellID"] = 5277,
					["spellIDs"] = {
						[5277] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136205,
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["refSpellID"] = 64843,
					["spellIDs"] = {
						[64843] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237540,
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["refSpellID"] = 201078,
					["spellIDs"] = {
						[201078] = true,
					},
					["cooldown"] = 120,
					["texture"] = 254647,
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186265,
					["spellIDs"] = {
						[186265] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132199,
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 31884,
					["spellIDs"] = {
						[31884] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135875,
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 91802,
					["spellIDs"] = {
						[91802] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237569,
				},
				["燃烧"] = {
					["enabled"] = true,
					["refSpellID"] = 190319,
					["spellIDs"] = {
						[190319] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135824,
				},
				["唤醒"] = {
					["enabled"] = true,
					["refSpellID"] = 12051,
					["spellIDs"] = {
						[12051] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136075,
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["refSpellID"] = 206491,
					["spellIDs"] = {
						[206491] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236299,
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["refSpellID"] = 42292,
					["spellIDs"] = {
						[42292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 200851,
					["spellIDs"] = {
						[200851] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1129695,
				},
				["法术反射"] = {
					["enabled"] = true,
					["refSpellID"] = 23920,
					["spellIDs"] = {
						[23920] = true,
					},
					["cooldown"] = 25,
					["texture"] = 132361,
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 123904,
					["spellIDs"] = {
						[123904] = true,
					},
					["cooldown"] = 180,
					["texture"] = 620832,
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["refSpellID"] = 45438,
					["spellIDs"] = {
						[45438] = true,
					},
					["cooldown"] = 240,
					["texture"] = 135841,
				},
				["时光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 198111,
					["spellIDs"] = {
						[198111] = true,
					},
					["cooldown"] = 45,
					["texture"] = 610472,
				},
				["脚踢"] = {
					["enabled"] = true,
					["refSpellID"] = 1766,
					["spellIDs"] = {
						[1766] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132219,
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 18499,
					["spellIDs"] = {
						[18499] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136009,
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202137,
					["spellIDs"] = {
						[202137] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418288,
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["refSpellID"] = 198664,
					["spellIDs"] = {
						[198664] = true,
					},
					["cooldown"] = 180,
					["texture"] = 877514,
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["refSpellID"] = 194223,
					["spellIDs"] = {
						[194223] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136060,
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 98008,
					["spellIDs"] = {
						[98008] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237586,
				},
				["拳击"] = {
					["enabled"] = true,
					["refSpellID"] = 6552,
					["spellIDs"] = {
						[6552] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132938,
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["refSpellID"] = 211881,
					["spellIDs"] = {
						[211881] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1118739,
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 51485,
					["spellIDs"] = {
						[51485] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136100,
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["refSpellID"] = 59543,
					["spellIDs"] = {
						[59543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135923,
				},
				["宁静"] = {
					["enabled"] = true,
					["refSpellID"] = 740,
					["spellIDs"] = {
						[740] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136107,
				},
				["急奔"] = {
					["enabled"] = true,
					["refSpellID"] = 1850,
					["spellIDs"] = {
						[1850] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132120,
				},
				["缴械"] = {
					["enabled"] = true,
					["refSpellID"] = 236077,
					["spellIDs"] = {
						[236077] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132343,
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 212295,
					["spellIDs"] = {
						[212295] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135796,
				},
				["自然之力"] = {
					["enabled"] = true,
					["refSpellID"] = 205636,
					["spellIDs"] = {
						[205636] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132129,
				},
				["根基图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204336,
					["spellIDs"] = {
						[204336] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136039,
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["refSpellID"] = 209749,
					["spellIDs"] = {
						[209749] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538516,
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["refSpellID"] = 184364,
					["spellIDs"] = {
						[184364] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132345,
				},
				["保护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1022,
					["spellIDs"] = {
						[1022] = true,
					},
					["cooldown"] = 135,
					["texture"] = 135964,
				},
				["血之镜像"] = {
					["enabled"] = true,
					["refSpellID"] = 206977,
					["spellIDs"] = {
						[206977] = true,
					},
					["cooldown"] = 120,
					["texture"] = 134084,
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 196932,
					["spellIDs"] = {
						[196932] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136232,
				},
				["平心之环"] = {
					["enabled"] = true,
					["refSpellID"] = 116844,
					["spellIDs"] = {
						[116844] = true,
					},
					["cooldown"] = 45,
					["texture"] = 839107,
				},
				["虚空转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108968,
					["spellIDs"] = {
						[108968] = true,
					},
					["cooldown"] = 300,
					["texture"] = 537079,
				},
				["急速冷却"] = {
					["enabled"] = true,
					["refSpellID"] = 235219,
					["spellIDs"] = {
						[235219] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135865,
				},
				["光环掌握"] = {
					["enabled"] = true,
					["refSpellID"] = 31821,
					["spellIDs"] = {
						[31821] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135872,
				},
				["火箭跳"] = {
					["enabled"] = true,
					["refSpellID"] = 69070,
					["spellIDs"] = {
						[69070] = true,
					},
					["cooldown"] = 120,
					["texture"] = 370769,
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["refSpellID"] = 19386,
					["spellIDs"] = {
						[19386] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135125,
				},
				["伪装"] = {
					["enabled"] = true,
					["refSpellID"] = 199483,
					["spellIDs"] = {
						[199483] = true,
					},
					["cooldown"] = 60,
					["texture"] = 461113,
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186289,
					["spellIDs"] = {
						[186289] = true,
					},
					["cooldown"] = 120,
					["texture"] = 612363,
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["refSpellID"] = 63560,
					["spellIDs"] = {
						[63560] = true,
					},
					["cooldown"] = 60,
					["texture"] = 342913,
				},
				["抓钩"] = {
					["enabled"] = true,
					["refSpellID"] = 195457,
					["spellIDs"] = {
						[195457] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1373906,
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["refSpellID"] = 205369,
					["spellIDs"] = {
						[205369] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136173,
				},
				["圣佑术"] = {
					["enabled"] = true,
					["refSpellID"] = 498,
					["spellIDs"] = {
						[498] = true,
					},
					["cooldown"] = 60,
					["texture"] = 524353,
				},
				["禁锢"] = {
					["enabled"] = true,
					["refSpellID"] = 221527,
					["spellIDs"] = {
						[221527] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380368,
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["refSpellID"] = 207349,
					["spellIDs"] = {
						[207349] = true,
					},
					["cooldown"] = 120,
					["texture"] = 298674,
				},
				["责难"] = {
					["enabled"] = true,
					["refSpellID"] = 96231,
					["spellIDs"] = {
						[96231] = true,
					},
					["cooldown"] = 15,
					["texture"] = 523893,
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 202246,
					["spellIDs"] = {
						[202246] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1408833,
				},
				["冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 100,
					["spellIDs"] = {
						[100] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132337,
				},
				["意气风发"] = {
					["enabled"] = true,
					["refSpellID"] = 109304,
					["spellIDs"] = {
						[109304] = true,
					},
					["cooldown"] = 120,
					["texture"] = 461117,
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 205629,
					["spellIDs"] = {
						[205629] = true,
					},
					["cooldown"] = 30,
					["texture"] = 134294,
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 207736,
					["spellIDs"] = {
						[207736] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1020341,
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["refSpellID"] = 119381,
					["spellIDs"] = {
						[119381] = true,
					},
					["cooldown"] = 60,
					["texture"] = 642414,
				},
				["圣盾术"] = {
					["enabled"] = true,
					["refSpellID"] = 642,
					["spellIDs"] = {
						[642] = true,
					},
					["cooldown"] = 240,
					["texture"] = 524354,
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["refSpellID"] = 7744,
					["spellIDs"] = {
						[7744] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136187,
				},
				["虚空行走"] = {
					["enabled"] = true,
					["refSpellID"] = 196555,
					["spellIDs"] = {
						[196555] = true,
					},
					["cooldown"] = 120,
					["texture"] = 463284,
				},
				["战旗"] = {
					["enabled"] = true,
					["refSpellID"] = 236320,
					["spellIDs"] = {
						[236320] = true,
					},
					["cooldown"] = 90,
					["texture"] = 603532,
				},
				["还击"] = {
					["enabled"] = true,
					["refSpellID"] = 199754,
					["spellIDs"] = {
						[199754] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132269,
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 227847,
					["spellIDs"] = {
						[227847] = true,
					},
					["cooldown"] = 60,
					["texture"] = 236303,
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186257,
					["spellIDs"] = {
						[186257] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132242,
				},
				["甘霖"] = {
					["enabled"] = true,
					["refSpellID"] = 108238,
					["spellIDs"] = {
						[108238] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136059,
				},
				["决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 236273,
					["spellIDs"] = {
						[236273] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1455893,
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202138,
					["spellIDs"] = {
						[202138] = true,
					},
					["cooldown"] = 54,
					["texture"] = 1418286,
				},
				["百发百中"] = {
					["enabled"] = true,
					["refSpellID"] = 193526,
					["spellIDs"] = {
						[193526] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132329,
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["refSpellID"] = 31224,
					["spellIDs"] = {
						[31224] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136177,
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["refSpellID"] = 205191,
					["spellIDs"] = {
						[205191] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135986,
				},
				["群体反射"] = {
					["enabled"] = true,
					["refSpellID"] = 213915,
					["spellIDs"] = {
						[213915] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132358,
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["refSpellID"] = 53271,
					["spellIDs"] = {
						[53271] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236189,
				},
				["从天而降"] = {
					["enabled"] = true,
					["refSpellID"] = 206803,
					["spellIDs"] = {
						[206803] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380371,
				},
				["驱散射击"] = {
					["enabled"] = true,
					["refSpellID"] = 213691,
					["spellIDs"] = {
						[213691] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132153,
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 108280,
					["spellIDs"] = {
						[108280] = true,
					},
					["cooldown"] = 180,
					["texture"] = 538569,
				},
				["能量灌注"] = {
					["enabled"] = true,
					["refSpellID"] = 10060,
					["spellIDs"] = {
						[10060] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135939,
				},
				["窒息"] = {
					["enabled"] = true,
					["refSpellID"] = 47476,
					["spellIDs"] = {
						[47476] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136214,
				},
				["卸除武装"] = {
					["enabled"] = true,
					["refSpellID"] = 207777,
					["spellIDs"] = {
						[207777] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236272,
				},
				["升腾"] = {
					["enabled"] = true,
					["refSpellID"] = 114050,
					["spellIDs"] = {
						[114050] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135791,
				},
				["拦截"] = {
					["enabled"] = true,
					["refSpellID"] = 198304,
					["spellIDs"] = {
						[198304] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132365,
				},
				["闪现术"] = {
					["enabled"] = true,
					["refSpellID"] = 1953,
					["spellIDs"] = {
						[1953] = true,
					},
					["cooldown"] = 15,
					["texture"] = 135736,
				},
				["树皮术"] = {
					["enabled"] = true,
					["refSpellID"] = 22812,
					["spellIDs"] = {
						[22812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136097,
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["refSpellID"] = 5484,
					["spellIDs"] = {
						[5484] = true,
					},
					["cooldown"] = 40,
					["texture"] = 607852,
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["refSpellID"] = 89766,
					["spellIDs"] = {
						[89766] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236316,
				},
				["反转魔法"] = {
					["enabled"] = true,
					["refSpellID"] = 205604,
					["spellIDs"] = {
						[205604] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380372,
				},
				["火焰之息"] = {
					["enabled"] = true,
					["refSpellID"] = 115181,
					["spellIDs"] = {
						[115181] = true,
					},
					["cooldown"] = 15,
					["texture"] = 615339,
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["refSpellID"] = 216113,
					["spellIDs"] = {
						[216113] = true,
					},
					["cooldown"] = 45,
					["texture"] = 977169,
				},
				["疾跑"] = {
					["enabled"] = true,
					["refSpellID"] = 2983,
					["spellIDs"] = {
						[2983] = true,
					},
					["cooldown"] = 51,
					["texture"] = 132307,
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["refSpellID"] = 12292,
					["spellIDs"] = {
						[12292] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236304,
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["refSpellID"] = 64044,
					["spellIDs"] = {
						[64044] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237568,
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["refSpellID"] = 33891,
					["spellIDs"] = {
						[33891] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236157,
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["refSpellID"] = 115176,
					["spellIDs"] = {
						[115176] = true,
					},
					["cooldown"] = 150,
					["texture"] = 642417,
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["refSpellID"] = 121471,
					["spellIDs"] = {
						[121471] = true,
					},
					["cooldown"] = 180,
					["texture"] = 376022,
				},
				["冲动"] = {
					["enabled"] = true,
					["refSpellID"] = 13750,
					["spellIDs"] = {
						[13750] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136206,
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["refSpellID"] = 8122,
					["spellIDs"] = {
						[8122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136184,
				},
				["躯不坏"] = {
					["enabled"] = true,
					["refSpellID"] = 122278,
					["spellIDs"] = {
						[122278] = true,
					},
					["cooldown"] = 120,
					["texture"] = 620827,
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 208683,
					["spellIDs"] = {
						[208683] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["暗影步"] = {
					["enabled"] = true,
					["refSpellID"] = 36554,
					["spellIDs"] = {
						[36554] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132303,
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["refSpellID"] = 213602,
					["spellIDs"] = {
						[213602] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135994,
				},
				["凿击"] = {
					["enabled"] = true,
					["refSpellID"] = 1776,
					["spellIDs"] = {
						[1776] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132155,
				},
				["逃命专家"] = {
					["enabled"] = true,
					["refSpellID"] = 20589,
					["spellIDs"] = {
						[20589] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132309,
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["refSpellID"] = 191427,
					["spellIDs"] = {
						[191427] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1247262,
				},
				["圣疗术"] = {
					["enabled"] = true,
					["refSpellID"] = 633,
					["spellIDs"] = {
						[633] = true,
					},
					["cooldown"] = 600,
					["texture"] = 135928,
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 210256,
					["spellIDs"] = {
						[210256] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135911,
				},
				["自由祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1044,
					["spellIDs"] = {
						[1044] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135968,
				},
				["散魔功"] = {
					["enabled"] = true,
					["refSpellID"] = 122783,
					["spellIDs"] = {
						[122783] = true,
					},
					["cooldown"] = 90,
					["texture"] = 775460,
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["refSpellID"] = 33697,
					["spellIDs"] = {
						[33697] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135726,
				},
				["复生"] = {
					["enabled"] = true,
					["refSpellID"] = 20484,
					["spellIDs"] = {
						[20484] = true,
					},
					["cooldown"] = 600,
					["texture"] = 136080,
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["refSpellID"] = 102560,
					["spellIDs"] = {
						[102560] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 204018,
					["spellIDs"] = {
						[204018] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135880,
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 207399,
					["spellIDs"] = {
						[207399] = true,
					},
					["cooldown"] = 300,
					["texture"] = 136080,
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157997,
					["spellIDs"] = {
						[157997] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033909,
				},
				["消失"] = {
					["enabled"] = true,
					["refSpellID"] = 1856,
					["spellIDs"] = {
						[1856] = true,
					},
					["cooldown"] = 75,
					["texture"] = 132331,
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["refSpellID"] = 47528,
					["spellIDs"] = {
						[47528] = true,
					},
					["cooldown"] = 15,
					["texture"] = 237527,
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["refSpellID"] = 12975,
					["spellIDs"] = {
						[12975] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135871,
				},
				["盾墙"] = {
					["enabled"] = true,
					["refSpellID"] = 871,
					["spellIDs"] = {
						[871] = true,
					},
					["cooldown"] = 240,
					["texture"] = 132362,
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["refSpellID"] = 19574,
					["spellIDs"] = {
						[19574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132127,
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["refSpellID"] = 186387,
					["spellIDs"] = {
						[186387] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1376038,
				},
				["龙息术"] = {
					["enabled"] = true,
					["refSpellID"] = 31661,
					["spellIDs"] = {
						[31661] = true,
					},
					["cooldown"] = 20,
					["texture"] = 134153,
				},
				["天神下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 107574,
					["spellIDs"] = {
						[107574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 613534,
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["refSpellID"] = 5246,
					["spellIDs"] = {
						[5246] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132154,
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["refSpellID"] = 115078,
					["spellIDs"] = {
						[115078] = true,
					},
					["cooldown"] = 15,
					["texture"] = 629534,
				},
				["元素宗师"] = {
					["enabled"] = true,
					["refSpellID"] = 16166,
					["spellIDs"] = {
						[16166] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136027,
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["refSpellID"] = 51533,
					["spellIDs"] = {
						[51533] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237577,
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 51490,
					["spellIDs"] = {
						[51490] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237589,
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["refSpellID"] = 88625,
					["spellIDs"] = {
						[88625] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135886,
				},
				["胁迫"] = {
					["enabled"] = true,
					["refSpellID"] = 19577,
					["spellIDs"] = {
						[19577] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132111,
				},
				["风火雷电"] = {
					["enabled"] = true,
					["refSpellID"] = 137639,
					["spellIDs"] = {
						[137639] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136038,
				},
				["星界转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108271,
					["spellIDs"] = {
						[108271] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538565,
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 6940,
					["spellIDs"] = {
						[6940] = true,
					},
					["cooldown"] = 75,
					["texture"] = 135966,
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["refSpellID"] = 31687,
					["spellIDs"] = {
						[31687] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135862,
				},
				["宿敌"] = {
					["enabled"] = true,
					["refSpellID"] = 79140,
					["spellIDs"] = {
						[79140] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458726,
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["refSpellID"] = 202370,
					["spellIDs"] = {
						[202370] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1381297,
				},
				["斗转星移"] = {
					["enabled"] = true,
					["refSpellID"] = 202162,
					["spellIDs"] = {
						[202162] = true,
					},
					["cooldown"] = 45,
					["texture"] = 620829,
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 86659,
					["spellIDs"] = {
						[86659] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135919,
				},
				["不灭决心"] = {
					["enabled"] = true,
					["refSpellID"] = 104773,
					["spellIDs"] = {
						[104773] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136150,
				},
				["反制射击"] = {
					["enabled"] = true,
					["refSpellID"] = 147362,
					["spellIDs"] = {
						[147362] = true,
					},
					["cooldown"] = 24,
					["texture"] = 249170,
				},
				["灵体形态"] = {
					["enabled"] = true,
					["refSpellID"] = 210918,
					["spellIDs"] = {
						[210918] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237572,
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 73325,
					["spellIDs"] = {
						[73325] = true,
					},
					["cooldown"] = 45,
					["texture"] = 463835,
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["refSpellID"] = 102793,
					["spellIDs"] = {
						[102793] = true,
					},
					["cooldown"] = 60,
					["texture"] = 571588,
				},
				["英勇"] = {
					["enabled"] = true,
					["refSpellID"] = 32182,
					["spellIDs"] = {
						[32182] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132313,
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["refSpellID"] = 108416,
					["spellIDs"] = {
						[108416] = true,
					},
					["cooldown"] = 60,
					["texture"] = 538538,
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["refSpellID"] = 152173,
					["spellIDs"] = {
						[152173] = true,
					},
					["cooldown"] = 90,
					["texture"] = 988197,
				},
				["守护之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 47788,
					["spellIDs"] = {
						[47788] = true,
					},
					["cooldown"] = 60,
					["texture"] = 237542,
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["refSpellID"] = 48020,
					["spellIDs"] = {
						[48020] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237560,
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["refSpellID"] = 205630,
					["spellIDs"] = {
						[205630] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380367,
				},
				["妖术"] = {
					["enabled"] = true,
					["refSpellID"] = 51514,
					["spellIDs"] = {
						[51514] = true,
					},
					["cooldown"] = 10,
					["texture"] = 237579,
				},
				["摧心魔"] = {
					["enabled"] = true,
					["refSpellID"] = 123040,
					["spellIDs"] = {
						[123040] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["瓦解"] = {
					["enabled"] = true,
					["refSpellID"] = 183752,
					["spellIDs"] = {
						[183752] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1305153,
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["refSpellID"] = 12472,
					["spellIDs"] = {
						[12472] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135838,
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["refSpellID"] = 209789,
					["spellIDs"] = {
						[209789] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1033903,
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 102359,
					["spellIDs"] = {
						[102359] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538515,
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 30283,
					["spellIDs"] = {
						[30283] = true,
					},
					["cooldown"] = 30,
					["texture"] = 607865,
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["refSpellID"] = 207319,
					["spellIDs"] = {
						[207319] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1531513,
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["refSpellID"] = 31850,
					["spellIDs"] = {
						[31850] = true,
					},
					["cooldown"] = 110,
					["texture"] = 135870,
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["refSpellID"] = 201325,
					["spellIDs"] = {
						[201325] = true,
					},
					["cooldown"] = 180,
					["texture"] = 642417,
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["refSpellID"] = 69041,
					["spellIDs"] = {
						[69041] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133032,
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["refSpellID"] = 77606,
					["spellIDs"] = {
						[77606] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135888,
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["refSpellID"] = 108201,
					["spellIDs"] = {
						[108201] = true,
					},
					["cooldown"] = 120,
					["texture"] = 538768,
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["refSpellID"] = 33206,
					["spellIDs"] = {
						[33206] = true,
					},
					["cooldown"] = 210,
					["texture"] = 135936,
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["refSpellID"] = 19236,
					["spellIDs"] = {
						[19236] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237550,
				},
				["肾击"] = {
					["enabled"] = true,
					["refSpellID"] = 408,
					["spellIDs"] = {
						[408] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132298,
				},
				["奥术强化"] = {
					["enabled"] = true,
					["refSpellID"] = 12042,
					["spellIDs"] = {
						[12042] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136048,
				},
				["致盲"] = {
					["enabled"] = true,
					["refSpellID"] = 2094,
					["spellIDs"] = {
						[2094] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136175,
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["refSpellID"] = 187650,
					["spellIDs"] = {
						[187650] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135834,
				},
				["正中眉心"] = {
					["enabled"] = true,
					["refSpellID"] = 199804,
					["spellIDs"] = {
						[199804] = true,
					},
					["cooldown"] = 20,
					["texture"] = 135610,
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["refSpellID"] = 79206,
					["spellIDs"] = {
						[79206] = true,
					},
					["cooldown"] = 60,
					["texture"] = 451170,
				},
				["牺牲"] = {
					["enabled"] = true,
					["refSpellID"] = 7812,
					["spellIDs"] = {
						[7812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136190,
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["refSpellID"] = 228049,
					["spellIDs"] = {
						[228049] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135919,
				},
				["闪回"] = {
					["enabled"] = true,
					["refSpellID"] = 195676,
					["spellIDs"] = {
						[195676] = true,
					},
					["cooldown"] = 24,
					["texture"] = 132171,
				},
				["台风"] = {
					["enabled"] = true,
					["refSpellID"] = 132469,
					["spellIDs"] = {
						[132469] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236170,
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["refSpellID"] = 198898,
					["spellIDs"] = {
						[198898] = true,
					},
					["cooldown"] = 15,
					["texture"] = 332402,
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["refSpellID"] = 84714,
					["spellIDs"] = {
						[84714] = true,
					},
					["cooldown"] = 60,
					["texture"] = 629077,
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["refSpellID"] = 216331,
					["spellIDs"] = {
						[216331] = true,
					},
					["cooldown"] = 60,
					["texture"] = 589117,
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["refSpellID"] = 188501,
					["spellIDs"] = {
						[188501] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1247266,
				},
				["日光术"] = {
					["enabled"] = true,
					["refSpellID"] = 78675,
					["spellIDs"] = {
						[78675] = true,
					},
					["cooldown"] = 30,
					["texture"] = 252188,
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["refSpellID"] = 208253,
					["spellIDs"] = {
						[208253] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1115592,
				},
				["幻影打击"] = {
					["enabled"] = true,
					["refSpellID"] = 196718,
					["spellIDs"] = {
						[196718] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1305154,
				},
				["隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 66,
					["spellIDs"] = {
						[66] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132220,
				},
				["真言术：障"] = {
					["enabled"] = true,
					["refSpellID"] = 62618,
					["spellIDs"] = {
						[62618] = true,
					},
					["cooldown"] = 120,
					["texture"] = 253400,
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["refSpellID"] = 106839,
					["spellIDs"] = {
						[106839] = true,
					},
					["cooldown"] = 15,
					["texture"] = 236946,
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["refSpellID"] = 102543,
					["spellIDs"] = {
						[102543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["战争践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 11876,
					["spellIDs"] = {
						[11876] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132091,
				},
				["割碎"] = {
					["enabled"] = true,
					["refSpellID"] = 22570,
					["spellIDs"] = {
						[22570] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132134,
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["refSpellID"] = 105809,
					["spellIDs"] = {
						[105809] = true,
					},
					["cooldown"] = 90,
					["texture"] = 571555,
				},
				["束缚射击"] = {
					["enabled"] = true,
					["refSpellID"] = 109248,
					["spellIDs"] = {
						[109248] = true,
					},
					["cooldown"] = 45,
					["texture"] = 462650,
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 107570,
					["spellIDs"] = {
						[107570] = true,
					},
					["cooldown"] = 30,
					["texture"] = 613535,
				},
				["疾影"] = {
					["enabled"] = true,
					["refSpellID"] = 198589,
					["spellIDs"] = {
						[198589] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1305150,
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 6544,
					["spellIDs"] = {
						[6544] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236171,
				},
				["还魂术"] = {
					["enabled"] = true,
					["refSpellID"] = 115310,
					["spellIDs"] = {
						[115310] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1020466,
				},
				["逃脱"] = {
					["enabled"] = true,
					["refSpellID"] = 781,
					["spellIDs"] = {
						[781] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132294,
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["refSpellID"] = 49206,
					["spellIDs"] = {
						[49206] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458967,
				},
				["血魔之握"] = {
					["enabled"] = true,
					["refSpellID"] = 108199,
					["spellIDs"] = {
						[108199] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538767,
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["refSpellID"] = 51271,
					["spellIDs"] = {
						[51271] = true,
					},
					["cooldown"] = 60,
					["texture"] = 458718,
				},
				["巨人打击"] = {
					["enabled"] = true,
					["refSpellID"] = 167105,
					["spellIDs"] = {
						[167105] = true,
					},
					["cooldown"] = 45,
					["texture"] = 464973,
				},
				["沉默"] = {
					["enabled"] = true,
					["refSpellID"] = 15487,
					["spellIDs"] = {
						[15487] = true,
					},
					["cooldown"] = 45,
					["texture"] = 458230,
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["refSpellID"] = 212182,
					["spellIDs"] = {
						[212182] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458733,
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["refSpellID"] = 205691,
					["spellIDs"] = {
						[205691] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1412204,
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["refSpellID"] = 190784,
					["spellIDs"] = {
						[190784] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1360759,
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["refSpellID"] = 68992,
					["spellIDs"] = {
						[68992] = true,
					},
					["cooldown"] = 120,
					["texture"] = 366937,
				},
				["业报之触"] = {
					["enabled"] = true,
					["refSpellID"] = 122470,
					["spellIDs"] = {
						[122470] = true,
					},
					["cooldown"] = 90,
					["texture"] = 651728,
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["refSpellID"] = 119996,
					["spellIDs"] = {
						[119996] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237585,
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["refSpellID"] = 5211,
					["spellIDs"] = {
						[5211] = true,
					},
					["cooldown"] = 50,
					["texture"] = 132114,
				},
				["影遁"] = {
					["enabled"] = true,
					["refSpellID"] = 58984,
					["spellIDs"] = {
						[58984] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132089,
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["refSpellID"] = 1122,
					["spellIDs"] = {
						[1122] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136219,
				},
				["闪光力场"] = {
					["enabled"] = true,
					["refSpellID"] = 204263,
					["spellIDs"] = {
						[204263] = true,
					},
					["cooldown"] = 45,
					["texture"] = 571554,
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["refSpellID"] = 212459,
					["spellIDs"] = {
						[212459] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1113433,
				},
			},
			["DBVersion"] = 8,
		},
		["Rainylone - 末日行者"] = {
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["refSpellID"] = 31230,
					["spellIDs"] = {
						[31230] = true,
					},
					["cooldown"] = 360,
					["texture"] = 132285,
				},
				["法术反制"] = {
					["enabled"] = true,
					["refSpellID"] = 2139,
					["spellIDs"] = {
						[2139] = true,
					},
					["cooldown"] = 24,
					["texture"] = 135856,
				},
				["天灾契约"] = {
					["enabled"] = true,
					["refSpellID"] = 48743,
					["spellIDs"] = {
						[48743] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136146,
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["refSpellID"] = 204437,
					["spellIDs"] = {
						[204437] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1385911,
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["refSpellID"] = 132578,
					["spellIDs"] = {
						[132578] = true,
					},
					["cooldown"] = 180,
					["texture"] = 608951,
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 206572,
					["spellIDs"] = {
						[206572] = true,
					},
					["cooldown"] = 20,
					["texture"] = 1380676,
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 215769,
					["spellIDs"] = {
						[215769] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132864,
				},
				["震荡波"] = {
					["enabled"] = true,
					["refSpellID"] = 46968,
					["spellIDs"] = {
						[46968] = true,
					},
					["cooldown"] = 40,
					["texture"] = 236312,
				},
				["谈判"] = {
					["enabled"] = true,
					["refSpellID"] = 199743,
					["spellIDs"] = {
						[199743] = true,
					},
					["cooldown"] = 20,
					["texture"] = 236448,
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 195710,
					["spellIDs"] = {
						[195710] = true,
					},
					["cooldown"] = 180,
					["texture"] = 338784,
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["refSpellID"] = 207167,
					["spellIDs"] = {
						[207167] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135836,
				},
				["超级新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157980,
					["spellIDs"] = {
						[157980] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033912,
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["refSpellID"] = 206650,
					["spellIDs"] = {
						[206650] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380366,
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["refSpellID"] = 48792,
					["spellIDs"] = {
						[48792] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237525,
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["refSpellID"] = 102558,
					["spellIDs"] = {
						[102558] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["死亡之握"] = {
					["enabled"] = true,
					["refSpellID"] = 49576,
					["spellIDs"] = {
						[49576] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237532,
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 853,
					["spellIDs"] = {
						[853] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135963,
				},
				["狂暴"] = {
					["enabled"] = true,
					["refSpellID"] = 26297,
					["spellIDs"] = {
						[26297] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135727,
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["refSpellID"] = 116849,
					["spellIDs"] = {
						[116849] = true,
					},
					["cooldown"] = 90,
					["texture"] = 627485,
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["refSpellID"] = 198817,
					["spellIDs"] = {
						[198817] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1380678,
				},
				["嗜血"] = {
					["enabled"] = true,
					["refSpellID"] = 2825,
					["spellIDs"] = {
						[2825] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136012,
				},
				["墓石"] = {
					["enabled"] = true,
					["refSpellID"] = 219809,
					["spellIDs"] = {
						[219809] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132151,
				},
				["电能图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 192058,
					["spellIDs"] = {
						[192058] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136013,
				},
				["影舞步"] = {
					["enabled"] = true,
					["refSpellID"] = 51690,
					["spellIDs"] = {
						[51690] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236277,
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["refSpellID"] = 108359,
					["spellIDs"] = {
						[108359] = true,
					},
					["cooldown"] = 120,
					["texture"] = 537516,
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["refSpellID"] = 102342,
					["spellIDs"] = {
						[102342] = true,
					},
					["cooldown"] = 90,
					["texture"] = 572025,
				},
				["亡者大军"] = {
					["enabled"] = true,
					["refSpellID"] = 42650,
					["spellIDs"] = {
						[42650] = true,
					},
					["cooldown"] = 600,
					["texture"] = 237511,
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["refSpellID"] = 198529,
					["spellIDs"] = {
						[198529] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133787,
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["refSpellID"] = 51052,
					["spellIDs"] = {
						[51052] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237510,
				},
				["消散"] = {
					["enabled"] = true,
					["refSpellID"] = 47585,
					["spellIDs"] = {
						[47585] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237563,
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["refSpellID"] = 122,
					["spellIDs"] = {
						[122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135848,
				},
				["轮回之触"] = {
					["enabled"] = true,
					["refSpellID"] = 115080,
					["spellIDs"] = {
						[115080] = true,
					},
					["cooldown"] = 60,
					["texture"] = 606552,
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["refSpellID"] = 48707,
					["spellIDs"] = {
						[48707] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136120,
				},
				["火焰石"] = {
					["enabled"] = true,
					["refSpellID"] = 212284,
					["spellIDs"] = {
						[212284] = true,
					},
					["cooldown"] = 45,
					["texture"] = 134085,
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["refSpellID"] = 196884,
					["spellIDs"] = {
						[196884] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1027879,
				},
				["鲁莽"] = {
					["enabled"] = true,
					["refSpellID"] = 1719,
					["spellIDs"] = {
						[1719] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458972,
				},
				["游侠之网"] = {
					["enabled"] = true,
					["refSpellID"] = 200108,
					["spellIDs"] = {
						[200108] = true,
					},
					["cooldown"] = 60,
					["texture"] = 134325,
				},
				["虚空联结"] = {
					["enabled"] = true,
					["refSpellID"] = 207810,
					["spellIDs"] = {
						[207810] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1450144,
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 5217,
					["spellIDs"] = {
						[5217] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132242,
				},
				["风剪"] = {
					["enabled"] = true,
					["refSpellID"] = 57994,
					["spellIDs"] = {
						[57994] = true,
					},
					["cooldown"] = 12,
					["texture"] = 136018,
				},
				["灭战者"] = {
					["enabled"] = true,
					["refSpellID"] = 262161,
					["spellIDs"] = {
						[262161] = true,
					},
					["cooldown"] = 45,
					["texture"] = 2065633,
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["refSpellID"] = 49028,
					["spellIDs"] = {
						[49028] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135277,
				},
				["石像形态"] = {
					["enabled"] = true,
					["refSpellID"] = 20594,
					["spellIDs"] = {
						[20594] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136225,
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["refSpellID"] = 201318,
					["spellIDs"] = {
						[201318] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1616072,
				},
				["压制"] = {
					["enabled"] = true,
					["refSpellID"] = 187707,
					["spellIDs"] = {
						[187707] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1376045,
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 110959,
					["spellIDs"] = {
						[110959] = true,
					},
					["cooldown"] = 75,
					["texture"] = 575584,
				},
				["剑在人在"] = {
					["enabled"] = true,
					["refSpellID"] = 118038,
					["spellIDs"] = {
						[118038] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132336,
				},
				["自利"] = {
					["enabled"] = true,
					["refSpellID"] = 59752,
					["spellIDs"] = {
						[59752] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136129,
				},
				["反击图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204331,
					["spellIDs"] = {
						[204331] = true,
					},
					["cooldown"] = 45,
					["texture"] = 511726,
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 207684,
					["spellIDs"] = {
						[207684] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418287,
				},
				["阵风"] = {
					["enabled"] = true,
					["refSpellID"] = 192063,
					["spellIDs"] = {
						[192063] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1029585,
				},
				["混乱新星"] = {
					["enabled"] = true,
					["refSpellID"] = 179057,
					["spellIDs"] = {
						[179057] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135795,
				},
				["切喉手"] = {
					["enabled"] = true,
					["refSpellID"] = 116705,
					["spellIDs"] = {
						[116705] = true,
					},
					["cooldown"] = 15,
					["texture"] = 608940,
				},
				["法术封锁"] = {
					["enabled"] = true,
					["refSpellID"] = 19647,
					["spellIDs"] = {
						[19647] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136174,
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["refSpellID"] = 115781,
					["spellIDs"] = {
						[115781] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136028,
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["refSpellID"] = 80483,
					["spellIDs"] = {
						[80483] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136222,
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["refSpellID"] = 11426,
					["spellIDs"] = {
						[11426] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135988,
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 204150,
					["spellIDs"] = {
						[204150] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135909,
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 89751,
					["spellIDs"] = {
						[89751] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236303,
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 6789,
					["spellIDs"] = {
						[6789] = true,
					},
					["cooldown"] = 45,
					["texture"] = 607853,
				},
				["生存本能"] = {
					["enabled"] = true,
					["refSpellID"] = 61336,
					["spellIDs"] = {
						[61336] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236169,
				},
				["闪避"] = {
					["enabled"] = true,
					["refSpellID"] = 5277,
					["spellIDs"] = {
						[5277] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136205,
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["refSpellID"] = 64843,
					["spellIDs"] = {
						[64843] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237540,
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["refSpellID"] = 201078,
					["spellIDs"] = {
						[201078] = true,
					},
					["cooldown"] = 120,
					["texture"] = 254647,
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186265,
					["spellIDs"] = {
						[186265] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132199,
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 31884,
					["spellIDs"] = {
						[31884] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135875,
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 91802,
					["spellIDs"] = {
						[91802] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237569,
				},
				["燃烧"] = {
					["enabled"] = true,
					["refSpellID"] = 190319,
					["spellIDs"] = {
						[190319] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135824,
				},
				["唤醒"] = {
					["enabled"] = true,
					["refSpellID"] = 12051,
					["spellIDs"] = {
						[12051] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136075,
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["refSpellID"] = 206491,
					["spellIDs"] = {
						[206491] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236299,
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["refSpellID"] = 42292,
					["spellIDs"] = {
						[42292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 200851,
					["spellIDs"] = {
						[200851] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1129695,
				},
				["法术反射"] = {
					["enabled"] = true,
					["refSpellID"] = 23920,
					["spellIDs"] = {
						[23920] = true,
					},
					["cooldown"] = 25,
					["texture"] = 132361,
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 123904,
					["spellIDs"] = {
						[123904] = true,
					},
					["cooldown"] = 180,
					["texture"] = 620832,
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["refSpellID"] = 45438,
					["spellIDs"] = {
						[45438] = true,
					},
					["cooldown"] = 240,
					["texture"] = 135841,
				},
				["时光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 198111,
					["spellIDs"] = {
						[198111] = true,
					},
					["cooldown"] = 45,
					["texture"] = 610472,
				},
				["脚踢"] = {
					["enabled"] = true,
					["refSpellID"] = 1766,
					["spellIDs"] = {
						[1766] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132219,
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 18499,
					["spellIDs"] = {
						[18499] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136009,
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202137,
					["spellIDs"] = {
						[202137] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418288,
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["refSpellID"] = 198664,
					["spellIDs"] = {
						[198664] = true,
					},
					["cooldown"] = 180,
					["texture"] = 877514,
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["refSpellID"] = 194223,
					["spellIDs"] = {
						[194223] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136060,
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 98008,
					["spellIDs"] = {
						[98008] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237586,
				},
				["拳击"] = {
					["enabled"] = true,
					["refSpellID"] = 6552,
					["spellIDs"] = {
						[6552] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132938,
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["refSpellID"] = 211881,
					["spellIDs"] = {
						[211881] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1118739,
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 51485,
					["spellIDs"] = {
						[51485] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136100,
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["refSpellID"] = 59543,
					["spellIDs"] = {
						[59543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135923,
				},
				["宁静"] = {
					["enabled"] = true,
					["refSpellID"] = 740,
					["spellIDs"] = {
						[740] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136107,
				},
				["急奔"] = {
					["enabled"] = true,
					["refSpellID"] = 1850,
					["spellIDs"] = {
						[1850] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132120,
				},
				["缴械"] = {
					["enabled"] = true,
					["refSpellID"] = 236077,
					["spellIDs"] = {
						[236077] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132343,
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 212295,
					["spellIDs"] = {
						[212295] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135796,
				},
				["自然之力"] = {
					["enabled"] = true,
					["refSpellID"] = 205636,
					["spellIDs"] = {
						[205636] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132129,
				},
				["根基图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204336,
					["spellIDs"] = {
						[204336] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136039,
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["refSpellID"] = 209749,
					["spellIDs"] = {
						[209749] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538516,
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["refSpellID"] = 184364,
					["spellIDs"] = {
						[184364] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132345,
				},
				["保护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1022,
					["spellIDs"] = {
						[1022] = true,
					},
					["cooldown"] = 135,
					["texture"] = 135964,
				},
				["血之镜像"] = {
					["enabled"] = true,
					["refSpellID"] = 206977,
					["spellIDs"] = {
						[206977] = true,
					},
					["cooldown"] = 120,
					["texture"] = 134084,
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 196932,
					["spellIDs"] = {
						[196932] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136232,
				},
				["平心之环"] = {
					["enabled"] = true,
					["refSpellID"] = 116844,
					["spellIDs"] = {
						[116844] = true,
					},
					["cooldown"] = 45,
					["texture"] = 839107,
				},
				["虚空转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108968,
					["spellIDs"] = {
						[108968] = true,
					},
					["cooldown"] = 300,
					["texture"] = 537079,
				},
				["急速冷却"] = {
					["enabled"] = true,
					["refSpellID"] = 235219,
					["spellIDs"] = {
						[235219] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135865,
				},
				["光环掌握"] = {
					["enabled"] = true,
					["refSpellID"] = 31821,
					["spellIDs"] = {
						[31821] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135872,
				},
				["火箭跳"] = {
					["enabled"] = true,
					["refSpellID"] = 69070,
					["spellIDs"] = {
						[69070] = true,
					},
					["cooldown"] = 120,
					["texture"] = 370769,
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["refSpellID"] = 19386,
					["spellIDs"] = {
						[19386] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135125,
				},
				["伪装"] = {
					["enabled"] = true,
					["refSpellID"] = 199483,
					["spellIDs"] = {
						[199483] = true,
					},
					["cooldown"] = 60,
					["texture"] = 461113,
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186289,
					["spellIDs"] = {
						[186289] = true,
					},
					["cooldown"] = 120,
					["texture"] = 612363,
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["refSpellID"] = 63560,
					["spellIDs"] = {
						[63560] = true,
					},
					["cooldown"] = 60,
					["texture"] = 342913,
				},
				["抓钩"] = {
					["enabled"] = true,
					["refSpellID"] = 195457,
					["spellIDs"] = {
						[195457] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1373906,
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["refSpellID"] = 205369,
					["spellIDs"] = {
						[205369] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136173,
				},
				["圣佑术"] = {
					["enabled"] = true,
					["refSpellID"] = 498,
					["spellIDs"] = {
						[498] = true,
					},
					["cooldown"] = 60,
					["texture"] = 524353,
				},
				["禁锢"] = {
					["enabled"] = true,
					["refSpellID"] = 221527,
					["spellIDs"] = {
						[221527] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380368,
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["refSpellID"] = 207349,
					["spellIDs"] = {
						[207349] = true,
					},
					["cooldown"] = 120,
					["texture"] = 298674,
				},
				["责难"] = {
					["enabled"] = true,
					["refSpellID"] = 96231,
					["spellIDs"] = {
						[96231] = true,
					},
					["cooldown"] = 15,
					["texture"] = 523893,
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 202246,
					["spellIDs"] = {
						[202246] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1408833,
				},
				["冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 100,
					["spellIDs"] = {
						[100] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132337,
				},
				["意气风发"] = {
					["enabled"] = true,
					["refSpellID"] = 109304,
					["spellIDs"] = {
						[109304] = true,
					},
					["cooldown"] = 120,
					["texture"] = 461117,
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 205629,
					["spellIDs"] = {
						[205629] = true,
					},
					["cooldown"] = 30,
					["texture"] = 134294,
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 207736,
					["spellIDs"] = {
						[207736] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1020341,
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["refSpellID"] = 119381,
					["spellIDs"] = {
						[119381] = true,
					},
					["cooldown"] = 60,
					["texture"] = 642414,
				},
				["圣盾术"] = {
					["enabled"] = true,
					["refSpellID"] = 642,
					["spellIDs"] = {
						[642] = true,
					},
					["cooldown"] = 240,
					["texture"] = 524354,
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["refSpellID"] = 7744,
					["spellIDs"] = {
						[7744] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136187,
				},
				["虚空行走"] = {
					["enabled"] = true,
					["refSpellID"] = 196555,
					["spellIDs"] = {
						[196555] = true,
					},
					["cooldown"] = 120,
					["texture"] = 463284,
				},
				["战旗"] = {
					["enabled"] = true,
					["refSpellID"] = 236320,
					["spellIDs"] = {
						[236320] = true,
					},
					["cooldown"] = 90,
					["texture"] = 603532,
				},
				["还击"] = {
					["enabled"] = true,
					["refSpellID"] = 199754,
					["spellIDs"] = {
						[199754] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132269,
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 227847,
					["spellIDs"] = {
						[227847] = true,
					},
					["cooldown"] = 60,
					["texture"] = 236303,
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186257,
					["spellIDs"] = {
						[186257] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132242,
				},
				["甘霖"] = {
					["enabled"] = true,
					["refSpellID"] = 108238,
					["spellIDs"] = {
						[108238] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136059,
				},
				["决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 236273,
					["spellIDs"] = {
						[236273] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1455893,
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202138,
					["spellIDs"] = {
						[202138] = true,
					},
					["cooldown"] = 54,
					["texture"] = 1418286,
				},
				["百发百中"] = {
					["enabled"] = true,
					["refSpellID"] = 193526,
					["spellIDs"] = {
						[193526] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132329,
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["refSpellID"] = 31224,
					["spellIDs"] = {
						[31224] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136177,
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["refSpellID"] = 205191,
					["spellIDs"] = {
						[205191] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135986,
				},
				["群体反射"] = {
					["enabled"] = true,
					["refSpellID"] = 213915,
					["spellIDs"] = {
						[213915] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132358,
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["refSpellID"] = 53271,
					["spellIDs"] = {
						[53271] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236189,
				},
				["从天而降"] = {
					["enabled"] = true,
					["refSpellID"] = 206803,
					["spellIDs"] = {
						[206803] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380371,
				},
				["驱散射击"] = {
					["enabled"] = true,
					["refSpellID"] = 213691,
					["spellIDs"] = {
						[213691] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132153,
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 108280,
					["spellIDs"] = {
						[108280] = true,
					},
					["cooldown"] = 180,
					["texture"] = 538569,
				},
				["能量灌注"] = {
					["enabled"] = true,
					["refSpellID"] = 10060,
					["spellIDs"] = {
						[10060] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135939,
				},
				["窒息"] = {
					["enabled"] = true,
					["refSpellID"] = 47476,
					["spellIDs"] = {
						[47476] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136214,
				},
				["卸除武装"] = {
					["enabled"] = true,
					["refSpellID"] = 207777,
					["spellIDs"] = {
						[207777] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236272,
				},
				["升腾"] = {
					["enabled"] = true,
					["refSpellID"] = 114050,
					["spellIDs"] = {
						[114050] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135791,
				},
				["拦截"] = {
					["enabled"] = true,
					["refSpellID"] = 198304,
					["spellIDs"] = {
						[198304] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132365,
				},
				["闪现术"] = {
					["enabled"] = true,
					["refSpellID"] = 1953,
					["spellIDs"] = {
						[1953] = true,
					},
					["cooldown"] = 15,
					["texture"] = 135736,
				},
				["树皮术"] = {
					["enabled"] = true,
					["refSpellID"] = 22812,
					["spellIDs"] = {
						[22812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136097,
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["refSpellID"] = 5484,
					["spellIDs"] = {
						[5484] = true,
					},
					["cooldown"] = 40,
					["texture"] = 607852,
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["refSpellID"] = 89766,
					["spellIDs"] = {
						[89766] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236316,
				},
				["反转魔法"] = {
					["enabled"] = true,
					["refSpellID"] = 205604,
					["spellIDs"] = {
						[205604] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380372,
				},
				["火焰之息"] = {
					["enabled"] = true,
					["refSpellID"] = 115181,
					["spellIDs"] = {
						[115181] = true,
					},
					["cooldown"] = 15,
					["texture"] = 615339,
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["refSpellID"] = 216113,
					["spellIDs"] = {
						[216113] = true,
					},
					["cooldown"] = 45,
					["texture"] = 977169,
				},
				["疾跑"] = {
					["enabled"] = true,
					["refSpellID"] = 2983,
					["spellIDs"] = {
						[2983] = true,
					},
					["cooldown"] = 51,
					["texture"] = 132307,
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["refSpellID"] = 12292,
					["spellIDs"] = {
						[12292] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236304,
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["refSpellID"] = 64044,
					["spellIDs"] = {
						[64044] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237568,
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["refSpellID"] = 33891,
					["spellIDs"] = {
						[33891] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236157,
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["refSpellID"] = 115176,
					["spellIDs"] = {
						[115176] = true,
					},
					["cooldown"] = 150,
					["texture"] = 642417,
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["refSpellID"] = 121471,
					["spellIDs"] = {
						[121471] = true,
					},
					["cooldown"] = 180,
					["texture"] = 376022,
				},
				["冲动"] = {
					["enabled"] = true,
					["refSpellID"] = 13750,
					["spellIDs"] = {
						[13750] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136206,
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["refSpellID"] = 8122,
					["spellIDs"] = {
						[8122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136184,
				},
				["躯不坏"] = {
					["enabled"] = true,
					["refSpellID"] = 122278,
					["spellIDs"] = {
						[122278] = true,
					},
					["cooldown"] = 120,
					["texture"] = 620827,
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 208683,
					["spellIDs"] = {
						[208683] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["暗影步"] = {
					["enabled"] = true,
					["refSpellID"] = 36554,
					["spellIDs"] = {
						[36554] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132303,
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["refSpellID"] = 213602,
					["spellIDs"] = {
						[213602] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135994,
				},
				["凿击"] = {
					["enabled"] = true,
					["refSpellID"] = 1776,
					["spellIDs"] = {
						[1776] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132155,
				},
				["逃命专家"] = {
					["enabled"] = true,
					["refSpellID"] = 20589,
					["spellIDs"] = {
						[20589] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132309,
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["refSpellID"] = 191427,
					["spellIDs"] = {
						[191427] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1247262,
				},
				["圣疗术"] = {
					["enabled"] = true,
					["refSpellID"] = 633,
					["spellIDs"] = {
						[633] = true,
					},
					["cooldown"] = 600,
					["texture"] = 135928,
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 210256,
					["spellIDs"] = {
						[210256] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135911,
				},
				["自由祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1044,
					["spellIDs"] = {
						[1044] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135968,
				},
				["散魔功"] = {
					["enabled"] = true,
					["refSpellID"] = 122783,
					["spellIDs"] = {
						[122783] = true,
					},
					["cooldown"] = 90,
					["texture"] = 775460,
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["refSpellID"] = 33697,
					["spellIDs"] = {
						[33697] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135726,
				},
				["复生"] = {
					["enabled"] = true,
					["refSpellID"] = 20484,
					["spellIDs"] = {
						[20484] = true,
					},
					["cooldown"] = 600,
					["texture"] = 136080,
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["refSpellID"] = 102560,
					["spellIDs"] = {
						[102560] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 204018,
					["spellIDs"] = {
						[204018] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135880,
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 207399,
					["spellIDs"] = {
						[207399] = true,
					},
					["cooldown"] = 300,
					["texture"] = 136080,
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157997,
					["spellIDs"] = {
						[157997] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033909,
				},
				["消失"] = {
					["enabled"] = true,
					["refSpellID"] = 1856,
					["spellIDs"] = {
						[1856] = true,
					},
					["cooldown"] = 75,
					["texture"] = 132331,
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["refSpellID"] = 47528,
					["spellIDs"] = {
						[47528] = true,
					},
					["cooldown"] = 15,
					["texture"] = 237527,
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["refSpellID"] = 12975,
					["spellIDs"] = {
						[12975] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135871,
				},
				["盾墙"] = {
					["enabled"] = true,
					["refSpellID"] = 871,
					["spellIDs"] = {
						[871] = true,
					},
					["cooldown"] = 240,
					["texture"] = 132362,
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["refSpellID"] = 19574,
					["spellIDs"] = {
						[19574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132127,
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["refSpellID"] = 186387,
					["spellIDs"] = {
						[186387] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1376038,
				},
				["龙息术"] = {
					["enabled"] = true,
					["refSpellID"] = 31661,
					["spellIDs"] = {
						[31661] = true,
					},
					["cooldown"] = 20,
					["texture"] = 134153,
				},
				["天神下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 107574,
					["spellIDs"] = {
						[107574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 613534,
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["refSpellID"] = 5246,
					["spellIDs"] = {
						[5246] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132154,
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["refSpellID"] = 115078,
					["spellIDs"] = {
						[115078] = true,
					},
					["cooldown"] = 15,
					["texture"] = 629534,
				},
				["元素宗师"] = {
					["enabled"] = true,
					["refSpellID"] = 16166,
					["spellIDs"] = {
						[16166] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136027,
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["refSpellID"] = 51533,
					["spellIDs"] = {
						[51533] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237577,
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 51490,
					["spellIDs"] = {
						[51490] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237589,
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["refSpellID"] = 88625,
					["spellIDs"] = {
						[88625] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135886,
				},
				["胁迫"] = {
					["enabled"] = true,
					["refSpellID"] = 19577,
					["spellIDs"] = {
						[19577] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132111,
				},
				["风火雷电"] = {
					["enabled"] = true,
					["refSpellID"] = 137639,
					["spellIDs"] = {
						[137639] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136038,
				},
				["星界转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108271,
					["spellIDs"] = {
						[108271] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538565,
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 6940,
					["spellIDs"] = {
						[6940] = true,
					},
					["cooldown"] = 75,
					["texture"] = 135966,
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["refSpellID"] = 31687,
					["spellIDs"] = {
						[31687] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135862,
				},
				["宿敌"] = {
					["enabled"] = true,
					["refSpellID"] = 79140,
					["spellIDs"] = {
						[79140] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458726,
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["refSpellID"] = 202370,
					["spellIDs"] = {
						[202370] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1381297,
				},
				["斗转星移"] = {
					["enabled"] = true,
					["refSpellID"] = 202162,
					["spellIDs"] = {
						[202162] = true,
					},
					["cooldown"] = 45,
					["texture"] = 620829,
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 86659,
					["spellIDs"] = {
						[86659] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135919,
				},
				["不灭决心"] = {
					["enabled"] = true,
					["refSpellID"] = 104773,
					["spellIDs"] = {
						[104773] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136150,
				},
				["反制射击"] = {
					["enabled"] = true,
					["refSpellID"] = 147362,
					["spellIDs"] = {
						[147362] = true,
					},
					["cooldown"] = 24,
					["texture"] = 249170,
				},
				["灵体形态"] = {
					["enabled"] = true,
					["refSpellID"] = 210918,
					["spellIDs"] = {
						[210918] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237572,
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 73325,
					["spellIDs"] = {
						[73325] = true,
					},
					["cooldown"] = 45,
					["texture"] = 463835,
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["refSpellID"] = 102793,
					["spellIDs"] = {
						[102793] = true,
					},
					["cooldown"] = 60,
					["texture"] = 571588,
				},
				["英勇"] = {
					["enabled"] = true,
					["refSpellID"] = 32182,
					["spellIDs"] = {
						[32182] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132313,
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["refSpellID"] = 108416,
					["spellIDs"] = {
						[108416] = true,
					},
					["cooldown"] = 60,
					["texture"] = 538538,
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["refSpellID"] = 152173,
					["spellIDs"] = {
						[152173] = true,
					},
					["cooldown"] = 90,
					["texture"] = 988197,
				},
				["守护之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 47788,
					["spellIDs"] = {
						[47788] = true,
					},
					["cooldown"] = 60,
					["texture"] = 237542,
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["refSpellID"] = 48020,
					["spellIDs"] = {
						[48020] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237560,
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["refSpellID"] = 205630,
					["spellIDs"] = {
						[205630] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380367,
				},
				["妖术"] = {
					["enabled"] = true,
					["refSpellID"] = 51514,
					["spellIDs"] = {
						[51514] = true,
					},
					["cooldown"] = 10,
					["texture"] = 237579,
				},
				["摧心魔"] = {
					["enabled"] = true,
					["refSpellID"] = 123040,
					["spellIDs"] = {
						[123040] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["瓦解"] = {
					["enabled"] = true,
					["refSpellID"] = 183752,
					["spellIDs"] = {
						[183752] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1305153,
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["refSpellID"] = 12472,
					["spellIDs"] = {
						[12472] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135838,
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["refSpellID"] = 209789,
					["spellIDs"] = {
						[209789] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1033903,
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 102359,
					["spellIDs"] = {
						[102359] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538515,
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 30283,
					["spellIDs"] = {
						[30283] = true,
					},
					["cooldown"] = 30,
					["texture"] = 607865,
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["refSpellID"] = 207319,
					["spellIDs"] = {
						[207319] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1531513,
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["refSpellID"] = 77606,
					["spellIDs"] = {
						[77606] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135888,
				},
				["日光术"] = {
					["enabled"] = true,
					["refSpellID"] = 78675,
					["spellIDs"] = {
						[78675] = true,
					},
					["cooldown"] = 30,
					["texture"] = 252188,
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["refSpellID"] = 69041,
					["spellIDs"] = {
						[69041] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133032,
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["refSpellID"] = 31850,
					["spellIDs"] = {
						[31850] = true,
					},
					["cooldown"] = 110,
					["texture"] = 135870,
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["refSpellID"] = 108201,
					["spellIDs"] = {
						[108201] = true,
					},
					["cooldown"] = 120,
					["texture"] = 538768,
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["refSpellID"] = 33206,
					["spellIDs"] = {
						[33206] = true,
					},
					["cooldown"] = 210,
					["texture"] = 135936,
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["refSpellID"] = 19236,
					["spellIDs"] = {
						[19236] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237550,
				},
				["肾击"] = {
					["enabled"] = true,
					["refSpellID"] = 408,
					["spellIDs"] = {
						[408] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132298,
				},
				["奥术强化"] = {
					["enabled"] = true,
					["refSpellID"] = 12042,
					["spellIDs"] = {
						[12042] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136048,
				},
				["致盲"] = {
					["enabled"] = true,
					["refSpellID"] = 2094,
					["spellIDs"] = {
						[2094] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136175,
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["refSpellID"] = 187650,
					["spellIDs"] = {
						[187650] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135834,
				},
				["正中眉心"] = {
					["enabled"] = true,
					["refSpellID"] = 199804,
					["spellIDs"] = {
						[199804] = true,
					},
					["cooldown"] = 20,
					["texture"] = 135610,
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["refSpellID"] = 79206,
					["spellIDs"] = {
						[79206] = true,
					},
					["cooldown"] = 60,
					["texture"] = 451170,
				},
				["牺牲"] = {
					["enabled"] = true,
					["refSpellID"] = 7812,
					["spellIDs"] = {
						[7812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136190,
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["refSpellID"] = 228049,
					["spellIDs"] = {
						[228049] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135919,
				},
				["闪回"] = {
					["enabled"] = true,
					["refSpellID"] = 195676,
					["spellIDs"] = {
						[195676] = true,
					},
					["cooldown"] = 24,
					["texture"] = 132171,
				},
				["台风"] = {
					["enabled"] = true,
					["refSpellID"] = 132469,
					["spellIDs"] = {
						[132469] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236170,
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["refSpellID"] = 198898,
					["spellIDs"] = {
						[198898] = true,
					},
					["cooldown"] = 15,
					["texture"] = 332402,
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["refSpellID"] = 84714,
					["spellIDs"] = {
						[84714] = true,
					},
					["cooldown"] = 60,
					["texture"] = 629077,
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["refSpellID"] = 216331,
					["spellIDs"] = {
						[216331] = true,
					},
					["cooldown"] = 60,
					["texture"] = 589117,
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["refSpellID"] = 188501,
					["spellIDs"] = {
						[188501] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1247266,
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["refSpellID"] = 201325,
					["spellIDs"] = {
						[201325] = true,
					},
					["cooldown"] = 180,
					["texture"] = 642417,
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["refSpellID"] = 208253,
					["spellIDs"] = {
						[208253] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1115592,
				},
				["幻影打击"] = {
					["enabled"] = true,
					["refSpellID"] = 196718,
					["spellIDs"] = {
						[196718] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1305154,
				},
				["隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 66,
					["spellIDs"] = {
						[66] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132220,
				},
				["真言术：障"] = {
					["enabled"] = true,
					["refSpellID"] = 62618,
					["spellIDs"] = {
						[62618] = true,
					},
					["cooldown"] = 120,
					["texture"] = 253400,
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["refSpellID"] = 106839,
					["spellIDs"] = {
						[106839] = true,
					},
					["cooldown"] = 15,
					["texture"] = 236946,
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["refSpellID"] = 102543,
					["spellIDs"] = {
						[102543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["战争践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 11876,
					["spellIDs"] = {
						[11876] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132091,
				},
				["割碎"] = {
					["enabled"] = true,
					["refSpellID"] = 22570,
					["spellIDs"] = {
						[22570] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132134,
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["refSpellID"] = 105809,
					["spellIDs"] = {
						[105809] = true,
					},
					["cooldown"] = 90,
					["texture"] = 571555,
				},
				["束缚射击"] = {
					["enabled"] = true,
					["refSpellID"] = 109248,
					["spellIDs"] = {
						[109248] = true,
					},
					["cooldown"] = 45,
					["texture"] = 462650,
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 107570,
					["spellIDs"] = {
						[107570] = true,
					},
					["cooldown"] = 30,
					["texture"] = 613535,
				},
				["疾影"] = {
					["enabled"] = true,
					["refSpellID"] = 198589,
					["spellIDs"] = {
						[198589] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1305150,
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 6544,
					["spellIDs"] = {
						[6544] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236171,
				},
				["还魂术"] = {
					["enabled"] = true,
					["refSpellID"] = 115310,
					["spellIDs"] = {
						[115310] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1020466,
				},
				["逃脱"] = {
					["enabled"] = true,
					["refSpellID"] = 781,
					["spellIDs"] = {
						[781] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132294,
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["refSpellID"] = 49206,
					["spellIDs"] = {
						[49206] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458967,
				},
				["血魔之握"] = {
					["enabled"] = true,
					["refSpellID"] = 108199,
					["spellIDs"] = {
						[108199] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538767,
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["refSpellID"] = 51271,
					["spellIDs"] = {
						[51271] = true,
					},
					["cooldown"] = 60,
					["texture"] = 458718,
				},
				["巨人打击"] = {
					["enabled"] = true,
					["refSpellID"] = 167105,
					["spellIDs"] = {
						[167105] = true,
					},
					["cooldown"] = 45,
					["texture"] = 464973,
				},
				["沉默"] = {
					["enabled"] = true,
					["refSpellID"] = 15487,
					["spellIDs"] = {
						[15487] = true,
					},
					["cooldown"] = 45,
					["texture"] = 458230,
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["refSpellID"] = 212182,
					["spellIDs"] = {
						[212182] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458733,
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["refSpellID"] = 205691,
					["spellIDs"] = {
						[205691] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1412204,
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["refSpellID"] = 190784,
					["spellIDs"] = {
						[190784] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1360759,
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["refSpellID"] = 68992,
					["spellIDs"] = {
						[68992] = true,
					},
					["cooldown"] = 120,
					["texture"] = 366937,
				},
				["业报之触"] = {
					["enabled"] = true,
					["refSpellID"] = 122470,
					["spellIDs"] = {
						[122470] = true,
					},
					["cooldown"] = 90,
					["texture"] = 651728,
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["refSpellID"] = 119996,
					["spellIDs"] = {
						[119996] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237585,
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["refSpellID"] = 5211,
					["spellIDs"] = {
						[5211] = true,
					},
					["cooldown"] = 50,
					["texture"] = 132114,
				},
				["影遁"] = {
					["enabled"] = true,
					["refSpellID"] = 58984,
					["spellIDs"] = {
						[58984] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132089,
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["refSpellID"] = 1122,
					["spellIDs"] = {
						[1122] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136219,
				},
				["闪光力场"] = {
					["enabled"] = true,
					["refSpellID"] = 204263,
					["spellIDs"] = {
						[204263] = true,
					},
					["cooldown"] = 45,
					["texture"] = 571554,
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["refSpellID"] = 212459,
					["spellIDs"] = {
						[212459] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1113433,
				},
			},
			["DBVersion"] = 8,
		},
		["你诺 - 索瑞森"] = {
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["refSpellID"] = 31230,
					["spellIDs"] = {
						[31230] = true,
					},
					["cooldown"] = 360,
					["texture"] = 132285,
				},
				["法术反制"] = {
					["enabled"] = true,
					["refSpellID"] = 2139,
					["spellIDs"] = {
						[2139] = true,
					},
					["cooldown"] = 24,
					["texture"] = 135856,
				},
				["天灾契约"] = {
					["enabled"] = true,
					["refSpellID"] = 48743,
					["spellIDs"] = {
						[48743] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136146,
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["refSpellID"] = 204437,
					["spellIDs"] = {
						[204437] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1385911,
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["refSpellID"] = 132578,
					["spellIDs"] = {
						[132578] = true,
					},
					["cooldown"] = 180,
					["texture"] = 608951,
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 206572,
					["spellIDs"] = {
						[206572] = true,
					},
					["cooldown"] = 20,
					["texture"] = 1380676,
				},
				["巨人打击"] = {
					["enabled"] = true,
					["refSpellID"] = 167105,
					["spellIDs"] = {
						[167105] = true,
					},
					["cooldown"] = 45,
					["texture"] = 464973,
				},
				["震荡波"] = {
					["enabled"] = true,
					["refSpellID"] = 46968,
					["spellIDs"] = {
						[46968] = true,
					},
					["cooldown"] = 40,
					["texture"] = 236312,
				},
				["谈判"] = {
					["enabled"] = true,
					["refSpellID"] = 199743,
					["spellIDs"] = {
						[199743] = true,
					},
					["cooldown"] = 20,
					["texture"] = 236448,
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 195710,
					["spellIDs"] = {
						[195710] = true,
					},
					["cooldown"] = 180,
					["texture"] = 338784,
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["refSpellID"] = 207167,
					["spellIDs"] = {
						[207167] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135836,
				},
				["超级新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157980,
					["spellIDs"] = {
						[157980] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033912,
				},
				["闪光力场"] = {
					["enabled"] = true,
					["refSpellID"] = 204263,
					["spellIDs"] = {
						[204263] = true,
					},
					["cooldown"] = 45,
					["texture"] = 571554,
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["refSpellID"] = 48792,
					["spellIDs"] = {
						[48792] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237525,
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["refSpellID"] = 102558,
					["spellIDs"] = {
						[102558] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["死亡之握"] = {
					["enabled"] = true,
					["refSpellID"] = 49576,
					["spellIDs"] = {
						[49576] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237532,
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 853,
					["spellIDs"] = {
						[853] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135963,
				},
				["狂暴"] = {
					["enabled"] = true,
					["refSpellID"] = 26297,
					["spellIDs"] = {
						[26297] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135727,
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["refSpellID"] = 116849,
					["spellIDs"] = {
						[116849] = true,
					},
					["cooldown"] = 90,
					["texture"] = 627485,
				},
				["还魂术"] = {
					["enabled"] = true,
					["refSpellID"] = 115310,
					["spellIDs"] = {
						[115310] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1020466,
				},
				["嗜血"] = {
					["enabled"] = true,
					["refSpellID"] = 2825,
					["spellIDs"] = {
						[2825] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136012,
				},
				["墓石"] = {
					["enabled"] = true,
					["refSpellID"] = 219809,
					["spellIDs"] = {
						[219809] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132151,
				},
				["电能图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 192058,
					["spellIDs"] = {
						[192058] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136013,
				},
				["影舞步"] = {
					["enabled"] = true,
					["refSpellID"] = 51690,
					["spellIDs"] = {
						[51690] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236277,
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["refSpellID"] = 108359,
					["spellIDs"] = {
						[108359] = true,
					},
					["cooldown"] = 120,
					["texture"] = 537516,
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["refSpellID"] = 102342,
					["spellIDs"] = {
						[102342] = true,
					},
					["cooldown"] = 90,
					["texture"] = 572025,
				},
				["亡者大军"] = {
					["enabled"] = true,
					["refSpellID"] = 42650,
					["spellIDs"] = {
						[42650] = true,
					},
					["cooldown"] = 600,
					["texture"] = 237511,
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["refSpellID"] = 198529,
					["spellIDs"] = {
						[198529] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133787,
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["refSpellID"] = 51052,
					["spellIDs"] = {
						[51052] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237510,
				},
				["消散"] = {
					["enabled"] = true,
					["refSpellID"] = 47585,
					["spellIDs"] = {
						[47585] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237563,
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["refSpellID"] = 122,
					["spellIDs"] = {
						[122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135848,
				},
				["轮回之触"] = {
					["enabled"] = true,
					["refSpellID"] = 115080,
					["spellIDs"] = {
						[115080] = true,
					},
					["cooldown"] = 60,
					["texture"] = 606552,
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["refSpellID"] = 48707,
					["spellIDs"] = {
						[48707] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136120,
				},
				["火焰石"] = {
					["enabled"] = true,
					["refSpellID"] = 212284,
					["spellIDs"] = {
						[212284] = true,
					},
					["cooldown"] = 45,
					["texture"] = 134085,
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["refSpellID"] = 196884,
					["spellIDs"] = {
						[196884] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1027879,
				},
				["鲁莽"] = {
					["enabled"] = true,
					["refSpellID"] = 1719,
					["spellIDs"] = {
						[1719] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458972,
				},
				["游侠之网"] = {
					["enabled"] = true,
					["refSpellID"] = 200108,
					["spellIDs"] = {
						[200108] = true,
					},
					["cooldown"] = 60,
					["texture"] = 134325,
				},
				["虚空联结"] = {
					["enabled"] = true,
					["refSpellID"] = 207810,
					["spellIDs"] = {
						[207810] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1450144,
				},
				["摧心魔"] = {
					["enabled"] = true,
					["refSpellID"] = 123040,
					["spellIDs"] = {
						[123040] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["风剪"] = {
					["enabled"] = true,
					["refSpellID"] = 57994,
					["spellIDs"] = {
						[57994] = true,
					},
					["cooldown"] = 12,
					["texture"] = 136018,
				},
				["灭战者"] = {
					["enabled"] = true,
					["refSpellID"] = 262161,
					["spellIDs"] = {
						[262161] = true,
					},
					["cooldown"] = 45,
					["texture"] = 2065633,
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["refSpellID"] = 49028,
					["spellIDs"] = {
						[49028] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135277,
				},
				["石像形态"] = {
					["enabled"] = true,
					["refSpellID"] = 20594,
					["spellIDs"] = {
						[20594] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136225,
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["refSpellID"] = 201318,
					["spellIDs"] = {
						[201318] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1616072,
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 30283,
					["spellIDs"] = {
						[30283] = true,
					},
					["cooldown"] = 30,
					["texture"] = 607865,
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 110959,
					["spellIDs"] = {
						[110959] = true,
					},
					["cooldown"] = 75,
					["texture"] = 575584,
				},
				["剑在人在"] = {
					["enabled"] = true,
					["refSpellID"] = 118038,
					["spellIDs"] = {
						[118038] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132336,
				},
				["自利"] = {
					["enabled"] = true,
					["refSpellID"] = 59752,
					["spellIDs"] = {
						[59752] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136129,
				},
				["反击图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204331,
					["spellIDs"] = {
						[204331] = true,
					},
					["cooldown"] = 45,
					["texture"] = 511726,
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 207684,
					["spellIDs"] = {
						[207684] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418287,
				},
				["阵风"] = {
					["enabled"] = true,
					["refSpellID"] = 192063,
					["spellIDs"] = {
						[192063] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1029585,
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["refSpellID"] = 115078,
					["spellIDs"] = {
						[115078] = true,
					},
					["cooldown"] = 15,
					["texture"] = 629534,
				},
				["切喉手"] = {
					["enabled"] = true,
					["refSpellID"] = 116705,
					["spellIDs"] = {
						[116705] = true,
					},
					["cooldown"] = 15,
					["texture"] = 608940,
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["refSpellID"] = 102560,
					["spellIDs"] = {
						[102560] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["refSpellID"] = 115781,
					["spellIDs"] = {
						[115781] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136028,
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["refSpellID"] = 80483,
					["spellIDs"] = {
						[80483] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136222,
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["refSpellID"] = 11426,
					["spellIDs"] = {
						[11426] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135988,
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 204150,
					["spellIDs"] = {
						[204150] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135909,
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 89751,
					["spellIDs"] = {
						[89751] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236303,
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 6789,
					["spellIDs"] = {
						[6789] = true,
					},
					["cooldown"] = 45,
					["texture"] = 607853,
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["refSpellID"] = 105809,
					["spellIDs"] = {
						[105809] = true,
					},
					["cooldown"] = 90,
					["texture"] = 571555,
				},
				["闪避"] = {
					["enabled"] = true,
					["refSpellID"] = 5277,
					["spellIDs"] = {
						[5277] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136205,
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["refSpellID"] = 190784,
					["spellIDs"] = {
						[190784] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1360759,
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["refSpellID"] = 201078,
					["spellIDs"] = {
						[201078] = true,
					},
					["cooldown"] = 120,
					["texture"] = 254647,
				},
				["天神下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 107574,
					["spellIDs"] = {
						[107574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 613534,
				},
				["复生"] = {
					["enabled"] = true,
					["refSpellID"] = 20484,
					["spellIDs"] = {
						[20484] = true,
					},
					["cooldown"] = 600,
					["texture"] = 136080,
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 91802,
					["spellIDs"] = {
						[91802] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237569,
				},
				["燃烧"] = {
					["enabled"] = true,
					["refSpellID"] = 190319,
					["spellIDs"] = {
						[190319] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135824,
				},
				["唤醒"] = {
					["enabled"] = true,
					["refSpellID"] = 12051,
					["spellIDs"] = {
						[12051] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136075,
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["refSpellID"] = 206491,
					["spellIDs"] = {
						[206491] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236299,
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["refSpellID"] = 42292,
					["spellIDs"] = {
						[42292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 200851,
					["spellIDs"] = {
						[200851] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1129695,
				},
				["法术反射"] = {
					["enabled"] = true,
					["refSpellID"] = 23920,
					["spellIDs"] = {
						[23920] = true,
					},
					["cooldown"] = 25,
					["texture"] = 132361,
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 123904,
					["spellIDs"] = {
						[123904] = true,
					},
					["cooldown"] = 180,
					["texture"] = 620832,
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["refSpellID"] = 45438,
					["spellIDs"] = {
						[45438] = true,
					},
					["cooldown"] = 240,
					["texture"] = 135841,
				},
				["时光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 198111,
					["spellIDs"] = {
						[198111] = true,
					},
					["cooldown"] = 45,
					["texture"] = 610472,
				},
				["脚踢"] = {
					["enabled"] = true,
					["refSpellID"] = 1766,
					["spellIDs"] = {
						[1766] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132219,
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 18499,
					["spellIDs"] = {
						[18499] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136009,
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202137,
					["spellIDs"] = {
						[202137] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418288,
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["refSpellID"] = 198664,
					["spellIDs"] = {
						[198664] = true,
					},
					["cooldown"] = 180,
					["texture"] = 877514,
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["refSpellID"] = 194223,
					["spellIDs"] = {
						[194223] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136060,
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 98008,
					["spellIDs"] = {
						[98008] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237586,
				},
				["拳击"] = {
					["enabled"] = true,
					["refSpellID"] = 6552,
					["spellIDs"] = {
						[6552] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132938,
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["refSpellID"] = 211881,
					["spellIDs"] = {
						[211881] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1118739,
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 51485,
					["spellIDs"] = {
						[51485] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136100,
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["refSpellID"] = 59543,
					["spellIDs"] = {
						[59543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135923,
				},
				["宁静"] = {
					["enabled"] = true,
					["refSpellID"] = 740,
					["spellIDs"] = {
						[740] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136107,
				},
				["急奔"] = {
					["enabled"] = true,
					["refSpellID"] = 1850,
					["spellIDs"] = {
						[1850] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132120,
				},
				["缴械"] = {
					["enabled"] = true,
					["refSpellID"] = 236077,
					["spellIDs"] = {
						[236077] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132343,
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 212295,
					["spellIDs"] = {
						[212295] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135796,
				},
				["自然之力"] = {
					["enabled"] = true,
					["refSpellID"] = 205636,
					["spellIDs"] = {
						[205636] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132129,
				},
				["根基图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204336,
					["spellIDs"] = {
						[204336] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136039,
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["refSpellID"] = 209749,
					["spellIDs"] = {
						[209749] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538516,
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["refSpellID"] = 184364,
					["spellIDs"] = {
						[184364] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132345,
				},
				["保护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1022,
					["spellIDs"] = {
						[1022] = true,
					},
					["cooldown"] = 135,
					["texture"] = 135964,
				},
				["血之镜像"] = {
					["enabled"] = true,
					["refSpellID"] = 206977,
					["spellIDs"] = {
						[206977] = true,
					},
					["cooldown"] = 120,
					["texture"] = 134084,
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 196932,
					["spellIDs"] = {
						[196932] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136232,
				},
				["平心之环"] = {
					["enabled"] = true,
					["refSpellID"] = 116844,
					["spellIDs"] = {
						[116844] = true,
					},
					["cooldown"] = 45,
					["texture"] = 839107,
				},
				["虚空转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108968,
					["spellIDs"] = {
						[108968] = true,
					},
					["cooldown"] = 300,
					["texture"] = 537079,
				},
				["急速冷却"] = {
					["enabled"] = true,
					["refSpellID"] = 235219,
					["spellIDs"] = {
						[235219] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135865,
				},
				["光环掌握"] = {
					["enabled"] = true,
					["refSpellID"] = 31821,
					["spellIDs"] = {
						[31821] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135872,
				},
				["火箭跳"] = {
					["enabled"] = true,
					["refSpellID"] = 69070,
					["spellIDs"] = {
						[69070] = true,
					},
					["cooldown"] = 120,
					["texture"] = 370769,
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["refSpellID"] = 19386,
					["spellIDs"] = {
						[19386] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135125,
				},
				["伪装"] = {
					["enabled"] = true,
					["refSpellID"] = 199483,
					["spellIDs"] = {
						[199483] = true,
					},
					["cooldown"] = 60,
					["texture"] = 461113,
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186289,
					["spellIDs"] = {
						[186289] = true,
					},
					["cooldown"] = 120,
					["texture"] = 612363,
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["refSpellID"] = 63560,
					["spellIDs"] = {
						[63560] = true,
					},
					["cooldown"] = 60,
					["texture"] = 342913,
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["refSpellID"] = 119996,
					["spellIDs"] = {
						[119996] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237585,
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["refSpellID"] = 205369,
					["spellIDs"] = {
						[205369] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136173,
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["refSpellID"] = 68992,
					["spellIDs"] = {
						[68992] = true,
					},
					["cooldown"] = 120,
					["texture"] = 366937,
				},
				["禁锢"] = {
					["enabled"] = true,
					["refSpellID"] = 221527,
					["spellIDs"] = {
						[221527] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380368,
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["refSpellID"] = 207349,
					["spellIDs"] = {
						[207349] = true,
					},
					["cooldown"] = 120,
					["texture"] = 298674,
				},
				["责难"] = {
					["enabled"] = true,
					["refSpellID"] = 96231,
					["spellIDs"] = {
						[96231] = true,
					},
					["cooldown"] = 15,
					["texture"] = 523893,
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 202246,
					["spellIDs"] = {
						[202246] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1408833,
				},
				["冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 100,
					["spellIDs"] = {
						[100] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132337,
				},
				["意气风发"] = {
					["enabled"] = true,
					["refSpellID"] = 109304,
					["spellIDs"] = {
						[109304] = true,
					},
					["cooldown"] = 120,
					["texture"] = 461117,
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 205629,
					["spellIDs"] = {
						[205629] = true,
					},
					["cooldown"] = 30,
					["texture"] = 134294,
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 207736,
					["spellIDs"] = {
						[207736] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1020341,
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["refSpellID"] = 119381,
					["spellIDs"] = {
						[119381] = true,
					},
					["cooldown"] = 60,
					["texture"] = 642414,
				},
				["圣盾术"] = {
					["enabled"] = true,
					["refSpellID"] = 642,
					["spellIDs"] = {
						[642] = true,
					},
					["cooldown"] = 240,
					["texture"] = 524354,
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["refSpellID"] = 7744,
					["spellIDs"] = {
						[7744] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136187,
				},
				["虚空行走"] = {
					["enabled"] = true,
					["refSpellID"] = 196555,
					["spellIDs"] = {
						[196555] = true,
					},
					["cooldown"] = 120,
					["texture"] = 463284,
				},
				["战旗"] = {
					["enabled"] = true,
					["refSpellID"] = 236320,
					["spellIDs"] = {
						[236320] = true,
					},
					["cooldown"] = 90,
					["texture"] = 603532,
				},
				["还击"] = {
					["enabled"] = true,
					["refSpellID"] = 199754,
					["spellIDs"] = {
						[199754] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132269,
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 227847,
					["spellIDs"] = {
						[227847] = true,
					},
					["cooldown"] = 60,
					["texture"] = 236303,
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186257,
					["spellIDs"] = {
						[186257] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132242,
				},
				["甘霖"] = {
					["enabled"] = true,
					["refSpellID"] = 108238,
					["spellIDs"] = {
						[108238] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136059,
				},
				["决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 236273,
					["spellIDs"] = {
						[236273] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1455893,
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202138,
					["spellIDs"] = {
						[202138] = true,
					},
					["cooldown"] = 54,
					["texture"] = 1418286,
				},
				["百发百中"] = {
					["enabled"] = true,
					["refSpellID"] = 193526,
					["spellIDs"] = {
						[193526] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132329,
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["refSpellID"] = 31224,
					["spellIDs"] = {
						[31224] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136177,
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["refSpellID"] = 205191,
					["spellIDs"] = {
						[205191] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135986,
				},
				["闪回"] = {
					["enabled"] = true,
					["refSpellID"] = 195676,
					["spellIDs"] = {
						[195676] = true,
					},
					["cooldown"] = 24,
					["texture"] = 132171,
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["refSpellID"] = 53271,
					["spellIDs"] = {
						[53271] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236189,
				},
				["从天而降"] = {
					["enabled"] = true,
					["refSpellID"] = 206803,
					["spellIDs"] = {
						[206803] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380371,
				},
				["驱散射击"] = {
					["enabled"] = true,
					["refSpellID"] = 213691,
					["spellIDs"] = {
						[213691] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132153,
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 108280,
					["spellIDs"] = {
						[108280] = true,
					},
					["cooldown"] = 180,
					["texture"] = 538569,
				},
				["能量灌注"] = {
					["enabled"] = true,
					["refSpellID"] = 10060,
					["spellIDs"] = {
						[10060] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135939,
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["refSpellID"] = 5211,
					["spellIDs"] = {
						[5211] = true,
					},
					["cooldown"] = 50,
					["texture"] = 132114,
				},
				["卸除武装"] = {
					["enabled"] = true,
					["refSpellID"] = 207777,
					["spellIDs"] = {
						[207777] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236272,
				},
				["升腾"] = {
					["enabled"] = true,
					["refSpellID"] = 114050,
					["spellIDs"] = {
						[114050] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135791,
				},
				["拦截"] = {
					["enabled"] = true,
					["refSpellID"] = 198304,
					["spellIDs"] = {
						[198304] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132365,
				},
				["闪现术"] = {
					["enabled"] = true,
					["refSpellID"] = 1953,
					["spellIDs"] = {
						[1953] = true,
					},
					["cooldown"] = 15,
					["texture"] = 135736,
				},
				["树皮术"] = {
					["enabled"] = true,
					["refSpellID"] = 22812,
					["spellIDs"] = {
						[22812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136097,
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["refSpellID"] = 5484,
					["spellIDs"] = {
						[5484] = true,
					},
					["cooldown"] = 40,
					["texture"] = 607852,
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["refSpellID"] = 89766,
					["spellIDs"] = {
						[89766] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236316,
				},
				["反转魔法"] = {
					["enabled"] = true,
					["refSpellID"] = 205604,
					["spellIDs"] = {
						[205604] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380372,
				},
				["火焰之息"] = {
					["enabled"] = true,
					["refSpellID"] = 115181,
					["spellIDs"] = {
						[115181] = true,
					},
					["cooldown"] = 15,
					["texture"] = 615339,
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["refSpellID"] = 216113,
					["spellIDs"] = {
						[216113] = true,
					},
					["cooldown"] = 45,
					["texture"] = 977169,
				},
				["疾跑"] = {
					["enabled"] = true,
					["refSpellID"] = 2983,
					["spellIDs"] = {
						[2983] = true,
					},
					["cooldown"] = 51,
					["texture"] = 132307,
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["refSpellID"] = 12292,
					["spellIDs"] = {
						[12292] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236304,
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 6940,
					["spellIDs"] = {
						[6940] = true,
					},
					["cooldown"] = 75,
					["texture"] = 135966,
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["refSpellID"] = 88625,
					["spellIDs"] = {
						[88625] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135886,
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["refSpellID"] = 115176,
					["spellIDs"] = {
						[115176] = true,
					},
					["cooldown"] = 150,
					["texture"] = 642417,
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["refSpellID"] = 121471,
					["spellIDs"] = {
						[121471] = true,
					},
					["cooldown"] = 180,
					["texture"] = 376022,
				},
				["冲动"] = {
					["enabled"] = true,
					["refSpellID"] = 13750,
					["spellIDs"] = {
						[13750] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136206,
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["refSpellID"] = 8122,
					["spellIDs"] = {
						[8122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136184,
				},
				["躯不坏"] = {
					["enabled"] = true,
					["refSpellID"] = 122278,
					["spellIDs"] = {
						[122278] = true,
					},
					["cooldown"] = 120,
					["texture"] = 620827,
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 208683,
					["spellIDs"] = {
						[208683] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["暗影步"] = {
					["enabled"] = true,
					["refSpellID"] = 36554,
					["spellIDs"] = {
						[36554] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132303,
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["refSpellID"] = 213602,
					["spellIDs"] = {
						[213602] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135994,
				},
				["正中眉心"] = {
					["enabled"] = true,
					["refSpellID"] = 199804,
					["spellIDs"] = {
						[199804] = true,
					},
					["cooldown"] = 20,
					["texture"] = 135610,
				},
				["逃命专家"] = {
					["enabled"] = true,
					["refSpellID"] = 20589,
					["spellIDs"] = {
						[20589] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132309,
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["refSpellID"] = 191427,
					["spellIDs"] = {
						[191427] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1247262,
				},
				["圣疗术"] = {
					["enabled"] = true,
					["refSpellID"] = 633,
					["spellIDs"] = {
						[633] = true,
					},
					["cooldown"] = 600,
					["texture"] = 135928,
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["refSpellID"] = 19574,
					["spellIDs"] = {
						[19574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132127,
				},
				["自由祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1044,
					["spellIDs"] = {
						[1044] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135968,
				},
				["散魔功"] = {
					["enabled"] = true,
					["refSpellID"] = 122783,
					["spellIDs"] = {
						[122783] = true,
					},
					["cooldown"] = 90,
					["texture"] = 775460,
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["refSpellID"] = 12472,
					["spellIDs"] = {
						[12472] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135838,
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["refSpellID"] = 209789,
					["spellIDs"] = {
						[209789] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1033903,
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["refSpellID"] = 12975,
					["spellIDs"] = {
						[12975] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135871,
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 204018,
					["spellIDs"] = {
						[204018] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135880,
				},
				["压制"] = {
					["enabled"] = true,
					["refSpellID"] = 187707,
					["spellIDs"] = {
						[187707] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1376045,
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157997,
					["spellIDs"] = {
						[157997] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033909,
				},
				["业报之触"] = {
					["enabled"] = true,
					["refSpellID"] = 122470,
					["spellIDs"] = {
						[122470] = true,
					},
					["cooldown"] = 90,
					["texture"] = 651728,
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["refSpellID"] = 47528,
					["spellIDs"] = {
						[47528] = true,
					},
					["cooldown"] = 15,
					["texture"] = 237527,
				},
				["胁迫"] = {
					["enabled"] = true,
					["refSpellID"] = 19577,
					["spellIDs"] = {
						[19577] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132111,
				},
				["盾墙"] = {
					["enabled"] = true,
					["refSpellID"] = 871,
					["spellIDs"] = {
						[871] = true,
					},
					["cooldown"] = 240,
					["texture"] = 132362,
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 210256,
					["spellIDs"] = {
						[210256] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135911,
				},
				["法术封锁"] = {
					["enabled"] = true,
					["refSpellID"] = 19647,
					["spellIDs"] = {
						[19647] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136174,
				},
				["混乱新星"] = {
					["enabled"] = true,
					["refSpellID"] = 179057,
					["spellIDs"] = {
						[179057] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135795,
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["refSpellID"] = 108416,
					["spellIDs"] = {
						[108416] = true,
					},
					["cooldown"] = 60,
					["texture"] = 538538,
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["refSpellID"] = 5246,
					["spellIDs"] = {
						[5246] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132154,
				},
				["抓钩"] = {
					["enabled"] = true,
					["refSpellID"] = 195457,
					["spellIDs"] = {
						[195457] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1373906,
				},
				["元素宗师"] = {
					["enabled"] = true,
					["refSpellID"] = 16166,
					["spellIDs"] = {
						[16166] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136027,
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["refSpellID"] = 51533,
					["spellIDs"] = {
						[51533] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237577,
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 51490,
					["spellIDs"] = {
						[51490] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237589,
				},
				["圣佑术"] = {
					["enabled"] = true,
					["refSpellID"] = 498,
					["spellIDs"] = {
						[498] = true,
					},
					["cooldown"] = 60,
					["texture"] = 524353,
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["refSpellID"] = 33891,
					["spellIDs"] = {
						[33891] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236157,
				},
				["龙息术"] = {
					["enabled"] = true,
					["refSpellID"] = 31661,
					["spellIDs"] = {
						[31661] = true,
					},
					["cooldown"] = 20,
					["texture"] = 134153,
				},
				["星界转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108271,
					["spellIDs"] = {
						[108271] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538565,
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 215769,
					["spellIDs"] = {
						[215769] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132864,
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["refSpellID"] = 31687,
					["spellIDs"] = {
						[31687] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135862,
				},
				["宿敌"] = {
					["enabled"] = true,
					["refSpellID"] = 79140,
					["spellIDs"] = {
						[79140] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458726,
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["refSpellID"] = 202370,
					["spellIDs"] = {
						[202370] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1381297,
				},
				["斗转星移"] = {
					["enabled"] = true,
					["refSpellID"] = 202162,
					["spellIDs"] = {
						[202162] = true,
					},
					["cooldown"] = 45,
					["texture"] = 620829,
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 86659,
					["spellIDs"] = {
						[86659] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135919,
				},
				["不灭决心"] = {
					["enabled"] = true,
					["refSpellID"] = 104773,
					["spellIDs"] = {
						[104773] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136150,
				},
				["反制射击"] = {
					["enabled"] = true,
					["refSpellID"] = 147362,
					["spellIDs"] = {
						[147362] = true,
					},
					["cooldown"] = 24,
					["texture"] = 249170,
				},
				["灵体形态"] = {
					["enabled"] = true,
					["refSpellID"] = 210918,
					["spellIDs"] = {
						[210918] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237572,
				},
				["隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 66,
					["spellIDs"] = {
						[66] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132220,
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["refSpellID"] = 102793,
					["spellIDs"] = {
						[102793] = true,
					},
					["cooldown"] = 60,
					["texture"] = 571588,
				},
				["英勇"] = {
					["enabled"] = true,
					["refSpellID"] = 32182,
					["spellIDs"] = {
						[32182] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132313,
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["refSpellID"] = 49206,
					["spellIDs"] = {
						[49206] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458967,
				},
				["束缚射击"] = {
					["enabled"] = true,
					["refSpellID"] = 109248,
					["spellIDs"] = {
						[109248] = true,
					},
					["cooldown"] = 45,
					["texture"] = 462650,
				},
				["守护之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 47788,
					["spellIDs"] = {
						[47788] = true,
					},
					["cooldown"] = 60,
					["texture"] = 237542,
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["refSpellID"] = 48020,
					["spellIDs"] = {
						[48020] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237560,
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["refSpellID"] = 228049,
					["spellIDs"] = {
						[228049] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135919,
				},
				["妖术"] = {
					["enabled"] = true,
					["refSpellID"] = 51514,
					["spellIDs"] = {
						[51514] = true,
					},
					["cooldown"] = 10,
					["texture"] = 237579,
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 31884,
					["spellIDs"] = {
						[31884] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135875,
				},
				["瓦解"] = {
					["enabled"] = true,
					["refSpellID"] = 183752,
					["spellIDs"] = {
						[183752] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1305153,
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 73325,
					["spellIDs"] = {
						[73325] = true,
					},
					["cooldown"] = 45,
					["texture"] = 463835,
				},
				["血魔之握"] = {
					["enabled"] = true,
					["refSpellID"] = 108199,
					["spellIDs"] = {
						[108199] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538767,
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["refSpellID"] = 64843,
					["spellIDs"] = {
						[64843] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237540,
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 207399,
					["spellIDs"] = {
						[207399] = true,
					},
					["cooldown"] = 300,
					["texture"] = 136080,
				},
				["消失"] = {
					["enabled"] = true,
					["refSpellID"] = 1856,
					["spellIDs"] = {
						[1856] = true,
					},
					["cooldown"] = 75,
					["texture"] = 132331,
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["refSpellID"] = 77606,
					["spellIDs"] = {
						[77606] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135888,
				},
				["日光术"] = {
					["enabled"] = true,
					["refSpellID"] = 78675,
					["spellIDs"] = {
						[78675] = true,
					},
					["cooldown"] = 30,
					["texture"] = 252188,
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["refSpellID"] = 188501,
					["spellIDs"] = {
						[188501] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1247266,
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["refSpellID"] = 31850,
					["spellIDs"] = {
						[31850] = true,
					},
					["cooldown"] = 110,
					["texture"] = 135870,
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["refSpellID"] = 108201,
					["spellIDs"] = {
						[108201] = true,
					},
					["cooldown"] = 120,
					["texture"] = 538768,
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["refSpellID"] = 33206,
					["spellIDs"] = {
						[33206] = true,
					},
					["cooldown"] = 210,
					["texture"] = 135936,
				},
				["肾击"] = {
					["enabled"] = true,
					["refSpellID"] = 408,
					["spellIDs"] = {
						[408] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132298,
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["refSpellID"] = 19236,
					["spellIDs"] = {
						[19236] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237550,
				},
				["奥术强化"] = {
					["enabled"] = true,
					["refSpellID"] = 12042,
					["spellIDs"] = {
						[12042] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136048,
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["refSpellID"] = 198817,
					["spellIDs"] = {
						[198817] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1380678,
				},
				["风火雷电"] = {
					["enabled"] = true,
					["refSpellID"] = 137639,
					["spellIDs"] = {
						[137639] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136038,
				},
				["致盲"] = {
					["enabled"] = true,
					["refSpellID"] = 2094,
					["spellIDs"] = {
						[2094] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136175,
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["refSpellID"] = 79206,
					["spellIDs"] = {
						[79206] = true,
					},
					["cooldown"] = 60,
					["texture"] = 451170,
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["refSpellID"] = 187650,
					["spellIDs"] = {
						[187650] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135834,
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["refSpellID"] = 205630,
					["spellIDs"] = {
						[205630] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380367,
				},
				["牺牲"] = {
					["enabled"] = true,
					["refSpellID"] = 7812,
					["spellIDs"] = {
						[7812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136190,
				},
				["台风"] = {
					["enabled"] = true,
					["refSpellID"] = 132469,
					["spellIDs"] = {
						[132469] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236170,
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["refSpellID"] = 198898,
					["spellIDs"] = {
						[198898] = true,
					},
					["cooldown"] = 15,
					["texture"] = 332402,
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["refSpellID"] = 84714,
					["spellIDs"] = {
						[84714] = true,
					},
					["cooldown"] = 60,
					["texture"] = 629077,
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["refSpellID"] = 216331,
					["spellIDs"] = {
						[216331] = true,
					},
					["cooldown"] = 60,
					["texture"] = 589117,
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["refSpellID"] = 69041,
					["spellIDs"] = {
						[69041] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133032,
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["refSpellID"] = 201325,
					["spellIDs"] = {
						[201325] = true,
					},
					["cooldown"] = 180,
					["texture"] = 642417,
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["refSpellID"] = 208253,
					["spellIDs"] = {
						[208253] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1115592,
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["refSpellID"] = 33697,
					["spellIDs"] = {
						[33697] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135726,
				},
				["群体反射"] = {
					["enabled"] = true,
					["refSpellID"] = 213915,
					["spellIDs"] = {
						[213915] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132358,
				},
				["真言术：障"] = {
					["enabled"] = true,
					["refSpellID"] = 62618,
					["spellIDs"] = {
						[62618] = true,
					},
					["cooldown"] = 120,
					["texture"] = 253400,
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["refSpellID"] = 106839,
					["spellIDs"] = {
						[106839] = true,
					},
					["cooldown"] = 15,
					["texture"] = 236946,
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["refSpellID"] = 102543,
					["spellIDs"] = {
						[102543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["战争践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 11876,
					["spellIDs"] = {
						[11876] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132091,
				},
				["割碎"] = {
					["enabled"] = true,
					["refSpellID"] = 22570,
					["spellIDs"] = {
						[22570] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132134,
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["refSpellID"] = 152173,
					["spellIDs"] = {
						[152173] = true,
					},
					["cooldown"] = 90,
					["texture"] = 988197,
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["refSpellID"] = 206650,
					["spellIDs"] = {
						[206650] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380366,
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 107570,
					["spellIDs"] = {
						[107570] = true,
					},
					["cooldown"] = 30,
					["texture"] = 613535,
				},
				["疾影"] = {
					["enabled"] = true,
					["refSpellID"] = 198589,
					["spellIDs"] = {
						[198589] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1305150,
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 6544,
					["spellIDs"] = {
						[6544] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236171,
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 5217,
					["spellIDs"] = {
						[5217] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132242,
				},
				["逃脱"] = {
					["enabled"] = true,
					["refSpellID"] = 781,
					["spellIDs"] = {
						[781] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132294,
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["refSpellID"] = 186387,
					["spellIDs"] = {
						[186387] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1376038,
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["refSpellID"] = 212459,
					["spellIDs"] = {
						[212459] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1113433,
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186265,
					["spellIDs"] = {
						[186265] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132199,
				},
				["窒息"] = {
					["enabled"] = true,
					["refSpellID"] = 47476,
					["spellIDs"] = {
						[47476] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136214,
				},
				["沉默"] = {
					["enabled"] = true,
					["refSpellID"] = 15487,
					["spellIDs"] = {
						[15487] = true,
					},
					["cooldown"] = 45,
					["texture"] = 458230,
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["refSpellID"] = 64044,
					["spellIDs"] = {
						[64044] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237568,
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["refSpellID"] = 205691,
					["spellIDs"] = {
						[205691] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1412204,
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["refSpellID"] = 51271,
					["spellIDs"] = {
						[51271] = true,
					},
					["cooldown"] = 60,
					["texture"] = 458718,
				},
				["凿击"] = {
					["enabled"] = true,
					["refSpellID"] = 1776,
					["spellIDs"] = {
						[1776] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132155,
				},
				["幻影打击"] = {
					["enabled"] = true,
					["refSpellID"] = 196718,
					["spellIDs"] = {
						[196718] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1305154,
				},
				["生存本能"] = {
					["enabled"] = true,
					["refSpellID"] = 61336,
					["spellIDs"] = {
						[61336] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236169,
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["refSpellID"] = 207319,
					["spellIDs"] = {
						[207319] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1531513,
				},
				["影遁"] = {
					["enabled"] = true,
					["refSpellID"] = 58984,
					["spellIDs"] = {
						[58984] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132089,
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["refSpellID"] = 1122,
					["spellIDs"] = {
						[1122] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136219,
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 102359,
					["spellIDs"] = {
						[102359] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538515,
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["refSpellID"] = 212182,
					["spellIDs"] = {
						[212182] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458733,
				},
			},
			["DBVersion"] = 8,
		},
		["WARLOCK"] = {
			["ShowCooldownsOnCurrentTargetOnly"] = true,
			["DBVersion"] = 10,
			["IconSortMode"] = "interrupt-trinket-other",
			["TimerTextSize"] = 10,
			["IconSize"] = 19,
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 360,
					["spellIDs"] = {
						[31230] = true,
					},
				},
				["法术反制"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 24,
					["spellIDs"] = {
						[2139] = true,
					},
				},
				["天灾契约"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 120,
					["spellIDs"] = {
						[48743] = true,
					},
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[186387] = true,
					},
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[132578] = true,
					},
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 20,
					["spellIDs"] = {
						[206572] = true,
					},
				},
				["巨人打击"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 45,
					["spellIDs"] = {
						[167105] = true,
					},
				},
				["震荡波"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 25,
					["spellIDs"] = {
						[46968] = true,
					},
				},
				["谈判"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 20,
					["spellIDs"] = {
						[199743] = true,
					},
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[195710] = true,
					},
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 60,
					["spellIDs"] = {
						[207167] = true,
					},
				},
				["超级新星"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 25,
					["spellIDs"] = {
						[157980] = true,
					},
				},
				["寒冰形态"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 60,
					["spellIDs"] = {
						[198144] = true,
					},
				},
				["闪光力场"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 45,
					["spellIDs"] = {
						[204263] = true,
					},
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 165,
					["spellIDs"] = {
						[48792] = true,
					},
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[102558] = true,
					},
				},
				["思维窃取"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 90,
					["spellIDs"] = {
						[316262] = true,
					},
				},
				["死亡之握"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 20,
					["spellIDs"] = {
						[49576] = true,
					},
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 60,
					["spellIDs"] = {
						[853] = true,
					},
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 90,
					["spellIDs"] = {
						[73325] = true,
					},
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 65,
					["spellIDs"] = {
						[116849] = true,
					},
				},
				["血性狂暴"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 20,
					["spellIDs"] = {
						[329038] = true,
					},
				},
				["还魂术"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[115310] = true,
					},
				},
				["风火雷电"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[137639] = true,
					},
				},
				["墓石"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[219809] = true,
					},
				},
				["天启"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 30,
					["spellIDs"] = {
						[275699] = true,
					},
				},
				["牺牲"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[7812] = true,
					},
				},
				["影舞步"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[51690] = true,
					},
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[108359] = true,
					},
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 90,
					["spellIDs"] = {
						[102342] = true,
					},
				},
				["亡者大军"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 240,
					["spellIDs"] = {
						[42650] = true,
					},
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[198529] = true,
					},
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 120,
					["spellIDs"] = {
						[51052] = true,
					},
				},
				["消散"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 90,
					["spellIDs"] = {
						[47585] = true,
					},
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 30,
					["spellIDs"] = {
						[122] = true,
					},
				},
				["轮回之触"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 144,
					["spellIDs"] = {
						[115080] = true,
					},
				},
				["隐形术"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 300,
					["spellIDs"] = {
						[66] = true,
					},
				},
				["束缚射击"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[109248] = true,
					},
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[196884] = true,
					},
				},
				["鲁莽"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 90,
					["spellIDs"] = {
						[1719] = true,
					},
				},
				["游侠之网"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[200108] = true,
					},
				},
				["虚空联结"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[207810] = true,
					},
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[5217] = true,
					},
				},
				["风剪"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 9,
					["spellIDs"] = {
						[57994] = true,
					},
				},
				["灭战者"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 45,
					["spellIDs"] = {
						[262161] = true,
					},
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 60,
					["spellIDs"] = {
						[49028] = true,
					},
				},
				["石像形态"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[20594] = true,
					},
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[201318] = true,
					},
				},
				["禅意聚神茶"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[209584] = true,
					},
				},
				["压制"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 15,
					["spellIDs"] = {
						[187707] = true,
					},
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 75,
					["spellIDs"] = {
						[110959] = true,
					},
				},
				["剑在人在"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 120,
					["spellIDs"] = {
						[118038] = true,
					},
				},
				["自利"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[59752] = true,
					},
				},
				["反击图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 45,
					["spellIDs"] = {
						[204331] = true,
					},
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[207684] = true,
					},
				},
				["阵风"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 15,
					["spellIDs"] = {
						[192063] = true,
					},
				},
				["混乱新星"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 60,
					["spellIDs"] = {
						[179057] = true,
					},
				},
				["切喉手"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 15,
					["spellIDs"] = {
						[116705] = true,
					},
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[102560] = true,
					},
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 24,
					["spellIDs"] = {
						[115781] = true,
					},
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[80483] = true,
					},
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 25,
					["spellIDs"] = {
						[11426] = true,
					},
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[204150] = true,
					},
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 45,
					["spellIDs"] = {
						[89751] = true,
					},
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[6789] = true,
					},
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[105809] = true,
					},
				},
				["猩红之瓶"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 25,
					["spellIDs"] = {
						[185311] = true,
					},
				},
				["镜像"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[55342] = true,
					},
				},
				["闪避"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[5277] = true,
					},
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 180,
					["spellIDs"] = {
						[64843] = true,
					},
				},
				["死亡脚步"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 45,
					["spellIDs"] = {
						[48265] = true,
					},
				},
				["追踪者之网"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 25,
					["spellIDs"] = {
						[212638] = true,
					},
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[201078] = true,
					},
				},
				["天神下凡"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 90,
					["spellIDs"] = {
						[107574] = true,
					},
				},
				["胁迫"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 60,
					["spellIDs"] = {
						[19577] = true,
					},
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 30,
					["spellIDs"] = {
						[91802] = true,
					},
				},
				["燃烧"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[190319] = true,
					},
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 300,
					["spellIDs"] = {
						[207399] = true,
					},
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[206491] = true,
					},
				},
				["协同进攻"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 96,
					["spellIDs"] = {
						[266779] = true,
					},
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[200851] = true,
					},
				},
				["法术反射"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 25,
					["spellIDs"] = {
						[23920] = true,
					},
				},
				["裂地术"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 40,
					["spellIDs"] = {
						[197214] = true,
					},
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 90,
					["spellIDs"] = {
						[123904] = true,
					},
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 210,
					["spellIDs"] = {
						[45438] = true,
					},
				},
				["时光护盾"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 45,
					["spellIDs"] = {
						[198111] = true,
					},
				},
				["脚踢"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 15,
					["spellIDs"] = {
						[1766] = true,
					},
				},
				["群兽奔腾"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 120,
					["spellIDs"] = {
						[201430] = true,
					},
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[207319] = true,
					},
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[202137] = true,
					},
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[198664] = true,
					},
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[194223] = true,
					},
				},
				["操控时间"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 30,
					["spellIDs"] = {
						[108978] = true,
					},
				},
				["拳击"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 15,
					["spellIDs"] = {
						[6552] = true,
					},
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[211881] = true,
					},
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[33697] = true,
					},
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 90,
					["spellIDs"] = {
						[212459] = true,
					},
				},
				["宁静"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 66,
					["spellIDs"] = {
						[740] = true,
					},
				},
				["急奔"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 120,
					["spellIDs"] = {
						[1850] = true,
					},
				},
				["缴械"] = {
					["enabled"] = false,
					["class"] = "WARRIOR",
					["cooldown"] = 45,
					["spellIDs"] = {
						[236077] = true,
					},
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[212295] = true,
					},
				},
				["自然之力"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[205636] = true,
					},
				},
				["盲目之光"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 90,
					["spellIDs"] = {
						[115750] = true,
					},
				},
				["根基图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[204336] = true,
					},
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 30,
					["spellIDs"] = {
						[209749] = true,
					},
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 120,
					["spellIDs"] = {
						[184364] = true,
					},
				},
				["保护祝福"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 225,
					["spellIDs"] = {
						[1022] = true,
					},
				},
				["血之镜像"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[206977] = true,
					},
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[196932] = true,
					},
				},
				["平心之环"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[116844] = true,
					},
				},
				["虚空转移"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 300,
					["spellIDs"] = {
						[108968] = true,
					},
				},
				["急速冷却"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 270,
					["spellIDs"] = {
						[235219] = true,
					},
				},
				["光环掌握"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[31821] = true,
					},
				},
				["火箭跳"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[69070] = true,
					},
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 45,
					["spellIDs"] = {
						[19386] = true,
					},
				},
				["伪装"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 60,
					["spellIDs"] = {
						[199483] = true,
					},
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[186289] = true,
					},
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[63560] = true,
					},
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 25,
					["spellIDs"] = {
						[119996] = true,
					},
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 30,
					["spellIDs"] = {
						[205369] = true,
					},
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[68992] = true,
					},
				},
				["龙息术"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 18,
					["spellIDs"] = {
						[31661] = true,
					},
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[207349] = true,
					},
				},
				["责难"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 15,
					["spellIDs"] = {
						[96231] = true,
					},
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 25,
					["spellIDs"] = {
						[202246] = true,
					},
				},
				["冲锋"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 20,
					["spellIDs"] = {
						[100] = true,
					},
				},
				["意气风发"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 96,
					["spellIDs"] = {
						[109304] = true,
					},
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 20,
					["spellIDs"] = {
						[205629] = true,
					},
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[207736] = true,
					},
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[119381] = true,
					},
				},
				["圣盾术"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 120,
					["spellIDs"] = {
						[642] = true,
					},
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[7744] = true,
					},
				},
				["虚空行走"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 180,
					["spellIDs"] = {
						[196555] = true,
					},
				},
				["战旗"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 90,
					["spellIDs"] = {
						[236320] = true,
					},
				},
				["还击"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[199754] = true,
					},
				},
				["狂风图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 120,
					["spellIDs"] = {
						[192077] = true,
					},
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 60.3,
					["spellIDs"] = {
						[227847] = true,
					},
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 90,
					["spellIDs"] = {
						[152173] = true,
					},
				},
				["甘霖"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 90,
					["spellIDs"] = {
						[108238] = true,
					},
				},
				["决斗"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 60,
					["spellIDs"] = {
						[236273] = true,
					},
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 67.5,
					["spellIDs"] = {
						[202138] = true,
					},
				},
				["百发百中"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[193526] = true,
					},
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[31224] = true,
					},
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 60,
					["spellIDs"] = {
						[205191] = true,
					},
				},
				["群体反射"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[213915] = true,
					},
				},
				["潜伏帷幕"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 360,
					["spellIDs"] = {
						[114018] = true,
					},
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[53271] = true,
					},
				},
				["从天而降"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 60,
					["spellIDs"] = {
						[206803] = true,
					},
				},
				["恐惧之刃"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 90,
					["spellIDs"] = {
						[343142] = true,
					},
				},
				["驱散射击"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[213691] = true,
					},
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[108280] = true,
					},
				},
				["能量灌注"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 120,
					["spellIDs"] = {
						[10060] = true,
					},
				},
				["窒息"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 45,
					["spellIDs"] = {
						[47476] = true,
					},
				},
				["卸除武装"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 45,
					["spellIDs"] = {
						[207777] = true,
					},
				},
				["升腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[114050] = true,
					},
				},
				["拦截"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 20,
					["spellIDs"] = {
						[198304] = true,
					},
				},
				["施法之环"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 60,
					["spellIDs"] = {
						[221703] = true,
					},
				},
				["闪现术"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 15,
					["spellIDs"] = {
						[1953] = true,
					},
				},
				["树皮术"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 34.2,
					["spellIDs"] = {
						[22812] = true,
					},
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 40,
					["spellIDs"] = {
						[5484] = true,
					},
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[89766] = true,
					},
				},
				["反转魔法"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 60,
					["spellIDs"] = {
						[205604] = true,
					},
				},
				["火焰之息"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 15,
					["spellIDs"] = {
						[115181] = true,
					},
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[216113] = true,
					},
				},
				["疾跑"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 60,
					["spellIDs"] = {
						[2983] = true,
					},
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[12292] = true,
					},
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 72,
					["spellIDs"] = {
						[6940] = true,
					},
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[33891] = true,
					},
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 75,
					["spellIDs"] = {
						[115176] = true,
					},
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 180,
					["spellIDs"] = {
						[121471] = true,
					},
				},
				["冲动"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 180,
					["spellIDs"] = {
						[13750] = true,
					},
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 30,
					["spellIDs"] = {
						[8122] = true,
					},
				},
				["躯不坏"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 120,
					["spellIDs"] = {
						[122278] = true,
					},
				},
				["业报之触"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 60,
					["spellIDs"] = {
						[122470] = true,
					},
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[208683] = true,
					},
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 180,
					["spellIDs"] = {
						[12472] = true,
					},
				},
				["暗影步"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 22,
					["spellIDs"] = {
						[36554] = true,
					},
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[209789] = true,
					},
				},
				["征伐"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 120,
					["spellIDs"] = {
						[231895] = true,
					},
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 45,
					["spellIDs"] = {
						[213602] = true,
					},
				},
				["正中眉心"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[199804] = true,
					},
				},
				["消失"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 75,
					["spellIDs"] = {
						[1856] = true,
					},
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 108,
					["spellIDs"] = {
						[204018] = true,
					},
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 60,
					["spellIDs"] = {
						[18499] = true,
					},
				},
				["逃命专家"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[20589] = true,
					},
				},
				["唤醒"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[12051] = true,
					},
				},
				["复生"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 600,
					["spellIDs"] = {
						[20484] = true,
					},
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 75,
					["spellIDs"] = {
						[191427] = true,
					},
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[190784] = true,
					},
				},
				["冰霜之环"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 45,
					["spellIDs"] = {
						[113724] = true,
					},
				},
				["召唤地狱猎犬"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 24,
					["spellIDs"] = {
						[212619] = true,
					},
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 90,
					["spellIDs"] = {
						[5246] = true,
					},
				},
				["圣疗术"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 300,
					["spellIDs"] = {
						[633] = true,
					},
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 90,
					["spellIDs"] = {
						[51533] = true,
					},
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 76.5,
					["spellIDs"] = {
						[19574] = true,
					},
				},
				["生存意志"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[59752] = true,
					},
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 60,
					["spellIDs"] = {
						[88625] = true,
					},
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 45,
					["spellIDs"] = {
						[64044] = true,
					},
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 27,
					["spellIDs"] = {
						[102359] = true,
					},
				},
				["暗影之舞"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 60,
					["spellIDs"] = {
						[185313] = true,
					},
				},
				["散魔功"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 90,
					["spellIDs"] = {
						[122783] = true,
					},
				},
				["火焰石"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 25,
					["spellIDs"] = {
						[212284] = true,
					},
				},
				["不灭决心"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 180,
					["spellIDs"] = {
						[104773] = true,
					},
				},
				["战栗图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 59,
					["spellIDs"] = {
						[8143] = true,
					},
				},
				["夺魂咆哮"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 30,
					["spellIDs"] = {
						[99] = true,
					},
				},
				["血魔之握"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 90,
					["spellIDs"] = {
						[108199] = true,
					},
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 25,
					["spellIDs"] = {
						[157997] = true,
					},
				},
				["神圣守卫"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 30,
					["spellIDs"] = {
						[213610] = true,
					},
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 15,
					["spellIDs"] = {
						[47528] = true,
					},
				},
				["巫妖之躯"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 120,
					["spellIDs"] = {
						[49039] = true,
					},
				},
				["盾墙"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 140,
					["spellIDs"] = {
						[871] = true,
					},
				},
				["妖术"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 10,
					["spellIDs"] = {
						[51514] = true,
					},
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 144,
					["spellIDs"] = {
						[186265] = true,
					},
				},
				["瓦解"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 15,
					["spellIDs"] = {
						[183752] = true,
					},
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[228049] = true,
					},
				},
				["真言术：障"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 90,
					["spellIDs"] = {
						[62618] = true,
					},
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[30283] = true,
					},
				},
				["元素宗师"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[16166] = true,
					},
				},
				["电能图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 59,
					["spellIDs"] = {
						[192058] = true,
					},
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[51490] = true,
					},
				},
				["凿击"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 15,
					["spellIDs"] = {
						[1776] = true,
					},
				},
				["致盲"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 90,
					["spellIDs"] = {
						[2094] = true,
					},
				},
				["嗜血"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 60,
					["spellIDs"] = {
						[2825] = true,
					},
				},
				["星界转移"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 90,
					["spellIDs"] = {
						[108271] = true,
					},
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[198898] = true,
					},
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[31687] = true,
					},
				},
				["宿敌"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[79140] = true,
					},
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[202370] = true,
					},
				},
				["斗转星移"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 45,
					["spellIDs"] = {
						[202162] = true,
					},
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 215,
					["spellIDs"] = {
						[86659] = true,
					},
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 25,
					["spellIDs"] = {
						[187650] = true,
					},
				},
				["反制射击"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 24,
					["spellIDs"] = {
						[147362] = true,
					},
				},
				["灵体形态"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 45,
					["spellIDs"] = {
						[210918] = true,
					},
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 90,
					["spellIDs"] = {
						[19236] = true,
					},
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 60,
					["spellIDs"] = {
						[102793] = true,
					},
				},
				["英勇"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 60,
					["spellIDs"] = {
						[32182] = true,
					},
				},
				["法术封锁"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 24,
					["spellIDs"] = {
						[19647] = true,
					},
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 120,
					["spellIDs"] = {
						[31884] = true,
					},
				},
				["守护之魂"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 120,
					["spellIDs"] = {
						[47788] = true,
					},
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[48020] = true,
					},
				},
				["野性之心"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 300,
					["spellIDs"] = {
						[319454] = true,
					},
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 40,
					["spellIDs"] = {
						[48707] = true,
					},
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[51485] = true,
					},
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[215769] = true,
					},
				},
				["禁锢"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[221527] = true,
					},
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[204437] = true,
					},
				},
				["抓钩"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 30,
					["spellIDs"] = {
						[195457] = true,
					},
				},
				["圣佑术"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[498] = true,
					},
				},
				["日光术"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 40,
					["spellIDs"] = {
						[78675] = true,
					},
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 60,
					["spellIDs"] = {
						[33206] = true,
					},
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[108201] = true,
					},
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 20,
					["spellIDs"] = {
						[77606] = true,
					},
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 45,
					["spellIDs"] = {
						[201325] = true,
					},
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[69041] = true,
					},
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 120,
					["spellIDs"] = {
						[216331] = true,
					},
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 84,
					["spellIDs"] = {
						[31850] = true,
					},
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[188501] = true,
					},
				},
				["奥术强化"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[12042] = true,
					},
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[59543] = true,
					},
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[206650] = true,
					},
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 160,
					["spellIDs"] = {
						[49206] = true,
					},
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 60,
					["spellIDs"] = {
						[79206] = true,
					},
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 36,
					["spellIDs"] = {
						[12975] = true,
					},
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[186257] = true,
					},
				},
				["狂暴"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[26297] = true,
					},
				},
				["台风"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 30,
					["spellIDs"] = {
						[132469] = true,
					},
				},
				["肾击"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 20,
					["spellIDs"] = {
						[408] = true,
					},
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 60,
					["spellIDs"] = {
						[84714] = true,
					},
				},
				["鱼叉猛刺"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[190925] = true,
					},
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 60,
					["spellIDs"] = {
						[205630] = true,
					},
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 25,
					["spellIDs"] = {
						[198817] = true,
					},
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[208253] = true,
					},
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 45,
					["spellIDs"] = {
						[210256] = true,
					},
				},
				["自由祝福"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 18.75,
					["spellIDs"] = {
						[1044] = true,
					},
				},
				["照明弹"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 20,
					["spellIDs"] = {
						[1543] = true,
					},
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 15,
					["spellIDs"] = {
						[106839] = true,
					},
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[102543] = true,
					},
				},
				["战争践踏"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[11876] = true,
					},
				},
				["割碎"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 20,
					["spellIDs"] = {
						[22570] = true,
					},
				},
				["幻影打击"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[196718] = true,
					},
				},
				["闪回"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 30,
					["spellIDs"] = {
						[195676] = true,
					},
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 30,
					["spellIDs"] = {
						[107570] = true,
					},
				},
				["疾影"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[198589] = true,
					},
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 30,
					["spellIDs"] = {
						[6544] = true,
					},
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[115078] = true,
					},
				},
				["逃脱"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 20,
					["spellIDs"] = {
						[781] = true,
					},
				},
				["摧心魔"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[123040] = true,
					},
				},
				["神圣晋升"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 60,
					["spellIDs"] = {
						[328530] = true,
					},
				},
				["抓钩武器"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[233759] = true,
					},
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 60,
					["spellIDs"] = {
						[108416] = true,
					},
				},
				["沉默"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 30,
					["spellIDs"] = {
						[15487] = true,
					},
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 45,
					["spellIDs"] = {
						[51271] = true,
					},
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[205691] = true,
					},
				},
				["生存本能"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 180,
					["spellIDs"] = {
						[61336] = true,
					},
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[42292] = true,
					},
				},
				["闪光术"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 25,
					["spellIDs"] = {
						[212653] = true,
					},
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 180,
					["spellIDs"] = {
						[212182] = true,
					},
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[98008] = true,
					},
				},
				["影遁"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[58984] = true,
					},
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 60,
					["spellIDs"] = {
						[1122] = true,
					},
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 54,
					["spellIDs"] = {
						[5211] = true,
					},
				},
				["蜘蛛钉刺"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[202914] = true,
					},
				},
			},
			["MigrationVersion"] = 5,
			["IconYOffset"] = 97,
		},
		["Madeep - 冰风岗"] = {
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["refSpellID"] = 31230,
					["spellIDs"] = {
						[31230] = true,
					},
					["cooldown"] = 360,
					["texture"] = 132285,
				},
				["法术反制"] = {
					["enabled"] = true,
					["refSpellID"] = 2139,
					["spellIDs"] = {
						[2139] = true,
					},
					["cooldown"] = 24,
					["texture"] = 135856,
				},
				["天灾契约"] = {
					["enabled"] = true,
					["refSpellID"] = 48743,
					["spellIDs"] = {
						[48743] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136146,
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["refSpellID"] = 204437,
					["spellIDs"] = {
						[204437] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1385911,
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["refSpellID"] = 132578,
					["spellIDs"] = {
						[132578] = true,
					},
					["cooldown"] = 180,
					["texture"] = 608951,
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 206572,
					["spellIDs"] = {
						[206572] = true,
					},
					["cooldown"] = 20,
					["texture"] = 1380676,
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 215769,
					["spellIDs"] = {
						[215769] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132864,
				},
				["震荡波"] = {
					["enabled"] = true,
					["refSpellID"] = 46968,
					["spellIDs"] = {
						[46968] = true,
					},
					["cooldown"] = 40,
					["texture"] = 236312,
				},
				["谈判"] = {
					["enabled"] = true,
					["refSpellID"] = 199743,
					["spellIDs"] = {
						[199743] = true,
					},
					["cooldown"] = 20,
					["texture"] = 236448,
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 195710,
					["spellIDs"] = {
						[195710] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1322720,
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["refSpellID"] = 207167,
					["spellIDs"] = {
						[207167] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135836,
				},
				["超级新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157980,
					["spellIDs"] = {
						[157980] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033912,
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["refSpellID"] = 206650,
					["spellIDs"] = {
						[206650] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380366,
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["refSpellID"] = 48792,
					["spellIDs"] = {
						[48792] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237525,
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["refSpellID"] = 102558,
					["spellIDs"] = {
						[102558] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["死亡之握"] = {
					["enabled"] = true,
					["refSpellID"] = 49576,
					["spellIDs"] = {
						[49576] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237532,
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 853,
					["spellIDs"] = {
						[853] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135963,
				},
				["狂暴"] = {
					["enabled"] = true,
					["refSpellID"] = 26297,
					["spellIDs"] = {
						[26297] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135727,
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["refSpellID"] = 116849,
					["spellIDs"] = {
						[116849] = true,
					},
					["cooldown"] = 90,
					["texture"] = 627485,
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["refSpellID"] = 198817,
					["spellIDs"] = {
						[198817] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1380678,
				},
				["嗜血"] = {
					["enabled"] = true,
					["refSpellID"] = 2825,
					["spellIDs"] = {
						[2825] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136012,
				},
				["墓石"] = {
					["enabled"] = true,
					["refSpellID"] = 219809,
					["spellIDs"] = {
						[219809] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132151,
				},
				["电能图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 192058,
					["spellIDs"] = {
						[192058] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136013,
				},
				["影舞步"] = {
					["enabled"] = true,
					["refSpellID"] = 51690,
					["spellIDs"] = {
						[51690] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236277,
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["refSpellID"] = 108359,
					["spellIDs"] = {
						[108359] = true,
					},
					["cooldown"] = 120,
					["texture"] = 537516,
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["refSpellID"] = 102342,
					["spellIDs"] = {
						[102342] = true,
					},
					["cooldown"] = 90,
					["texture"] = 572025,
				},
				["亡者大军"] = {
					["enabled"] = true,
					["refSpellID"] = 42650,
					["spellIDs"] = {
						[42650] = true,
					},
					["cooldown"] = 600,
					["texture"] = 237511,
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["refSpellID"] = 198529,
					["spellIDs"] = {
						[198529] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133787,
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["refSpellID"] = 51052,
					["spellIDs"] = {
						[51052] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237510,
				},
				["消散"] = {
					["enabled"] = true,
					["refSpellID"] = 47585,
					["spellIDs"] = {
						[47585] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237563,
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["refSpellID"] = 122,
					["spellIDs"] = {
						[122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135848,
				},
				["轮回之触"] = {
					["enabled"] = true,
					["refSpellID"] = 115080,
					["spellIDs"] = {
						[115080] = true,
					},
					["cooldown"] = 60,
					["texture"] = 606552,
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["refSpellID"] = 48707,
					["spellIDs"] = {
						[48707] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136120,
				},
				["火焰石"] = {
					["enabled"] = true,
					["refSpellID"] = 212284,
					["spellIDs"] = {
						[212284] = true,
					},
					["cooldown"] = 45,
					["texture"] = 134085,
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["refSpellID"] = 196884,
					["spellIDs"] = {
						[196884] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1027879,
				},
				["鲁莽"] = {
					["enabled"] = true,
					["refSpellID"] = 1719,
					["spellIDs"] = {
						[1719] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458972,
				},
				["游侠之网"] = {
					["enabled"] = true,
					["refSpellID"] = 200108,
					["spellIDs"] = {
						[200108] = true,
					},
					["cooldown"] = 60,
					["texture"] = 134325,
				},
				["虚空联结"] = {
					["enabled"] = true,
					["refSpellID"] = 207810,
					["spellIDs"] = {
						[207810] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1450144,
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 5217,
					["spellIDs"] = {
						[5217] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132242,
				},
				["风剪"] = {
					["enabled"] = true,
					["refSpellID"] = 57994,
					["spellIDs"] = {
						[57994] = true,
					},
					["cooldown"] = 12,
					["texture"] = 136018,
				},
				["灭战者"] = {
					["enabled"] = true,
					["refSpellID"] = 262161,
					["spellIDs"] = {
						[262161] = true,
					},
					["cooldown"] = 45,
					["texture"] = 2065633,
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["refSpellID"] = 49028,
					["spellIDs"] = {
						[49028] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135277,
				},
				["石像形态"] = {
					["enabled"] = true,
					["refSpellID"] = 20594,
					["spellIDs"] = {
						[20594] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136225,
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["refSpellID"] = 201318,
					["spellIDs"] = {
						[201318] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1616072,
				},
				["压制"] = {
					["enabled"] = true,
					["refSpellID"] = 187707,
					["spellIDs"] = {
						[187707] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1376045,
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 110959,
					["spellIDs"] = {
						[110959] = true,
					},
					["cooldown"] = 75,
					["texture"] = 575584,
				},
				["剑在人在"] = {
					["enabled"] = true,
					["refSpellID"] = 118038,
					["spellIDs"] = {
						[118038] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132336,
				},
				["自利"] = {
					["enabled"] = true,
					["refSpellID"] = 59752,
					["spellIDs"] = {
						[59752] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136129,
				},
				["反击图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204331,
					["spellIDs"] = {
						[204331] = true,
					},
					["cooldown"] = 45,
					["texture"] = 511726,
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 207684,
					["spellIDs"] = {
						[207684] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418287,
				},
				["阵风"] = {
					["enabled"] = true,
					["refSpellID"] = 192063,
					["spellIDs"] = {
						[192063] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1029585,
				},
				["混乱新星"] = {
					["enabled"] = true,
					["refSpellID"] = 179057,
					["spellIDs"] = {
						[179057] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135795,
				},
				["切喉手"] = {
					["enabled"] = true,
					["refSpellID"] = 116705,
					["spellIDs"] = {
						[116705] = true,
					},
					["cooldown"] = 15,
					["texture"] = 608940,
				},
				["法术封锁"] = {
					["enabled"] = true,
					["refSpellID"] = 19647,
					["spellIDs"] = {
						[19647] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136174,
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["refSpellID"] = 115781,
					["spellIDs"] = {
						[115781] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136028,
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["refSpellID"] = 80483,
					["spellIDs"] = {
						[80483] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136222,
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["refSpellID"] = 11426,
					["spellIDs"] = {
						[11426] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135988,
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 204150,
					["spellIDs"] = {
						[204150] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135909,
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 89751,
					["spellIDs"] = {
						[89751] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236303,
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 6789,
					["spellIDs"] = {
						[6789] = true,
					},
					["cooldown"] = 45,
					["texture"] = 607853,
				},
				["生存本能"] = {
					["enabled"] = true,
					["refSpellID"] = 61336,
					["spellIDs"] = {
						[61336] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236169,
				},
				["闪避"] = {
					["enabled"] = true,
					["refSpellID"] = 5277,
					["spellIDs"] = {
						[5277] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136205,
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["refSpellID"] = 64843,
					["spellIDs"] = {
						[64843] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237540,
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["refSpellID"] = 201078,
					["spellIDs"] = {
						[201078] = true,
					},
					["cooldown"] = 120,
					["texture"] = 254647,
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186265,
					["spellIDs"] = {
						[186265] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132199,
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 31884,
					["spellIDs"] = {
						[31884] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135875,
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 91802,
					["spellIDs"] = {
						[91802] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237569,
				},
				["燃烧"] = {
					["enabled"] = true,
					["refSpellID"] = 190319,
					["spellIDs"] = {
						[190319] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135824,
				},
				["唤醒"] = {
					["enabled"] = true,
					["refSpellID"] = 12051,
					["spellIDs"] = {
						[12051] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136075,
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["refSpellID"] = 206491,
					["spellIDs"] = {
						[206491] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236299,
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["refSpellID"] = 42292,
					["spellIDs"] = {
						[42292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 200851,
					["spellIDs"] = {
						[200851] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1129695,
				},
				["法术反射"] = {
					["enabled"] = true,
					["refSpellID"] = 23920,
					["spellIDs"] = {
						[23920] = true,
					},
					["cooldown"] = 25,
					["texture"] = 132361,
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 123904,
					["spellIDs"] = {
						[123904] = true,
					},
					["cooldown"] = 180,
					["texture"] = 620832,
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["refSpellID"] = 45438,
					["spellIDs"] = {
						[45438] = true,
					},
					["cooldown"] = 240,
					["texture"] = 135841,
				},
				["时光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 198111,
					["spellIDs"] = {
						[198111] = true,
					},
					["cooldown"] = 45,
					["texture"] = 610472,
				},
				["脚踢"] = {
					["enabled"] = true,
					["refSpellID"] = 1766,
					["spellIDs"] = {
						[1766] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132219,
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 18499,
					["spellIDs"] = {
						[18499] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136009,
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202137,
					["spellIDs"] = {
						[202137] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418288,
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["refSpellID"] = 198664,
					["spellIDs"] = {
						[198664] = true,
					},
					["cooldown"] = 180,
					["texture"] = 877514,
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["refSpellID"] = 194223,
					["spellIDs"] = {
						[194223] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136060,
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 98008,
					["spellIDs"] = {
						[98008] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237586,
				},
				["拳击"] = {
					["enabled"] = true,
					["refSpellID"] = 6552,
					["spellIDs"] = {
						[6552] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132938,
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["refSpellID"] = 211881,
					["spellIDs"] = {
						[211881] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1118739,
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 51485,
					["spellIDs"] = {
						[51485] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136100,
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["refSpellID"] = 59543,
					["spellIDs"] = {
						[59543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135923,
				},
				["宁静"] = {
					["enabled"] = true,
					["refSpellID"] = 740,
					["spellIDs"] = {
						[740] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136107,
				},
				["急奔"] = {
					["enabled"] = true,
					["refSpellID"] = 1850,
					["spellIDs"] = {
						[1850] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132120,
				},
				["缴械"] = {
					["enabled"] = true,
					["refSpellID"] = 236077,
					["spellIDs"] = {
						[236077] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132343,
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 212295,
					["spellIDs"] = {
						[212295] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135796,
				},
				["自然之力"] = {
					["enabled"] = true,
					["refSpellID"] = 205636,
					["spellIDs"] = {
						[205636] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132129,
				},
				["根基图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204336,
					["spellIDs"] = {
						[204336] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136039,
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["refSpellID"] = 209749,
					["spellIDs"] = {
						[209749] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538516,
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["refSpellID"] = 184364,
					["spellIDs"] = {
						[184364] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132345,
				},
				["保护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1022,
					["spellIDs"] = {
						[1022] = true,
					},
					["cooldown"] = 135,
					["texture"] = 135964,
				},
				["血之镜像"] = {
					["enabled"] = true,
					["refSpellID"] = 206977,
					["spellIDs"] = {
						[206977] = true,
					},
					["cooldown"] = 120,
					["texture"] = 134084,
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 196932,
					["spellIDs"] = {
						[196932] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136232,
				},
				["平心之环"] = {
					["enabled"] = true,
					["refSpellID"] = 116844,
					["spellIDs"] = {
						[116844] = true,
					},
					["cooldown"] = 45,
					["texture"] = 839107,
				},
				["虚空转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108968,
					["spellIDs"] = {
						[108968] = true,
					},
					["cooldown"] = 300,
					["texture"] = 537079,
				},
				["急速冷却"] = {
					["enabled"] = true,
					["refSpellID"] = 235219,
					["spellIDs"] = {
						[235219] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135865,
				},
				["光环掌握"] = {
					["enabled"] = true,
					["refSpellID"] = 31821,
					["spellIDs"] = {
						[31821] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135872,
				},
				["火箭跳"] = {
					["enabled"] = true,
					["refSpellID"] = 69070,
					["spellIDs"] = {
						[69070] = true,
					},
					["cooldown"] = 120,
					["texture"] = 370769,
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["refSpellID"] = 19386,
					["spellIDs"] = {
						[19386] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135125,
				},
				["伪装"] = {
					["enabled"] = true,
					["refSpellID"] = 199483,
					["spellIDs"] = {
						[199483] = true,
					},
					["cooldown"] = 60,
					["texture"] = 461113,
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186289,
					["spellIDs"] = {
						[186289] = true,
					},
					["cooldown"] = 120,
					["texture"] = 612363,
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["refSpellID"] = 63560,
					["spellIDs"] = {
						[63560] = true,
					},
					["cooldown"] = 60,
					["texture"] = 342913,
				},
				["抓钩"] = {
					["enabled"] = true,
					["refSpellID"] = 195457,
					["spellIDs"] = {
						[195457] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1373906,
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["refSpellID"] = 205369,
					["spellIDs"] = {
						[205369] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136173,
				},
				["圣佑术"] = {
					["enabled"] = true,
					["refSpellID"] = 498,
					["spellIDs"] = {
						[498] = true,
					},
					["cooldown"] = 60,
					["texture"] = 524353,
				},
				["禁锢"] = {
					["enabled"] = true,
					["refSpellID"] = 221527,
					["spellIDs"] = {
						[221527] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380368,
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["refSpellID"] = 207349,
					["spellIDs"] = {
						[207349] = true,
					},
					["cooldown"] = 120,
					["texture"] = 298674,
				},
				["责难"] = {
					["enabled"] = true,
					["refSpellID"] = 96231,
					["spellIDs"] = {
						[96231] = true,
					},
					["cooldown"] = 15,
					["texture"] = 523893,
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 202246,
					["spellIDs"] = {
						[202246] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1408833,
				},
				["冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 100,
					["spellIDs"] = {
						[100] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132337,
				},
				["意气风发"] = {
					["enabled"] = true,
					["refSpellID"] = 109304,
					["spellIDs"] = {
						[109304] = true,
					},
					["cooldown"] = 120,
					["texture"] = 461117,
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 205629,
					["spellIDs"] = {
						[205629] = true,
					},
					["cooldown"] = 30,
					["texture"] = 134294,
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 207736,
					["spellIDs"] = {
						[207736] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1020341,
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["refSpellID"] = 119381,
					["spellIDs"] = {
						[119381] = true,
					},
					["cooldown"] = 60,
					["texture"] = 642414,
				},
				["圣盾术"] = {
					["enabled"] = true,
					["refSpellID"] = 642,
					["spellIDs"] = {
						[642] = true,
					},
					["cooldown"] = 240,
					["texture"] = 524354,
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["refSpellID"] = 7744,
					["spellIDs"] = {
						[7744] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136187,
				},
				["虚空行走"] = {
					["enabled"] = true,
					["refSpellID"] = 196555,
					["spellIDs"] = {
						[196555] = true,
					},
					["cooldown"] = 120,
					["texture"] = 463284,
				},
				["战旗"] = {
					["enabled"] = true,
					["refSpellID"] = 236320,
					["spellIDs"] = {
						[236320] = true,
					},
					["cooldown"] = 90,
					["texture"] = 603532,
				},
				["还击"] = {
					["enabled"] = true,
					["refSpellID"] = 199754,
					["spellIDs"] = {
						[199754] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132269,
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 227847,
					["spellIDs"] = {
						[227847] = true,
					},
					["cooldown"] = 60,
					["texture"] = 236303,
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186257,
					["spellIDs"] = {
						[186257] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132242,
				},
				["甘霖"] = {
					["enabled"] = true,
					["refSpellID"] = 108238,
					["spellIDs"] = {
						[108238] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136059,
				},
				["决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 236273,
					["spellIDs"] = {
						[236273] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1455893,
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202138,
					["spellIDs"] = {
						[202138] = true,
					},
					["cooldown"] = 54,
					["texture"] = 1418286,
				},
				["百发百中"] = {
					["enabled"] = true,
					["refSpellID"] = 193526,
					["spellIDs"] = {
						[193526] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132329,
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["refSpellID"] = 31224,
					["spellIDs"] = {
						[31224] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136177,
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["refSpellID"] = 205191,
					["spellIDs"] = {
						[205191] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135986,
				},
				["群体反射"] = {
					["enabled"] = true,
					["refSpellID"] = 213915,
					["spellIDs"] = {
						[213915] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132358,
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["refSpellID"] = 53271,
					["spellIDs"] = {
						[53271] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236189,
				},
				["从天而降"] = {
					["enabled"] = true,
					["refSpellID"] = 206803,
					["spellIDs"] = {
						[206803] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380371,
				},
				["驱散射击"] = {
					["enabled"] = true,
					["refSpellID"] = 213691,
					["spellIDs"] = {
						[213691] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132153,
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 108280,
					["spellIDs"] = {
						[108280] = true,
					},
					["cooldown"] = 180,
					["texture"] = 538569,
				},
				["能量灌注"] = {
					["enabled"] = true,
					["refSpellID"] = 10060,
					["spellIDs"] = {
						[10060] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135939,
				},
				["窒息"] = {
					["enabled"] = true,
					["refSpellID"] = 47476,
					["spellIDs"] = {
						[47476] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136214,
				},
				["卸除武装"] = {
					["enabled"] = true,
					["refSpellID"] = 207777,
					["spellIDs"] = {
						[207777] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236272,
				},
				["升腾"] = {
					["enabled"] = true,
					["refSpellID"] = 114050,
					["spellIDs"] = {
						[114050] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135791,
				},
				["拦截"] = {
					["enabled"] = true,
					["refSpellID"] = 198304,
					["spellIDs"] = {
						[198304] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132365,
				},
				["闪现术"] = {
					["enabled"] = true,
					["refSpellID"] = 1953,
					["spellIDs"] = {
						[1953] = true,
					},
					["cooldown"] = 15,
					["texture"] = 135739,
				},
				["树皮术"] = {
					["enabled"] = true,
					["refSpellID"] = 22812,
					["spellIDs"] = {
						[22812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136097,
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["refSpellID"] = 5484,
					["spellIDs"] = {
						[5484] = true,
					},
					["cooldown"] = 40,
					["texture"] = 607852,
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["refSpellID"] = 89766,
					["spellIDs"] = {
						[89766] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236316,
				},
				["反转魔法"] = {
					["enabled"] = true,
					["refSpellID"] = 205604,
					["spellIDs"] = {
						[205604] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380372,
				},
				["火焰之息"] = {
					["enabled"] = true,
					["refSpellID"] = 115181,
					["spellIDs"] = {
						[115181] = true,
					},
					["cooldown"] = 15,
					["texture"] = 615339,
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["refSpellID"] = 216113,
					["spellIDs"] = {
						[216113] = true,
					},
					["cooldown"] = 45,
					["texture"] = 977169,
				},
				["疾跑"] = {
					["enabled"] = true,
					["refSpellID"] = 2983,
					["spellIDs"] = {
						[2983] = true,
					},
					["cooldown"] = 51,
					["texture"] = 132307,
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["refSpellID"] = 12292,
					["spellIDs"] = {
						[12292] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236304,
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["refSpellID"] = 64044,
					["spellIDs"] = {
						[64044] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237568,
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["refSpellID"] = 33891,
					["spellIDs"] = {
						[33891] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236157,
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["refSpellID"] = 115176,
					["spellIDs"] = {
						[115176] = true,
					},
					["cooldown"] = 150,
					["texture"] = 642417,
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["refSpellID"] = 121471,
					["spellIDs"] = {
						[121471] = true,
					},
					["cooldown"] = 180,
					["texture"] = 376022,
				},
				["冲动"] = {
					["enabled"] = true,
					["refSpellID"] = 13750,
					["spellIDs"] = {
						[13750] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136206,
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["refSpellID"] = 8122,
					["spellIDs"] = {
						[8122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136184,
				},
				["躯不坏"] = {
					["enabled"] = true,
					["refSpellID"] = 122278,
					["spellIDs"] = {
						[122278] = true,
					},
					["cooldown"] = 120,
					["texture"] = 620827,
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 208683,
					["spellIDs"] = {
						[208683] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["暗影步"] = {
					["enabled"] = true,
					["refSpellID"] = 36554,
					["spellIDs"] = {
						[36554] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132303,
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["refSpellID"] = 213602,
					["spellIDs"] = {
						[213602] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135994,
				},
				["凿击"] = {
					["enabled"] = true,
					["refSpellID"] = 1776,
					["spellIDs"] = {
						[1776] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132155,
				},
				["逃命专家"] = {
					["enabled"] = true,
					["refSpellID"] = 20589,
					["spellIDs"] = {
						[20589] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132309,
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["refSpellID"] = 191427,
					["spellIDs"] = {
						[191427] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1247262,
				},
				["圣疗术"] = {
					["enabled"] = true,
					["refSpellID"] = 633,
					["spellIDs"] = {
						[633] = true,
					},
					["cooldown"] = 600,
					["texture"] = 135928,
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 210256,
					["spellIDs"] = {
						[210256] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135911,
				},
				["自由祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1044,
					["spellIDs"] = {
						[1044] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135968,
				},
				["散魔功"] = {
					["enabled"] = true,
					["refSpellID"] = 122783,
					["spellIDs"] = {
						[122783] = true,
					},
					["cooldown"] = 90,
					["texture"] = 775460,
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["refSpellID"] = 33697,
					["spellIDs"] = {
						[33697] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135726,
				},
				["复生"] = {
					["enabled"] = true,
					["refSpellID"] = 20484,
					["spellIDs"] = {
						[20484] = true,
					},
					["cooldown"] = 600,
					["texture"] = 136080,
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["refSpellID"] = 102560,
					["spellIDs"] = {
						[102560] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 204018,
					["spellIDs"] = {
						[204018] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135880,
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 207399,
					["spellIDs"] = {
						[207399] = true,
					},
					["cooldown"] = 300,
					["texture"] = 136080,
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157997,
					["spellIDs"] = {
						[157997] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033909,
				},
				["消失"] = {
					["enabled"] = true,
					["refSpellID"] = 1856,
					["spellIDs"] = {
						[1856] = true,
					},
					["cooldown"] = 75,
					["texture"] = 132331,
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["refSpellID"] = 47528,
					["spellIDs"] = {
						[47528] = true,
					},
					["cooldown"] = 15,
					["texture"] = 237527,
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["refSpellID"] = 12975,
					["spellIDs"] = {
						[12975] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135871,
				},
				["盾墙"] = {
					["enabled"] = true,
					["refSpellID"] = 871,
					["spellIDs"] = {
						[871] = true,
					},
					["cooldown"] = 240,
					["texture"] = 132362,
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["refSpellID"] = 19574,
					["spellIDs"] = {
						[19574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132127,
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["refSpellID"] = 186387,
					["spellIDs"] = {
						[186387] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1376038,
				},
				["龙息术"] = {
					["enabled"] = true,
					["refSpellID"] = 31661,
					["spellIDs"] = {
						[31661] = true,
					},
					["cooldown"] = 20,
					["texture"] = 134153,
				},
				["天神下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 107574,
					["spellIDs"] = {
						[107574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 613534,
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["refSpellID"] = 5246,
					["spellIDs"] = {
						[5246] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132154,
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["refSpellID"] = 115078,
					["spellIDs"] = {
						[115078] = true,
					},
					["cooldown"] = 15,
					["texture"] = 629534,
				},
				["元素宗师"] = {
					["enabled"] = true,
					["refSpellID"] = 16166,
					["spellIDs"] = {
						[16166] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136027,
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["refSpellID"] = 51533,
					["spellIDs"] = {
						[51533] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237577,
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 51490,
					["spellIDs"] = {
						[51490] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237589,
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["refSpellID"] = 88625,
					["spellIDs"] = {
						[88625] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135886,
				},
				["胁迫"] = {
					["enabled"] = true,
					["refSpellID"] = 19577,
					["spellIDs"] = {
						[19577] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132111,
				},
				["风火雷电"] = {
					["enabled"] = true,
					["refSpellID"] = 137639,
					["spellIDs"] = {
						[137639] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136038,
				},
				["星界转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108271,
					["spellIDs"] = {
						[108271] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538565,
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 6940,
					["spellIDs"] = {
						[6940] = true,
					},
					["cooldown"] = 75,
					["texture"] = 135966,
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["refSpellID"] = 31687,
					["spellIDs"] = {
						[31687] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135862,
				},
				["宿敌"] = {
					["enabled"] = true,
					["refSpellID"] = 79140,
					["spellIDs"] = {
						[79140] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458726,
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["refSpellID"] = 202370,
					["spellIDs"] = {
						[202370] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1381297,
				},
				["斗转星移"] = {
					["enabled"] = true,
					["refSpellID"] = 202162,
					["spellIDs"] = {
						[202162] = true,
					},
					["cooldown"] = 45,
					["texture"] = 620829,
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 86659,
					["spellIDs"] = {
						[86659] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135919,
				},
				["不灭决心"] = {
					["enabled"] = true,
					["refSpellID"] = 104773,
					["spellIDs"] = {
						[104773] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136150,
				},
				["反制射击"] = {
					["enabled"] = true,
					["refSpellID"] = 147362,
					["spellIDs"] = {
						[147362] = true,
					},
					["cooldown"] = 24,
					["texture"] = 249170,
				},
				["灵体形态"] = {
					["enabled"] = true,
					["refSpellID"] = 210918,
					["spellIDs"] = {
						[210918] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237572,
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 73325,
					["spellIDs"] = {
						[73325] = true,
					},
					["cooldown"] = 45,
					["texture"] = 463835,
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["refSpellID"] = 102793,
					["spellIDs"] = {
						[102793] = true,
					},
					["cooldown"] = 60,
					["texture"] = 571588,
				},
				["英勇"] = {
					["enabled"] = true,
					["refSpellID"] = 32182,
					["spellIDs"] = {
						[32182] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132313,
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["refSpellID"] = 108416,
					["spellIDs"] = {
						[108416] = true,
					},
					["cooldown"] = 60,
					["texture"] = 538538,
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["refSpellID"] = 152173,
					["spellIDs"] = {
						[152173] = true,
					},
					["cooldown"] = 90,
					["texture"] = 988197,
				},
				["守护之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 47788,
					["spellIDs"] = {
						[47788] = true,
					},
					["cooldown"] = 60,
					["texture"] = 237542,
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["refSpellID"] = 48020,
					["spellIDs"] = {
						[48020] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237560,
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["refSpellID"] = 205630,
					["spellIDs"] = {
						[205630] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380367,
				},
				["妖术"] = {
					["enabled"] = true,
					["refSpellID"] = 51514,
					["spellIDs"] = {
						[51514] = true,
					},
					["cooldown"] = 10,
					["texture"] = 237579,
				},
				["摧心魔"] = {
					["enabled"] = true,
					["refSpellID"] = 123040,
					["spellIDs"] = {
						[123040] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["瓦解"] = {
					["enabled"] = true,
					["refSpellID"] = 183752,
					["spellIDs"] = {
						[183752] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1305153,
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["refSpellID"] = 12472,
					["spellIDs"] = {
						[12472] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135838,
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["refSpellID"] = 209789,
					["spellIDs"] = {
						[209789] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1033903,
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 102359,
					["spellIDs"] = {
						[102359] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538515,
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 30283,
					["spellIDs"] = {
						[30283] = true,
					},
					["cooldown"] = 30,
					["texture"] = 607865,
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["refSpellID"] = 207319,
					["spellIDs"] = {
						[207319] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1531513,
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["refSpellID"] = 31850,
					["spellIDs"] = {
						[31850] = true,
					},
					["cooldown"] = 110,
					["texture"] = 135870,
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["refSpellID"] = 201325,
					["spellIDs"] = {
						[201325] = true,
					},
					["cooldown"] = 180,
					["texture"] = 642417,
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["refSpellID"] = 69041,
					["spellIDs"] = {
						[69041] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133032,
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["refSpellID"] = 77606,
					["spellIDs"] = {
						[77606] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135888,
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["refSpellID"] = 108201,
					["spellIDs"] = {
						[108201] = true,
					},
					["cooldown"] = 120,
					["texture"] = 538768,
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["refSpellID"] = 33206,
					["spellIDs"] = {
						[33206] = true,
					},
					["cooldown"] = 210,
					["texture"] = 135936,
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["refSpellID"] = 19236,
					["spellIDs"] = {
						[19236] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237550,
				},
				["肾击"] = {
					["enabled"] = true,
					["refSpellID"] = 408,
					["spellIDs"] = {
						[408] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132298,
				},
				["奥术强化"] = {
					["enabled"] = true,
					["refSpellID"] = 12042,
					["spellIDs"] = {
						[12042] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136048,
				},
				["致盲"] = {
					["enabled"] = true,
					["refSpellID"] = 2094,
					["spellIDs"] = {
						[2094] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136175,
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["refSpellID"] = 187650,
					["spellIDs"] = {
						[187650] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135834,
				},
				["正中眉心"] = {
					["enabled"] = true,
					["refSpellID"] = 199804,
					["spellIDs"] = {
						[199804] = true,
					},
					["cooldown"] = 20,
					["texture"] = 135610,
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["refSpellID"] = 79206,
					["spellIDs"] = {
						[79206] = true,
					},
					["cooldown"] = 60,
					["texture"] = 451170,
				},
				["牺牲"] = {
					["enabled"] = true,
					["refSpellID"] = 7812,
					["spellIDs"] = {
						[7812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136190,
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["refSpellID"] = 228049,
					["spellIDs"] = {
						[228049] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135919,
				},
				["闪回"] = {
					["enabled"] = true,
					["refSpellID"] = 195676,
					["spellIDs"] = {
						[195676] = true,
					},
					["cooldown"] = 24,
					["texture"] = 132171,
				},
				["台风"] = {
					["enabled"] = true,
					["refSpellID"] = 132469,
					["spellIDs"] = {
						[132469] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236170,
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["refSpellID"] = 198898,
					["spellIDs"] = {
						[198898] = true,
					},
					["cooldown"] = 15,
					["texture"] = 332402,
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["refSpellID"] = 84714,
					["spellIDs"] = {
						[84714] = true,
					},
					["cooldown"] = 60,
					["texture"] = 629077,
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["refSpellID"] = 216331,
					["spellIDs"] = {
						[216331] = true,
					},
					["cooldown"] = 60,
					["texture"] = 589117,
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["refSpellID"] = 188501,
					["spellIDs"] = {
						[188501] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1247266,
				},
				["日光术"] = {
					["enabled"] = true,
					["refSpellID"] = 78675,
					["spellIDs"] = {
						[78675] = true,
					},
					["cooldown"] = 30,
					["texture"] = 252188,
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["refSpellID"] = 208253,
					["spellIDs"] = {
						[208253] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1115592,
				},
				["幻影打击"] = {
					["enabled"] = true,
					["refSpellID"] = 196718,
					["spellIDs"] = {
						[196718] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1305154,
				},
				["隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 66,
					["spellIDs"] = {
						[66] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132220,
				},
				["真言术：障"] = {
					["enabled"] = true,
					["refSpellID"] = 62618,
					["spellIDs"] = {
						[62618] = true,
					},
					["cooldown"] = 120,
					["texture"] = 253400,
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["refSpellID"] = 106839,
					["spellIDs"] = {
						[106839] = true,
					},
					["cooldown"] = 15,
					["texture"] = 236946,
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["refSpellID"] = 102543,
					["spellIDs"] = {
						[102543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["战争践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 11876,
					["spellIDs"] = {
						[11876] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132091,
				},
				["割碎"] = {
					["enabled"] = true,
					["refSpellID"] = 22570,
					["spellIDs"] = {
						[22570] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132134,
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["refSpellID"] = 105809,
					["spellIDs"] = {
						[105809] = true,
					},
					["cooldown"] = 90,
					["texture"] = 571555,
				},
				["束缚射击"] = {
					["enabled"] = true,
					["refSpellID"] = 109248,
					["spellIDs"] = {
						[109248] = true,
					},
					["cooldown"] = 45,
					["texture"] = 462650,
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 107570,
					["spellIDs"] = {
						[107570] = true,
					},
					["cooldown"] = 30,
					["texture"] = 613535,
				},
				["疾影"] = {
					["enabled"] = true,
					["refSpellID"] = 198589,
					["spellIDs"] = {
						[198589] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1305150,
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 6544,
					["spellIDs"] = {
						[6544] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236171,
				},
				["还魂术"] = {
					["enabled"] = true,
					["refSpellID"] = 115310,
					["spellIDs"] = {
						[115310] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1020466,
				},
				["逃脱"] = {
					["enabled"] = true,
					["refSpellID"] = 781,
					["spellIDs"] = {
						[781] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132294,
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["refSpellID"] = 49206,
					["spellIDs"] = {
						[49206] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458967,
				},
				["血魔之握"] = {
					["enabled"] = true,
					["refSpellID"] = 108199,
					["spellIDs"] = {
						[108199] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538767,
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["refSpellID"] = 51271,
					["spellIDs"] = {
						[51271] = true,
					},
					["cooldown"] = 60,
					["texture"] = 458718,
				},
				["巨人打击"] = {
					["enabled"] = true,
					["refSpellID"] = 167105,
					["spellIDs"] = {
						[167105] = true,
					},
					["cooldown"] = 45,
					["texture"] = 464973,
				},
				["沉默"] = {
					["enabled"] = true,
					["refSpellID"] = 15487,
					["spellIDs"] = {
						[15487] = true,
					},
					["cooldown"] = 45,
					["texture"] = 458230,
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["refSpellID"] = 212182,
					["spellIDs"] = {
						[212182] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458733,
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["refSpellID"] = 205691,
					["spellIDs"] = {
						[205691] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1412204,
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["refSpellID"] = 190784,
					["spellIDs"] = {
						[190784] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1360759,
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["refSpellID"] = 68992,
					["spellIDs"] = {
						[68992] = true,
					},
					["cooldown"] = 120,
					["texture"] = 366937,
				},
				["业报之触"] = {
					["enabled"] = true,
					["refSpellID"] = 122470,
					["spellIDs"] = {
						[122470] = true,
					},
					["cooldown"] = 90,
					["texture"] = 651728,
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["refSpellID"] = 119996,
					["spellIDs"] = {
						[119996] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237585,
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["refSpellID"] = 5211,
					["spellIDs"] = {
						[5211] = true,
					},
					["cooldown"] = 50,
					["texture"] = 132114,
				},
				["影遁"] = {
					["enabled"] = true,
					["refSpellID"] = 58984,
					["spellIDs"] = {
						[58984] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132089,
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["refSpellID"] = 1122,
					["spellIDs"] = {
						[1122] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136219,
				},
				["闪光力场"] = {
					["enabled"] = true,
					["refSpellID"] = 204263,
					["spellIDs"] = {
						[204263] = true,
					},
					["cooldown"] = 45,
					["texture"] = 571554,
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["refSpellID"] = 212459,
					["spellIDs"] = {
						[212459] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1113433,
				},
			},
			["DBVersion"] = 8,
		},
		["別雨 - 索瑞森"] = {
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["refSpellID"] = 31230,
					["spellIDs"] = {
						[31230] = true,
					},
					["cooldown"] = 360,
					["texture"] = 132285,
				},
				["业报之触"] = {
					["enabled"] = true,
					["refSpellID"] = 122470,
					["spellIDs"] = {
						[122470] = true,
					},
					["cooldown"] = 90,
					["texture"] = 651728,
				},
				["致盲"] = {
					["enabled"] = true,
					["refSpellID"] = 2094,
					["spellIDs"] = {
						[2094] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136175,
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["refSpellID"] = 204437,
					["spellIDs"] = {
						[204437] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1385911,
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["refSpellID"] = 132578,
					["spellIDs"] = {
						[132578] = true,
					},
					["cooldown"] = 180,
					["texture"] = 608951,
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 206572,
					["spellIDs"] = {
						[206572] = true,
					},
					["cooldown"] = 20,
					["texture"] = 1380676,
				},
				["巨人打击"] = {
					["enabled"] = true,
					["refSpellID"] = 167105,
					["spellIDs"] = {
						[167105] = true,
					},
					["cooldown"] = 45,
					["texture"] = 464973,
				},
				["震荡波"] = {
					["enabled"] = true,
					["refSpellID"] = 46968,
					["spellIDs"] = {
						[46968] = true,
					},
					["cooldown"] = 40,
					["texture"] = 236312,
				},
				["谈判"] = {
					["enabled"] = true,
					["refSpellID"] = 199743,
					["spellIDs"] = {
						[199743] = true,
					},
					["cooldown"] = 20,
					["texture"] = 236448,
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 195710,
					["spellIDs"] = {
						[195710] = true,
					},
					["cooldown"] = 180,
					["texture"] = 338784,
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["refSpellID"] = 207167,
					["spellIDs"] = {
						[207167] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135836,
				},
				["超级新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157980,
					["spellIDs"] = {
						[157980] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033912,
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["refSpellID"] = 206650,
					["spellIDs"] = {
						[206650] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380366,
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["refSpellID"] = 48792,
					["spellIDs"] = {
						[48792] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237525,
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["refSpellID"] = 102558,
					["spellIDs"] = {
						[102558] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["死亡之握"] = {
					["enabled"] = true,
					["refSpellID"] = 49576,
					["spellIDs"] = {
						[49576] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237532,
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 853,
					["spellIDs"] = {
						[853] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135963,
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 73325,
					["spellIDs"] = {
						[73325] = true,
					},
					["cooldown"] = 45,
					["texture"] = 463835,
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["refSpellID"] = 116849,
					["spellIDs"] = {
						[116849] = true,
					},
					["cooldown"] = 90,
					["texture"] = 627485,
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["refSpellID"] = 198817,
					["spellIDs"] = {
						[198817] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1380678,
				},
				["嗜血"] = {
					["enabled"] = true,
					["refSpellID"] = 2825,
					["spellIDs"] = {
						[2825] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136012,
				},
				["墓石"] = {
					["enabled"] = true,
					["refSpellID"] = 219809,
					["spellIDs"] = {
						[219809] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132151,
				},
				["牺牲"] = {
					["enabled"] = true,
					["refSpellID"] = 7812,
					["spellIDs"] = {
						[7812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136190,
				},
				["影舞步"] = {
					["enabled"] = true,
					["refSpellID"] = 51690,
					["spellIDs"] = {
						[51690] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236277,
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["refSpellID"] = 108359,
					["spellIDs"] = {
						[108359] = true,
					},
					["cooldown"] = 120,
					["texture"] = 537516,
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["refSpellID"] = 102342,
					["spellIDs"] = {
						[102342] = true,
					},
					["cooldown"] = 90,
					["texture"] = 572025,
				},
				["亡者大军"] = {
					["enabled"] = true,
					["refSpellID"] = 42650,
					["spellIDs"] = {
						[42650] = true,
					},
					["cooldown"] = 600,
					["texture"] = 237511,
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["refSpellID"] = 198529,
					["spellIDs"] = {
						[198529] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133787,
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["refSpellID"] = 51052,
					["spellIDs"] = {
						[51052] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237510,
				},
				["消散"] = {
					["enabled"] = true,
					["refSpellID"] = 47585,
					["spellIDs"] = {
						[47585] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237563,
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["refSpellID"] = 122,
					["spellIDs"] = {
						[122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135848,
				},
				["轮回之触"] = {
					["enabled"] = true,
					["refSpellID"] = 115080,
					["spellIDs"] = {
						[115080] = true,
					},
					["cooldown"] = 60,
					["texture"] = 606552,
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["refSpellID"] = 48707,
					["spellIDs"] = {
						[48707] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136120,
				},
				["火焰石"] = {
					["enabled"] = true,
					["refSpellID"] = 212284,
					["spellIDs"] = {
						[212284] = true,
					},
					["cooldown"] = 45,
					["texture"] = 134085,
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["refSpellID"] = 196884,
					["spellIDs"] = {
						[196884] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1027879,
				},
				["鲁莽"] = {
					["enabled"] = true,
					["refSpellID"] = 1719,
					["spellIDs"] = {
						[1719] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458972,
				},
				["游侠之网"] = {
					["enabled"] = true,
					["refSpellID"] = 200108,
					["spellIDs"] = {
						[200108] = true,
					},
					["cooldown"] = 60,
					["texture"] = 134325,
				},
				["虚空联结"] = {
					["enabled"] = true,
					["refSpellID"] = 207810,
					["spellIDs"] = {
						[207810] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1450144,
				},
				["摧心魔"] = {
					["enabled"] = true,
					["refSpellID"] = 123040,
					["spellIDs"] = {
						[123040] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136214,
				},
				["风剪"] = {
					["enabled"] = true,
					["refSpellID"] = 57994,
					["spellIDs"] = {
						[57994] = true,
					},
					["cooldown"] = 12,
					["texture"] = 136018,
				},
				["灭战者"] = {
					["enabled"] = true,
					["refSpellID"] = 262161,
					["spellIDs"] = {
						[262161] = true,
					},
					["cooldown"] = 45,
					["texture"] = 2065633,
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["refSpellID"] = 49028,
					["spellIDs"] = {
						[49028] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135277,
				},
				["石像形态"] = {
					["enabled"] = true,
					["refSpellID"] = 20594,
					["spellIDs"] = {
						[20594] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136225,
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["refSpellID"] = 201318,
					["spellIDs"] = {
						[201318] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1616072,
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["refSpellID"] = 51533,
					["spellIDs"] = {
						[51533] = true,
					},
					["cooldown"] = 120,
					["texture"] = 237577,
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 110959,
					["spellIDs"] = {
						[110959] = true,
					},
					["cooldown"] = 75,
					["texture"] = 575584,
				},
				["剑在人在"] = {
					["enabled"] = true,
					["refSpellID"] = 118038,
					["spellIDs"] = {
						[118038] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132336,
				},
				["自利"] = {
					["enabled"] = true,
					["refSpellID"] = 59752,
					["spellIDs"] = {
						[59752] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136129,
				},
				["反击图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204331,
					["spellIDs"] = {
						[204331] = true,
					},
					["cooldown"] = 45,
					["texture"] = 511726,
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 207684,
					["spellIDs"] = {
						[207684] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418287,
				},
				["阵风"] = {
					["enabled"] = true,
					["refSpellID"] = 192063,
					["spellIDs"] = {
						[192063] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1029585,
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["refSpellID"] = 115078,
					["spellIDs"] = {
						[115078] = true,
					},
					["cooldown"] = 15,
					["texture"] = 629534,
				},
				["切喉手"] = {
					["enabled"] = true,
					["refSpellID"] = 116705,
					["spellIDs"] = {
						[116705] = true,
					},
					["cooldown"] = 15,
					["texture"] = 608940,
				},
				["法术封锁"] = {
					["enabled"] = true,
					["refSpellID"] = 19647,
					["spellIDs"] = {
						[19647] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136174,
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["refSpellID"] = 115781,
					["spellIDs"] = {
						[115781] = true,
					},
					["cooldown"] = 24,
					["texture"] = 136028,
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["refSpellID"] = 80483,
					["spellIDs"] = {
						[80483] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136222,
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["refSpellID"] = 11426,
					["spellIDs"] = {
						[11426] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135988,
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 204150,
					["spellIDs"] = {
						[204150] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135909,
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 89751,
					["spellIDs"] = {
						[89751] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236303,
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 6789,
					["spellIDs"] = {
						[6789] = true,
					},
					["cooldown"] = 45,
					["texture"] = 607853,
				},
				["生存本能"] = {
					["enabled"] = true,
					["refSpellID"] = 61336,
					["spellIDs"] = {
						[61336] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236169,
				},
				["闪避"] = {
					["enabled"] = true,
					["refSpellID"] = 5277,
					["spellIDs"] = {
						[5277] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136205,
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["refSpellID"] = 64843,
					["spellIDs"] = {
						[64843] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237540,
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["refSpellID"] = 201078,
					["spellIDs"] = {
						[201078] = true,
					},
					["cooldown"] = 120,
					["texture"] = 254647,
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186265,
					["spellIDs"] = {
						[186265] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132199,
				},
				["胁迫"] = {
					["enabled"] = true,
					["refSpellID"] = 19577,
					["spellIDs"] = {
						[19577] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132111,
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 91802,
					["spellIDs"] = {
						[91802] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237569,
				},
				["燃烧"] = {
					["enabled"] = true,
					["refSpellID"] = 190319,
					["spellIDs"] = {
						[190319] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135824,
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 207399,
					["spellIDs"] = {
						[207399] = true,
					},
					["cooldown"] = 300,
					["texture"] = 136080,
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["refSpellID"] = 206491,
					["spellIDs"] = {
						[206491] = true,
					},
					["cooldown"] = 120,
					["texture"] = 236299,
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["refSpellID"] = 42292,
					["spellIDs"] = {
						[42292] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 200851,
					["spellIDs"] = {
						[200851] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1129695,
				},
				["法术反射"] = {
					["enabled"] = true,
					["refSpellID"] = 23920,
					["spellIDs"] = {
						[23920] = true,
					},
					["cooldown"] = 25,
					["texture"] = 132361,
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 123904,
					["spellIDs"] = {
						[123904] = true,
					},
					["cooldown"] = 180,
					["texture"] = 620832,
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["refSpellID"] = 45438,
					["spellIDs"] = {
						[45438] = true,
					},
					["cooldown"] = 240,
					["texture"] = 135841,
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 204018,
					["spellIDs"] = {
						[204018] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135880,
				},
				["脚踢"] = {
					["enabled"] = true,
					["refSpellID"] = 1766,
					["spellIDs"] = {
						[1766] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132219,
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 18499,
					["spellIDs"] = {
						[18499] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136009,
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202137,
					["spellIDs"] = {
						[202137] = true,
					},
					["cooldown"] = 36,
					["texture"] = 1418288,
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["refSpellID"] = 198664,
					["spellIDs"] = {
						[198664] = true,
					},
					["cooldown"] = 180,
					["texture"] = 877514,
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["refSpellID"] = 194223,
					["spellIDs"] = {
						[194223] = true,
					},
					["cooldown"] = 180,
					["texture"] = 136060,
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 98008,
					["spellIDs"] = {
						[98008] = true,
					},
					["cooldown"] = 180,
					["texture"] = 237586,
				},
				["拳击"] = {
					["enabled"] = true,
					["refSpellID"] = 6552,
					["spellIDs"] = {
						[6552] = true,
					},
					["cooldown"] = 15,
					["texture"] = 132938,
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["refSpellID"] = 211881,
					["spellIDs"] = {
						[211881] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1118739,
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["refSpellID"] = 20572,
					["spellIDs"] = {
						[20572] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135726,
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["refSpellID"] = 59543,
					["spellIDs"] = {
						[59543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135923,
				},
				["宁静"] = {
					["enabled"] = true,
					["refSpellID"] = 740,
					["spellIDs"] = {
						[740] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136107,
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["refSpellID"] = 12975,
					["spellIDs"] = {
						[12975] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135871,
				},
				["缴械"] = {
					["enabled"] = true,
					["refSpellID"] = 236077,
					["spellIDs"] = {
						[236077] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132343,
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 212295,
					["spellIDs"] = {
						[212295] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135796,
				},
				["自然之力"] = {
					["enabled"] = true,
					["refSpellID"] = 205636,
					["spellIDs"] = {
						[205636] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132129,
				},
				["根基图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 204336,
					["spellIDs"] = {
						[204336] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136039,
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["refSpellID"] = 209789,
					["spellIDs"] = {
						[209789] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1033903,
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["refSpellID"] = 184364,
					["spellIDs"] = {
						[184364] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132345,
				},
				["保护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1022,
					["spellIDs"] = {
						[1022] = true,
					},
					["cooldown"] = 135,
					["texture"] = 135964,
				},
				["血之镜像"] = {
					["enabled"] = true,
					["refSpellID"] = 206977,
					["spellIDs"] = {
						[206977] = true,
					},
					["cooldown"] = 120,
					["texture"] = 134084,
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 196932,
					["spellIDs"] = {
						[196932] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136232,
				},
				["平心之环"] = {
					["enabled"] = true,
					["refSpellID"] = 116844,
					["spellIDs"] = {
						[116844] = true,
					},
					["cooldown"] = 45,
					["texture"] = 839107,
				},
				["虚空转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108968,
					["spellIDs"] = {
						[108968] = true,
					},
					["cooldown"] = 300,
					["texture"] = 537079,
				},
				["急速冷却"] = {
					["enabled"] = true,
					["refSpellID"] = 235219,
					["spellIDs"] = {
						[235219] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135865,
				},
				["光环掌握"] = {
					["enabled"] = true,
					["refSpellID"] = 31821,
					["spellIDs"] = {
						[31821] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135872,
				},
				["火箭跳"] = {
					["enabled"] = true,
					["refSpellID"] = 69070,
					["spellIDs"] = {
						[69070] = true,
					},
					["cooldown"] = 120,
					["texture"] = 370769,
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["refSpellID"] = 19386,
					["spellIDs"] = {
						[19386] = true,
					},
					["cooldown"] = 45,
					["texture"] = 135125,
				},
				["伪装"] = {
					["enabled"] = true,
					["refSpellID"] = 199483,
					["spellIDs"] = {
						[199483] = true,
					},
					["cooldown"] = 60,
					["texture"] = 461113,
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["refSpellID"] = 76577,
					["spellIDs"] = {
						[76577] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458733,
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["refSpellID"] = 63560,
					["spellIDs"] = {
						[63560] = true,
					},
					["cooldown"] = 60,
					["texture"] = 342913,
				},
				["抓钩"] = {
					["enabled"] = true,
					["refSpellID"] = 195457,
					["spellIDs"] = {
						[195457] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1373906,
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["refSpellID"] = 205369,
					["spellIDs"] = {
						[205369] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136173,
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["refSpellID"] = 68992,
					["spellIDs"] = {
						[68992] = true,
					},
					["cooldown"] = 120,
					["texture"] = 366937,
				},
				["禁锢"] = {
					["enabled"] = true,
					["refSpellID"] = 221527,
					["spellIDs"] = {
						[221527] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1380368,
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["refSpellID"] = 207349,
					["spellIDs"] = {
						[207349] = true,
					},
					["cooldown"] = 120,
					["texture"] = 298674,
				},
				["责难"] = {
					["enabled"] = true,
					["refSpellID"] = 96231,
					["spellIDs"] = {
						[96231] = true,
					},
					["cooldown"] = 15,
					["texture"] = 523893,
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 202246,
					["spellIDs"] = {
						[202246] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1408833,
				},
				["冲锋"] = {
					["enabled"] = true,
					["refSpellID"] = 100,
					["spellIDs"] = {
						[100] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132337,
				},
				["意气风发"] = {
					["enabled"] = true,
					["refSpellID"] = 109304,
					["spellIDs"] = {
						[109304] = true,
					},
					["cooldown"] = 120,
					["texture"] = 461117,
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 205629,
					["spellIDs"] = {
						[205629] = true,
					},
					["cooldown"] = 30,
					["texture"] = 134294,
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 207736,
					["spellIDs"] = {
						[207736] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1020341,
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["refSpellID"] = 119381,
					["spellIDs"] = {
						[119381] = true,
					},
					["cooldown"] = 60,
					["texture"] = 642414,
				},
				["圣盾术"] = {
					["enabled"] = true,
					["refSpellID"] = 642,
					["spellIDs"] = {
						[642] = true,
					},
					["cooldown"] = 240,
					["texture"] = 524354,
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["refSpellID"] = 7744,
					["spellIDs"] = {
						[7744] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136187,
				},
				["虚空行走"] = {
					["enabled"] = true,
					["refSpellID"] = 196555,
					["spellIDs"] = {
						[196555] = true,
					},
					["cooldown"] = 120,
					["texture"] = 463284,
				},
				["战旗"] = {
					["enabled"] = true,
					["refSpellID"] = 236320,
					["spellIDs"] = {
						[236320] = true,
					},
					["cooldown"] = 90,
					["texture"] = 603532,
				},
				["还击"] = {
					["enabled"] = true,
					["refSpellID"] = 199754,
					["spellIDs"] = {
						[199754] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132269,
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 46924,
					["spellIDs"] = {
						[46924] = true,
					},
					["cooldown"] = 60,
					["texture"] = 236303,
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["refSpellID"] = 152173,
					["spellIDs"] = {
						[152173] = true,
					},
					["cooldown"] = 90,
					["texture"] = 988197,
				},
				["甘霖"] = {
					["enabled"] = true,
					["refSpellID"] = 108238,
					["spellIDs"] = {
						[108238] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136059,
				},
				["决斗"] = {
					["enabled"] = true,
					["refSpellID"] = 236273,
					["spellIDs"] = {
						[236273] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1455893,
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["refSpellID"] = 12472,
					["spellIDs"] = {
						[12472] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135838,
				},
				["百发百中"] = {
					["enabled"] = true,
					["refSpellID"] = 193526,
					["spellIDs"] = {
						[193526] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132329,
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["refSpellID"] = 31224,
					["spellIDs"] = {
						[31224] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136177,
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["refSpellID"] = 205191,
					["spellIDs"] = {
						[205191] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135986,
				},
				["闪回"] = {
					["enabled"] = true,
					["refSpellID"] = 195676,
					["spellIDs"] = {
						[195676] = true,
					},
					["cooldown"] = 24,
					["texture"] = 132171,
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["refSpellID"] = 53271,
					["spellIDs"] = {
						[53271] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236189,
				},
				["从天而降"] = {
					["enabled"] = true,
					["refSpellID"] = 206803,
					["spellIDs"] = {
						[206803] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380371,
				},
				["驱散射击"] = {
					["enabled"] = true,
					["refSpellID"] = 213691,
					["spellIDs"] = {
						[213691] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132153,
				},
				["血魔之握"] = {
					["enabled"] = true,
					["refSpellID"] = 108199,
					["spellIDs"] = {
						[108199] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538767,
				},
				["能量灌注"] = {
					["enabled"] = true,
					["refSpellID"] = 10060,
					["spellIDs"] = {
						[10060] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135939,
				},
				["窒息"] = {
					["enabled"] = true,
					["refSpellID"] = 108194,
					["spellIDs"] = {
						[108194] = true,
					},
					["cooldown"] = 45,
					["texture"] = 538558,
				},
				["卸除武装"] = {
					["enabled"] = true,
					["refSpellID"] = 207777,
					["spellIDs"] = {
						[207777] = true,
					},
					["cooldown"] = 45,
					["texture"] = 236272,
				},
				["升腾"] = {
					["enabled"] = true,
					["refSpellID"] = 114050,
					["spellIDs"] = {
						[114050] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135791,
				},
				["拦截"] = {
					["enabled"] = true,
					["refSpellID"] = 198304,
					["spellIDs"] = {
						[198304] = true,
					},
					["cooldown"] = 17,
					["texture"] = 132365,
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["refSpellID"] = 102359,
					["spellIDs"] = {
						[102359] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538515,
				},
				["树皮术"] = {
					["enabled"] = true,
					["refSpellID"] = 22812,
					["spellIDs"] = {
						[22812] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136097,
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["refSpellID"] = 5484,
					["spellIDs"] = {
						[5484] = true,
					},
					["cooldown"] = 40,
					["texture"] = 607852,
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["refSpellID"] = 89766,
					["spellIDs"] = {
						[89766] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236316,
				},
				["反转魔法"] = {
					["enabled"] = true,
					["refSpellID"] = 205604,
					["spellIDs"] = {
						[205604] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380372,
				},
				["火焰之息"] = {
					["enabled"] = true,
					["refSpellID"] = 115181,
					["spellIDs"] = {
						[115181] = true,
					},
					["cooldown"] = 15,
					["texture"] = 615339,
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["refSpellID"] = 216113,
					["spellIDs"] = {
						[216113] = true,
					},
					["cooldown"] = 45,
					["texture"] = 977169,
				},
				["疾跑"] = {
					["enabled"] = true,
					["refSpellID"] = 2983,
					["spellIDs"] = {
						[2983] = true,
					},
					["cooldown"] = 51,
					["texture"] = 132307,
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["refSpellID"] = 12292,
					["spellIDs"] = {
						[12292] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236304,
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 6940,
					["spellIDs"] = {
						[6940] = true,
					},
					["cooldown"] = 75,
					["texture"] = 135966,
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["refSpellID"] = 88625,
					["spellIDs"] = {
						[88625] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135886,
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["refSpellID"] = 115176,
					["spellIDs"] = {
						[115176] = true,
					},
					["cooldown"] = 150,
					["texture"] = 642417,
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["refSpellID"] = 121471,
					["spellIDs"] = {
						[121471] = true,
					},
					["cooldown"] = 180,
					["texture"] = 376022,
				},
				["冲动"] = {
					["enabled"] = true,
					["refSpellID"] = 13750,
					["spellIDs"] = {
						[13750] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136206,
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["refSpellID"] = 8122,
					["spellIDs"] = {
						[8122] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136184,
				},
				["躯不坏"] = {
					["enabled"] = true,
					["refSpellID"] = 122278,
					["spellIDs"] = {
						[122278] = true,
					},
					["cooldown"] = 120,
					["texture"] = 620827,
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["refSpellID"] = 208683,
					["spellIDs"] = {
						[208683] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1322720,
				},
				["暗影步"] = {
					["enabled"] = true,
					["refSpellID"] = 36554,
					["spellIDs"] = {
						[36554] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132303,
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["refSpellID"] = 213602,
					["spellIDs"] = {
						[213602] = true,
					},
					["cooldown"] = 30,
					["texture"] = 135994,
				},
				["凿击"] = {
					["enabled"] = true,
					["refSpellID"] = 1776,
					["spellIDs"] = {
						[1776] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132155,
				},
				["逃命专家"] = {
					["enabled"] = true,
					["refSpellID"] = 20589,
					["spellIDs"] = {
						[20589] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132309,
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["refSpellID"] = 191427,
					["spellIDs"] = {
						[191427] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1247262,
				},
				["圣疗术"] = {
					["enabled"] = true,
					["refSpellID"] = 633,
					["spellIDs"] = {
						[633] = true,
					},
					["cooldown"] = 600,
					["texture"] = 135928,
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["refSpellID"] = 19574,
					["spellIDs"] = {
						[19574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132127,
				},
				["自由祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 1044,
					["spellIDs"] = {
						[1044] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135968,
				},
				["散魔功"] = {
					["enabled"] = true,
					["refSpellID"] = 122783,
					["spellIDs"] = {
						[122783] = true,
					},
					["cooldown"] = 90,
					["texture"] = 775460,
				},
				["闪光力场"] = {
					["enabled"] = true,
					["refSpellID"] = 204263,
					["spellIDs"] = {
						[204263] = true,
					},
					["cooldown"] = 45,
					["texture"] = 571554,
				},
				["复生"] = {
					["enabled"] = true,
					["refSpellID"] = 20484,
					["spellIDs"] = {
						[20484] = true,
					},
					["cooldown"] = 600,
					["texture"] = 136080,
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 51485,
					["spellIDs"] = {
						[51485] = true,
					},
					["cooldown"] = 30,
					["texture"] = 136100,
				},
				["天灾契约"] = {
					["enabled"] = true,
					["refSpellID"] = 48743,
					["spellIDs"] = {
						[48743] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136146,
				},
				["急奔"] = {
					["enabled"] = true,
					["refSpellID"] = 1850,
					["spellIDs"] = {
						[1850] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132120,
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["refSpellID"] = 157997,
					["spellIDs"] = {
						[157997] = true,
					},
					["cooldown"] = 25,
					["texture"] = 1033909,
				},
				["圣佑术"] = {
					["enabled"] = true,
					["refSpellID"] = 498,
					["spellIDs"] = {
						[498] = true,
					},
					["cooldown"] = 60,
					["texture"] = 524353,
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["refSpellID"] = 47528,
					["spellIDs"] = {
						[47528] = true,
					},
					["cooldown"] = 15,
					["texture"] = 237527,
				},
				["混乱新星"] = {
					["enabled"] = true,
					["refSpellID"] = 179057,
					["spellIDs"] = {
						[179057] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135795,
				},
				["盾墙"] = {
					["enabled"] = true,
					["refSpellID"] = 871,
					["spellIDs"] = {
						[871] = true,
					},
					["cooldown"] = 240,
					["texture"] = 132362,
				},
				["消失"] = {
					["enabled"] = true,
					["refSpellID"] = 1856,
					["spellIDs"] = {
						[1856] = true,
					},
					["cooldown"] = 75,
					["texture"] = 132331,
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 31884,
					["spellIDs"] = {
						[31884] = true,
					},
					["cooldown"] = 120,
					["texture"] = 135875,
				},
				["天神下凡"] = {
					["enabled"] = true,
					["refSpellID"] = 107574,
					["spellIDs"] = {
						[107574] = true,
					},
					["cooldown"] = 90,
					["texture"] = 613534,
				},
				["龙息术"] = {
					["enabled"] = true,
					["refSpellID"] = 31661,
					["spellIDs"] = {
						[31661] = true,
					},
					["cooldown"] = 20,
					["texture"] = 134153,
				},
				["沉默"] = {
					["enabled"] = true,
					["refSpellID"] = 15487,
					["spellIDs"] = {
						[15487] = true,
					},
					["cooldown"] = 45,
					["texture"] = 458230,
				},
				["正中眉心"] = {
					["enabled"] = true,
					["refSpellID"] = 199804,
					["spellIDs"] = {
						[199804] = true,
					},
					["cooldown"] = 20,
					["texture"] = 135610,
				},
				["元素宗师"] = {
					["enabled"] = true,
					["refSpellID"] = 16166,
					["spellIDs"] = {
						[16166] = true,
					},
					["cooldown"] = 120,
					["texture"] = 136027,
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["refSpellID"] = 205630,
					["spellIDs"] = {
						[205630] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1380367,
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["refSpellID"] = 51490,
					["spellIDs"] = {
						[51490] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237589,
				},
				["狂暴"] = {
					["enabled"] = true,
					["refSpellID"] = 26297,
					["spellIDs"] = {
						[26297] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135727,
				},
				["时光护盾"] = {
					["enabled"] = true,
					["refSpellID"] = 198111,
					["spellIDs"] = {
						[198111] = true,
					},
					["cooldown"] = 45,
					["texture"] = 610472,
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["refSpellID"] = 209749,
					["spellIDs"] = {
						[209749] = true,
					},
					["cooldown"] = 30,
					["texture"] = 538516,
				},
				["星界转移"] = {
					["enabled"] = true,
					["refSpellID"] = 108271,
					["spellIDs"] = {
						[108271] = true,
					},
					["cooldown"] = 90,
					["texture"] = 538565,
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 30283,
					["spellIDs"] = {
						[30283] = true,
					},
					["cooldown"] = 30,
					["texture"] = 607865,
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["refSpellID"] = 31687,
					["spellIDs"] = {
						[31687] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135862,
				},
				["宿敌"] = {
					["enabled"] = true,
					["refSpellID"] = 79140,
					["spellIDs"] = {
						[79140] = true,
					},
					["cooldown"] = 90,
					["texture"] = 458726,
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["refSpellID"] = 202370,
					["spellIDs"] = {
						[202370] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1381297,
				},
				["斗转星移"] = {
					["enabled"] = true,
					["refSpellID"] = 202162,
					["spellIDs"] = {
						[202162] = true,
					},
					["cooldown"] = 45,
					["texture"] = 620829,
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["refSpellID"] = 86659,
					["spellIDs"] = {
						[86659] = true,
					},
					["cooldown"] = 300,
					["texture"] = 135919,
				},
				["不灭决心"] = {
					["enabled"] = true,
					["refSpellID"] = 104773,
					["spellIDs"] = {
						[104773] = true,
					},
					["cooldown"] = 150,
					["texture"] = 136150,
				},
				["反制射击"] = {
					["enabled"] = true,
					["refSpellID"] = 147362,
					["spellIDs"] = {
						[147362] = true,
					},
					["cooldown"] = 24,
					["texture"] = 249170,
				},
				["灵体形态"] = {
					["enabled"] = true,
					["refSpellID"] = 210918,
					["spellIDs"] = {
						[210918] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237572,
				},
				["英勇"] = {
					["enabled"] = true,
					["refSpellID"] = 32182,
					["spellIDs"] = {
						[32182] = true,
					},
					["cooldown"] = 60,
					["texture"] = 132313,
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["refSpellID"] = 102793,
					["spellIDs"] = {
						[102793] = true,
					},
					["cooldown"] = 60,
					["texture"] = 571588,
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["refSpellID"] = 187650,
					["spellIDs"] = {
						[187650] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135834,
				},
				["闪电奔涌图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 192058,
					["spellIDs"] = {
						[192058] = true,
					},
					["cooldown"] = 45,
					["texture"] = 136013,
				},
				["幻影打击"] = {
					["enabled"] = true,
					["refSpellID"] = 196718,
					["spellIDs"] = {
						[196718] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1305154,
				},
				["守护之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 47788,
					["spellIDs"] = {
						[47788] = true,
					},
					["cooldown"] = 60,
					["texture"] = 237542,
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["refSpellID"] = 48020,
					["spellIDs"] = {
						[48020] = true,
					},
					["cooldown"] = 30,
					["texture"] = 237560,
				},
				["群体反射"] = {
					["enabled"] = true,
					["refSpellID"] = 213915,
					["spellIDs"] = {
						[213915] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132358,
				},
				["妖术"] = {
					["enabled"] = true,
					["refSpellID"] = 51514,
					["spellIDs"] = {
						[51514] = true,
					},
					["cooldown"] = 10,
					["texture"] = 237579,
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186289,
					["spellIDs"] = {
						[186289] = true,
					},
					["cooldown"] = 120,
					["texture"] = 612363,
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["refSpellID"] = 102543,
					["spellIDs"] = {
						[102543] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["refSpellID"] = 49206,
					["spellIDs"] = {
						[49206] = true,
					},
					["cooldown"] = 180,
					["texture"] = 458967,
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["refSpellID"] = 210256,
					["spellIDs"] = {
						[210256] = true,
					},
					["cooldown"] = 25,
					["texture"] = 135911,
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["refSpellID"] = 108416,
					["spellIDs"] = {
						[108416] = true,
					},
					["cooldown"] = 60,
					["texture"] = 538538,
				},
				["闪现术"] = {
					["enabled"] = true,
					["refSpellID"] = 1953,
					["spellIDs"] = {
						[1953] = true,
					},
					["cooldown"] = 15,
					["texture"] = 135736,
				},
				["压制"] = {
					["enabled"] = true,
					["refSpellID"] = 187707,
					["spellIDs"] = {
						[187707] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1376045,
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["refSpellID"] = 51271,
					["spellIDs"] = {
						[51271] = true,
					},
					["cooldown"] = 60,
					["texture"] = 458718,
				},
				["日光术"] = {
					["enabled"] = true,
					["refSpellID"] = 78675,
					["spellIDs"] = {
						[78675] = true,
					},
					["cooldown"] = 30,
					["texture"] = 252188,
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["refSpellID"] = 108201,
					["spellIDs"] = {
						[108201] = true,
					},
					["cooldown"] = 120,
					["texture"] = 538768,
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["refSpellID"] = 201325,
					["spellIDs"] = {
						[201325] = true,
					},
					["cooldown"] = 180,
					["texture"] = 642417,
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["refSpellID"] = 188501,
					["spellIDs"] = {
						[188501] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1247266,
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["refSpellID"] = 33206,
					["spellIDs"] = {
						[33206] = true,
					},
					["cooldown"] = 210,
					["texture"] = 135936,
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["refSpellID"] = 19236,
					["spellIDs"] = {
						[19236] = true,
					},
					["cooldown"] = 90,
					["texture"] = 237550,
				},
				["肾击"] = {
					["enabled"] = true,
					["refSpellID"] = 408,
					["spellIDs"] = {
						[408] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132298,
				},
				["奥术强化"] = {
					["enabled"] = true,
					["refSpellID"] = 12042,
					["spellIDs"] = {
						[12042] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136048,
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["refSpellID"] = 202138,
					["spellIDs"] = {
						[202138] = true,
					},
					["cooldown"] = 54,
					["texture"] = 1418286,
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["refSpellID"] = 5217,
					["spellIDs"] = {
						[5217] = true,
					},
					["cooldown"] = 30,
					["texture"] = 132242,
				},
				["隐形术"] = {
					["enabled"] = true,
					["refSpellID"] = 66,
					["spellIDs"] = {
						[66] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132220,
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["refSpellID"] = 79206,
					["spellIDs"] = {
						[79206] = true,
					},
					["cooldown"] = 60,
					["texture"] = 451170,
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["refSpellID"] = 77606,
					["spellIDs"] = {
						[77606] = true,
					},
					["cooldown"] = 60,
					["texture"] = 135888,
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["refSpellID"] = 5211,
					["spellIDs"] = {
						[5211] = true,
					},
					["cooldown"] = 50,
					["texture"] = 132114,
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["refSpellID"] = 108280,
					["spellIDs"] = {
						[108280] = true,
					},
					["cooldown"] = 180,
					["texture"] = 538569,
				},
				["台风"] = {
					["enabled"] = true,
					["refSpellID"] = 132469,
					["spellIDs"] = {
						[132469] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236170,
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["refSpellID"] = 198898,
					["spellIDs"] = {
						[198898] = true,
					},
					["cooldown"] = 15,
					["texture"] = 332402,
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["refSpellID"] = 84714,
					["spellIDs"] = {
						[84714] = true,
					},
					["cooldown"] = 60,
					["texture"] = 629077,
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["refSpellID"] = 216331,
					["spellIDs"] = {
						[216331] = true,
					},
					["cooldown"] = 60,
					["texture"] = 589117,
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["refSpellID"] = 69041,
					["spellIDs"] = {
						[69041] = true,
					},
					["cooldown"] = 120,
					["texture"] = 133032,
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["refSpellID"] = 31850,
					["spellIDs"] = {
						[31850] = true,
					},
					["cooldown"] = 110,
					["texture"] = 135870,
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["refSpellID"] = 208253,
					["spellIDs"] = {
						[208253] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1115592,
				},
				["束缚射击"] = {
					["enabled"] = true,
					["refSpellID"] = 109248,
					["spellIDs"] = {
						[109248] = true,
					},
					["cooldown"] = 45,
					["texture"] = 462650,
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["refSpellID"] = 228049,
					["spellIDs"] = {
						[228049] = true,
					},
					["cooldown"] = 180,
					["texture"] = 135919,
				},
				["真言术：障"] = {
					["enabled"] = true,
					["refSpellID"] = 62618,
					["spellIDs"] = {
						[62618] = true,
					},
					["cooldown"] = 120,
					["texture"] = 253400,
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["refSpellID"] = 106839,
					["spellIDs"] = {
						[106839] = true,
					},
					["cooldown"] = 15,
					["texture"] = 236946,
				},
				["瓦解"] = {
					["enabled"] = true,
					["refSpellID"] = 183752,
					["spellIDs"] = {
						[183752] = true,
					},
					["cooldown"] = 15,
					["texture"] = 1305153,
				},
				["战争践踏"] = {
					["enabled"] = true,
					["refSpellID"] = 11876,
					["spellIDs"] = {
						[11876] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132091,
				},
				["割碎"] = {
					["enabled"] = true,
					["refSpellID"] = 22570,
					["spellIDs"] = {
						[22570] = true,
					},
					["cooldown"] = 10,
					["texture"] = 132134,
				},
				["还魂术"] = {
					["enabled"] = true,
					["refSpellID"] = 115310,
					["spellIDs"] = {
						[115310] = true,
					},
					["cooldown"] = 180,
					["texture"] = 1020466,
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["refSpellID"] = 186257,
					["spellIDs"] = {
						[186257] = true,
					},
					["cooldown"] = 180,
					["texture"] = 132242,
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["refSpellID"] = 107570,
					["spellIDs"] = {
						[107570] = true,
					},
					["cooldown"] = 30,
					["texture"] = 613535,
				},
				["疾影"] = {
					["enabled"] = true,
					["refSpellID"] = 198589,
					["spellIDs"] = {
						[198589] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1305150,
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["refSpellID"] = 6544,
					["spellIDs"] = {
						[6544] = true,
					},
					["cooldown"] = 30,
					["texture"] = 236171,
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["refSpellID"] = 64044,
					["spellIDs"] = {
						[64044] = true,
					},
					["cooldown"] = 45,
					["texture"] = 237568,
				},
				["逃脱"] = {
					["enabled"] = true,
					["refSpellID"] = 781,
					["spellIDs"] = {
						[781] = true,
					},
					["cooldown"] = 20,
					["texture"] = 132294,
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["refSpellID"] = 105809,
					["spellIDs"] = {
						[105809] = true,
					},
					["cooldown"] = 90,
					["texture"] = 571555,
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["refSpellID"] = 207319,
					["spellIDs"] = {
						[207319] = true,
					},
					["cooldown"] = 60,
					["texture"] = 1531513,
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["refSpellID"] = 215769,
					["spellIDs"] = {
						[215769] = true,
					},
					["cooldown"] = 300,
					["texture"] = 132864,
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["refSpellID"] = 33891,
					["spellIDs"] = {
						[33891] = true,
					},
					["cooldown"] = 180,
					["texture"] = 236157,
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["refSpellID"] = 5246,
					["spellIDs"] = {
						[5246] = true,
					},
					["cooldown"] = 90,
					["texture"] = 132154,
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["refSpellID"] = 186387,
					["spellIDs"] = {
						[186387] = true,
					},
					["cooldown"] = 30,
					["texture"] = 1376038,
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["refSpellID"] = 205691,
					["spellIDs"] = {
						[205691] = true,
					},
					["cooldown"] = 120,
					["texture"] = 1412204,
				},
				["风火雷电"] = {
					["enabled"] = true,
					["refSpellID"] = 137639,
					["spellIDs"] = {
						[137639] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136038,
				},
				["法术反制"] = {
					["enabled"] = true,
					["refSpellID"] = 2139,
					["spellIDs"] = {
						[2139] = true,
					},
					["cooldown"] = 24,
					["texture"] = 135856,
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["refSpellID"] = 119996,
					["spellIDs"] = {
						[119996] = true,
					},
					["cooldown"] = 25,
					["texture"] = 237585,
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["refSpellID"] = 190784,
					["spellIDs"] = {
						[190784] = true,
					},
					["cooldown"] = 45,
					["texture"] = 1360759,
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["refSpellID"] = 102560,
					["spellIDs"] = {
						[102560] = true,
					},
					["cooldown"] = 180,
					["texture"] = 571586,
				},
				["影遁"] = {
					["enabled"] = true,
					["refSpellID"] = 58984,
					["spellIDs"] = {
						[58984] = true,
					},
					["cooldown"] = 120,
					["texture"] = 132089,
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["refSpellID"] = 1122,
					["spellIDs"] = {
						[1122] = true,
					},
					["cooldown"] = 60,
					["texture"] = 136219,
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["refSpellID"] = 212459,
					["spellIDs"] = {
						[212459] = true,
					},
					["cooldown"] = 90,
					["texture"] = 1113433,
				},
				["唤醒"] = {
					["enabled"] = true,
					["refSpellID"] = 12051,
					["spellIDs"] = {
						[12051] = true,
					},
					["cooldown"] = 90,
					["texture"] = 136075,
				},
			},
			["DBVersion"] = 8,
		},
		["ENNYIN"] = {
			["ShowCooldownsOnCurrentTargetOnly"] = true,
			["IconSortMode"] = "interrupt-trinket-other",
			["SpellCDs"] = {
				["装死"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 360,
					["spellIDs"] = {
						[31230] = true,
					},
				},
				["法术反制"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 24,
					["spellIDs"] = {
						[2139] = true,
					},
				},
				["天灾契约"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 120,
					["spellIDs"] = {
						[48743] = true,
					},
				},
				["爆裂射击"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[186387] = true,
					},
				},
				["玄牛砮皂"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[132578] = true,
					},
				},
				["巨龙冲锋"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 20,
					["spellIDs"] = {
						[206572] = true,
					},
				},
				["巨人打击"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 45,
					["spellIDs"] = {
						[167105] = true,
					},
				},
				["震荡波"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 25,
					["spellIDs"] = {
						[46968] = true,
					},
				},
				["谈判"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 20,
					["spellIDs"] = {
						[199743] = true,
					},
				},
				["荣誉勋章"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[195710] = true,
					},
				},
				["致盲冰雨"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 60,
					["spellIDs"] = {
						[207167] = true,
					},
				},
				["超级新星"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 25,
					["spellIDs"] = {
						[157980] = true,
					},
				},
				["寒冰形态"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 60,
					["spellIDs"] = {
						[198144] = true,
					},
				},
				["莱欧瑟拉斯之眼"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[206650] = true,
					},
				},
				["冰封之韧"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 165,
					["spellIDs"] = {
						[48792] = true,
					},
				},
				["化身：乌索克的守护者"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[102558] = true,
					},
				},
				["思维窃取"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 90,
					["spellIDs"] = {
						[316262] = true,
					},
				},
				["死亡之握"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 20,
					["spellIDs"] = {
						[49576] = true,
					},
				},
				["制裁之锤"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 60,
					["spellIDs"] = {
						[853] = true,
					},
				},
				["狂暴"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[26297] = true,
					},
				},
				["作茧缚命"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 65,
					["spellIDs"] = {
						[116849] = true,
					},
				},
				["血性狂暴"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 20,
					["spellIDs"] = {
						[329038] = true,
					},
				},
				["打磨利刃"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 25,
					["spellIDs"] = {
						[198817] = true,
					},
				},
				["风火雷电"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[137639] = true,
					},
				},
				["墓石"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[219809] = true,
					},
				},
				["天启"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 30,
					["spellIDs"] = {
						[275699] = true,
					},
				},
				["牺牲"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[7812] = true,
					},
				},
				["影舞步"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[51690] = true,
					},
				},
				["黑暗再生"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[108359] = true,
					},
				},
				["铁木树皮"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 90,
					["spellIDs"] = {
						[102342] = true,
					},
				},
				["亡者大军"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 240,
					["spellIDs"] = {
						[42650] = true,
					},
				},
				["掠夺护甲"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[198529] = true,
					},
				},
				["反魔法领域"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 120,
					["spellIDs"] = {
						[51052] = true,
					},
				},
				["消散"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 90,
					["spellIDs"] = {
						[47585] = true,
					},
				},
				["冰霜新星"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 30,
					["spellIDs"] = {
						[122] = true,
					},
				},
				["轮回之触"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 144,
					["spellIDs"] = {
						[115080] = true,
					},
				},
				["反魔法护罩"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 40,
					["spellIDs"] = {
						[48707] = true,
					},
				},
				["束缚射击"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[109248] = true,
					},
				},
				["夺魂咆哮"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 30,
					["spellIDs"] = {
						[99] = true,
					},
				},
				["鲁莽"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 90,
					["spellIDs"] = {
						[1719] = true,
					},
				},
				["游侠之网"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[200108] = true,
					},
				},
				["虚空联结"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[207810] = true,
					},
				},
				["摧心魔"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[123040] = true,
					},
				},
				["风剪"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 9,
					["spellIDs"] = {
						[57994] = true,
					},
				},
				["灭战者"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 45,
					["spellIDs"] = {
						[262161] = true,
					},
				},
				["符文刃舞"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 60,
					["spellIDs"] = {
						[49028] = true,
					},
				},
				["石像形态"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[20594] = true,
					},
				},
				["壮胆酒"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[201318] = true,
					},
				},
				["禅意聚神茶"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[209584] = true,
					},
				},
				["野性狼魂"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 90,
					["spellIDs"] = {
						[51533] = true,
					},
				},
				["强化隐形术"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 75,
					["spellIDs"] = {
						[110959] = true,
					},
				},
				["剑在人在"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 120,
					["spellIDs"] = {
						[118038] = true,
					},
				},
				["自利"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[59752] = true,
					},
				},
				["反击图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 45,
					["spellIDs"] = {
						[204331] = true,
					},
				},
				["悲苦咒符"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[207684] = true,
					},
				},
				["阵风"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 15,
					["spellIDs"] = {
						[192063] = true,
					},
				},
				["分筋错骨"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[115078] = true,
					},
				},
				["切喉手"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 15,
					["spellIDs"] = {
						[116705] = true,
					},
				},
				["法术封锁"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 24,
					["spellIDs"] = {
						[19647] = true,
					},
				},
				["眼棱爆炸"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 24,
					["spellIDs"] = {
						[115781] = true,
					},
				},
				["奥术洪流"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[80483] = true,
					},
				},
				["寒冰护体"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 25,
					["spellIDs"] = {
						[11426] = true,
					},
				},
				["圣光护盾"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[204150] = true,
					},
				},
				["魔刃风暴"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 45,
					["spellIDs"] = {
						[89751] = true,
					},
				},
				["死亡缠绕"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[6789] = true,
					},
				},
				["生存本能"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 180,
					["spellIDs"] = {
						[61336] = true,
					},
				},
				["猩红之瓶"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 25,
					["spellIDs"] = {
						[185311] = true,
					},
				},
				["镜像"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[55342] = true,
					},
				},
				["闪避"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[5277] = true,
					},
				},
				["神圣马驹"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[190784] = true,
					},
				},
				["死亡脚步"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 45,
					["spellIDs"] = {
						[48265] = true,
					},
				},
				["追踪者之网"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 25,
					["spellIDs"] = {
						[212638] = true,
					},
				},
				["毒蛇猎手"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[201078] = true,
					},
				},
				["天神下凡"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 90,
					["spellIDs"] = {
						[107574] = true,
					},
				},
				["胁迫"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 60,
					["spellIDs"] = {
						[19577] = true,
					},
				},
				["蹒跚冲锋"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 30,
					["spellIDs"] = {
						[91802] = true,
					},
				},
				["燃烧"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[190319] = true,
					},
				},
				["先祖护佑图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 300,
					["spellIDs"] = {
						[207399] = true,
					},
				},
				["涅墨西斯"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[206491] = true,
					},
				},
				["PvP饰品"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[42292] = true,
					},
				},
				["沉睡者之怒"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[200851] = true,
					},
				},
				["法术反射"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 25,
					["spellIDs"] = {
						[23920] = true,
					},
				},
				["裂地术"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 40,
					["spellIDs"] = {
						[197214] = true,
					},
				},
				["白虎下凡"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 90,
					["spellIDs"] = {
						[123904] = true,
					},
				},
				["寒冰屏障"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 210,
					["spellIDs"] = {
						[45438] = true,
					},
				},
				["时光护盾"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 45,
					["spellIDs"] = {
						[198111] = true,
					},
				},
				["脚踢"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 15,
					["spellIDs"] = {
						[1766] = true,
					},
				},
				["神圣晋升"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 60,
					["spellIDs"] = {
						[328530] = true,
					},
				},
				["狂暴之怒"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 60,
					["spellIDs"] = {
						[18499] = true,
					},
				},
				["沉默咒符"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[202137] = true,
					},
				},
				["朱鹤赤精"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[198664] = true,
					},
				},
				["超凡之盟"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[194223] = true,
					},
				},
				["灵魂链接图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[98008] = true,
					},
				},
				["征伐"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 120,
					["spellIDs"] = {
						[231895] = true,
					},
				},
				["邪能爆发"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[211881] = true,
					},
				},
				["血性狂怒"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[33697] = true,
					},
				},
				["召唤邪能领主"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 90,
					["spellIDs"] = {
						[212459] = true,
					},
				},
				["宁静"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 66,
					["spellIDs"] = {
						[740] = true,
					},
				},
				["急奔"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 120,
					["spellIDs"] = {
						[1850] = true,
					},
				},
				["缴械"] = {
					["enabled"] = false,
					["class"] = "WARRIOR",
					["cooldown"] = 45,
					["spellIDs"] = {
						[236077] = true,
					},
				},
				["虚空守卫"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[212295] = true,
					},
				},
				["自然之力"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[205636] = true,
					},
				},
				["盲目之光"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 90,
					["spellIDs"] = {
						[115750] = true,
					},
				},
				["根基图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[204336] = true,
					},
				},
				["精灵虫群"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 30,
					["spellIDs"] = {
						[209749] = true,
					},
				},
				["狂怒回复"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 120,
					["spellIDs"] = {
						[184364] = true,
					},
				},
				["保护祝福"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 225,
					["spellIDs"] = {
						[1022] = true,
					},
				},
				["血之镜像"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[206977] = true,
					},
				},
				["巫毒图腾"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[196932] = true,
					},
				},
				["平心之环"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[116844] = true,
					},
				},
				["虚空转移"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 300,
					["spellIDs"] = {
						[108968] = true,
					},
				},
				["急速冷却"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 270,
					["spellIDs"] = {
						[235219] = true,
					},
				},
				["光环掌握"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[31821] = true,
					},
				},
				["火箭跳"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[69070] = true,
					},
				},
				["翼龙钉刺"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 45,
					["spellIDs"] = {
						[19386] = true,
					},
				},
				["伪装"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 60,
					["spellIDs"] = {
						[199483] = true,
					},
				},
				["雄鹰守护"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[186289] = true,
					},
				},
				["黑暗突变"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[63560] = true,
					},
				},
				["抓钩"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 30,
					["spellIDs"] = {
						[195457] = true,
					},
				},
				["心灵炸弹"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 30,
					["spellIDs"] = {
						[205369] = true,
					},
				},
				["圣佑术"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[498] = true,
					},
				},
				["禁锢"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[221527] = true,
					},
				},
				["黑暗仲裁者"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[207349] = true,
					},
				},
				["责难"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 15,
					["spellIDs"] = {
						[96231] = true,
					},
				},
				["蛮力冲锋"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 25,
					["spellIDs"] = {
						[202246] = true,
					},
				},
				["冲锋"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 20,
					["spellIDs"] = {
						[100] = true,
					},
				},
				["意气风发"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 96,
					["spellIDs"] = {
						[109304] = true,
					},
				},
				["恶魔践踏"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 20,
					["spellIDs"] = {
						[205629] = true,
					},
				},
				["暗影决斗"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[207736] = true,
					},
				},
				["扫堂腿"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[119381] = true,
					},
				},
				["圣盾术"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 120,
					["spellIDs"] = {
						[642] = true,
					},
				},
				["被遗忘者的意志"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[7744] = true,
					},
				},
				["虚空行走"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 180,
					["spellIDs"] = {
						[196555] = true,
					},
				},
				["战旗"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 90,
					["spellIDs"] = {
						[236320] = true,
					},
				},
				["还击"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[199754] = true,
					},
				},
				["狂风图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 120,
					["spellIDs"] = {
						[192077] = true,
					},
				},
				["剑刃风暴"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 60.3,
					["spellIDs"] = {
						[227847] = true,
					},
				},
				["伊利丹之握"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 60,
					["spellIDs"] = {
						[205630] = true,
					},
				},
				["甘霖"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 90,
					["spellIDs"] = {
						[108238] = true,
					},
				},
				["决斗"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 60,
					["spellIDs"] = {
						[236273] = true,
					},
				},
				["锁链咒符"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 67.5,
					["spellIDs"] = {
						[202138] = true,
					},
				},
				["百发百中"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[193526] = true,
					},
				},
				["暗影斗篷"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[31224] = true,
					},
				},
				["以眼还眼"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 60,
					["spellIDs"] = {
						[205191] = true,
					},
				},
				["群体反射"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[213915] = true,
					},
				},
				["潜伏帷幕"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 360,
					["spellIDs"] = {
						[114018] = true,
					},
				},
				["主人的召唤"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[53271] = true,
					},
				},
				["从天而降"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 60,
					["spellIDs"] = {
						[206803] = true,
					},
				},
				["恐惧之刃"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 90,
					["spellIDs"] = {
						[343142] = true,
					},
				},
				["驱散射击"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[213691] = true,
					},
				},
				["血魔之握"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 90,
					["spellIDs"] = {
						[108199] = true,
					},
				},
				["能量灌注"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 120,
					["spellIDs"] = {
						[10060] = true,
					},
				},
				["窒息"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 45,
					["spellIDs"] = {
						[47476] = true,
					},
				},
				["卸除武装"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 45,
					["spellIDs"] = {
						[207777] = true,
					},
				},
				["升腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[114050] = true,
					},
				},
				["拦截"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 20,
					["spellIDs"] = {
						[198304] = true,
					},
				},
				["施法之环"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 60,
					["spellIDs"] = {
						[221703] = true,
					},
				},
				["闪现术"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 15,
					["spellIDs"] = {
						[1953] = true,
					},
				},
				["树皮术"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 34.2,
					["spellIDs"] = {
						[22812] = true,
					},
				},
				["恐惧嚎叫"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 40,
					["spellIDs"] = {
						[5484] = true,
					},
				},
				["巨斧投掷"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[89766] = true,
					},
				},
				["反转魔法"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 60,
					["spellIDs"] = {
						[205604] = true,
					},
				},
				["火焰之息"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 15,
					["spellIDs"] = {
						[115181] = true,
					},
				},
				["仙鹤之道"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[216113] = true,
					},
				},
				["疾跑"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 60,
					["spellIDs"] = {
						[2983] = true,
					},
				},
				["浴血奋战"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[12292] = true,
					},
				},
				["牺牲祝福"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 72,
					["spellIDs"] = {
						[6940] = true,
					},
				},
				["化身：生命之树"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[33891] = true,
					},
				},
				["禅悟冥想"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 75,
					["spellIDs"] = {
						[115176] = true,
					},
				},
				["暗影之刃"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 180,
					["spellIDs"] = {
						[121471] = true,
					},
				},
				["冲动"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 180,
					["spellIDs"] = {
						[13750] = true,
					},
				},
				["心灵尖啸"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 30,
					["spellIDs"] = {
						[8122] = true,
					},
				},
				["躯不坏"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 120,
					["spellIDs"] = {
						[122278] = true,
					},
				},
				["蜘蛛钉刺"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[202914] = true,
					},
				},
				["角斗士勋章"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[208683] = true,
						[336126] = true,
					},
				},
				["蛮力猛击"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 54,
					["spellIDs"] = {
						[5211] = true,
					},
				},
				["暗影步"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 22,
					["spellIDs"] = {
						[36554] = true,
					},
				},
				["暗影之怒"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[30283] = true,
					},
				},
				["血肉之盾"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[207319] = true,
					},
				},
				["强化渐隐术"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 45,
					["spellIDs"] = {
						[213602] = true,
					},
				},
				["凿击"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 15,
					["spellIDs"] = {
						[1776] = true,
					},
				},
				["群兽奔腾"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 120,
					["spellIDs"] = {
						[201430] = true,
					},
				},
				["协同进攻"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 96,
					["spellIDs"] = {
						[266779] = true,
					},
				},
				["灵龟守护"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 144,
					["spellIDs"] = {
						[186265] = true,
					},
				},
				["逃命专家"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[20589] = true,
					},
				},
				["神圣赞美诗"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 180,
					["spellIDs"] = {
						[64843] = true,
					},
				},
				["混乱新星"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 40,
					["spellIDs"] = {
						[179057] = true,
					},
				},
				["恶魔变形"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 75,
					["spellIDs"] = {
						[191427] = true,
					},
				},
				["化身：艾露恩之眷"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[102560] = true,
					},
				},
				["冰霜之环"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 45,
					["spellIDs"] = {
						[113724] = true,
					},
				},
				["黑暗契约"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 60,
					["spellIDs"] = {
						[108416] = true,
					},
				},
				["沉默"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 30,
					["spellIDs"] = {
						[15487] = true,
					},
				},
				["召唤地狱猎犬"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 24,
					["spellIDs"] = {
						[212619] = true,
					},
				},
				["心灵惊骇"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 45,
					["spellIDs"] = {
						[64044] = true,
					},
				},
				["庇护祝福"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 45,
					["spellIDs"] = {
						[210256] = true,
					},
				},
				["自由祝福"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 18.75,
					["spellIDs"] = {
						[1044] = true,
					},
				},
				["烟雾弹"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 180,
					["spellIDs"] = {
						[212182] = true,
					},
				},
				["猛虎之怒"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[5217] = true,
					},
				},
				["火焰石"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 25,
					["spellIDs"] = {
						[212284] = true,
					},
				},
				["鱼叉猛刺"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[190925] = true,
					},
				},
				["散魔功"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 90,
					["spellIDs"] = {
						[122783] = true,
					},
				},
				["神圣复仇者"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[105809] = true,
					},
				},
				["英勇飞跃"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 30,
					["spellIDs"] = {
						[6544] = true,
					},
				},
				["野性之心"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 300,
					["spellIDs"] = {
						[319454] = true,
					},
				},
				["治疗之潮图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[108280] = true,
					},
				},
				["暗影之舞"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 60,
					["spellIDs"] = {
						[185313] = true,
					},
				},
				["寒冰新星"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 25,
					["spellIDs"] = {
						[157997] = true,
					},
				},
				["幻影打击"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[196718] = true,
					},
				},
				["心灵冰冻"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 15,
					["spellIDs"] = {
						[47528] = true,
					},
				},
				["巫妖之躯"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 120,
					["spellIDs"] = {
						[49039] = true,
					},
				},
				["盾墙"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 140,
					["spellIDs"] = {
						[871] = true,
					},
				},
				["割碎"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 20,
					["spellIDs"] = {
						[22570] = true,
					},
				},
				["陷地图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[51485] = true,
					},
				},
				["化身：丛林之王"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 126,
					["spellIDs"] = {
						[102543] = true,
					},
				},
				["抓钩武器"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 45,
					["spellIDs"] = {
						[233759] = true,
					},
				},
				["照明弹"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 20,
					["spellIDs"] = {
						[1543] = true,
					},
				},
				["破釜沉舟"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 36,
					["spellIDs"] = {
						[12975] = true,
					},
				},
				["元素宗师"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[16166] = true,
					},
				},
				["生存意志"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[59752] = true,
					},
				},
				["雷霆风暴"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[51490] = true,
					},
				},
				["纳鲁的赐福"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[59543] = true,
					},
				},
				["还魂术"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[115310] = true,
					},
				},
				["战栗图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 59,
					["spellIDs"] = {
						[8143] = true,
					},
				},
				["星界转移"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 90,
					["spellIDs"] = {
						[108271] = true,
					},
				},
				["猎豹守护"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[186257] = true,
					},
				},
				["召唤水元素"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[31687] = true,
					},
				},
				["宿敌"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[79140] = true,
					},
				},
				["蛮牛踢"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[202370] = true,
					},
				},
				["斗转星移"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 45,
					["spellIDs"] = {
						[202162] = true,
					},
				},
				["远古列王守卫"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 215,
					["spellIDs"] = {
						[86659] = true,
					},
				},
				["英勇"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 60,
					["spellIDs"] = {
						[32182] = true,
					},
				},
				["反制射击"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 24,
					["spellIDs"] = {
						[147362] = true,
					},
				},
				["灵体形态"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 45,
					["spellIDs"] = {
						[210918] = true,
					},
				},
				["肾击"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 20,
					["spellIDs"] = {
						[408] = true,
					},
				},
				["乌索尔旋风"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 60,
					["spellIDs"] = {
						[102793] = true,
					},
				},
				["冰冻陷阱"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 25,
					["spellIDs"] = {
						[187650] = true,
					},
				},
				["圣疗术"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 300,
					["spellIDs"] = {
						[633] = true,
					},
				},
				["信仰飞跃"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 90,
					["spellIDs"] = {
						[73325] = true,
					},
				},
				["守护之魂"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 120,
					["spellIDs"] = {
						[47788] = true,
					},
				},
				["恶魔法阵：传送"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[48020] = true,
					},
				},
				["致盲"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 90,
					["spellIDs"] = {
						[2094] = true,
					},
				},
				["群体缠绕"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 27,
					["spellIDs"] = {
						[102359] = true,
					},
				},
				["被遗忘的女王护卫"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 180,
					["spellIDs"] = {
						[228049] = true,
					},
				},
				["神圣守卫"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 30,
					["spellIDs"] = {
						[213610] = true,
					},
				},
				["闪光力场"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 45,
					["spellIDs"] = {
						[204263] = true,
					},
				},
				["闪电磁索"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[204437] = true,
					},
				},
				["魂体双分：转移"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 25,
					["spellIDs"] = {
						[119996] = true,
					},
				},
				["疾步夜行"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[68992] = true,
					},
				},
				["日光术"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 40,
					["spellIDs"] = {
						[78675] = true,
					},
				},
				["复仇十字军"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 120,
					["spellIDs"] = {
						[216331] = true,
					},
				},
				["邪恶之地"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 60,
					["spellIDs"] = {
						[108201] = true,
					},
				},
				["炽热防御者"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 84,
					["spellIDs"] = {
						[31850] = true,
					},
				},
				["黑暗模拟"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 20,
					["spellIDs"] = {
						[77606] = true,
					},
				},
				["火箭弹幕"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[69041] = true,
					},
				},
				["痛苦压制"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 60,
					["spellIDs"] = {
						[33206] = true,
					},
				},
				["禅意时刻"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 45,
					["spellIDs"] = {
						[201325] = true,
					},
				},
				["幽灵视觉"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[188501] = true,
					},
				},
				["奥术强化"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 120,
					["spellIDs"] = {
						[12042] = true,
					},
				},
				["龙息术"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 18,
					["spellIDs"] = {
						[31661] = true,
					},
				},
				["救赎之魂"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[215769] = true,
					},
				},
				["操控时间"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 30,
					["spellIDs"] = {
						[108978] = true,
					},
				},
				["灵魂行者的恩赐"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 60,
					["spellIDs"] = {
						[79206] = true,
					},
				},
				["拳击"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 15,
					["spellIDs"] = {
						[6552] = true,
					},
				},
				["复生"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 600,
					["spellIDs"] = {
						[20484] = true,
					},
				},
				["冰冻之箭"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 30,
					["spellIDs"] = {
						[209789] = true,
					},
				},
				["台风"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 30,
					["spellIDs"] = {
						[132469] = true,
					},
				},
				["赤精之歌"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 30,
					["spellIDs"] = {
						[198898] = true,
					},
				},
				["寒冰宝珠"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 60,
					["spellIDs"] = {
						[84714] = true,
					},
				},
				["绝望祷言"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 90,
					["spellIDs"] = {
						[19236] = true,
					},
				},
				["嗜血"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 60,
					["spellIDs"] = {
						[2825] = true,
					},
				},
				["召唤石像鬼"] = {
					["enabled"] = true,
					["class"] = "DEATHKNIGHT",
					["cooldown"] = 160,
					["spellIDs"] = {
						[49206] = true,
					},
				},
				["加尼尔的精华"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 90,
					["spellIDs"] = {
						[208253] = true,
					},
				},
				["正中眉心"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 30,
					["spellIDs"] = {
						[199804] = true,
					},
				},
				["电能图腾"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 59,
					["spellIDs"] = {
						[192058] = true,
					},
				},
				["真言术：障"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 90,
					["spellIDs"] = {
						[62618] = true,
					},
				},
				["迎头痛击"] = {
					["enabled"] = true,
					["class"] = "DRUID",
					["cooldown"] = 15,
					["spellIDs"] = {
						[106839] = true,
					},
				},
				["瓦解"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 15,
					["spellIDs"] = {
						[183752] = true,
					},
				},
				["战争践踏"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[11876] = true,
					},
				},
				["妖术"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 10,
					["spellIDs"] = {
						[51514] = true,
					},
				},
				["冰霜之柱"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 45,
					["spellIDs"] = {
						[51271] = true,
					},
				},
				["闪回"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 30,
					["spellIDs"] = {
						[195676] = true,
					},
				},
				["风暴之锤"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 30,
					["spellIDs"] = {
						[107570] = true,
					},
				},
				["疾影"] = {
					["enabled"] = true,
					["class"] = "DEMONHUNTER",
					["cooldown"] = 45,
					["spellIDs"] = {
						[198589] = true,
					},
				},
				["不灭决心"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 180,
					["spellIDs"] = {
						[104773] = true,
					},
				},
				["隐形术"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 300,
					["spellIDs"] = {
						[66] = true,
					},
				},
				["逃脱"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 20,
					["spellIDs"] = {
						[781] = true,
					},
				},
				["狂野扑击"] = {
					["enabled"] = true,
					["class"] = "SHAMAN",
					["cooldown"] = 30,
					["spellIDs"] = {
						[196884] = true,
					},
				},
				["狂野怒火"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 76.5,
					["spellIDs"] = {
						[19574] = true,
					},
				},
				["消失"] = {
					["enabled"] = true,
					["class"] = "ROGUE",
					["cooldown"] = 75,
					["spellIDs"] = {
						[1856] = true,
					},
				},
				["圣言术：罚"] = {
					["enabled"] = true,
					["class"] = "PRIEST",
					["cooldown"] = 60,
					["spellIDs"] = {
						[88625] = true,
					},
				},
				["破胆怒吼"] = {
					["enabled"] = true,
					["class"] = "WARRIOR",
					["cooldown"] = 90,
					["spellIDs"] = {
						[5246] = true,
					},
				},
				["压制"] = {
					["enabled"] = true,
					["class"] = "HUNTER",
					["cooldown"] = 15,
					["spellIDs"] = {
						[187707] = true,
					},
				},
				["凶暴野兽：蜥蜴"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[205691] = true,
					},
				},
				["复仇之怒"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 120,
					["spellIDs"] = {
						[31884] = true,
					},
				},
				["唤醒"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 180,
					["spellIDs"] = {
						[12051] = true,
					},
				},
				["闪光术"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 25,
					["spellIDs"] = {
						[212653] = true,
					},
				},
				["破咒祝福"] = {
					["enabled"] = true,
					["class"] = "PALADIN",
					["cooldown"] = 108,
					["spellIDs"] = {
						[204018] = true,
					},
				},
				["屏气凝神"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 90,
					["spellIDs"] = {
						[152173] = true,
					},
				},
				["影遁"] = {
					["enabled"] = true,
					["class"] = "MISC",
					["cooldown"] = 120,
					["spellIDs"] = {
						[58984] = true,
					},
				},
				["召唤地狱火"] = {
					["enabled"] = true,
					["class"] = "WARLOCK",
					["cooldown"] = 60,
					["spellIDs"] = {
						[1122] = true,
					},
				},
				["冰冷血脉"] = {
					["enabled"] = true,
					["class"] = "MAGE",
					["cooldown"] = 180,
					["spellIDs"] = {
						[12472] = true,
					},
				},
				["业报之触"] = {
					["enabled"] = true,
					["class"] = "MONK",
					["cooldown"] = 90,
					["spellIDs"] = {
						[122470] = true,
					},
				},
			},
			["MigrationVersion"] = 6,
			["IconSize"] = 19,
			["TimerTextUseRelativeScale"] = false,
			["DBVersion"] = 11,
			["FontScale"] = 1.4,
			["IconYOffset"] = 66,
			["Font"] = "默认",
			["TimerTextSize"] = 12,
			["TimerTextColor"] = {
				0.7019607843137254, -- [1]
			},
			["TimerTextYOffset"] = -5,
		},
	},
}
