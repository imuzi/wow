
DCT_SAVE = {
}
DCT_FONT_SAVE = {
	{
		["path"] = "Fonts\\bLEI00D.TTF",
		["name"] = "系統主字型",
		["active"] = true,
	}, -- [1]
	{
		["path"] = "Fonts\\bKAI00M.TTF",
		["name"] = "戰鬥字型",
		["active"] = true,
	}, -- [2]
	{
		["path"] = "Fonts\\bHEI00M.TTF",
		["name"] = "物品訊息字型",
		["active"] = true,
	}, -- [3]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [4]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [5]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [6]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [7]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [8]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [9]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [10]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [11]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [12]
}
