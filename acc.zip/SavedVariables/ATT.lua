
ATTDB = {
	["classSelected"] = "WARRIOR",
	["growLeft"] = false,
	["scale"] = 0.5,
	["showSelf"] = false,
	["tworows"] = false,
	["offsetX"] = -8,
	["lock"] = true,
	["Trinkets"] = {
		["emblem"] = true,
		["pvptrinket"] = true,
	},
	["positions"] = {
		{
			["y"] = -323.2437548167072,
			["x"] = 402.1778868522924,
		}, -- [1]
		{
			["y"] = -374.4440973765268,
			["x"] = 402.1777403679153,
		}, -- [2]
		{
			["y"] = -423.5106264279875,
			["x"] = 402.1777159538524,
		}, -- [3]
		{
			["y"] = -460.4885566665016,
			["x"] = 400.0445860392538,
		}, -- [4]
		{
			["y"] = -400.7556700342248,
			["x"] = 326.8002001822024,
		}, -- [5]
	},
	["glow"] = true,
	["arena"] = true,
	["offsetY"] = 0,
	["attach"] = 0,
	["iconOffsetY"] = 0,
	["Essence"] = {
	},
	["outside"] = true,
	["hidden"] = false,
	["dungeons"] = true,
	["version"] = 9.5,
	["abilities"] = {
		["HUNTER"] = {
			["254"] = {
				{
					["ability"] = "反制射击",
					["cooldown"] = 24,
					["id"] = 147362,
				}, -- [1]
			},
			["255"] = {
			},
			["253"] = {
				{
					["ability"] = "反制射击",
					["cooldown"] = 24,
					["id"] = 147362,
				}, -- [1]
			},
			["ALL"] = {
				{
					["ability"] = "灵龟守护",
					["cooldown"] = 180,
					["id"] = 186265,
				}, -- [1]
				{
					["ability"] = "冰冻陷阱",
					["cooldown"] = 30,
					["id"] = 187650,
				}, -- [2]
				{
					["ability"] = "牺牲咆哮",
					["cooldown"] = 60,
					["id"] = 53480,
				}, -- [3]
				{
					["ability"] = "假死",
					["cooldown"] = 30,
					["id"] = 5384,
				}, -- [4]
				{
					["ability"] = "意气风发",
					["cooldown"] = 120,
					["id"] = 109304,
				}, -- [5]
				{
					["ability"] = "夺命黑鸦",
					["cooldown"] = 60,
					["id"] = 131894,
				}, -- [6]
			},
		},
		["WARRIOR"] = {
			["71"] = {
				{
					["ability"] = "破胆怒吼",
					["cooldown"] = 90,
					["id"] = 5246,
				}, -- [1]
				{
					["ability"] = "剑在人在",
					["cooldown"] = 180,
					["id"] = 118038,
				}, -- [2]
				{
					["ability"] = "天神下凡",
					["cooldown"] = 90,
					["id"] = 107574,
				}, -- [3]
			},
			["72"] = {
				{
					["ability"] = "破胆怒吼",
					["cooldown"] = 90,
					["id"] = 5246,
				}, -- [1]
				{
					["ability"] = "鲁莽",
					["cooldown"] = 90,
					["id"] = 1719,
				}, -- [2]
				{
					["ability"] = "剑刃风暴",
					["cooldown"] = 60,
					["id"] = 46924,
				}, -- [3]
			},
			["73"] = {
			},
			["ALL"] = {
				{
					["ability"] = "拳击",
					["cooldown"] = 15,
					["id"] = 6552,
				}, -- [1]
				{
					["ability"] = "缴械",
					["cooldown"] = 45,
					["id"] = 236077,
				}, -- [2]
				{
					["ability"] = "风暴之锤",
					["cooldown"] = 30,
					["id"] = 107570,
				}, -- [3]
				{
					["ability"] = "法术反射",
					["cooldown"] = 25,
					["id"] = 23920,
				}, -- [4]
			},
		},
		["SHAMAN"] = {
			["262"] = {
				{
					["ability"] = "闪电磁索",
					["cooldown"] = 30,
					["id"] = 305483,
				}, -- [1]
			},
			["264"] = {
				{
					["ability"] = "灵魂链接图腾",
					["cooldown"] = 180,
					["id"] = 98008,
				}, -- [1]
				{
					["ability"] = "大地之墙图腾",
					["cooldown"] = 60,
					["id"] = 198838,
				}, -- [2]
			},
			["263"] = {
				{
					["ability"] = "灵体形态",
					["cooldown"] = 60,
					["id"] = 210918,
				}, -- [1]
				{
					["ability"] = "萨满之道",
					["cooldown"] = 60,
					["id"] = 193876,
				}, -- [2]
			},
			["ALL"] = {
				{
					["ability"] = "星界转移",
					["cooldown"] = 90,
					["id"] = 108271,
				}, -- [1]
				{
					["ability"] = "风剪",
					["cooldown"] = 12,
					["id"] = 57994,
				}, -- [2]
				{
					["ability"] = "升腾",
					["cooldown"] = 180,
					["id"] = 114052,
				}, -- [3]
			},
		},
		["MAGE"] = {
			["63"] = {
				{
					["ability"] = "龙息术",
					["cooldown"] = 20,
					["id"] = 31661,
				}, -- [1]
				{
					["ability"] = "燃烧",
					["cooldown"] = 120,
					["id"] = 190319,
				}, -- [2]
			},
			["64"] = {
				{
					["ability"] = "冰冷血脉",
					["cooldown"] = 180,
					["id"] = 12472,
				}, -- [1]
			},
			["62"] = {
				{
					["ability"] = "奥术强化",
					["cooldown"] = 120,
					["id"] = 12042,
				}, -- [1]
			},
			["ALL"] = {
				{
					["ability"] = "时光护盾",
					["cooldown"] = 45,
					["id"] = 198111,
				}, -- [1]
				{
					["ability"] = "法术反制",
					["cooldown"] = 24,
					["id"] = 2139,
				}, -- [2]
				{
					["ability"] = "寒冰屏障",
					["cooldown"] = 240,
					["id"] = 45438,
				}, -- [3]
				{
					["ability"] = "冰霜之环",
					["cooldown"] = 45,
					["id"] = 113724,
				}, -- [4]
			},
		},
		["PRIEST"] = {
			["257"] = {
				{
					["ability"] = "圣言术：静",
					["cooldown"] = 60,
					["id"] = 2050,
				}, -- [1]
				{
					["ability"] = "圣言术：灵",
					["cooldown"] = 60,
					["id"] = 34861,
				}, -- [2]
				{
					["ability"] = "圣言术：聚",
					["cooldown"] = 45,
					["id"] = 289657,
				}, -- [3]
				{
					["ability"] = "强化渐隐术",
					["cooldown"] = 45,
					["id"] = 213602,
				}, -- [4]
				{
					["ability"] = "希望之光",
					["cooldown"] = 60,
					["id"] = 197268,
				}, -- [5]
				{
					["ability"] = "守护之魂",
					["cooldown"] = 180,
					["id"] = 47788,
				}, -- [6]
			},
			["258"] = {
				{
					["ability"] = "消散",
					["cooldown"] = 120,
					["id"] = 47585,
				}, -- [1]
				{
					["ability"] = "心灵尖啸",
					["cooldown"] = 60,
					["id"] = 8122,
				}, -- [2]
				{
					["ability"] = "沉默",
					["cooldown"] = 45,
					["id"] = 15487,
				}, -- [3]
				{
					["ability"] = "虚空转移",
					["cooldown"] = 300,
					["id"] = 108968,
				}, -- [4]
				{
					["ability"] = "强化渐隐术",
					["cooldown"] = 45,
					["id"] = 213602,
				}, -- [5]
			},
			["256"] = {
				{
					["ability"] = "心灵尖啸",
					["cooldown"] = 60,
					["id"] = 8122,
				}, -- [1]
				{
					["ability"] = "痛苦压制",
					["cooldown"] = 180,
					["id"] = 33206,
				}, -- [2]
				{
					["ability"] = "真言术：障",
					["cooldown"] = 180,
					["id"] = 62618,
				}, -- [3]
				{
					["ability"] = "微光屏障",
					["cooldown"] = 180,
					["id"] = 271466,
				}, -- [4]
			},
			["ALL"] = {
			},
		},
		["PALADIN"] = {
			["65"] = {
				{
					["ability"] = "牺牲祝福",
					["cooldown"] = 120,
					["id"] = 6940,
				}, -- [1]
				{
					["ability"] = "圣盾术",
					["cooldown"] = 300,
					["id"] = 642,
				}, -- [2]
				{
					["ability"] = "复仇十字军",
					["cooldown"] = 120,
					["id"] = 216331,
				}, -- [3]
				{
					["ability"] = "保护祝福",
					["cooldown"] = 300,
					["id"] = 1022,
				}, -- [4]
				{
					["ability"] = "自由祝福",
					["cooldown"] = 25,
					["id"] = 1044,
				}, -- [5]
				{
					["ability"] = "忏悔",
					["cooldown"] = 15,
					["id"] = 20066,
				}, -- [6]
				{
					["ability"] = "复仇之怒",
					["cooldown"] = 180,
					["id"] = 31884,
				}, -- [7]
			},
			["70"] = {
				{
					["ability"] = "圣盾术",
					["cooldown"] = 300,
					["id"] = 642,
				}, -- [1]
				{
					["ability"] = "责难",
					["cooldown"] = 15,
					["id"] = 96231,
				}, -- [2]
				{
					["ability"] = "保护祝福",
					["cooldown"] = 300,
					["id"] = 1022,
				}, -- [3]
				{
					["ability"] = "自由祝福",
					["cooldown"] = 25,
					["id"] = 1044,
				}, -- [4]
				{
					["ability"] = "庇护祝福",
					["cooldown"] = 45,
					["id"] = 210256,
				}, -- [5]
				{
					["ability"] = "以眼还眼",
					["cooldown"] = 60,
					["id"] = 205191,
				}, -- [6]
				{
					["ability"] = "复仇之怒",
					["cooldown"] = 180,
					["id"] = 31884,
				}, -- [7]
				{
					["ability"] = "复仇之盾",
					["cooldown"] = 120,
					["id"] = 184662,
				}, -- [8]
				{
					["ability"] = "征伐",
					["cooldown"] = 120,
					["id"] = 231895,
				}, -- [9]
			},
			["66"] = {
				{
					["ability"] = "责难",
					["cooldown"] = 15,
					["id"] = 96231,
				}, -- [1]
			},
			["ALL"] = {
				{
					["ability"] = "制裁之锤",
					["cooldown"] = 60,
					["id"] = 853,
				}, -- [1]
			},
		},
		["WARLOCK"] = {
			["265"] = {
			},
			["266"] = {
			},
			["267"] = {
			},
			["ALL"] = {
				{
					["ability"] = "法术封锁",
					["cooldown"] = 24,
					["id"] = 19647,
				}, -- [1]
				{
					["ability"] = "不灭决心",
					["cooldown"] = 180,
					["id"] = 104773,
				}, -- [2]
				{
					["ability"] = "黑暗契约",
					["cooldown"] = 60,
					["id"] = 108416,
				}, -- [3]
				{
					["ability"] = "虚空守卫",
					["cooldown"] = 45,
					["id"] = 212295,
				}, -- [4]
				{
					["ability"] = "死亡缠绕",
					["cooldown"] = 45,
					["id"] = 6789,
				}, -- [5]
				{
					["ability"] = "暗影之怒",
					["cooldown"] = 60,
					["id"] = 30283,
				}, -- [6]
			},
		},
		["DEMONHUNTER"] = {
			["577"] = {
				{
					["ability"] = "黑暗",
					["cooldown"] = 180,
					["id"] = 196718,
				}, -- [1]
				{
					["ability"] = "恶魔变形",
					["cooldown"] = 300,
					["id"] = 191427,
				}, -- [2]
				{
					["ability"] = "虚空行走",
					["cooldown"] = 180,
					["id"] = 196555,
				}, -- [3]
			},
			["581"] = {
				{
					["ability"] = "恶魔变形",
					["cooldown"] = 300,
					["id"] = 187827,
				}, -- [1]
			},
			["ALL"] = {
				{
					["ability"] = "疾影",
					["cooldown"] = 60,
					["id"] = 198589,
				}, -- [1]
				{
					["ability"] = "禁锢",
					["cooldown"] = 45,
					["id"] = 217832,
				}, -- [2]
				{
					["ability"] = "瓦解",
					["cooldown"] = 15,
					["id"] = 183752,
				}, -- [3]
			},
		},
		["DEATHKNIGHT"] = {
			["252"] = {
				{
					["ability"] = "窒息",
					["cooldown"] = 45,
					["id"] = 108194,
				}, -- [1]
				{
					["ability"] = "跳跃",
					["cooldown"] = 30,
					["id"] = 47482,
				}, -- [2]
				{
					["ability"] = "反魔法领域",
					["cooldown"] = 120,
					["id"] = 51052,
				}, -- [3]
				{
					["ability"] = "亡者大军",
					["cooldown"] = 480,
					["id"] = 42650,
				}, -- [4]
				{
					["ability"] = "召唤石像鬼",
					["cooldown"] = 180,
					["id"] = 49206,
				}, -- [5]
			},
			["251"] = {
				{
					["ability"] = "幻影步",
					["cooldown"] = 60,
					["id"] = 212552,
				}, -- [1]
				{
					["ability"] = "冷酷严冬",
					["cooldown"] = 20,
					["id"] = 196770,
				}, -- [2]
			},
			["250"] = {
			},
			["ALL"] = {
				{
					["ability"] = "心灵冰冻",
					["cooldown"] = 15,
					["id"] = 47528,
				}, -- [1]
				{
					["ability"] = "反魔法护罩",
					["cooldown"] = 60,
					["id"] = 48707,
				}, -- [2]
				{
					["ability"] = "冰封之韧",
					["cooldown"] = 180,
					["id"] = 48792,
				}, -- [3]
			},
		},
		["DRUID"] = {
			["105"] = {
				{
					["ability"] = "铁木树皮",
					["cooldown"] = 90,
					["id"] = 102342,
				}, -- [1]
			},
			["104"] = {
				{
					["ability"] = "迎头痛击",
					["cooldown"] = 15,
					["id"] = 106839,
				}, -- [1]
			},
			["102"] = {
				{
					["ability"] = "日光术",
					["cooldown"] = 60,
					["id"] = 78675,
				}, -- [1]
				{
					["ability"] = "化身：艾露恩之眷",
					["cooldown"] = 180,
					["id"] = 102560,
				}, -- [2]
				{
					["ability"] = "超凡之盟",
					["cooldown"] = 180,
					["id"] = 194223,
				}, -- [3]
			},
			["103"] = {
				{
					["ability"] = "迎头痛击",
					["cooldown"] = 15,
					["id"] = 106839,
				}, -- [1]
				{
					["ability"] = "生存本能",
					["cooldown"] = 180,
					["id"] = 61336,
				}, -- [2]
				{
					["ability"] = "狂暴",
					["cooldown"] = 180,
					["id"] = 106951,
				}, -- [3]
			},
			["ALL"] = {
				{
					["ability"] = "蛮力猛击",
					["cooldown"] = 60,
					["id"] = 5211,
				}, -- [1]
				{
					["ability"] = "树皮术",
					["cooldown"] = 60,
					["id"] = 22812,
				}, -- [2]
			},
		},
		["MONK"] = {
			["270"] = {
				{
					["ability"] = "作茧缚命",
					["cooldown"] = 120,
					["id"] = 116849,
				}, -- [1]
				{
					["ability"] = "壮胆酒",
					["cooldown"] = 420,
					["id"] = 243435,
				}, -- [2]
			},
			["269"] = {
				{
					["ability"] = "切喉手",
					["cooldown"] = 15,
					["id"] = 116705,
				}, -- [1]
				{
					["ability"] = "业报之触",
					["cooldown"] = 90,
					["id"] = 122470,
				}, -- [2]
				{
					["ability"] = "壮胆酒",
					["cooldown"] = 420,
					["id"] = 243435,
				}, -- [3]
				{
					["ability"] = "风火雷电",
					["cooldown"] = 90,
					["id"] = 137639,
				}, -- [4]
				{
					["ability"] = "屏气凝神",
					["cooldown"] = 90,
					["id"] = 152173,
				}, -- [5]
				{
					["ability"] = "轮回之触",
					["cooldown"] = 120,
					["id"] = 115080,
				}, -- [6]
			},
			["268"] = {
				{
					["ability"] = "切喉手",
					["cooldown"] = 15,
					["id"] = 116705,
				}, -- [1]
			},
			["ALL"] = {
				{
					["ability"] = "扫堂腿",
					["cooldown"] = 60,
					["id"] = 119381,
				}, -- [1]
				{
					["ability"] = "迅如猛虎",
					["cooldown"] = 30,
					["id"] = 116841,
				}, -- [2]
			},
		},
		["ROGUE"] = {
			["261"] = {
				{
					["ability"] = "闪避",
					["cooldown"] = 120,
					["id"] = 5277,
				}, -- [1]
				{
					["ability"] = "烟雾弹",
					["cooldown"] = 180,
					["id"] = 212182,
				}, -- [2]
			},
			["260"] = {
				{
					["ability"] = "猩红之瓶",
					["cooldown"] = 30,
					["id"] = 185311,
				}, -- [1]
				{
					["ability"] = "还击",
					["cooldown"] = 120,
					["id"] = 199754,
				}, -- [2]
			},
			["259"] = {
				{
					["ability"] = "闪避",
					["cooldown"] = 120,
					["id"] = 5277,
				}, -- [1]
				{
					["ability"] = "致盲",
					["cooldown"] = 120,
					["id"] = 2094,
				}, -- [2]
				{
					["ability"] = "烟雾弹",
					["cooldown"] = 180,
					["id"] = 212182,
				}, -- [3]
				{
					["ability"] = "宿敌",
					["cooldown"] = 120,
					["id"] = 79140,
				}, -- [4]
			},
			["ALL"] = {
				{
					["ability"] = "脚踢",
					["cooldown"] = 15,
					["id"] = 1766,
				}, -- [1]
				{
					["ability"] = "暗影斗篷",
					["cooldown"] = 120,
					["id"] = 31224,
				}, -- [2]
				{
					["ability"] = "消失",
					["cooldown"] = 120,
					["id"] = 1856,
				}, -- [3]
			},
		},
	},
	["scenarios"] = true,
	["showIconBorders"] = true,
	["iconOffsetX"] = 2,
	["horizontal"] = false,
	["showTooltip"] = true,
	["biggroup"] = true,
}
