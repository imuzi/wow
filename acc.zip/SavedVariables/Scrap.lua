
Scrap_Sets = {
	["destroy"] = true,
	["safe"] = true,
	["guild"] = false,
	["list"] = {
	},
	["tutorial"] = 5,
	["sell"] = true,
	["icons"] = true,
	["repair"] = true,
}
