
Scrap_Sets = {
	["destroy"] = true,
	["repair"] = true,
	["guild"] = false,
	["list"] = {
	},
	["tutorial"] = 5,
	["sell"] = true,
	["icons"] = true,
	["safe"] = true,
}
