
Scrap_Sets = {
	["destroy"] = true,
	["repair"] = true,
	["safe"] = true,
	["list"] = {
	},
	["tutorial"] = 5,
	["sell"] = true,
	["icons"] = true,
	["guild"] = false,
}
