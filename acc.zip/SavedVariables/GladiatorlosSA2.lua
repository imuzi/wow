
GladiatorlosSADB = {
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "Default",
		["Rainylone - 末日行者"] = "Default",
		["Ennyin - 索瑞森"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["Ennyin - 埃加洛尔"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["battleground"] = false,
			["path_menu"] = "GladiatorlosSA2_zhCN\\Voice_zhCN",
			["CreateHealthstone"] = false,
			["field"] = true,
			["summonDemon"] = false,
			["glacialSpike"] = false,
			["waterElemental"] = false,
			["smartDisable"] = true,
			["all"] = true,
			["drinking"] = true,
			["path"] = "GladiatorlosSA2_zhCN\\Voice_zhCN",
			["ebonbolt"] = false,
		},
	},
}
