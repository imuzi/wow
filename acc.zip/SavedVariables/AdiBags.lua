
AdiBagsDB = {
	["profileKeys"] = {
		["嘿嘿牛 - 达尔坎"] = "Default",
		["香水般的温柔 - 恶魔之翼"] = "Default",
		["Whsi - 伊森利恩"] = "Default",
		["云雨別 - 索瑞森"] = "Default",
		["Ennysoul - 索瑞森"] = "Default",
		["別雨 - 索瑞森"] = "Default",
		["借你流年 - 燃烧之刃"] = "Default",
		["额为我 - 战歌"] = "Default",
		["那片云的味道 - 恶魔之翼"] = "Default",
		["你诺 - 索瑞森"] = "Default",
		["幽笠巫 - 熊猫酒仙"] = "Default",
		["Madeep - 冰风岗"] = "Default",
		["Sotu - 燃烧之刃"] = "Default",
		["Lure - 达文格尔"] = "Default",
		["Ennyin - 提瑞斯法"] = "Default",
		["我过年好 - 鬼雾峰"] = "Default",
		["Wonderain - 伊森利恩"] = "Default",
		["Ennyin - 索瑞森"] = "Default",
		["失重 - 冰风岗"] = "Default",
		["Nuc - 阿拉希"] = "Default",
		["Oow - 达文格尔"] = "Default",
		["闰汐 - 伊森利恩"] = "Default",
		["海雅 - 索瑞森"] = "Default",
		["绑住了风 - 索瑞森"] = "Default",
		["浮雲 - 恶魔之翼"] = "Default",
		["绑住了风 - 恶魔之翼"] = "Default",
		["木诺子其 - 索瑞森"] = "Default",
		["Rainylone - 末日行者"] = "Default",
		["Revp - 黑铁"] = "Default",
		["Ennyin - 埃加洛尔"] = "ENNYIN",
	},
	["namespaces"] = {
		["FilterOverride"] = {
			["profiles"] = {
				["Default"] = {
					["overrides"] = {
						[46735] = "任务#任务",
						[81405] = "装备#武器",
					},
					["version"] = 3,
				},
				["ENNYIN"] = {
					["version"] = 3,
					["overrides"] = {
						[46735] = "任务#任务",
						[81405] = "装备#武器",
					},
				},
			},
		},
		["Cata"] = {
		},
		["WoW"] = {
		},
		["Shadowlands"] = {
		},
		["ItemSets"] = {
		},
		["Junk"] = {
		},
		["BfA"] = {
		},
		["ItemLevel"] = {
		},
		["TBC"] = {
		},
		["ItemCategory"] = {
			["profiles"] = {
				["Default"] = {
					["splitBySubclass"] = {
						["宝石"] = true,
						["商品"] = true,
						["消耗品"] = true,
					},
				},
				["ENNYIN"] = {
					["splitBySubclass"] = {
						["消耗品"] = true,
						["商品"] = true,
						["宝石"] = true,
					},
				},
			},
		},
		["WoD"] = {
		},
		["NewItem"] = {
		},
		["MoP"] = {
		},
		["Equipment"] = {
			["profiles"] = {
				["Default"] = {
					["armorTypes"] = true,
				},
				["ENNYIN"] = {
					["armorTypes"] = true,
				},
			},
		},
		["Legion"] = {
		},
		["Wrath"] = {
		},
		["MoneyFrame"] = {
		},
		["AdiBags_TooltipInfo"] = {
		},
		["CurrencyFrame"] = {
			["profiles"] = {
				["Default"] = {
					["shown"] = {
						["破碎命运印记"] = false,
						["钢化命运印记"] = false,
						["战痕命运印记"] = false,
						["次级好运护符"] = false,
						["腐化的纪念品"] = false,
						["海员达布隆币"] = false,
						["虚空碎片"] = false,
						["托尔巴拉德奖章"] = false,
						["永恒铸币"] = false,
						["黑暗之尘"] = false,
						["拳手的金币"] = false,
						["凝结幻象"] = false,
						["世界之树的印记"] = false,
						["魔古命运符文"] = false,
						["死亡之翼的堕落精华"] = false,
						["泰坦残血精华"] = false,
						["冠军的徽记"] = false,
						["盲目之眼"] = false,
						["战火徽记"] = false,
						["要塞物资"] = false,
						["暗月奖券"] = false,
						["尼奥罗萨的回响"] = false,
						["荣耀战团服役勋章"] = false,
						["古怪硬币"] = false,
						["原油"] = false,
						["时空扭曲徽章"] = false,
						["远古魔力"] = false,
						["棱彩法力珍珠"] = false,
						["长者的好运符"] = false,
						["职业大厅资源"] = false,
						["铁掌徽记"] = false,
						["银色嘉奖"] = false,
						["幽魂碎片"] = false,
						["美食家奖章"] = false,
						["战斗的回响"] = false,
						["觉醒精华"] = false,
						["战争物资"] = false,
						["埃匹希斯水晶"] = false,
						["神器碎片"] = false,
					},
				},
				["ENNYIN"] = {
					["shown"] = {
						["破碎命运印记"] = false,
						["钢化命运印记"] = false,
						["时空扭曲徽章"] = false,
						["次级好运护符"] = false,
						["腐化的纪念品"] = false,
						["海员达布隆币"] = false,
						["虚空碎片"] = false,
						["托尔巴拉德奖章"] = false,
						["永恒铸币"] = false,
						["黑暗之尘"] = false,
						["拳手的金币"] = false,
						["凝结幻象"] = false,
						["世界之树的印记"] = false,
						["魔古命运符文"] = false,
						["死亡之翼的堕落精华"] = false,
						["泰坦残血精华"] = false,
						["冠军的徽记"] = false,
						["盲目之眼"] = false,
						["战火徽记"] = false,
						["要塞物资"] = false,
						["暗月奖券"] = false,
						["尼奥罗萨的回响"] = false,
						["荣耀战团服役勋章"] = false,
						["古怪硬币"] = false,
						["原油"] = false,
						["神器碎片"] = false,
						["埃匹希斯水晶"] = false,
						["棱彩法力珍珠"] = false,
						["长者的好运符"] = false,
						["职业大厅资源"] = false,
						["战争物资"] = false,
						["觉醒精华"] = false,
						["幽魂碎片"] = false,
						["美食家奖章"] = false,
						["战斗的回响"] = false,
						["银色嘉奖"] = false,
						["战痕命运印记"] = false,
						["铁掌徽记"] = false,
						["远古魔力"] = false,
					},
				},
			},
		},
		["TidyBags"] = {
		},
		["DataSource"] = {
		},
	},
	["global"] = {
		["muteBugGrabber"] = true,
	},
	["profiles"] = {
		["Default"] = {
			["virtualStacks"] = {
				["others"] = true,
				["stackable"] = true,
			},
			["skin"] = {
				["background"] = "Blizzard Dialog Background",
				["border"] = "None",
				["borderWidth"] = 1,
			},
			["rightClickConfig"] = false,
			["positionMode"] = "manual",
			["positions"] = {
				["anchor"] = {
					["xOffset"] = -375.1114501953125,
					["yOffset"] = 248.0000457763672,
				},
				["Bank"] = {
					["xOffset"] = 16.28577752539184,
					["yOffset"] = -50.51410998275969,
				},
				["Backpack"] = {
					["xOffset"] = -249.9532497776527,
					["point"] = "TOPRIGHT",
					["yOffset"] = -116.4742061804864,
				},
			},
		},
		["ENNYIN"] = {
			["virtualStacks"] = {
				["stackable"] = true,
				["others"] = true,
			},
			["skin"] = {
				["border"] = "None",
				["background"] = "Blizzard Dialog Background",
				["borderWidth"] = 1,
			},
			["positions"] = {
				["anchor"] = {
					["xOffset"] = -375.1114501953125,
					["yOffset"] = 248.0000457763672,
				},
				["Backpack"] = {
					["xOffset"] = -63.2893798086443,
					["yOffset"] = 99.3477187655526,
				},
				["Bank"] = {
					["xOffset"] = 16.28577752539184,
					["yOffset"] = -50.51410998275969,
				},
			},
			["rightClickConfig"] = false,
			["positionMode"] = "manual",
		},
	},
}
