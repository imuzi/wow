
RecountDB = {
	["profileKeys"] = {
		["借你流年 - 燃烧之刃"] = "借你流年 - 燃烧之刃",
		["Rainylone - 末日行者"] = "Rainylone - 末日行者",
		["Ennyin - 索瑞森"] = "Ennyin - 索瑞森",
		["Madeep - 冰风岗"] = "Madeep - 冰风岗",
		["Ennyin - 埃加洛尔"] = "Ennyin - 埃加洛尔",
	},
	["profiles"] = {
		["借你流年 - 燃烧之刃"] = {
			["MainWindowVis"] = false,
			["MainWindow"] = {
				["Position"] = {
					["w"] = 140.0000762939453,
					["h"] = 200.0000305175781,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["CurDataSet"] = "OverallData",
		},
		["Rainylone - 末日行者"] = {
			["MainWindow"] = {
				["Position"] = {
					["h"] = 200.0000305175781,
					["w"] = 140.0000762939453,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["MainWindowVis"] = false,
			["CurDataSet"] = "OverallData",
		},
		["Ennyin - 索瑞森"] = {
			["MainWindow"] = {
				["BarText"] = {
					["NumFormat"] = 3,
				},
				["Position"] = {
					["y"] = -335.5,
					["x"] = 358.5000610351563,
					["w"] = 271.0001220703125,
					["h"] = 199.0000305175781,
				},
				["Buttons"] = {
					["ResetButton"] = false,
					["LeftButton"] = false,
					["ReportButton"] = false,
				},
			},
			["AutoDeleteNewInstance"] = false,
			["MaxFights"] = 15,
			["Modules"] = {
				["HOTUptime"] = false,
				["Activity"] = false,
				["HealingTaken"] = false,
				["OverhealingDone"] = false,
				["DOTUptime"] = false,
				["Deaths"] = false,
			},
			["AutoDelete"] = false,
			["Filters"] = {
				["Show"] = {
					["Pet"] = true,
					["Hostile"] = true,
				},
				["TrackDeaths"] = {
					["Hostile"] = true,
				},
				["Data"] = {
					["Hostile"] = true,
				},
			},
			["MainWindowVis"] = false,
			["DetailWindowX"] = 488.0000305175781,
			["MainWindowHeight"] = 198.742919921875,
			["BarTexture"] = "Flat",
			["FrameStrata"] = "3-MEDIUM",
			["LastInstanceName"] = "机械天穹",
			["RealtimeWindows"] = {
				["Realtime_!RAID_DAMAGE"] = {
					"!RAID", -- [1]
					"DAMAGE", -- [2]
					"Raid DPS", -- [3]
					0, -- [4]
					0, -- [5]
					200.000076293945, -- [6]
					232, -- [7]
					false, -- [8]
				},
				["Realtime_!RAID_HEALING"] = {
					"!RAID", -- [1]
					"HEALING", -- [2]
					"Raid HPS", -- [3]
					0, -- [4]
					0, -- [5]
					200.000076293945, -- [6]
					232, -- [7]
					false, -- [8]
				},
			},
			["CurDataSet"] = "OverallData",
			["Colors"] = {
				["Window"] = {
					["Background"] = {
						["a"] = 0,
					},
					["Title"] = {
						["a"] = 0,
					},
					["Title Text"] = {
						["a"] = 0.2800000309944153,
					},
				},
				["Other Windows"] = {
					["Title"] = {
						["a"] = 0.963635977357626,
					},
				},
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = -307.0000610351563,
			["MainWindowMode"] = 12,
			["Font"] = "默认",
			["MainWindowWidth"] = 271.3143005371094,
			["BarTextColorSwap"] = false,
		},
		["Madeep - 冰风岗"] = {
			["MainWindowVis"] = false,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -343.3143615722656,
					["h"] = 200.0000305175781,
					["w"] = 140.0001831054688,
					["x"] = 384.0004272460938,
				},
			},
			["MainWindowMode"] = 6,
			["LastInstanceName"] = "战歌峡谷",
			["CurDataSet"] = "OverallData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
		},
		["Ennyin - 埃加洛尔"] = {
			["MainWindowVis"] = false,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -346.2569427490234,
					["h"] = 199.9999847412109,
					["w"] = 139.9999694824219,
					["x"] = 429.6862182617188,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["LastInstanceName"] = "尼奥罗萨，觉醒之城",
			["CurDataSet"] = "OverallData",
		},
	},
}
