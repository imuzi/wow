
AUCTIONATOR_SAVEDVARS = {
	["_50000"] = 500,
	["_2000"] = 100,
	["_200000"] = 1000,
	["_10000"] = 200,
	["_1000000"] = 2500,
	["_5000000"] = 10000,
	["STARTING_DISCOUNT"] = 5,
	["_500"] = 5,
	["LOG_DE_DATA_X"] = true,
}
AUCTIONATOR_PRICING_HISTORY = {
}
AUCTIONATOR_SHOPPING_LISTS = {
	{
		["items"] = {
		},
		["isRecents"] = 1,
		["name"] = "最近搜索",
	}, -- [1]
}
AUCTIONATOR_SHOPPING_LISTS_MIGRATED_V2 = nil
AUCTIONATOR_PRICE_DATABASE = {
	["__dbversion"] = 4,
	["索瑞森_Horde"] = {
	},
}
AUCTIONATOR_LAST_SCAN_TIME = nil
AUCTIONATOR_TOONS = {
	["Ennyin"] = {
		["firstSeen"] = 1581139594,
		["guid"] = "Player-743-019FE1FE",
		["firstVersion"] = "8.2.0",
	},
}
AUCTIONATOR_STACKING_PREFS = {
}
AUCTIONATOR_SCAN_MINLEVEL = 1
AUCTIONATOR_DB_MAXITEM_AGE = 180
AUCTIONATOR_DB_MAXHIST_AGE = -1
AUCTIONATOR_DB_MAXHIST_DAYS = 5
AUCTIONATOR_FS_CHUNK = nil
AUCTIONATOR_DE_DATA = nil
AUCTIONATOR_DE_DATA_BAK = nil
ITEM_ID_VERSION = "3.2.6"
AUCTIONATOR_SHOW_MAILBOX_TIPS = nil
