
TipTac_Config = {
	["fontFace"] = "Fonts\\FRIZQT__.TTF",
	["showRealm"] = "none",
	["classification_elite"] = "+%s ",
	["barHeight"] = 6,
	["overrideFade"] = true,
	["preFadeTime"] = 0,
	["hideWorldTips"] = false,
	["backdropEdgeSize"] = 16,
	["reactText"] = false,
	["showTarget"] = "first",
	["tipBackdropBG"] = "Interface\\DialogFrame\\UI-DialogBox-Gold-Background",
	["fontFlags"] = "",
	["tipColor"] = {
		0.1, -- [1]
		0.1, -- [2]
		0.2, -- [3]
		1, -- [4]
	},
	["hideDefaultBar"] = true,
	["healthBar"] = true,
	["colRace"] = "|cffffffff",
	["tipBorderColor"] = {
		0.3, -- [1]
		0.3, -- [2]
		0.4, -- [3]
		1, -- [4]
	},
	["classification_normal"] = "%s ",
	["colLevel"] = "|cffc0c0c0",
	["healthBarClassColor"] = true,
	["reactColoredBorder"] = false,
	["classification_minus"] = "-%s ",
	["barFontFlags"] = "OUTLINE",
	["showUnitTip"] = true,
	["anchorFrameUnitPoint"] = "TOPLEFT",
	["powerBar"] = false,
	["fontSize"] = 12,
	["classification_rare"] = "%s|r (Rare) ",
	["fontSizeDelta"] = 2,
	["colorGuildByReaction"] = true,
	["barsCondenseValues"] = false,
	["optionsBottom"] = 361.0000610351563,
	["nameType"] = "normal",
	["barFontFace"] = "Fonts\\FRIZQT__.TTF",
	["reactColoredBackdrop"] = false,
	["anchorWorldUnitPoint"] = "TOPLEFT",
	["classification_trivial"] = "~%s ",
	["classification_worldboss"] = "%s|r (Boss) ",
	["backdropInsets"] = 4,
	["manaBar"] = false,
	["iconAnchor"] = "TOPLEFT",
	["anchorWorldTipPoint"] = "TOPLEFT",
	["colorNameByClass"] = true,
	["gradientColor"] = {
		0.8, -- [1]
		0.8, -- [2]
		0.8, -- [3]
		0.2, -- [4]
	},
	["classification_rareelite"] = "+%s|r (Rare) ",
	["fadeTime"] = 0,
	["healthBarColor"] = {
		0.3, -- [1]
		0.9, -- [2]
		0.3, -- [3]
		1, -- [4]
	},
	["targetYouText"] = "<<YOU>>",
	["colSameGuild"] = "|cffff32ff",
	["top"] = 372.84814453125,
	["classColoredBorder"] = true,
	["gradientTip"] = false,
	["left"] = 1178.218627929688,
	["healthBarText"] = "percent",
	["barFontSize"] = 12,
	["anchorFrameTipPoint"] = "TOPLEFT",
	["optionsLeft"] = 1422.999877929688,
}
