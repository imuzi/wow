
TipTac_Config = {
	["fontFace"] = "Fonts\\FRIZQT__.TTF",
	["showRealm"] = "none",
	["classification_elite"] = "+%s ",
	["barHeight"] = 6,
	["overrideFade"] = true,
	["preFadeTime"] = 0,
	["hideWorldTips"] = false,
	["backdropEdgeSize"] = 16,
	["reactText"] = false,
	["showTarget"] = "first",
	["tipBackdropBG"] = "Interface\\DialogFrame\\UI-DialogBox-Gold-Background",
	["fontFlags"] = "",
	["tipColor"] = {
		0.1, -- [1]
		0.1, -- [2]
		0.2, -- [3]
		1, -- [4]
	},
	["hideDefaultBar"] = true,
	["healthBar"] = true,
	["colRace"] = "|cffffffff",
	["tipBorderColor"] = {
		0.3, -- [1]
		0.3, -- [2]
		0.4, -- [3]
		1, -- [4]
	},
	["classification_normal"] = "%s ",
	["colLevel"] = "|cffc0c0c0",
	["healthBarClassColor"] = true,
	["reactColoredBorder"] = false,
	["classification_minus"] = "-%s ",
	["barFontFlags"] = "OUTLINE",
	["optionsLeft"] = 1422.999877929688,
	["anchorFrameUnitPoint"] = "TOPLEFT",
	["powerBar"] = false,
	["fontSize"] = 12,
	["classification_rare"] = "%s|r (Rare) ",
	["healthBarText"] = "percent",
	["colorGuildByReaction"] = true,
	["barsCondenseValues"] = false,
	["optionsBottom"] = 361.0000610351563,
	["left"] = 1178.218627929688,
	["gradientTip"] = false,
	["reactColoredBackdrop"] = false,
	["anchorWorldUnitPoint"] = "TOPLEFT",
	["classification_trivial"] = "~%s ",
	["classification_worldboss"] = "%s|r (Boss) ",
	["colSameGuild"] = "|cffff32ff",
	["colorNameByClass"] = true,
	["iconAnchor"] = "TOPLEFT",
	["anchorWorldTipPoint"] = "TOPLEFT",
	["manaBar"] = false,
	["gradientColor"] = {
		0.8, -- [1]
		0.8, -- [2]
		0.8, -- [3]
		0.2, -- [4]
	},
	["classification_rareelite"] = "+%s|r (Rare) ",
	["healthBarColor"] = {
		0.3, -- [1]
		0.9, -- [2]
		0.3, -- [3]
		1, -- [4]
	},
	["fadeTime"] = 0,
	["targetYouText"] = "<<YOU>>",
	["classColoredBorder"] = true,
	["top"] = 372.84814453125,
	["backdropInsets"] = 4,
	["barFontFace"] = "Fonts\\FRIZQT__.TTF",
	["nameType"] = "normal",
	["fontSizeDelta"] = 2,
	["barFontSize"] = 12,
	["anchorFrameTipPoint"] = "TOPLEFT",
	["showUnitTip"] = true,
}
