
EventHorizonDBG = {
	["defaultProfile"] = "default",
	["profilePerChar"] = {
		["Sotu - 燃烧之刃"] = "default",
		["浮雲 - 恶魔之翼"] = "default",
		["木诺子其 - 索瑞森"] = "default",
		["幽笠巫 - 熊猫酒仙"] = "default",
		["別雨 - 索瑞森"] = "default",
		["Lure - 达文格尔"] = "default",
	},
	["version"] = 4,
	["itemInfo"] = {
	},
	["profiles"] = {
		["default"] = {
		},
	},
}
