
NameplateAurasAceDB = {
	["profileKeys"] = {
		["Ennyin - 埃加洛尔"] = "Ennyin - 埃加洛尔",
		["借你流年 - 燃烧之刃"] = "借你流年 - 燃烧之刃",
	},
	["profiles"] = {
		["Ennyin - 埃加洛尔"] = {
			["DBVersion"] = 5,
			["DefaultSpellsLastSetImported"] = 2,
			["StacksTextAnchorIcon"] = "BOTTOMRIGHT",
			["DebuffBordersDiseaseColor"] = {
				nil, -- [1]
				0.01568627450980392, -- [2]
				0.1176470588235294, -- [3]
			},
			["InterruptsShowOnlyOnPlayers"] = false,
			["TimerTextAnchorIcon"] = "CENTER",
			["CustomSpells2"] = {
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "盾墙",
				}, -- [1]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "烟雾弹",
				}, -- [2]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "禁锢",
				}, -- [3]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "复仇者之盾",
				}, -- [4]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰霜之柱",
				}, -- [5]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "寒冰屏障",
				}, -- [6]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "痛苦压制",
				}, -- [7]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "激活",
				}, -- [8]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "变形术",
				}, -- [9]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "不灭决心",
				}, -- [10]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "Horde Flag",
				}, -- [11]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "生存本能",
				}, -- [12]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "心灵炸弹",
				}, -- [13]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "散魔功",
				}, -- [14]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "灵魂收割",
				}, -- [15]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "忏悔",
				}, -- [16]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "业报之触",
				}, -- [17]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "追踪者之网",
				}, -- [18]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "仙鹤之道",
				}, -- [19]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "虚空风暴旗帜",
				}, -- [20]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "肾击",
				}, -- [21]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "致盲",
				}, -- [22]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "浮冰",
				}, -- [23]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "屏气凝神",
				}, -- [24]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "治疗绷带",
				}, -- [25]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "风火雷电",
				}, -- [26]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "牺牲咆哮",
				}, -- [27]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "灵魂收割",
				}, -- [28]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "龙息术",
				}, -- [29]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "束缚射击",
				}, -- [30]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "蛮力猛击",
				}, -- [31]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "反魔法护罩",
				}, -- [32]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "备战就绪",
				}, -- [33]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "升腾",
				}, -- [34]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "夺魂咆哮",
				}, -- [35]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "树皮术",
				}, -- [36]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "恐惧嚎叫",
				}, -- [37]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰冷血脉",
				}, -- [38]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "壮胆酒",
				}, -- [39]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "闷棍",
				}, -- [40]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "疾影",
				}, -- [41]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "邪能爆发",
				}, -- [42]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "暗影之怒",
				}, -- [43]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "光环掌握",
				}, -- [44]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "法术反射",
				}, -- [45]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "超凡之盟",
				}, -- [46]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "撕扯",
				}, -- [47]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "躯不坏",
				}, -- [48]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "死亡缠绕",
				}, -- [49]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "偷袭",
				}, -- [50]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "翼龙钉刺",
				}, -- [51]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "消散",
				}, -- [52]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "束缚亡灵",
				}, -- [53]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "致盲冰雨",
				}, -- [54]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "恐惧",
				}, -- [55]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "远古列王守卫",
				}, -- [56]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "妖术",
				}, -- [57]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "闪避",
				}, -- [58]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "施法之环",
				}, -- [59]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "铁木树皮",
				}, -- [60]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "跳跃",
				}, -- [61]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "日光术",
				}, -- [62]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "星界转移",
				}, -- [63]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "凿击",
				}, -- [64]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "锁喉 - 沉默",
				}, -- [65]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "虚空行走",
				}, -- [66]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "天使长",
				}, -- [67]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "Alliance Flag",
				}, -- [68]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "自然的守护",
				}, -- [69]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "威慑",
				}, -- [70]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "主人的召唤",
				}, -- [71]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "影舞步",
				}, -- [72]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "混乱新星",
				}, -- [73]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "流星打击",
				}, -- [74]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "能量灌注",
				}, -- [75]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "被遗忘的女王护卫",
				}, -- [76]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "游侠之网",
				}, -- [77]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "陷地",
				}, -- [78]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "自由祝福",
				}, -- [79]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "破胆怒吼",
				}, -- [80]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "寒冰形态",
				}, -- [81]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "掠食者的迅捷",
				}, -- [82]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "黑暗契约",
				}, -- [83]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰冻陷阱",
				}, -- [84]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "分筋错骨",
				}, -- [85]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "打磨利刃",
				}, -- [86]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "鲁莽",
				}, -- [87]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "虚空联结",
				}, -- [88]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "心灵尖啸",
				}, -- [89]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "迷魅",
				}, -- [90]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "幻影打击",
				}, -- [91]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冲锋",
				}, -- [92]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "幽灵视觉",
				}, -- [93]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "险境求生",
				}, -- [94]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "罪与罚",
				}, -- [95]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "遗言",
				}, -- [96]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "痛苦无常",
				}, -- [97]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰霜之环",
				}, -- [98]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "以眼还眼",
				}, -- [99]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "窒息",
				}, -- [100]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "虚空形态",
				}, -- [101]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "盲目之光",
				}, -- [102]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "保护祝福",
				}, -- [103]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "恶魔变形",
				}, -- [104]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "纠缠根须",
				}, -- [105]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "精神控制",
				}, -- [106]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "灵龟守护",
				}, -- [107]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "扫堂腿",
				}, -- [108]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰冻之箭",
				}, -- [109]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "诱惑",
				}, -- [110]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "虚空守卫",
				}, -- [111]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "剑在人在",
				}, -- [112]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "风暴之锤",
				}, -- [113]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "诱捕",
				}, -- [114]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "圣盾术",
				}, -- [115]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "静电充能",
				}, -- [116]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "暗影之刃",
				}, -- [117]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "巨斧投掷",
				}, -- [118]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "时光护盾",
				}, -- [119]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "奥术强化",
				}, -- [120]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "禅悟冥想",
				}, -- [121]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "暗影映像",
				}, -- [122]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "窒息",
				}, -- [123]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "天神下凡",
				}, -- [124]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "炽热防御者",
				}, -- [125]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "旋风",
				}, -- [126]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "沉默",
				}, -- [127]
				{
					["enabledState"] = 2,
					["checkSpellID"] = {
						[163505] = true,
					},
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["pvpCombat"] = 1,
					["iconSize"] = 22,
					["glowType"] = 3,
					["auraType"] = 3,
					["spellName"] = "斜掠",
				}, -- [128]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "狂暴之怒",
				}, -- [129]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "剑刃风暴",
				}, -- [130]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "圣光护盾",
				}, -- [131]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冲动",
				}, -- [132]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "作茧缚命",
				}, -- [133]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "黑暗天使长",
				}, -- [134]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "吸血鬼的拥抱",
				}, -- [135]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "制裁之锤",
				}, -- [136]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "灵体形态",
				}, -- [137]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "暗影斗篷",
				}, -- [138]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰冻术",
				}, -- [139]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "群体缠绕",
				}, -- [140]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "怒雷破",
				}, -- [141]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "震荡波",
				}, -- [142]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "战神",
				}, -- [143]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "根基图腾效果",
				}, -- [144]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "驱散射击",
				}, -- [145]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "元素宗师",
				}, -- [146]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "割碎",
				}, -- [147]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "放逐术",
				}, -- [148]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "正中眉心",
				}, -- [149]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "嗜血",
				}, -- [150]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "圣言术：罚",
				}, -- [151]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "血肉之盾",
				}, -- [152]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰封之韧",
				}, -- [153]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰霜新星",
				}, -- [154]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "守护之魂",
				}, -- [155]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "牺牲祝福",
				}, -- [156]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 1,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "装死",
				}, -- [157]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 2,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "缴械",
				}, -- [158]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 1,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "棱光屏障",
				}, -- [159]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 2,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "决斗",
				}, -- [160]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 2,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "战旗",
				}, -- [161]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 2,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "破胆咆哮",
				}, -- [162]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 1,
					["iconSize"] = 22,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "烈焰护体",
				}, -- [163]
			},
			["DebuffBordersPoisonColor"] = {
				1, -- [1]
				0.04313725490196078, -- [2]
				0.1450980392156863, -- [3]
			},
			["InterruptsGlowType"] = 1,
			["DebuffBordersMagicColor"] = {
				1, -- [1]
				0.0392156862745098, -- [2]
				0.1686274509803922, -- [3]
			},
			["DefaultIconSize"] = 22,
			["DebuffBordersCurseColor"] = {
				nil, -- [1]
				0.04705882352941176, -- [2]
				0.08235294117647059, -- [3]
			},
			["AlwaysShowMyAuras"] = true,
			["HidePlayerBlizzardFrame"] = true,
			["BorderThickness"] = 1,
		},
		["借你流年 - 燃烧之刃"] = {
			["InterruptsGlowType"] = 1,
			["DefaultSpellsLastSetImported"] = 2,
			["StacksTextAnchorIcon"] = "BOTTOMRIGHT",
			["CustomSpells2"] = {
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "盾墙",
				}, -- [1]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "烟雾弹",
				}, -- [2]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "禁锢",
				}, -- [3]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "复仇者之盾",
				}, -- [4]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰霜之柱",
				}, -- [5]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "寒冰屏障",
				}, -- [6]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "痛苦压制",
				}, -- [7]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "激活",
				}, -- [8]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "变形术",
				}, -- [9]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "不灭决心",
				}, -- [10]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "Horde Flag",
				}, -- [11]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "生存本能",
				}, -- [12]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "心灵炸弹",
				}, -- [13]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "散魔功",
				}, -- [14]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "灵魂收割",
				}, -- [15]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "忏悔",
				}, -- [16]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "业报之触",
				}, -- [17]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "追踪者之网",
				}, -- [18]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "仙鹤之道",
				}, -- [19]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "虚空风暴旗帜",
				}, -- [20]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "肾击",
				}, -- [21]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "致盲",
				}, -- [22]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "浮冰",
				}, -- [23]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "屏气凝神",
				}, -- [24]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "治疗绷带",
				}, -- [25]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "风火雷电",
				}, -- [26]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "牺牲咆哮",
				}, -- [27]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "灵魂收割",
				}, -- [28]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "龙息术",
				}, -- [29]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "束缚射击",
				}, -- [30]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "蛮力猛击",
				}, -- [31]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "反魔法护罩",
				}, -- [32]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "备战就绪",
				}, -- [33]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "升腾",
				}, -- [34]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "夺魂咆哮",
				}, -- [35]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "树皮术",
				}, -- [36]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "恐惧嚎叫",
				}, -- [37]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰冷血脉",
				}, -- [38]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "壮胆酒",
				}, -- [39]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "闷棍",
				}, -- [40]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "疾影",
				}, -- [41]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "邪能爆发",
				}, -- [42]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "暗影之怒",
				}, -- [43]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "光环掌握",
				}, -- [44]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "法术反射",
				}, -- [45]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "超凡之盟",
				}, -- [46]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "撕扯",
				}, -- [47]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "躯不坏",
				}, -- [48]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "死亡缠绕",
				}, -- [49]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "偷袭",
				}, -- [50]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "翼龙钉刺",
				}, -- [51]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "消散",
				}, -- [52]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "束缚亡灵",
				}, -- [53]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "致盲冰雨",
				}, -- [54]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "恐惧",
				}, -- [55]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "远古列王守卫",
				}, -- [56]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "妖术",
				}, -- [57]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "闪避",
				}, -- [58]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "施法之环",
				}, -- [59]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "铁木树皮",
				}, -- [60]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "跳跃",
				}, -- [61]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "日光术",
				}, -- [62]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "星界转移",
				}, -- [63]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "凿击",
				}, -- [64]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "锁喉 - 沉默",
				}, -- [65]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "虚空行走",
				}, -- [66]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "天使长",
				}, -- [67]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "Alliance Flag",
				}, -- [68]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "自然的守护",
				}, -- [69]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "威慑",
				}, -- [70]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "主人的召唤",
				}, -- [71]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "影舞步",
				}, -- [72]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "混乱新星",
				}, -- [73]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "流星打击",
				}, -- [74]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "能量灌注",
				}, -- [75]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "被遗忘的女王护卫",
				}, -- [76]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "游侠之网",
				}, -- [77]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "陷地",
				}, -- [78]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "自由祝福",
				}, -- [79]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "破胆怒吼",
				}, -- [80]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "寒冰形态",
				}, -- [81]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "掠食者的迅捷",
				}, -- [82]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "黑暗契约",
				}, -- [83]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰冻陷阱",
				}, -- [84]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "分筋错骨",
				}, -- [85]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "打磨利刃",
				}, -- [86]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "鲁莽",
				}, -- [87]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "虚空联结",
				}, -- [88]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "心灵尖啸",
				}, -- [89]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "迷魅",
				}, -- [90]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "幻影打击",
				}, -- [91]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冲锋",
				}, -- [92]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "幽灵视觉",
				}, -- [93]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "险境求生",
				}, -- [94]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "罪与罚",
				}, -- [95]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "遗言",
				}, -- [96]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "痛苦无常",
				}, -- [97]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰霜之环",
				}, -- [98]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "以眼还眼",
				}, -- [99]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "窒息",
				}, -- [100]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "虚空形态",
				}, -- [101]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "盲目之光",
				}, -- [102]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "保护祝福",
				}, -- [103]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "恶魔变形",
				}, -- [104]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "纠缠根须",
				}, -- [105]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "精神控制",
				}, -- [106]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "灵龟守护",
				}, -- [107]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "扫堂腿",
				}, -- [108]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰冻之箭",
				}, -- [109]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "诱惑",
				}, -- [110]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "虚空守卫",
				}, -- [111]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "剑在人在",
				}, -- [112]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "风暴之锤",
				}, -- [113]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "诱捕",
				}, -- [114]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "圣盾术",
				}, -- [115]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "静电充能",
				}, -- [116]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "暗影之刃",
				}, -- [117]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "巨斧投掷",
				}, -- [118]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "时光护盾",
				}, -- [119]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "奥术强化",
				}, -- [120]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "禅悟冥想",
				}, -- [121]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "暗影映像",
				}, -- [122]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "窒息",
				}, -- [123]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "天神下凡",
				}, -- [124]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "炽热防御者",
				}, -- [125]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "旋风",
				}, -- [126]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "沉默",
				}, -- [127]
				{
					["enabledState"] = 2,
					["checkSpellID"] = {
						[163505] = true,
					},
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["pvpCombat"] = 1,
					["iconSize"] = 45,
					["glowType"] = 3,
					["auraType"] = 3,
					["spellName"] = "斜掠",
				}, -- [128]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "狂暴之怒",
				}, -- [129]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "剑刃风暴",
				}, -- [130]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "圣光护盾",
				}, -- [131]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冲动",
				}, -- [132]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "作茧缚命",
				}, -- [133]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "黑暗天使长",
				}, -- [134]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "吸血鬼的拥抱",
				}, -- [135]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "制裁之锤",
				}, -- [136]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "灵体形态",
				}, -- [137]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "暗影斗篷",
				}, -- [138]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰冻术",
				}, -- [139]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "群体缠绕",
				}, -- [140]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "怒雷破",
				}, -- [141]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "震荡波",
				}, -- [142]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "战神",
				}, -- [143]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "根基图腾效果",
				}, -- [144]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "驱散射击",
				}, -- [145]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "元素宗师",
				}, -- [146]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "割碎",
				}, -- [147]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "放逐术",
				}, -- [148]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "正中眉心",
				}, -- [149]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "嗜血",
				}, -- [150]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "圣言术：罚",
				}, -- [151]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "血肉之盾",
				}, -- [152]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰封之韧",
				}, -- [153]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "冰霜新星",
				}, -- [154]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "守护之魂",
				}, -- [155]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 3,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "牺牲祝福",
				}, -- [156]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 1,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "装死",
				}, -- [157]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 2,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "缴械",
				}, -- [158]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 1,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "棱光屏障",
				}, -- [159]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 2,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "决斗",
				}, -- [160]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 2,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "战旗",
				}, -- [161]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 2,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "破胆咆哮",
				}, -- [162]
				{
					["glowType"] = 3,
					["pvpCombat"] = 1,
					["enabledState"] = 2,
					["auraType"] = 1,
					["iconSize"] = 45,
					["showOnEnemies"] = true,
					["showOnFriends"] = true,
					["spellName"] = "烈焰护体",
				}, -- [163]
			},
			["TimerTextAnchorIcon"] = "CENTER",
			["DBVersion"] = 5,
			["HidePlayerBlizzardFrame"] = true,
		},
	},
}
