
AucAdvancedStatPurchasedData = nil
