
AucAdvancedStatHistogramData = nil
