
SexyCooldownDB = {
	["global"] = {
		["dbVersion"] = 3,
	},
	["profileKeys"] = {
		["嘿嘿牛 - 达尔坎"] = "嘿嘿牛 - 达尔坎",
		["Whsi - 伊森利恩"] = "木诺子其 - 索瑞森",
		["云雨別 - 索瑞森"] = "木诺子其 - 索瑞森",
		["Ennysoul - 索瑞森"] = "Ennyin - 索瑞森",
		["额为我 - 战歌"] = "额为我 - 战歌",
		["那片云的味道 - 恶魔之翼"] = "那片云的味道 - 恶魔之翼",
		["你诺 - 索瑞森"] = "你诺 - 索瑞森",
		["幽笠巫 - 熊猫酒仙"] = "木诺子其 - 索瑞森",
		["Lure - 达文格尔"] = "Lure - 达文格尔",
		["我过年好 - 鬼雾峰"] = "我过年好 - 鬼雾峰",
		["Ennyin - 提瑞斯法"] = "Ennyin - 提瑞斯法",
		["Revp - 黑铁"] = "Revp - 黑铁",
		["绑住了风 - 恶魔之翼"] = "Ennyin - 索瑞森",
		["Ennyin - 索瑞森"] = "木诺子其 - 索瑞森",
		["失重 - 冰风岗"] = "失重 - 冰风岗",
		["Nuc - 阿拉希"] = "Nuc - 阿拉希",
		["Oow - 达文格尔"] = "Oow - 达文格尔",
		["闰汐 - 伊森利恩"] = "WARLOCK",
		["別雨 - 索瑞森"] = "木诺子其 - 索瑞森",
		["绑住了风 - 索瑞森"] = "木诺子其 - 索瑞森",
		["浮雲 - 恶魔之翼"] = "浮雲 - 恶魔之翼",
		["Wonderain - 伊森利恩"] = "木诺子其 - 索瑞森",
		["木诺子其 - 索瑞森"] = "木诺子其 - 索瑞森",
		["香水般的温柔 - 恶魔之翼"] = "香水般的温柔 - 恶魔之翼",
		["海雅 - 索瑞森"] = "木诺子其 - 索瑞森",
		["Sotu - 燃烧之刃"] = "Sotu - 燃烧之刃",
	},
	["profiles"] = {
		["嘿嘿牛 - 达尔坎"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000127185349,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.00001668453,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["Whsi - 伊森利恩"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["y"] = -300,
						["x"] = 1.99993896484375,
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["云雨別 - 索瑞森"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["y"] = 39.0000233856931,
						["x"] = 254.000044583251,
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000127185349,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.00001668453,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["Ennysoul - 索瑞森"] = {
			["bars"] = {
				{
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
					["events"] = {
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["额为我 - 战歌"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["那片云的味道 - 恶魔之翼"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
				}, -- [1]
			},
		},
		["你诺 - 索瑞森"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000127185349,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.00001668453,
					},
				}, -- [1]
			},
		},
		["幽笠巫 - 熊猫酒仙"] = {
			["bars"] = {
				{
					["blacklist"] = {
					},
					["events"] = {
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000127185349,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.00001668453,
					},
				}, -- [1]
			},
		},
		["我过年好 - 鬼雾峰"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["Revp - 黑铁"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
				}, -- [1]
			},
		},
		["Lure - 达文格尔"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
				}, -- [1]
			},
		},
		["Ennyin - 提瑞斯法"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["Wonderain - 伊森利恩"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["y"] = 27.9998659767294,
						["x"] = 381.000031864717,
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000127185349,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.00001668453,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["绑住了风 - 恶魔之翼"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["y"] = -298.999992370606,
						["x"] = -6.1035156250e-005,
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["Ennyin - 索瑞森"] = {
			["bars"] = {
				{
					["events"] = {
						["ITEM_COOLDOWN"] = false,
						["INTERNAL_ITEM_COOLDOWN"] = false,
					},
					["blacklist"] = {
						["spell:108503"] = "魔典：恶魔牺牲",
						["item:85021"] = "恶毒角斗士的邪纹护手",
						["spell:112948"] = "寒冰炸弹",
						["spell:125439"] = "复活战斗宠物",
						["spell:11426"] = "寒冰护体",
						["spell:120451"] = "克索诺斯之焰",
					},
					["eventColors"] = {
						["SPELL_COOLDOWN"] = {
							["a"] = 1,
							["b"] = 0.0392156862745098,
							["g"] = 0.0509803921568627,
							["r"] = 0.968627450980392,
						},
						["PET_SPELL_COOLDOWN"] = {
							["a"] = 1,
							["b"] = 0.145098039215686,
							["g"] = 0.466666666666667,
							["r"] = 1,
						},
					},
					["icon"] = {
						["showStacks"] = false,
						["splashScale"] = 15,
						["border"] = "None",
						["sizeOffset"] = 6,
						["disableMouse"] = false,
						["splashSpeed"] = 0.8,
						["borderColor"] = {
							["a"] = 0,
							["b"] = 1,
							["g"] = 1,
							["r"] = 1,
						},
						["disableTooltip"] = true,
						["pulseSpeed"] = 0.5,
						["fontColor"] = {
							["a"] = 1,
							["b"] = 0.109803921568628,
							["g"] = 0.0352941176470588,
							["r"] = 1,
						},
					},
					["bar"] = {
						["fontColor"] = {
							["a"] = 1,
							["b"] = 0.741176470588235,
							["g"] = 0.682352941176471,
							["r"] = 0.694117647058824,
						},
						["y"] = 99,
						["advancedOptions"] = true,
						["borderColor"] = {
							["a"] = 0,
							["b"] = 1,
							["g"] = 0.52156862745098,
							["r"] = 0.301960784313726,
						},
						["border"] = "None",
						["width"] = 449.999877929688,
						["maxDuration"] = 190,
						["x"] = 319.000061035156,
						["name"] = "Bar 0",
						["lock"] = true,
						["height"] = 33.0000648498535,
						["fontsize"] = 10,
						["backgroundColor"] = {
							["a"] = 0,
							["b"] = 0.815686274509804,
							["g"] = 0.925490196078432,
							["r"] = 1,
						},
						["texture"] = "BantoBar",
					},
				}, -- [1]
			},
		},
		["失重 - 冰风岗"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000152587891,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
				}, -- [1]
			},
		},
		["別雨 - 索瑞森"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["y"] = 87.9999694824219,
						["x"] = 279.000183105469,
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000648498535,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["Oow - 达文格尔"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["y"] = -286.999977111816,
						["x"] = 20.9999389648438,
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["Nuc - 阿拉希"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
				}, -- [1]
			},
		},
		["WARLOCK"] = {
			["bars"] = {
				{
					["events"] = {
						["ITEM_COOLDOWN"] = false,
						["INTERNAL_ITEM_COOLDOWN"] = false,
					},
					["blacklist"] = {
						["spell:108503"] = "魔典：恶魔牺牲",
						["item:85021"] = "恶毒角斗士的邪纹护手",
						["spell:112948"] = "寒冰炸弹",
						["spell:125439"] = "复活战斗宠物",
						["spell:11426"] = "寒冰护体",
						["spell:120451"] = "克索诺斯之焰",
					},
					["eventColors"] = {
						["SPELL_COOLDOWN"] = {
							["a"] = 1,
							["b"] = 0.0392156862745098,
							["g"] = 0.0509803921568627,
							["r"] = 0.968627450980392,
						},
						["PET_SPELL_COOLDOWN"] = {
							["a"] = 1,
							["b"] = 0.145098039215686,
							["g"] = 0.466666666666667,
							["r"] = 1,
						},
					},
					["icon"] = {
						["showStacks"] = false,
						["splashScale"] = 15,
						["border"] = "None",
						["sizeOffset"] = 6,
						["disableMouse"] = false,
						["splashSpeed"] = 0.8,
						["borderColor"] = {
							["a"] = 0,
							["b"] = 1,
							["g"] = 1,
							["r"] = 1,
						},
						["disableTooltip"] = true,
						["pulseSpeed"] = 0.5,
						["fontColor"] = {
							["a"] = 1,
							["b"] = 0.109803921568628,
							["g"] = 0.0352941176470588,
							["r"] = 1,
						},
					},
					["bar"] = {
						["fontColor"] = {
							["a"] = 1,
							["b"] = 0.741176470588235,
							["g"] = 0.682352941176471,
							["r"] = 0.694117647058824,
						},
						["borderColor"] = {
							["a"] = 0,
							["b"] = 1,
							["g"] = 0.52156862745098,
							["r"] = 0.301960784313726,
						},
						["advancedOptions"] = false,
						["border"] = "None",
						["width"] = 449.999877929688,
						["y"] = 52.9998513435764,
						["x"] = 224.999938321944,
						["name"] = "Bar 0",
						["lock"] = true,
						["height"] = 33.0000648498535,
						["fontsize"] = 10,
						["backgroundColor"] = {
							["a"] = 0,
							["b"] = 0.815686274509804,
							["g"] = 0.925490196078432,
							["r"] = 1,
						},
						["texture"] = "BantoBar",
					},
				}, -- [1]
			},
		},
		["绑住了风 - 索瑞森"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["y"] = 79.000244140625,
						["x"] = 248.999877929688,
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000152587891,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
				}, -- [1]
			},
		},
		["浮雲 - 恶魔之翼"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000152587891,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["闰汐 - 伊森利恩"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["y"] = -5.99984741210938,
						["x"] = 171,
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["木诺子其 - 索瑞森"] = {
			["bars"] = {
				{
					["events"] = {
						["ITEM_COOLDOWN"] = true,
						["INTERNAL_ITEM_COOLDOWN"] = true,
					},
					["bar"] = {
						["fontColor"] = {
							["a"] = 1,
							["r"] = 0.694117647058824,
							["g"] = 0.682352941176471,
							["b"] = 0.741176470588235,
						},
						["y"] = 99,
						["backgroundColor"] = {
							["a"] = 0,
							["r"] = 1,
							["g"] = 0.925490196078432,
							["b"] = 0.815686274509804,
						},
						["name"] = "Bar 0",
						["border"] = "None",
						["width"] = 448.000061035156,
						["maxDuration"] = 190,
						["x"] = 319.000061035156,
						["fontsize"] = 10,
						["lock"] = true,
						["height"] = 62.0000114440918,
						["borderColor"] = {
							["a"] = 0,
							["r"] = 0.301960784313726,
							["g"] = 0.52156862745098,
							["b"] = 1,
						},
						["advancedOptions"] = true,
						["texture"] = "BantoBar",
					},
					["eventColors"] = {
						["SPELL_COOLDOWN"] = {
							["a"] = 1,
							["r"] = 0.968627450980392,
							["g"] = 0.0509803921568627,
							["b"] = 0.0392156862745098,
						},
						["PET_SPELL_COOLDOWN"] = {
							["a"] = 1,
							["r"] = 1,
							["g"] = 0.466666666666667,
							["b"] = 0.145098039215686,
						},
					},
					["icon"] = {
						["fontColor"] = {
							["a"] = 1,
							["r"] = 1,
							["g"] = 0.0352941176470588,
							["b"] = 0.109803921568628,
						},
						["splashScale"] = 15,
						["border"] = "None",
						["sizeOffset"] = -24,
						["disableMouse"] = false,
						["splashSpeed"] = 0.8,
						["showStacks"] = false,
						["disableTooltip"] = true,
						["pulseSpeed"] = 0.5,
						["borderColor"] = {
							["a"] = 0,
							["r"] = 1,
							["g"] = 1,
							["b"] = 1,
						},
					},
					["blacklist"] = {
						["spell:108503"] = "魔典：恶魔牺牲",
						["spell:120451"] = "克索诺斯之焰",
						["spell:125439"] = "复活战斗宠物",
						["spell:112948"] = "寒冰炸弹",
						["spell:11426"] = "寒冰护体",
						["item:85021"] = "恶毒角斗士的邪纹护手",
					},
				}, -- [1]
			},
		},
		["Sotu - 燃烧之刃"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
				}, -- [1]
			},
		},
		["海雅 - 索瑞森"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["y"] = 25.9999805803016,
						["x"] = 252.000054156342,
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000127185349,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.00001668453,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["香水般的温柔 - 恶魔之翼"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["name"] = "Bar 0",
						["borderColor"] = {
						},
						["height"] = 33.0000038146973,
						["fontColor"] = {
						},
						["backgroundColor"] = {
						},
						["width"] = 450.000030517578,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
	},
}
