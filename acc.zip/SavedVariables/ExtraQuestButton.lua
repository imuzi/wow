
ExtraQuestButtonDB = nil
ExtraQuestButtonDB2 = {
	["profileKeys"] = {
		["Ennyin - 埃加洛尔"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["position"] = {
				nil, -- [1]
				nil, -- [2]
				"CENTER", -- [3]
				161.7777557373047, -- [4]
				58.66683959960938, -- [5]
			},
		},
	},
}
