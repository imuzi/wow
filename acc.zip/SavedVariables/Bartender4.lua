
Bartender4DB = {
	["namespaces"] = {
		["StatusTrackingBar"] = {
			["profiles"] = {
				["Ennyin - 埃加洛尔"] = {
					["enabled"] = true,
					["position"] = {
						["x"] = -256,
						["point"] = "BOTTOM",
						["scale"] = 0.6299999952316284,
						["y"] = 52,
					},
					["version"] = 3,
				},
			},
		},
		["ActionBars"] = {
			["profiles"] = {
				["Ennyin - 埃加洛尔"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["padding"] = 6,
							["position"] = {
								["x"] = -256,
								["point"] = "BOTTOM",
								["y"] = 41.75,
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["x"] = -231.5000305175781,
								["point"] = "CENTER",
								["y"] = -205,
							},
						}, -- [2]
						{
							["rows"] = 12,
							["version"] = 3,
							["padding"] = 5,
							["position"] = {
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
								["y"] = 610,
							},
						}, -- [3]
						{
							["rows"] = 12,
							["version"] = 3,
							["padding"] = 5,
							["position"] = {
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
								["y"] = 610,
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["x"] = -232,
								["point"] = "BOTTOM",
								["y"] = 94,
							},
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["x"] = -232,
								["point"] = "BOTTOM",
								["y"] = 132,
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						[10] = {
						},
					},
				},
			},
		},
		["LibDualSpec-1.0"] = {
		},
		["ExtraActionBar"] = {
			["profiles"] = {
				["Ennyin - 埃加洛尔"] = {
					["position"] = {
						["x"] = -63.50006103515625,
						["point"] = "CENTER",
						["y"] = -192.4999237060547,
					},
					["version"] = 3,
				},
			},
		},
		["MicroMenu"] = {
			["profiles"] = {
				["Ennyin - 埃加洛尔"] = {
					["enabled"] = false,
					["position"] = {
						["x"] = -198.8000634888813,
						["point"] = "CENTER",
						["scale"] = 0.800000011920929,
						["y"] = 41.99995895028042,
					},
					["version"] = 3,
				},
			},
		},
		["BagBar"] = {
			["profiles"] = {
				["Ennyin - 埃加洛尔"] = {
					["enabled"] = false,
					["version"] = 3,
					["position"] = {
						["x"] = 58.49993896484375,
						["point"] = "CENTER",
						["y"] = 1.50006103515625,
					},
				},
			},
		},
		["BlizzardArt"] = {
			["profiles"] = {
				["Ennyin - 埃加洛尔"] = {
					["artLayout"] = "ONEBAR",
					["position"] = {
						["x"] = -256,
						["point"] = "BOTTOM",
						["y"] = 47,
					},
					["version"] = 3,
				},
			},
		},
		["StanceBar"] = {
			["profiles"] = {
				["Ennyin - 埃加洛尔"] = {
					["enabled"] = false,
					["position"] = {
						["x"] = -82.5,
						["point"] = "CENTER",
						["y"] = -15,
					},
					["version"] = 3,
				},
			},
		},
		["PetBar"] = {
			["profiles"] = {
				["Ennyin - 埃加洛尔"] = {
					["version"] = 3,
					["position"] = {
						["x"] = -164,
						["point"] = "BOTTOM",
						["y"] = 164,
					},
				},
			},
		},
		["Vehicle"] = {
			["profiles"] = {
				["Ennyin - 埃加洛尔"] = {
					["position"] = {
						["x"] = 104.5,
						["point"] = "CENTER",
						["y"] = 42.50006103515625,
					},
					["version"] = 3,
				},
			},
		},
	},
	["profileKeys"] = {
		["Ennyin - 埃加洛尔"] = "Ennyin - 埃加洛尔",
	},
	["profiles"] = {
		["Ennyin - 埃加洛尔"] = {
			["focuscastmodifier"] = false,
			["outofrange"] = "hotkey",
		},
	},
}
