
MasqueDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Ennyin - 埃加洛尔"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["Groups"] = {
				["flyPlateBuffs"] = {
					["Inherit"] = false,
				},
				["Raven_目标"] = {
					["Inherit"] = false,
				},
				["Dominos_Action Bar 1"] = {
					["Inherit"] = false,
				},
				["AdiButtonAuras"] = {
					["Inherit"] = false,
				},
				["Dominos_Action Bar 3"] = {
					["Inherit"] = false,
				},
				["TellMeWhen_分组: 2"] = {
					["Inherit"] = false,
				},
				["WeakAuras_WMzbjelm7Xk"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["Dominos_Action Bar 4"] = {
					["Inherit"] = false,
				},
				["Dominos_Action Bar 5"] = {
					["Inherit"] = false,
				},
				["WeakAuras"] = {
					["Inherit"] = false,
				},
				["Dominos_Pet Bar"] = {
					["Inherit"] = false,
				},
				["WeakAuras_n7rBcOvb5a4"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["TellMeWhen_分组: 3"] = {
					["Inherit"] = false,
				},
				["WeakAuras_h2To4gvWX)3"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["Raven_Buffs"] = {
					["Inherit"] = false,
				},
				["Raven_SLEEP NOW"] = {
					["Inherit"] = false,
				},
				["Raven_集中值"] = {
					["Inherit"] = false,
				},
				["OmniBar_虚空守卫"] = {
					["Inherit"] = false,
				},
				["Dominos_Bag Bar"] = {
					["Inherit"] = false,
				},
				["WeakAuras_JX(vtJPREYG"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["TellMeWhen_分组: 1"] = {
					["Inherit"] = false,
				},
				["TellMeWhen_|cff00c300共用|r 分组: 2"] = {
					["Inherit"] = false,
				},
				["WeakAuras_3d2rZ5Y3Njw"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["Dominos_Action Bar 6"] = {
					["Inherit"] = false,
				},
				["Dominos_Action Bar 2"] = {
					["Inherit"] = false,
				},
				["Diminish"] = {
					["Inherit"] = false,
				},
				["OmniBar_法术封锁"] = {
					["Inherit"] = false,
				},
				["Dominos"] = {
					["Inherit"] = false,
				},
				["WeakAuras_8bAlz)EZ2Nz"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["Dominos_Action Bar 7"] = {
					["Inherit"] = false,
				},
				["Raven"] = {
					["Inherit"] = false,
				},
				["Dominos_Action Bar 10"] = {
					["Inherit"] = false,
				},
				["OmniBar"] = {
					["Inherit"] = false,
				},
				["TellMeWhen"] = {
					["Inherit"] = false,
				},
				["TellMeWhen_分组: 9"] = {
					["Inherit"] = false,
				},
				["WeakAuras_5VSDmnqWhdp"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["TellMeWhen_分组: 4"] = {
					["Inherit"] = false,
				},
				["Dominos_Action Bar 8"] = {
					["Inherit"] = false,
				},
				["TellMeWhen_分组: 5"] = {
					["Inherit"] = false,
				},
				["TellMeWhen_分组: 11"] = {
					["Inherit"] = false,
				},
				["TellMeWhen_分组: 10"] = {
					["Inherit"] = false,
				},
				["TellMeWhen_分组: 7"] = {
					["Inherit"] = false,
				},
				["Raven_Debuffs"] = {
					["Inherit"] = false,
				},
				["WeakAuras_NiOlq8j4mhZ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["WeakAuras_v0IfEQpa)nw"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["TellMeWhen_分组: 8"] = {
					["Inherit"] = false,
				},
				["Raven_Timeline"] = {
					["Inherit"] = false,
				},
				["TellMeWhen_|cff00c300共用|r 分组: 1"] = {
					["Inherit"] = false,
				},
				["Dominos_Action Bar 9"] = {
					["Inherit"] = false,
				},
				["WeakAuras_m4QVb6l2n6J"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
			},
		},
	},
}
