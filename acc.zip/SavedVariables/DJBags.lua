
DJBags_DB = {
	["categories"] = {
	},
	["newItems"] = {
	},
	["bagSettings"] = {
		["DJBagsReagents"] = {
			["maxColumns"] = 10,
			["containerSpacing"] = 5,
			["scale"] = 1,
			["padding"] = 5,
			["itemSpacing"] = 5,
			["filters"] = {
			},
		},
		["DJBagsBag"] = {
			["maxColumns"] = 10,
			["containerSpacing"] = 5,
			["scale"] = 1,
			["padding"] = 5,
			["itemSpacing"] = 5,
			["filters"] = {
			},
		},
		["DJBagsBank"] = {
			["maxColumns"] = 10,
			["containerSpacing"] = 5,
			["scale"] = 1,
			["padding"] = 5,
			["itemSpacing"] = 5,
			["filters"] = {
			},
		},
	},
	["VERSION"] = 0.8,
}
