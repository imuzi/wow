
CHANNELPULLOUT_OPTIONS = {
	["displayActive"] = true,
	["name"] = "频道名单",
}
